# Manual Activation Security Audit

**Date:** 2026-11-08
**Scope:** Customer requests, operator payment confirmation, activation-code issuance, bot authentication, customer redemption, code storage, and auditability.

## 1. Assets and threats

Assets:

- Paid subscription entitlement.
- Activation codes in transit and at rest.
- Bot credential (`BOT_API_TOKEN`).
- Operator and customer identities.
- Payment-confirmation state and audit records.

Threats considered:

- Reading raw activation codes from the database or backups.
- Guessing or brute-forcing codes.
- Reusing a code or redeeming another customer's code.
- Issuing multiple live codes for one payment.
- Issuing a code before payment is verified.
- Forging bot requests from a browser or unauthenticated client.
- Concurrent redemption creating two active subscriptions.
- Exposing payment or activation secrets in frontend bundles or logs.
- False “paid” state caused by simulated payments.

## 2. Controls implemented

### 2.1 Hash-only storage

- Raw codes are generated with `secrets.choice` from a 36-character alphabet, 16 characters long.
- Only `sha256(normalized_code)` is persisted in `ActivationCode.code_hash`.
- A four-character `code_hint` supports operator support without revealing the usable code.
- The raw code is attached to the in-memory object as `raw_code` only at issuance and is returned once in the API response.
- The database has no `code` column. Searches, admin, and serializers expose the hint, not the raw code.
- A migration hashed existing stored codes and added hash/revocation/audit fields.

SHA-256 without a per-code salt is acceptable here because the input is high-entropy random (approximately 82.7 bits), not a low-entropy password. A database dump does not reveal a usable code. Offline brute force remains computationally infeasible, and online attempts are throttled.

### 2.2 Single-use and customer binding

Redemption is wrapped in `transaction.atomic()` and locks the code row with `select_for_update()`. It verifies:

- `redeemed_at is null`
- `revoked_at is null`
- `expires_at > now`
- subscription status is `payment_confirmed`
- `subscription.business.owner_id == request.user.pk`
- no other current active subscription exists for the business

Only then does it mark the code redeemed and activate the subscription. A second redemption receives `400`. The isolated pilot and PostgreSQL concurrency tests confirm one winner under concurrent requests.

### 2.3 Reissue revokes prior codes

`issue_for_subscription()` locks the subscription, requires `payment_confirmed`, revokes all prior unredeemed codes, and creates one new code. This prevents several valid codes for a single payment.

### 2.4 Bot authentication boundary

`POST /api/bot/activation-codes/` requires `X-Bot-Token` and compares it with `secrets.compare_digest`. It is not a browser endpoint and the credential is not a `NEXT_PUBLIC_*` variable.

The endpoint additionally requires:

- linked Telegram user (`TelegramLink`)
- business owned by that user
- confirmed subscription
- per-business issuance limit (default 10 per rolling 24 hours)
- bot throttle (30/hour)

Missing configuration returns `503`; invalid credentials return `401`. The Next.js proxy now forwards `X-Bot-Token` only server-to-server, and the Caddy configuration does not expose a direct browser path to Django.

### 2.5 Operator confirmation

Only Django admin actions (or equivalent trusted server code) mark a request `payment_confirmed`. No customer-facing endpoint marks payment confirmed. Simulated membership/subscription payment is blocked with `409`. Manual confirmation records the operator and timestamp.

### 2.6 Audit trail

`ActivationCodeEvent` records issuance, redemption, revocation state, and expired redemption attempts, including actor and timestamp. The code row records issuer/source, expiry, redemption, revocation, and Telegram delivery errors.

### 2.7 Rate limiting and error handling

- Anonymous API: 100/hour.
- Authenticated user: 1000/hour.
- OTP: 5/hour.
- Bot issuance: 30/hour plus the per-business daily limit.
- Health endpoints explicitly bypass throttles; otherwise container probes would exhaust the anonymous limit and report a false outage.
- Django request errors are logged to the container console without code or token values.

### 2.8 Proxy boundary

The API is reached through Caddy and the Next.js same-origin proxy. The proxy was corrected to forward:

- `X-Bot-Token`
- `X-Forwarded-Proto`
- `X-Forwarded-Host`
- `X-Forwarded-For`

Without `X-Forwarded-Proto`, a production `SECURE_SSL_REDIRECT` configuration behind TLS termination could redirect or break API requests. The isolated HTTPS pilot exercised the corrected path.

## 3. Findings fixed during validation

| Finding | Impact | Fix |
|---|---|---|
| Redemption response crashed when `confirmed_by` was set | Customer saw HTTP 500 after successful activation; retry appeared to be a reuse | Replaced non-existent `get_full_name()` with first/last name or email/phone; regression test added |
| Health probes consumed the anonymous throttle | Backend became falsely `unhealthy` after repeated probes and Docker could restart it | Health views now set `throttle_classes = []`; tests make 150 consecutive readiness calls |
| Proxy dropped bot and forwarded headers | Bot issuance returned 401 through HTTPS; TLS termination information was lost | Forward `x-bot-token`, `x-forwarded-proto`, `x-forwarded-host`, `x-forwarded-for` |
| No production request-error logging | 500 cause was invisible under Gunicorn | Added a `django.request` error logger to the console |

## 4. Verification evidence

- 179 backend tests passed; 15 skipped in the SQLite test settings.
- 15 PostgreSQL concurrency tests passed on the isolated cluster.
- Activation tests cover hash-only storage, single use, wrong customer, revocation, expiry, reissue, unauthenticated access, and active-subscription conflict.
- Isolated HTTPS pilot: 23/23 checks passed, including invalid bot token, cross-customer redemption, revoked code, expired code, reuse, and six concurrent redemptions with exactly one success.
- No external payment call, Telegram delivery, or real customer data was used.

## 5. Residual risks and limitations

| Risk | Current state | Recommendation |
|---|---|---|
| Bot token theft | One long-lived shared secret; no rotation UI or IP allowlist | Rotate via environment change, restrict network egress, consider mTLS or signed requests |
| Admin account compromise | Django admin superuser can confirm and issue | Enforce strong admin passwords/2FA at the proxy or identity layer; restrict `/admin/` by network |
| Code delivery failure | Raw code is unrecoverable after issuance | Reissue after fixing delivery; record and monitor `telegram_delivery_error` |
| No per-code salt | Acceptable for 82-bit random codes; hashes are unsalted | Do not replace with human-generated or low-entropy codes |
| Online brute force | Rate limited but not locked per code | Monitor repeated invalid attempts; add alerting if needed |
| Payment verification is human | Operator can make a mistake or act maliciously | Dual review for high-value payments; reconcile against bank records |
| No automated cleanup | Expired/revoked rows remain | Retention policy must be set by the owner; do not delete audit history casually |
| Legacy club path | Trials and simulated subscription activation blocked, but legacy rows remain | Owner decision required before any migration or reuse |
| Production Telegram delivery | Not tested with a live bot in this phase | Test in a controlled production-like channel with a real linked account |

## 6. Conclusion

The activation-code design meets the stated requirements for hash-only storage, one-time use, customer binding, concurrency safety, operator-only issuance, and auditability. The remaining risks are operational rather than missing core controls. The feature is suitable for a controlled pilot, not an unsupervised public launch until admin access, bot-secret handling, delivery failure procedures, and owner payment/renewal policies are finalized.
