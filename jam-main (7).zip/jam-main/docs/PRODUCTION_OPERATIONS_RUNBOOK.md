# Production Operations Runbook

**Status:** Operational guidance for a controlled deployment. No production deployment was performed in this phase.
**Audience:** Operator/superuser responsible for JAM.
**Related:** `SUBSCRIPTION_ARCHITECTURE.md`, `TLS_AND_REVERSE_PROXY_VALIDATION.md`, `DOCKER_BUILD_AND_HEALTHCHECK_REPORT.md`.

## 1. Before first production start

### 1.1 Owner-supplied values

- Real `DOMAIN` and DNS pointing to the host.
- `DJANGO_SECRET_KEY`: long random value.
- `OTPY_API_KEY`: real OTP provider credential.
- `POSTGRES_PASSWORD`: strong database password.
- `TELEGRAM_BOT_TOKEN` and `TELEGRAM_BOT_USERNAME` if Telegram product editing is used.
- Final catalog prices, durations, descriptions, and renewal/refund policy.

### 1.2 Environment

Start from `.env.example`; copy to `.env` and replace every placeholder. Do not commit `.env`.

Minimum production posture:

```text
DJANGO_DEBUG=False
DJANGO_ALLOWED_HOSTS=your.real.domain
DJANGO_CSRF_TRUSTED_ORIGINS=https://your.real.domain
DJANGO_SECURE_SSL_REDIRECT=True
DJANGO_SESSION_COOKIE_SECURE=True
DJANGO_CSRF_COOKIE_SECURE=True
DJANGO_TRUST_PROXY_SSL=True
COMMERCE_ALLOW_SIMULATED_PAYMENTS=False
COMMERCE_ORDER_ONLINE_PAYMENTS_ENABLED=False
```

Do not enable long HSTS until the real domain and certificate are confirmed.

## 2. Release checklist

1. Back up PostgreSQL and the Caddy certificate volume.
2. Confirm `.env` has no placeholder secrets and no real secret has been committed.
3. Build the images:

```bash
docker compose -f docker-compose.prod.yml build
```

4. Validate Compose and Caddy:

```bash
docker compose -f docker-compose.prod.yml config --quiet
docker compose -f docker-compose.prod.yml run --rm caddy caddy validate --config /etc/caddy/Caddyfile
```

5. Start or update:

```bash
docker compose -f docker-compose.prod.yml up -d
docker compose -f docker-compose.prod.yml ps
```

6. Verify:

```bash
curl -I https://your.real.domain/
curl -sS https://your.real.domain/api/health/ready
curl -sS https://your.real.domain/health
```

Expected readiness:

```json
{"status":"ready","checks":{"database":"ok","cache":"ok"}}
```

7. Check logs for migration failures, 500s, certificate errors, and repeated 401s:

```bash
docker compose -f docker-compose.prod.yml logs --tail=200 backend
docker compose -f docker-compose.prod.yml logs --tail=200 caddy
docker compose -f docker-compose.prod.yml logs --tail=200 frontend
```

## 3. First-time catalog setup

1. Create a superuser:

```bash
docker compose -f docker-compose.prod.yml exec backend python manage.py createsuperuser
```

2. Sign in to `/admin/`.
3. Confirm the five seeded `SubscriptionProduct` rows match the owner-approved prices, durations, and entitlement mapping. Do not create a legacy plan.
4. Verify the public catalog:

```bash
curl -sS https://your.real.domain/api/subscriptions/products/
```

## 4. Online purchase operations

1. Customer selects a product at `/subscriptions` or `/panel/plan`.
2. JAM creates a `SubscriptionPurchase` with a server-side price snapshot and initiates ZarinPal payment.
3. The customer returns through the provider redirect. Only server-side callback verification marks the purchase `paid`.
4. `activate_entitlements_for_purchase()` creates the MENU and/or CLUB entitlements atomically. Gold creates both; each is independent.
5. If the provider is unconfigured, the API returns `503 payment_provider_unconfigured` and creates nothing. Do not substitute manual payment.
6. Admin purchase and entitlement visibility lives under `/admin/subscriptions` and `/admin/payments`.

There is no manual confirmation, activation code, trial, deactivation, or simulated subscription payment procedure.

## 5. Health and outage handling

### Backend unhealthy / readiness 503

1. Check `docker compose ps`.
2. If PostgreSQL or Redis is unhealthy, restore that dependency first.
3. Check backend logs for migration or database errors.
4. Do not restart-loop a healthy process for a dependency outage; readiness is intentionally dependency-aware.

### Database restart

The backend readiness probe recovers automatically after PostgreSQL returns. Verify with `/api/health/ready/`. No manual restart should be required.

### Caddy certificate failure

- Confirm DNS points to the host.
- Confirm inbound 80/443.
- Check Caddy logs and certificate volume (`caddy_data`).
- Do not disable TLS or expose Django directly as a workaround.

## 6. Backup and restore

Back up at minimum:

- PostgreSQL data volume/database.
- `media_data` volume.
- `caddy_data` volume (certificates and keys).
- `.env` in a secret manager, not in git.

Example database backup (run with the real service name):

```bash
docker compose -f docker-compose.prod.yml exec -T db \
  pg_dump -U "$POSTGRES_USER" "$POSTGRES_DB" > "backup-$(date +%F-%H%M).sql"
```

Test restoration in a separate environment before relying on a backup. Do not restore over production without a verified backup and an approved maintenance window.

## 7. Updating the application

1. Back up.
2. Pull/build the new images.
3. Run `up -d`; backend migrations run on start.
4. Verify readiness and the plan endpoint.
5. Check logs for errors.
6. If a migration is unsafe or irreversible, stop and use a dedicated migration plan rather than rolling back blindly.

## 8. Secrets and access

- Restrict `/admin/` to trusted networks or an identity-aware proxy.
- Enforce strong admin passwords; add 2FA at the proxy/identity layer if available.
- Never put `DJANGO_SECRET_KEY`, OTP keys, or Telegram tokens in `NEXT_PUBLIC_*` variables.
- Rotate the bot token after suspected exposure and restart both sides.
- Do not log raw codes. The admin action and bot response are the only places a raw code should appear.

## 9. Incident: suspected entitlement misuse

1. Identify the affected `SubscriptionPurchase` and `SubscriptionEntitlement` rows.
2. Revoke only the compromised entitlement through the audited admin action; independent MENU/CLUB entitlements remain untouched.
3. Review `Transaction`, `SubscriptionPurchase`, `AdminAction`, and bot logs.
4. Follow the owner's refund/entitlement policy. There is no automatic refund or code-based recovery.

## 10. Owner decisions still blocking a fully autonomous launch

- Renewal/early-renewal policy.
- Refund/cancellation policy.
- Legacy club-membership treatment.
- Who may confirm payments and issue codes (single operator vs dual control).
- Code delivery channel outside Telegram.
- Data retention for audit events and expired codes.

Do not invent these policies in code or support messages.
