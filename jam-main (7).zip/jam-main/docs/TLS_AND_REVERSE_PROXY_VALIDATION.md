# TLS and Reverse Proxy Validation

**Date:** 2026-11-08
**Status:** Local HTTPS path validated with an internal certificate and configuration equivalent to production. Public DNS/ACME issuance was not tested.

## 1. Topology

```text
Internet / browser
        |
        | :80 / :443
        v
      Caddy
        |
        +-- /admin/*, /static/* --------> backend:8000 (private)
        +-- /media/* -------------------> shared volume
        +-- everything else ------------> frontend:3000 (private)
                                              |
                                              | /api/* same-origin proxy
                                              v
                                         backend:8000 (private)
```

Caddy exposes only ports 80 and 443. The backend and frontend use Compose `expose`, not host port mappings, in production. This prevents bypassing the TLS/proxy boundary on the public host.

## 2. Files

| File | Purpose |
|---|---|
| `Caddyfile` | Production entrypoint: HTTP health/redirect listener plus HTTPS site for `DOMAIN`. |
| `Caddyfile.common` | Shared routing, security headers, body-size limit, logging, media serving. |
| `Caddyfile.local` | Local-only variant with `local_certs` and internal TLS. |
| `docker-compose.prod.yml` | Caddy ports, private services, health checks, volumes, restart policy. |
| `.env.example` | `DOMAIN`, proxy/TLS flags, and deploy-time placeholders. |

Production `Caddyfile` intentionally has no global `email` directive. If the owner wants ACME expiry mail, add a globally valid email block; do not leave an empty `email` value, which prevents Caddy from parsing the configuration.

## 3. Routing decisions

- API traffic does **not** go directly from Caddy to Django. It goes through Next.js so the same-origin proxy can restore Django's trailing slash and preserve POST semantics.
- `/admin/*` and `/static/*` go directly to Django.
- `/media/*` is served from the shared media volume.
- The HTTP listener serves `/healthz` and permanently redirects other HTTP requests to HTTPS.
- Caddy sets standard security headers: `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, `Permissions-Policy`, and removes `Server`.
- Request bodies are capped at 20 MB.

## 4. HTTPS/header forwarding correction

The Next.js proxy originally forwarded only a small header set. During the HTTPS pilot this caused two problems:

1. Bot issuance returned `401` because `X-Bot-Token` was dropped.
2. `X-Forwarded-Proto` was not forwarded, which would break Django's secure-request handling behind TLS termination.

The proxy now forwards:

```text
authorization
content-type
accept
accept-language
cookie
x-bot-token
x-forwarded-proto
x-forwarded-host
x-forwarded-for
```

This is server-to-server only. `BOT_API_TOKEN` is not exposed to the browser.

## 5. Local validation performed

Environment:

- Isolated Compose project (not production).
- `DOMAIN=localhost`.
- Caddy internal CA certificate; TLS verification intentionally disabled for `curl`.
- A test-only `Caddyfile` equivalent to production, with internal TLS and HTTP redirect.
- Backend and frontend healthy.

Commands and observed results:

| Check | Result |
|---|---|
| `http://localhost/healthz` | `200` |
| `http://localhost/` | `301` to `https://localhost/` |
| `https://localhost/` | `200` |
| `https://localhost/api/health/ready` | `200` with `{"status":"ready","checks":{"database":"ok","cache":"ok"}}` |
| `https://localhost/health` | `200` JSON frontend readiness |
| Slashless `POST https://localhost/api/subscriptions/request` without auth | `401`, no redirect to GET |
| `POST /api/bot/activation-codes/` with valid token through the proxy | `201` |
| Same endpoint with invalid token | `401` |
| `https://localhost/panel/plan` while unauthenticated | `200` login shell |
| Database stopped, `GET /api/health/ready` | `503` `not_ready`, database unavailable |
| Database restarted, readiness | `200` ready |
| Backend container health during DB outage | `unhealthy` |
| Backend container health after DB recovery | `healthy` |
| Caddy production configuration validation | `Valid configuration` |

The checked-in production `Caddyfile` was validated with:

```bash
docker run --rm -e DOMAIN=localhost \
  -v "$PWD/Caddyfile:/etc/caddy/Caddyfile:ro" \
  -v "$PWD/Caddyfile.common:/etc/caddy/Caddyfile.common:ro" \
  caddy:2.9-alpine caddy validate --config /etc/caddy/Caddyfile
```

Caddy reported a valid configuration. Its informational warning that the HTTP-only listener does not apply automatic HTTPS is expected because that listener exists for health and redirect.

## 6. Production TLS procedure (owner action)

1. Point the approved DNS name (`DOMAIN`) at the host. Both A and AAAA records must be correct if IPv6 is published.
2. Allow inbound TCP 80 and 443. ACME HTTP-01 or TLS-ALPN must be able to complete.
3. Set `DOMAIN=your.real.domain` in the deployment `.env`.
4. Keep the public `Caddyfile` (not `Caddyfile.local`).
5. Build/start with `docker-compose.prod.yml`; Caddy stores certificates in the `caddy_data` volume. Back up that volume.
6. Verify with a real DNS name before enabling HSTS:

```bash
curl -I https://your.real.domain/
curl -sS https://your.real.domain/api/health/ready
```

7. After HTTPS works, set the production security flags in `.env`:

```text
DJANGO_SECURE_SSL_REDIRECT=True
DJANGO_SESSION_COOKIE_SECURE=True
DJANGO_CSRF_COOKIE_SECURE=True
DJANGO_TRUST_PROXY_SSL=True
DJANGO_SECURE_HSTS_SECONDS=31536000
DJANGO_SECURE_HSTS_INCLUDE_SUBDOMAINS=True
```

Do not enable long HSTS before the domain and certificate are confirmed. HSTS is difficult to reverse in browsers.

8. Set `DJANGO_ALLOWED_HOSTS` to the real host; `CSRF_TRUSTED_ORIGINS` to the HTTPS origin.

## 7. Not tested / blocked

- Public ACME issuance for a real domain: **not tested**. No production DNS or public certificate was used.
- Browser trust of a public certificate: **not tested**; local tests used an internal CA.
- Real DNS propagation, firewall, or load-balancer behavior: **not tested**.
- Live Telegram delivery: **not tested**.
- Production HSTS/cookie behavior with a real browser session: **not tested**; only configuration and local HTTPS routing were exercised.

These are deployment-owner steps, not code defects. The TLS/routing path is ready for a controlled domain-based validation.
