# JAM — Production Deployment Readiness

Date: 2026-11-08
Scope: Django settings, Next.js runtime/proxy, Dockerfiles, Compose, environment variables, health checks, backups.
Nothing was deployed. Docker was unavailable on this machine (`docker info` failed), so container startup was **not executed**.

## 1. Result

| Area | Status |
|---|---|
| Django production settings | Implemented; `check --deploy` clean with the documented TLS env |
| Environment template | Added `.env.example` with placeholders only |
| Next.js API/media proxy | Implemented; source-verified and exercised through production smoke |
| Docker images/Compose | Static review only; **not run** (Docker daemon unavailable) |
| TLS/reverse proxy | **Not present**; owner/infrastructure decision required |
| Health checks | Database/Redis only; backend/frontend lack HTTP health checks |
| Backup/restore | Procedures documented below; not executed |
| Secret handling | No secrets baked into images; `.env` excluded from Git |

**Deployment status: NOT YET DEPLOYABLE AS-IS without a TLS/reverse-proxy layer and production health/backup decisions.** The application configuration is otherwise prepared.

## 2. Environment configuration

`.env.example` documents all required variables. Key protections:

| Variable / setting | Production default | Protection |
|---|---|---|
| `DJANGO_DEBUG` | `False` | Debug defaults false |
| `DJANGO_SECRET_KEY` | empty | Django refuses to start when DEBUG=false and empty |
| `OTPY_API_KEY` | empty | Django refuses to start in production when empty |
| `DJANGO_ALLOWED_HOSTS` | `localhost,127.0.0.1` | Must be set to the real host |
| `DJANGO_CSRF_TRUSTED_ORIGINS` | empty | Must list the HTTPS origin |
| `SESSION_COOKIE_SECURE` | true when DEBUG=false | Safe default |
| `CSRF_COOKIE_SECURE` | true when DEBUG=false | Safe default |
| `DJANGO_SECURE_SSL_REDIRECT` | false | Must be enabled behind TLS; defaults false to avoid breaking direct HTTP health checks |
| `DJANGO_SECURE_HSTS_SECONDS` | 0 | Opt-in after HTTPS is verified |
| `DJANGO_TRUST_PROXY_SSL` | false | Enables `X-Forwarded-Proto` trust only when intentionally set |
| `COMMERCE_ALLOW_SIMULATED_PAYMENTS` | false in production | Defaults to `DEBUG` |
| `COMMERCE_ORDER_ONLINE_PAYMENTS_ENABLED` | false | Online order creation returns 503 |
| `ZARINPAL_SANDBOX` | false in production | Changed from unconditional `True` to `not DEBUG` |
| `CORS_ALLOW_ALL_ORIGINS` | false in production | Equals `DEBUG` |
| `REDIS_URL` | empty → local memory cache | Compose sets Redis |
| `API_INTERNAL_URL` | `http://localhost:8000` on the server | Not exposed to the browser |

`NEXT_PUBLIC_DEMO_MODE` and `NEXT_PUBLIC_API_BASE` are build-time variables; they are not secrets and must be set when building the frontend image.

### `check --deploy`

Without TLS flags:

```
4 warnings: W004 (HSTS), W008 (SSL redirect), W012 (session cookie),
W016 (CSRF cookie)
```

With the documented production flags
(`DJANGO_SECURE_SSL_REDIRECT=true`, `DJANGO_SECURE_HSTS_SECONDS=31536000`,
`DJANGO_SECURE_HSTS_INCLUDE_SUBDOMAINS=true`, `DJANGO_TRUST_PROXY_SSL=true`):

```
1 warning: W021 HSTS preload not enabled (optional, owner decision)
```

No critical errors. The warning is expected because HSTS preload is a deliberate owner decision.

## 3. Next.js proxy and media

`frontend/app/api/[...path]/route.ts`:

- Server-only `API_INTERNAL_URL`; the internal backend URL is never sent to the browser.
- Restores Django's trailing slash for `/api/*` while preserving query strings.
- Forwards `Authorization`, `Content-Type`, `Accept`, `Accept-Language`, `Cookie`.
- Forwards method and body for non-GET/HEAD.
- `cache: "no-store"` for all API responses.
- `/api/media-proxy/<path>` maps to `${API_INTERNAL_URL}/media/<path>` and sets `Cache-Control: public, max-age=86400`.
- Upstream status/body are passed through; API body is not cached.
- Network failure returns 502 JSON `api_unreachable` without leaking the internal host.

Verified through the production server: public stores, menu, quote, order create/replay, orders, seller orders/status, invalid refresh, online-payment 503, and 502 when the backend is down.

## 4. Docker and Compose

### Dockerfiles

- Backend: Python 3.12-slim, installs the lockfile, collects static with build-only env, runs `migrate --noinput` then Gunicorn 3 workers.
  - Runs as **root** (no `USER` directive). Recommend a non-root runtime user.
  - Migrations run on every container start; no destructive migration was observed, but concurrent replica startups could race. Single-replica or a separate migration job is safer.
- Frontend: multi-stage Node 20, `npm ci`, production build, runtime `npm ci --omit=dev`, non-root `appuser`.
  - `NEXT_PUBLIC_*` variables are **not** passed as build args. The image builds production defaults (demo disabled). If a demo image is ever needed, add an explicit build arg.
  - No health check in the image.

### Compose

- `docker-compose.yml`: `db` and `redis` have healthchecks; backend depends on both; frontend depends on backend.
- `docker-compose.prod.yml`: same services but backend/frontend expose ports `8000:8000` and `3000:3000` directly. There is **no reverse proxy, no TLS termination and no frontend/backend HTTP healthcheck**.
- Database/Redis volumes are named and persistent.
- No restart policies are configured.
- Database password falls back to `jam-local-password` if `.env` is missing. Production should require an explicit value (`${POSTGRES_PASSWORD:?...}`) to fail closed.
- Secrets are supplied via `env_file`, not baked into images.

### Not executed

`docker compose build`, `docker compose up`, container health checks, and image scans could not run because the Docker daemon is unavailable. All Docker findings are static-review findings.

## 5. Required production topology

Before deployment, provide:

1. A TLS-terminating reverse proxy/CDN in front of Next.js and Django (Caddy, nginx, Traefik, or a cloud load balancer).
2. Public exposure of only the frontend/proxy; backend and database on a private network.
3. `DJANGO_SECURE_SSL_REDIRECT=True`, HSTS after verification, and `DJANGO_TRUST_PROXY_SSL=True` only when the proxy overwrites `X-Forwarded-Proto`.
4. `DJANGO_ALLOWED_HOSTS`, `DJANGO_CSRF_TRUSTED_ORIGINS`, `ZARINPAL_CALLBACK_URL` set to the real HTTPS origin.
5. HTTP health endpoints or proxy checks for Next.js and Django (currently only TCP/process-level checks exist).
6. Restart policies and resource limits.
7. A separate migration job or a single backend replica during migration.

## 6. Backup and recovery (documented, not executed)

### Database

```bash
# Logical backup (run from a host with pg_dump and credentials)
pg_dump --format=custom --no-owner --no-privileges \
  --host <db-host> --username <db-user> --dbname <db-name> \
  --file jam-$(date +%Y%m%d-%H%M).dump

# Restore into a NEW empty database, never over the live one
createdb --host <db-host> --username <db-user> jam_restore
pg_restore --no-owner --no-privileges --dbname jam_restore jam-YYYYMMDD-HHMM.dump
```

Verify restore in an isolated environment, check row counts for orders/transactions/settlements, and only then plan a cutover.

### Media

```bash
tar -czf jam-media-$(date +%Y%m%d-%H%M).tar.gz -C backend media
```

Store backups encrypted, off-host, with retention and access control. Test a restore periodically.

### Rollback

- Application: redeploy the previous image tag; keep the previous environment file.
- Database migrations: this phase added only additive constraints/tables; no destructive migration was introduced. Still, do not roll back migrations blindly. Prefer forward-fix or restore into a new database after verifying the dump.
- Media: restore the matching media archive if uploads changed.
- Payment/settlement records must never be deleted or rewritten during rollback.

## 7. Deployment checklist

- [ ] Fill `.env` from `.env.example` with real secrets (never commit).
- [ ] Set `DJANGO_DEBUG=False`, real hosts/origins, strong DB password.
- [ ] Enable TLS redirect/HSTS after HTTPS is verified.
- [ ] Set `ZARINPAL_MERCHANT_ID`, live callback URL, `ZARINPAL_SANDBOX=False`.
- [ ] Keep `COMMERCE_ALLOW_SIMULATED_PAYMENTS=False` and `COMMERCE_ORDER_ONLINE_PAYMENTS_ENABLED=False`.
- [ ] Build frontend with `NEXT_PUBLIC_DEMO_MODE=False`.
- [ ] Add reverse proxy and restrict backend/database network exposure.
- [ ] Add backend/frontend health checks and restart policies.
- [ ] Take and verify a database + media backup before cutover.
- [ ] Run `python manage.py check --deploy` and the full test suite against the release commit.
- [ ] Run a smoke test of public menu, checkout (offline), customer orders and seller orders after deploy.
- [ ] Confirm no demo routes are reachable.

## 8. Verification commands actually run

```bash
cd backend
DJANGO_DEBUG=false DJANGO_SECRET_KEY='...' OTPY_API_KEY='...' \
DJANGO_ALLOWED_HOSTS=example.com POSTGRES_PASSWORD=placeholder \
python3 manage.py check --deploy --settings=config.settings
# 4 warnings without TLS flags; 1 optional HSTS-preload warning with them

docker info   # failed: daemon unavailable (Docker checks BLOCKED)
curl http://127.0.0.1:3100/...  # production proxy smoke, see FINAL_REGRESSION_REPORT.md
```

No deployment, publish, image push or production database operation was performed.
