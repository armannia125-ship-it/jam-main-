# JamPlay Phase 1 — Completion Report

Date: 2026-11-17
Scope: playable Arena, playable Siege, base/building management, chest lifecycle, league, real backend data, persistence, validation, tests.

## Status

**PHASE 1 COMPLETE.**

Every previously unfinished Phase 1 feature is implemented in the existing JAM repository and exercised against a running Django API and a production Next.js build. No Phase 1 feature was moved to Phase 2.

This is not a production-readiness claim. PostgreSQL concurrency, real OTP/payment/storage providers, and Staging execution remain unverified (see Limitations).

## What Was Previously Unfinished

Before this work the `/play` route rendered a 28-line placeholder and the `games` backend could not serve a real battle. The following were missing and are now implemented:

1. Playable Arena (card battle, elixir, towers, crowns, overtime).
2. Playable Siege (isometric base assault, walls, buildings, destruction, stars).
3. Base screen and building upgrades with builder timers.
4. Chest slots, start timers, claim, rewards and idempotency.
5. League payload, trophy progression and league thresholds.
6. Real persisted backend state (no client-side rules engine, no fake outcomes).
7. Server-side validation for every deploy, upgrade, claim and settlement.

## Backend

App: `backend/games/` (new, registered in `config/settings.py`, routed from `config/urls.py`).

| File | Role |
|---|---|
| `rules.py` | Card/building/league constants, 473 lines |
| `combat.py` | Deterministic authoritative arena + siege simulation, 1030 lines |
| `models.py` | `GameProfile`, `PlayerCard`, `DeckCard`, `Battle` (`state`, `last_tick`, `opponent_name`, `difficulty`), `ChestSlot`, ledger |
| `services.py` | Transactions, wallet ledger, chests, buildings, battle start/action/finish, league, idempotent settlement, 876 lines |
| `views.py` / `urls.py` | 18 endpoints under `/api/games/`, all trailing-slash compatible |
| `serializers.py` | Typed API contracts |
| `tests.py` | 39 tests, 15 classes (API, engine, ownership, ledger, league, journeys) |
| `migrations/0002_*.py` | Additive `Battle`/`ChestSlot` migration |

Behaviour guarantees:

- Simulation runs only on the server; the client reports elapsed time and receives snapshots. Snapshots include unit `target` and `path` for presentation only.
- Deploy rules are enforced server-side: own half, river/bridges, wall perimeter, elixir cost, card ownership, deck size/duplicates.
- Arena: 180 s + 60 s overtime, 5/10 elixir, 0.58/1.15 regen, 1900 tower / 3200 king HP, crowns and tie handling.
- Siege: 22×22 base, walls, BFS pathing, destruction percentage and star thresholds.
- Money, XP, trophies, chest and entitlement-like transitions use `transaction.atomic()` + `select_for_update()`; settlement is idempotent.
- Chest ledger keys are per-claim UUIDs, so reusing a slot cannot silently skip payment (a bug found by the test suite and fixed).

Defect found and fixed during live verification:

- A retried `arena/finish` returned `{ok, already_settled, battle}` without `rewards`/`profile`/`chests`, so a client retry could render a result screen with no rewards. It now returns the same result payload as the first settlement; covered by a regression assertion in `games/tests.py`.

## Frontend

| File | Role |
|---|---|
| `frontend/app/play/page.tsx` | Full game shell: lobby, collection, deck editor, chests, base, Arena, Siege, result modal, HUD, toasts (1821 lines) |
| `frontend/app/play/ArenaField.tsx` | Canvas arena renderer with target lines, hit flash, interpolated snapshots |
| `frontend/app/play/SiegeField.tsx` | Isometric canvas base renderer |
| `frontend/app/play/BaseField.tsx` | Isometric SVG base view |
| `frontend/app/play/types.ts` | Explicit API contracts (no `any`) |
| `frontend/app/play/jamplay.css` | Prototype styling + integration block + final layout guard |
| `frontend/public/jamplay/*` | Prototype art assets |

Integration rules preserved: `apiFetch` + `lib/api.ts`, JWT in `jam.auth.v1`, same-origin `/api` proxy, trailing slashes, Persian RTL, existing CSS variables/tokens. No new packages, no client-side rules engine, no fake timers.

Defects found in browser QA and fixed:

1. The imported prototype CSS contains a later legacy shell that re-declared `#app` with auto-sized grid tracks. After minification the base grid collapsed, producing a zero-width content column: the lobby rendered blank. A final `.jg #app` layout guard now pins an explicit single-column, `hud/nav/main` grid.
2. The game tab bar originally shared the bottom edge with the site's fixed bottom navigation and was covered on mobile. The game shell now places it directly under the HUD.

## Validation (commands actually run)

Backend (`cd backend`):

| Command | Result |
|---|---|
| `python3 manage.py check --settings=config.test_settings` | System check identified no issues (0 silenced) |
| `python3 manage.py makemigrations --check --dry-run --settings=config.test_settings` | No changes detected |
| `python3 manage.py test games --settings=config.test_settings` | **Ran 39 tests — OK (skipped=1)** |
| `python3 manage.py test --settings=config.test_settings` | **Ran 265 tests — OK (skipped=19)** |

Frontend (`cd frontend`):

| Command | Result |
|---|---|
| `npx tsc --noEmit` | exit 0, 0 errors |
| `npm run lint` | exit 0, **0 errors, 40 warnings** (11 pre-existing; the rest are `<img>` advisories in the new play files) |
| `npm run build` | Compiled successfully; `/play` **18.2 kB**, 124 kB first load |

Live API verification (temporary SQLite settings, Django on `127.0.0.1:8011`, real JWT):

- **34/34 checks PASS**, covering: profile bootstrap (500 coins / 30 gems), 8-card deck, league payload, 4 chest slots, welcome chest claim, duplicate-claim rejection, single credit, building upgrade + coin deduction + single-builder enforcement + early-completion rejection, Arena start/snapshot/deploy/unit spawn/enemy-half rejection/server-side advance/settlement/reward ledger/settlement idempotency, Siege start/base/walls/deploy/inside-wall rejection/simulation/settlement, league endpoint, battle history, persisted stats, best-trophy consistency, non-negative wallet.
- Next.js production server proxy: `GET /play` → 200; `GET /api/games/profile/` with JWT → 200; without JWT → 401.

Browser visual QA (headless Chrome via DevTools Protocol, temporary local servers):

- Captured and inspected at **390×844** and **1440×900**: lobby, collection, deck editor, chests, Arena prep sheet, live Arena with deployed unit and tower damage, Siege prep sheet, live Siege base, siege result modal.
- RTL verified (`dir="rtl"`), Persian copy, resource HUD, league progress, cards, timers and result screens all render.
- The two layout defects above were found here and fixed, then re-verified.

## Changed Files

Backend:
- `backend/games/` — new app (`__init__.py`, `rules.py`, `combat.py`, `models.py`, `serializers.py`, `services.py`, `views.py`, `urls.py`, `tests.py`, `migrations/`).
- `backend/config/settings.py` — adds `games` to `INSTALLED_APPS` (CORS/DRF/SimpleJWT stack preserved).
- `backend/config/urls.py` — mounts `api/games/`.
- `backend/commerce/models.py` — `CheckConstraint(check=...)` → `condition=...` for Django 5.1/5.2 compatibility (no migration generated).

Frontend:
- `frontend/app/play/page.tsx` — replaced the placeholder.
- `frontend/app/play/{ArenaField,SiegeField,BaseField}.tsx`, `types.ts`, `jamplay.css` — new.
- `frontend/public/jamplay/` — prototype assets.

No commit, push, deploy, migration against a real database, or provider call was performed.

## Limitations / Not Verified

- **PostgreSQL concurrency: 19 tests skipped.** This environment has no PostgreSQL/Docker; SQLite skips every PostgreSQL-only concurrency test. Locking, constraint and callback races under PostgreSQL remain unverified.
- **No CI/CD exists in the repository.** All results above are local/manual.
- Browser QA used a temporary SQLite settings module and local Django/Next processes, not Staging. Real OTP delivery, Zarinpal, Telegram and S3 were not exercised and remain out of scope.
- Headless Chrome only: no real-device touch testing, no iOS/Android hardware pass.
- Siege visual QA shows intentional letterboxing around the isometric board on a tall phone viewport; functional siege deployment is covered by the engine/API tests.
- `/play` is still rendered inside the site header/footer chrome; the game tab bar was moved under the HUD so it remains reachable. A dedicated full-screen route would be a separate layout decision.
