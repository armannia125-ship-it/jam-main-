# Final Deployment Regression Report

**Date:** 2026-11-08
**Repository:** `/Users/erfmollaey/projects/polaris-jam`
**Branch/HEAD:** `main` at `5985bcd` at the start of the phase; working tree intentionally left uncommitted.
**Scope:** Final regression for the Deployment Foundation and Offline Commerce Pilot phase.

## 1. Status summary

| Area | Result |
|---|---|
| Backend test suite | **Passed**: 179 tests, 15 skipped |
| PostgreSQL concurrency suite | **Passed**: 15/15 |
| Manual subscription HTTPS pilot | **Passed**: 23/23 |
| Frontend ESLint | **Passed with warnings**: 0 errors, 11 warnings |
| TypeScript | **Passed**: no errors |
| Next.js production build | **Passed** |
| Docker backend/frontend images | **Passed** |
| Isolated Compose stack | **Passed**: all five services healthy |
| Readiness under DB outage | **Passed**: `503 / not_ready`, container `unhealthy`; recovery to `200 / healthy` |
| Local HTTPS routing | **Passed** with internal certificate |
| Public TLS/ACME | **Not tested** |
| Live Telegram delivery | **Not tested** |
| Real payment | **Not tested** (manual outside JAM) |
| Commit/push/deploy | **Not performed** |

## 2. Implemented

- Single canonical subscription plan, positive price and duration constraints, no free plan path.
- No free trial: `CLUB_TRIALS_ENABLED=False` default and `403 trial_disabled`.
- Manual request flow with idempotency and active-subscription conflict handling.
- Operator payment confirmation via admin action.
- Hash-only activation codes with one-time use, TTL, customer binding, reissue/revocation, and audit events.
- Server-to-server bot issuance with constant-time token check, Telegram/business binding, daily limit, and throttle.
- Customer redemption API and `/panel/plan` UI.
- Online subscription checkout permanently disabled (`410`).
- Simulated membership/subscription payment blocked (`409`).
- TLS/reverse proxy configuration with Caddy, private backend/frontend networking, media volume, health checks, and restart policy.
- Liveness/readiness endpoints and frontend health endpoint.
- Production request-error logging.
- ESLint flat configuration and `npm run lint`.
- Production operations and security documentation.
- Isolated HTTPS pilot with synthetic data.

## 3. Tested and passed

### 3.1 Backend

```bash
cd backend
python3 manage.py test --settings=config.test_settings
```

Result:

```text
Ran 179 tests
OK (skipped=15)
```

The 15 skips are SQLite-only test settings; PostgreSQL-specific behavior is covered separately.

### 3.2 PostgreSQL concurrency

```bash
PGTEST_PORT=55432 python3 manage.py test \
  subscriptions.test_concurrency commerce.test_concurrency \
  --settings=config.concurrency_settings
```

Result:

```text
Ran 15 tests
OK
```

This includes five subscription concurrency tests and existing commerce concurrency coverage.

### 3.3 Frontend

```bash
cd frontend
npm run lint
npx tsc --noEmit
npm run build
```

Results:

- Lint exit `0`; 11 warnings, 0 errors.
- TypeScript exit `0`.
- Build exit `0`; `/panel/plan`, `/health`, and the API proxy routes present.

### 3.4 Isolated HTTPS pilot

23 of 23 checks passed. Covered:

- one plan exposed;
- trial and online checkout disabled;
- pending manual request;
- no provider transaction;
- owner payment info;
- bot issuance, invalid bot token, reissue/revocation;
- hash-only storage;
- unauthenticated and cross-customer rejection;
- successful activation and plan-duration expiry;
- reuse and expired-code rejection;
- expired subscription display;
- six-way concurrent redemption with exactly one success.

### 3.5 Docker and readiness

- Backend and frontend images built successfully.
- Compose production config validation passed.
- All services healthy.
- Stopping PostgreSQL produced `503 not_ready` and backend `unhealthy`.
- Restarting PostgreSQL returned readiness to `200` and backend to `healthy`.
- Health probes no longer consume the anonymous throttle.

### 3.6 TLS/proxy

- HTTP `/healthz` returned `200`.
- HTTP root redirected `301` to HTTPS.
- HTTPS root returned `200`.
- HTTPS readiness returned `200`.
- Slashless unauthenticated POST returned `401`, not a redirect.
- Caddy production configuration validated.

## 4. Failed and fixed during this phase

| Failure | Status |
|---|---|
| Redemption response 500 when `confirmed_by` was set | **Fixed**; serializer uses custom user fields; regression test added |
| Backend false `unhealthy` from health-probe throttling | **Fixed**; health views bypass throttles; 150-request test added |
| Bot issuance 401 through HTTPS because `X-Bot-Token` was dropped | **Fixed**; proxy forwards bot and forwarded headers |
| No production 500 traceback under Gunicorn | **Fixed**; `django.request` console logger added |

No known failing test, build, lint error, or unresolved pilot check remains.

## 5. Not tested

- Real public DNS, ACME certificate issuance, browser trust, firewall/load-balancer behavior.
- Live Telegram bot delivery to a real account.
- OTP login end to end with a real provider.
- Automated browser click-through of `/panel/plan` with an authenticated session.
- Real manual payment and bank reconciliation.
- Production backup/restore.
- Production orchestrator behavior outside Docker Compose.
- Registry push/signing/vulnerability scanning.
- Cross-browser visual/accessibility review.

## 6. Blocked / owner decisions

- Final plan name, price, duration, and description.
- Real manual payment instructions and contact.
- Renewal/early-renewal rules.
- Refund/cancellation policy.
- Treatment of legacy club memberships.
- Production domain and TLS approval.
- Who can confirm payments and issue codes; whether dual control is required.
- Code delivery channel if Telegram is not used.

These cannot be answered by the codebase without inventing business policy or financial details.

## 7. Repository state

The implementation is present in the working tree. No commit, tag, push, release, deployment, or production data change was made. Temporary Compose/PG pilot assets live outside the repository and are disposable.

## 8. Release recommendation

**Conditionally ready for a controlled, owner-supervised pilot.**

Not ready for an unsupervised public launch until:

1. The owner supplies the real plan, payment instructions, and policies.
2. Public DNS/TLS is validated with the real domain.
3. Live Telegram and OTP flows are tested.
4. Admin access and bot-secret handling are hardened.
5. The owner accepts the remaining operational risks in `MANUAL_ACTIVATION_SECURITY_AUDIT.md`.
