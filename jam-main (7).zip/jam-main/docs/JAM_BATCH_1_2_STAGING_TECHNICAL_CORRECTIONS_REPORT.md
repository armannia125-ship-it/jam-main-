# JAM Batch 1.2: Staging Technical Corrections & Verification Report

Date: 2026-11-10
Repository: `/Users/erfmollaey/projects/polaris-jam`
Branch: `main`
HEAD: `fdb1add`
Scope: local repository corrections and local verification only.

## 1. Initial Git Status and Repository State

At the start of the batch:

```
 M .env.example
 M backend/Dockerfile
 M backend/config/settings.py
 M backend/requirements.lock.txt
 M backend/requirements.txt
 M backend/test_settings.py
?? JAM_BATCH_1_1_STAGING_CORRECTIONS_REPORT.md
?? JAM_FREE_STAGING_DEPLOYMENT_ASSESSMENT.md
?? docs/deployment/
```

The six modified files and the Batch 1.1 report/docs were pre-existing owner work. They were preserved. No AGENTS.md, CLAUDE.md, CONTRIBUTING.md, or other instruction file exists in the repository.

No commit, push, tag, or release was made. No external Staging service was contacted.

## 2. Files Inspected

Repository/deployment:

- `backend/requirements.txt`
- `backend/requirements.lock.txt`
- `backend/config/settings.py`
- `backend/config/test_settings.py`
- `backend/test_settings.py`
- `backend/Dockerfile`
- `backend/config/health.py`
- `backend/config/tests.py`
- `backend/config/urls.py`
- `docker-compose.yml`
- `docker-compose.prod.yml`
- `docker-compose.dev.yml`
- `frontend/Dockerfile`
- `.env.example`
- `docs/deployment/STAGING_PREPARATION.md`
- `docs/deployment/STAGING_OPERATIONS.md`
- `JAM_BATCH_1_1_STAGING_CORRECTIONS_REPORT.md`
- `JAM_FREE_STAGING_DEPLOYMENT_ASSESSMENT.md`
- `backend/*/tests.py`, `backend/*/test_*.py` (test inventory)

External platform documentation (read-only; no account or service created):

- <https://render.com/docs/free>
- <https://render.com/docs/ssh>
- <https://render.com/docs/one-off-jobs>
- <https://github.com/jschneier/django-storages/blob/1.14.6/CHANGELOG.rst>

## 3. Files Modified

| File | Change |
|---|---|
| `backend/requirements.txt` | Corrected impossible/incorrect `django-storages[boto3]>=3.12.0` to `>=1.14.6,<2.0` |
| `backend/requirements.lock.txt` | Aligned pin to `django-storages==1.14.6` |
| `backend/config/health.py` | Added backend-aware `cache_status()` used by readiness |
| `backend/config/settings.py` | Added `CACHE_REQUIRE_REDIS`; corrected S3 storage options to `OPTIONS` with django-storages keyword names |
| `backend/config/test_settings.py` | Explicitly set `CACHE_REQUIRE_REDIS = False` for tests |
| `backend/config/tests.py` | Added 6 focused cache/readiness tests |
| `.env.example` | Corrected misleading S3-mode comment (switch is `DEFAULT_FILE_STORAGE_BACKEND`) |
| `docs/deployment/STAGING_PREPARATION.md` | Dependency table, migration limitation, Redis readiness, S3 levels, setup sequence, limitations |
| `docs/deployment/STAGING_OPERATIONS.md` | Render Free migration limitation, Redis checks, S3 `ContentFile` + `try/finally` example, verification levels, stale one-off references |
| `JAM_BATCH_1_2_STAGING_TECHNICAL_CORRECTIONS_REPORT.md` | This report |

## 4. Dependency Versions Before and After

The reported inconsistency was real. `django-storages` has no 3.x release line; `>=3.12.0` could never resolve.

| Dependency | Before | After |
|---|---|---|
| Django | `5.2.18` (lock) | `5.2.18` (unchanged) |
| Python runtime | 3.12 (`python:3.12-slim`) | 3.12 (unchanged) |
| `django-storages` requirement | `django-storages[boto3]>=3.12.0` | `django-storages[boto3]>=1.14.6,<2.0` |
| `django-storages` lock | `==1.14.0` | `==1.14.6` |
| `boto3` lock | `1.35.28` | `1.35.28` (unchanged) |

Selection rationale:

- PyPI reports `django-storages` latest `1.14.6`; no 3.x exists.
- `1.14.6` metadata: `Requires-Python >=3.7`, `Requires-Dist: Django>=3.2`, extra `boto3` requires `boto3>=1.4.4`.
- `django-storages` 1.14.3 was the first release adding Django 5.0 and Python 3.12 support; the project uses Django 5.2.18 on Python 3.12. Keeping `1.14.0` was therefore not an appropriate pin even though it imports.
- `boto3` was not upgraded; no unrelated dependency was changed.
- No lock-generation tool/config (pip-tools, `requirements.in`, Makefile, or documented procedure) exists in the repository. The lock is hand-maintained, so no lock was fabricated. The two files were aligned and then verified by real installation.

## 5. Dependency Resolution Commands and Results

Package-index access was available and used. No Staging service was contacted.

```
$ python3 -m pip index versions django-storages
django-storages (1.14.6)
Available versions: 1.14.6, 1.14.5, 1.14.4, 1.14.3, 1.14.2, 1.14.1, 1.14, ...
```

```
$ python3 -m venv /tmp/jam-lock-verify
$ /tmp/jam-lock-verify/bin/pip install -r backend/requirements.lock.txt
INSTALL_EXIT: 0

$ /tmp/jam-lock-verify/bin/pip check
No broken requirements found.
CHECK_EXIT: 0

$ /tmp/jam-lock-verify/bin/python -c "import django, storages, boto3; ..."
Django 5.2.18
django-storages 1.14.6
boto3 1.35.28

$ /tmp/jam-lock-verify/bin/python -c "from storages.backends.s3boto3 import S3Boto3Storage; print(...)"
S3Boto3Storage import OK
```

```
$ cd backend
$ /tmp/jam-lock-verify/bin/pip install --dry-run --ignore-installed -r requirements.txt
RESOLVE_EXIT: 0
```

Both declarations are now satisfiable and the installed lock version matches the pin.

## 6. Verified Render Migration Method

### Verified platform facts (accessed 2026-11-10)

From Render's own documentation:

- Free instances exist only for Static Site, Web Service, Postgres, and Key Value.
- Free web services explicitly do **not** support:
  - running one-off jobs,
  - shell access via SSH or the Render Dashboard.
- One-off jobs require a base service and use its build artifact/environment; the Free plan cannot run them.

### Repository facts

- `backend/Dockerfile` builds with `python:3.12-slim`, installs `requirements.lock.txt`, runs `collectstatic` at build time, and starts only:
  `gunicorn config.wsgi:application --bind 0.0.0.0:8000 --workers 3 --timeout 60`.
- There is no `ENTRYPOINT`, no start script, and no `migrate` in `CMD` or at build time.
- There is no `render.yaml`; deployment is Render Docker Web Services configured in the dashboard.

### Conclusion

There is **no verified, free-of-charge way to execute `python manage.py migrate` inside a Render Free backend service**. The Batch 1.1 claim that the Render Dashboard "Run console" is available for that purpose was incorrect and has been removed.

`STAGING_OPERATIONS.md` §1B now documents:

- the verified limitation and sources,
- four options with trade-offs (temporary paid instance/one-off job; operator workstation against Neon using the exact commit/image; paid cron/worker; rejected startup migration),
- one-at-a-time, pre/post inspection, failure, and retry handling,
- migration execution as a **Batch 2 deployment blocker**.

No speculative workaround, new service, or automatic startup migration was added. No migration was executed.

## 7. Redis Verification Behavior and Tests

### Behavior

`config.health.cache_status()` now:

1. Reads the actual `CACHES["default"]["BACKEND"]`.
2. Rejects a non-Redis backend when `CACHE_REQUIRE_REDIS` is true.
3. Rejects `django_redis.cache.RedisCache` when `REDIS_URL` is empty.
4. Performs `cache.set` / `cache.get` and returns `ok` only on exact readback.
5. Returns `unavailable` on any connection/TLS/auth/readback failure.
6. Never returns or logs the Redis URL or credentials.

`CACHE_REQUIRE_REDIS` defaults to `not DEBUG`, so deployed environments require Redis while local development may use the in-memory fallback. `config/test_settings.py` sets it to `False`; staging tests override it to `True`.

The readiness contract is unchanged:

```json
{"status": "ready|not_ready", "checks": {"database": "ok|unavailable", "cache": "ok|unavailable"}}
```

A deployed `LocMemCache` fallback now yields HTTP 503 with `cache: "unavailable"` instead of a false `ok`.

### Tests added (`backend/config/tests.py`)

- `test_locmem_is_accepted_only_as_the_local_debug_fallback`
- `test_locmem_is_rejected_outside_the_local_fallback`
- `test_redis_backend_without_redis_url_is_rejected`
- `test_redis_backend_with_readback_is_accepted` (mocked cache; no network)
- `test_redis_backend_connection_failure_is_rejected` (mocked connection failure)
- `test_readiness_reports_locmem_fallback_as_unavailable_in_staging`

No Upstash connection was attempted. Redis-backed tests use mocks or the documented local-only fallback.

### Observed result

```
$ python manage.py test config --settings=config.test_settings
Ran 10 tests in 0.127s
OK
```

```
$ ... manage.py shell -c "from config.health import cache_status; print(cache_status())"   # DEBUG=false, no REDIS_URL
LocMem fallback under DEBUG=false -> unavailable
```

## 8. S3 Integration Example Correction

### Documentation correction

`STAGING_OPERATIONS.md` §6B now uses:

- `django.core.files.base.ContentFile` instead of raw `bytes`;
- a UUID key under `jam-staging-verify/`;
- an explicit overwrite guard;
- `default_storage` (the configured Django backend) rather than a separate boto3 client;
- existence check, readback, exact byte comparison, delete, and post-delete existence check;
- `try/finally` so deletion is attempted even after a failed read/assertion;
- cleanup of both the returned name and the generated key, limited to the UUID-named temporary object.

Levels are now explicitly separated and not overclaimed:

| Level | Meaning | Batch 1.2 status |
|---|---|---|
| A | Configuration-only; no network | Verified locally in filesystem mode and with dummy S3 credentials |
| B | Real S3 upload/read/delete via `default_storage` | **Deferred**; not executed |
| C | Media delivery through the real app path | **Deferred**; not executed |

### Additional defect found and corrected

While performing the required S3 initialization verification, the previous configuration was found to be ineffective: Django passes only `OPTIONS` to a storage backend, but `settings.py` placed `BUCKET_NAME` and `AWS_*` keys at the top level. They were silently ignored; `default_storage.bucket_name` was `None` even with a configured bucket.

The configuration now uses `OPTIONS` with django-storages 1.14.x keyword names (`bucket_name`, `access_key`, `secret_key`, `endpoint_url`, `region_name`, `custom_domain`, `default_acl`). This is required for the backend to actually initialize; it is a correction, not a new architecture.

### S3 verification evidence with dummy credentials only

```
$ DEFAULT_FILE_STORAGE_BACKEND=storages.backends.s3boto3.S3Boto3Storage \
  AWS_STORAGE_BUCKET_NAME=jam-dummy-bucket \
  AWS_ACCESS_KEY_ID=dummy-access-key AWS_SECRET_ACCESS_KEY=dummy-secret-key \
  AWS_S3_ENDPOINT_URL=https://s3.example.invalid AWS_S3_REGION_NAME=us-east-1 \
  python manage.py shell -c "..."
storage class: DefaultStorage
backend: storages.backends.s3.S3Storage
bucket: jam-dummy-bucket
endpoint: https://s3.example.invalid
region: us-east-1
access key set: True
secret key set: True
```

Fail-closed behavior (missing credentials) still works:

```
$ DEFAULT_FILE_STORAGE_BACKEND=storages.backends.s3boto3.S3Boto3Storage python manage.py check
django.core.exceptions.ImproperlyConfigured: DEFAULT_FILE_STORAGE_BACKEND is set to a non-filesystem backend, but
AWS_STORAGE_BUCKET_NAME, AWS_ACCESS_KEY_ID, and AWS_SECRET_ACCESS_KEY are not all set. ...
CHECK_EXIT: 1
```

No real S3 endpoint was contacted. The endpoint used is non-routable `.invalid`.

Filesystem mode remains the default and works:

```
Filesystem default_storage upload/read/delete: PASS
```

The documented S3 procedure structure was exercised against an in-memory fake backend:

```
S3 integration verification PASSED
Fake backend happy path cleanup: PASS
Fake backend failure path still cleaned up: PASS
```

The failure case forced a readback mismatch; cleanup still deleted the object and confirmed no leftovers.

## 9. Exact Verification Commands and Results

### Django system checks

```
$ env -u REDIS_URL DJANGO_DEBUG=false DJANGO_SECRET_KEY='test-secret-key-not-real' \
  OTPY_API_KEY='test-otpy-key' /tmp/jam-lock-verify/bin/python \
  manage.py check --settings=config.test_settings
System check identified no issues (0 silenced).
```

### Full backend suite

```
$ env -u REDIS_URL DJANGO_DEBUG=false DJANGO_SECRET_KEY='test-secret-key-not-real' \
  OTPY_API_KEY='test-otpy-key' TEST_DB_NAME=':memory:' \
  /tmp/jam-lock-verify/bin/python manage.py test --settings=config.test_settings --verbosity=2
Ran 236 tests in 1.615s
OK (skipped=17)
```

All 236 tests passed. The 17 skips are the existing PostgreSQL-only concurrency tests, skipped with reason `PostgreSQL-only concurrency tests`:

- 10 in `commerce.test_concurrency.CommerceConcurrencyTests`
- 7 in `subscriptions.test_concurrency.SubscriptionConcurrencyTests`

They require PostgreSQL-specific concurrency behavior and were not changed or weakened.

### Focused config tests

```
$ ... manage.py test config --settings=config.test_settings
Ran 10 tests in 0.127s
OK
```

### Dependency checks

See §5: lock install exit 0, `pip check` clean, S3 import OK, requirements dry-run exit 0.

### Diff hygiene

```
$ git diff --check
diff-check OK
```

No secret-like values were added. `.env` is unchanged and git-ignored.

### Final repository state checks

- New migration files: none (`find .../migrations/*.py -newermt "-60 minutes"` returned nothing; `git status` contains no migration paths).
- Commit/push/tag: none.
- Telegram bot: not started; no Telegram API call.
- External PostgreSQL/Redis/S3 connections: none.
- PyPI was accessed for dependency resolution/install; Render's public documentation was read. Neither is a Staging resource.

## 10. Docker Build Result

Docker build was **not executed** because the local Docker daemon is not running:

```
$ docker build -t jam-backend:batch1.2-verify ./backend
ERROR: failed to connect to the docker API at unix:///Users/erfmollaey/.docker/run/docker.sock;
check if the path is correct and if the daemon is running ...
DOCKER_BUILD_EXIT: 1
```

Docker CLI/compose are installed (`Docker version 29.5.2`, Compose `v5.1.4`), but no daemon socket exists. No image was built and nothing was deployed.

Static Dockerfile inspection confirms:

- no `migrate` at build time or in `CMD`;
- only `collectstatic`, Gunicorn, and non-root user setup;
- lockfile installation is the only dependency step.

## 11. Deferred External Integration Tests

| Test | Why deferred |
|---|---|
| Real S3 upload/read/delete (Level B) | Requires owner-provisioned bucket, authorized credentials, and an approved execution channel |
| Media delivery through the real frontend/backend (Level C) | Requires deployed Staging media infrastructure |
| PostgreSQL connectivity against Neon | Requires Neon project and credentials |
| Redis connectivity against Upstash | Requires Upstash database and credentials |
| Render Free migration execution | No supported Free execution channel exists |
| Docker image build | Local Docker daemon unavailable |
| Telegram bot startup | Intentionally not started; no token |
| ZarinPal/OTP real operations | Credentials intentionally absent |

None of these is claimed as passed.

## 12. Remaining Risks and Blockers

1. **Batch 2 deployment blocker — migration execution.** No verified free Render channel exists. The owner must choose and authorize one of the documented options before deploying the backend.
2. **Batch 2 deployment blocker — first admin and manual bot start.** These also require shell/one-off execution, unavailable on Render Free.
3. **Lock file is not a complete transitive lock.** `requirements.lock.txt` does not pin boto3's transitives (`botocore`, `s3transfer`, `jmespath`, `python-dateutil`, `six`). The Docker install resolves them at build time. There is no reproducible lock-generation tool in the repository. This predates Batch 1.2 and was not fabricated; a generated hash-locked dependency set should be considered separately.
4. **S3 remains unverified beyond Level A.** Backend selection and option initialization are now correct with dummy credentials, but no real upload/read/delete or media delivery has been proven.
5. **Redis remains unverified against Upstash.** Only mocked/isolated logic and the `LocMemCache` rejection path were tested.
6. **Docker build unverified locally.** The image build must be run where the Docker daemon is available.
7. **Render Free cold starts and single-instance restarts** remain operational risks documented in the preparation file.

## Confirmation

- No Render, Neon, Upstash, or S3 resource was created.
- No external PostgreSQL, Redis, or object-storage service was contacted.
- No credentials were generated, entered, or requested.
- No real payment, OTP, or Telegram operation was performed.
- No Telegram bot was started.
- No database migration was created or executed.
- No deployment, commit, push, tag, or release occurred.
- Authentication, OTP, subscriptions, payments, RBAC, and business logic were not changed.
- Batch 2 remains unauthorized.
