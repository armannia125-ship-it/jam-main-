# JamPlay Phase 2 — Feature Inventory

Source of truth for product evidence: `jam-life.html` (`script#jg-engine`, the
JamPlay single-file prototype). Current implementation evidence:
`backend/games/`, `frontend/app/play/`, `PHASE1_COMPLETE_REPORT.md`.

Classification:

1. **Complete in Phase 1** — shipped, do not duplicate.
2. **Phase 2** — in scope and implemented in this batch.
3. **Excluded** — outside Phase 2 by the brief.
4. **Blocked** — requires an owner-level business decision; isolated.

| # | Feature (prototype evidence) | Prototype behaviour | Phase 1 status | Phase 2 scope | Acceptance criteria |
|---|---|---|---|---|---|
| 1 | XP accumulation (`grant`, `xpNeed`) | XP from battles, missions, upgrades; curve `120 + (l-1)*90` | XP stored; no level-up rewards | **2** Reuse curve; add level records + duplicate-safe level-up rewards | XP is server-applied; level derived; level-up grants 8 gems once per level; persists across reload |
| 2 | Level-up feedback (`levelUp`, `grant`) | +8 gems per level and a toast | Missing | **2** | Settlement and mission claims report `level_up`; UI shows level-up notice |
| 3 | Daily challenges (`CHALS`) | 5 daily missions, reset by calendar day, claim once | Missing | **2** Three event-backed dailies implemented; two blocked (see #21) | Progress from server events; claim guarded; reset daily; duplicate claim rejected |
| 4 | Permanent missions (`JG_MISSIONS`) | 7 one-time missions with XP/coin/gem rewards | Missing | **2** Four game-event missions implemented; discovery/order missions blocked (#21) | One-time claim; progress survives reload; duplicate grant impossible |
| 5 | Badges/achievements (`BADGES`, `checkBadges`) | 6 automatic achievements, +10 gems each | Missing | **2** Three reachable achievements; three blocked (#21) | Server-evaluated; auto-granted once; catalog shows progress and earned state |
| 6 | Daily gift (`takeDaily`) | Once per day: `150 + 40*TH` coins + 3 gems | Missing (`rules.daily_gift` existed unused) | **2** | Claim once per day; idempotent; ledger entry; resets next local day |
| 7 | Reward pipeline (`grant`, `rewardChips`, toasts) | XP/coins/gems with toast and vault cap | Coins/XP/chests/trophies only | **2** Unify XP, mission, achievement, level-up, daily-gift rewards through wallet ledger | Every mutation atomic + append-only ledger + idempotency key |
| 8 | Profile screen (`renderMe`) | Level, XP bar, display name, preferences | Lobby HUD only | **2** Profile screen with progression and statistics (preferences remain cosmetic/out of scope) | Real persisted data; loading/empty/error/retry |
| 9 | City/progression summary (`renderMyCity`) | City stats, badges, base effects | Base screen exists; no badges | **2** Extend profile with arena/siege records, mission/achievement summaries, level history; city map stays excluded (#22) | Counts match battle settlement and mission state |
| 10 | Friends list (`renderClub`, `FRIENDS`) | List of friends with challenge buttons | Missing | **2** Real JAM-user friends (requests/accept/reject/remove) | Separate authenticated users only; no private data exposed |
| 11 | Add friend (`addJamFriend`) | Local-only "add friend" by name | Missing | **2** Server-backed request by display name | Ownership/privacy enforced; self-request rejected; duplicate request rejected |
| 12 | Friendly challenge (`friendly` battle flag) | Arena vs friend, 15 XP, no trophy change | Missing | **2** Async friendly arena against the friend's persisted deck/name | Only accepted friends; no trophies/chest; 15 XP; counts for friendly missions |
| 13 | Leaderboard (`board`) | Demo trophy/exploration table | Missing | **2** Real trophy leaderboard (display name, level, trophies) with own rank | No phone/email/user identifiers exposed; own row highlighted |
| 14 | Arena/Siege engines and battles | Full deterministic combat | Complete | 1 | Preserve; no changes beyond friendly flag |
| 15 | Cards, deck, upgrades | Collection and deck editing | Complete | 1 | Preserve |
| 16 | Base buildings + shared builder | Upgrade jobs and effects | Complete | 1 | Preserve |
| 17 | Chest lifecycle | 4 slots, timers, claim | Complete | 1 | Preserve |
| 18 | Leagues and trophies | Thresholds and progress | Complete | 1 | Preserve |
| 19 | Community feed / posts / likes / photo moderation (`communityView`, `reviewPosts`) | Photo posts, admin moderation, likes | Missing | **3** Excluded: social feed with user-generated media is not part of the approved Phase 2 social scope (non-real-time friends only) and would require new moderation/media policy | Not implemented |
| 20 | City Discovery, GPS, map, check-ins, quizzes (`renderCity`, `jamDiscover`) | GPS-verified discovery economy | Not implemented | **3** Explicitly excluded by the brief | Not implemented |
| 21 | Discovery/order missions and badges (`jd1`, `jd5`, `jm-first`, `jm-three`, `jm-order`, `BADGES.first/city10/local`) | Progress from city discovery and JAM order rewards | — | **4 Blocked**: objectives depend on excluded City Discovery, or on a Commerce→Games order-event contract that does not exist (and must not mutate the game wallet from Commerce). No substitute objectives invented. | Documented blocker; not shown as claimable work |
| 22 | Town-hall upgrades above level 3 (`TH_DP`) | Discovery points gate TH levels | Gated; no DP source | **4 Blocked**: DP only came from City Discovery (excluded). Achievement `th4` is catalogued and server-evaluated but unreachable until an approved DP source exists. | Documented blocker |
| 23 | Coin→JAM discount redemption (`JG_OFFERS`, `redeemJam`) | Spend coins for JAM coupon codes | Not implemented | **3/4** Excluded: business rules (rate, caps, eligible products, stacking, expiry) are unapproved. Contract documented only. | No redemption behaviour implemented |
| 24 | Coin/gem real-money offers, transfers, subscriptions | — | — | **3** Explicitly excluded | Not implemented |
| 25 | Multiplayer, WebSockets, matchmaking, presence | — | — | **3** Explicitly excluded | Not implemented |
| 26 | Backup export/import (`exportSave`, `importSave`) | Client JSON backup of local save | Not applicable (server stores state) | **3** Excluded: contradicts server-authoritative persistence | Not implemented |
| 27 | Sound/haptics/motion preferences (`renderMe` toggles) | Client-only preferences | Missing | **3** Excluded: cosmetic device settings, not product progression | Not implemented |

## Phase 2 event inventory

Server-generated events used for progression, missions and achievements:

| Event | Emitted by | Reference (idempotency) |
|---|---|---|
| `battle_completed` | Battle settlement | `battle:<key>` |
| `battle_win` | Battle settlement with `win` | `battle:<key>` |
| `arena_battle` | Arena settlement (ranked) | `battle:<key>` |
| `siege_battle` | Siege settlement | `battle:<key>` |
| `siege_win` | Siege settlement with `win` | `battle:<key>` |
| `friendly_battle` | Friendly arena settlement | `battle:<key>` |
| `building_upgrade` | Completed builder job | `building:<profile>:<key>:<level>` |
| `daily_gift` | Daily gift claim | `daily:<profile>:<date>` |

Events are append-only rows with a unique `(profile, kind, reference)` key, so a
retried settlement or claim cannot double-count progress.
