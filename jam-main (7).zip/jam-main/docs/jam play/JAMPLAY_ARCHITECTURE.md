# JamPlay Architecture

## System Overview

The JamPlay architecture is designed to be implemented within the existing JAM platform while maintaining separation between game mechanics and core business functionality.

### Core Components

```
Next.js / React / TypeScript
│
├── JamPlay UI
│   ├── Lobby
│   ├── Arena
│   ├── Siege
│   ├── Base
│   ├── Cards
│   ├── Missions
│   ├── Profile
│   └── Social
│
├── Canvas Renderer
│   ├── Arena Renderer
│   ├── Siege Renderer
│   └── Animation / Effects
│
├── Client Game Adapter
│   ├── Input Handling
│   ├── Visual Interpolation
│   └── Battle Transport
│
└── Existing Django API
    │
    ├── Game Profile
    ├── Battle API
    ├── Cards & Inventory
    ├── Base & Upgrades
    ├── Progression
    ├── Economy & Ledger
    ├── Missions & Achievements
    ├── Rewards
    ├── Social & Matchmaking
    └── Commerce Integration
         │
         ├── PostgreSQL
         │   ├── Persistent Game State
         │   ├── Battle Records
         │   ├── Wallet Ledger
         │   └── Inventory / Rewards
         │
         └── Redis
             ├── Active Battle State
             ├── Matchmaking Queue
             ├── Presence
             ├── Locks
             └── Temporary Events
```

## Backend Architecture

### Game App Structure

The `games` app will be created with the following structure:

```
backend/games/
├── domain/                    # Core game rules and logic
│   ├── arena/
│   │   ├── combat_rules.py
│   │   ├── session.py
│   │   └── battle_engine.py
│   ├── siege/
│   │   ├── base_rules.py
│   │   ├── destruction_engine.py
│   │   └── siege_session.py
│   ├── cards/
│   │   ├── card_system.py
│   │   ├── deck_manager.py
│   │   └── upgrade_rules.py
│   ├── rules/
│   │   ├── resource_rules.py
│   │   ├── progression_rules.py
│   │   └── economy_rules.py
│   └── combat/
│       ├── ai_controller.py
│       ├── simulation_engine.py
│       └── event_handler.py
│
├── engine/                    # Game execution engines
│   ├── simulation/
│   │   ├── battle_simulation.py
│   │   └── state_manager.py
│   ├── ai/
│   │   ├── ai_strategy.py
│   │   └── decision_engine.py
│   ├── events/
│   │   ├── battle_events.py
│   │   └── settlement_events.py
│   └── replay/
│       ├── replay_system.py
│       └── deterministic_runner.py
│
├── models/                    # Database models
│   ├── game_profile.py
│   ├── wallet_ledger.py
│   ├── inventory.py
│   ├── battle_record.py
│   ├── progression.py
│   ├── rewards.py
│   └── missions.py
│
├── services/                  # Business logic services
│   ├── battle_service.py
│   ├── settlement_service.py
│   ├── economy_service.py
│   ├── progression_service.py
│   └── reward_service.py
│
├── api/                       # API endpoints
│   ├── battle_api.py
│   ├── profile_api.py
│   ├── inventory_api.py
│   ├── progression_api.py
│   └── rewards_api.py
│
├── realtime/                  # Real-time communication
│   ├── matchmaking.py
│   ├── websocket_handler.py
│   └── presence_manager.py
│
├── tasks/                     # Background tasks
│   ├── battle_settlement.py
│   └── notification_scheduler.py
│
└── tests/                     # Test suite
    ├── test_battle_engine.py
    ├── test_economy_system.py
    ├── test_ai_behavior.py
    └── test_settlement.py
```

## Data Flow and Architecture Principles

### Server-Authoritative Design
1. **Client Responsibility**: Input handling, visual interpolation, rendering
2. **Server Responsibility**: Rules enforcement, simulation validation, outcome determination
3. **Data Integrity**: All game state changes must be validated server-side

### Battle Lifecycle
```
Lobby
  ↓
Create Battle Request
  ↓
Server Validation
  ↓
Create Battle Session
  ↓
Initialize State + Seed + Rules Version
  ↓
Battle Input / Simulation
  ↓
Server Determines Outcome
  ↓
Settlement
  ↓
Ledger + Progression + Rewards
  ↓
Battle History
```

### Economy and Integrity
- Wallet Ledger as the authoritative transaction history
- Atomic transactions for resource changes
- Preventing negative balances and duplicate rewards
- Unique constraints on one-time events
- All resource changes must be traceable

## Integration with Existing Systems

### Authentication & Authorization
- Uses existing `accounts` app authentication system
- JWT-based API access with proper permission checks
- User identity linked to game profile through foreign key relationship

### Commerce Integration
- Game economy connects to existing wallet system
- Resource conversion follows business rules from commerce module
- Coupon issuance integrates with payment infrastructure
- Atomic redemption process prevents fraud

### Subscription Benefits
- Premium subscription entitlements can unlock advanced game features
- Progression and rewards linked to active subscriptions
- Gold subscription creates both menu and club entitlements

## Real-time Communication (Multiplayer)

For the multiplayer implementation, we'll leverage Django's ASGI and Channels with Redis:

```
Client ↔ WebSocket ↔ Django Channels ↔ Redis Queue ↔ Game Engine
                                     ↘ Battle Session
```

### Key Features
- Matchmaking system using Redis queues
- Room lifecycle management
- Player presence tracking
- Input validation and event ordering
- Disconnect/reconnect handling
- Timeout management
- Anti-cheat measures

## Future Extensions

The architecture is designed to accommodate future extensions:

### City Discovery Phase
```
Business Discovery
  ↓
Location-based Missions
  ↓
GPS Verification
  ↓
Visit Events
  ↓
Discovery Rewards
```

## Security and Validation

1. **Input Validation**: All client inputs are validated server-side
2. **State Management**: Battle state is managed in Redis for temporary data
3. **Idempotency**: Settlement endpoints handle duplicate requests gracefully
4. **Audit Trail**: Complete wallet ledger tracks all resource changes
5. **Access Control**: Proper permission checks for all game APIs

## Performance Considerations

1. **Database Indexing**: Proper indexing on battle records, user profiles, and game state
2. **Redis Usage**: Efficient caching of active sessions and matchmaking queues
3. **Background Tasks**: Settlement and notification handling in background processes
4. **Canvas Optimization**: Efficient rendering with proper interpolation
5. **Scalability**: Modular design allows for horizontal scaling

This architecture ensures that JamPlay can be implemented as a robust, secure, and scalable game system within the existing JAM platform while maintaining clear separation between game mechanics and core business functionality.
---

## Phase 2 delivered implementation (2026-11-18)

This section records what actually shipped in Phase 2 and supersedes any earlier aspirational statements in
this document (Redis battle state, matchmaking queues, background settlement workers and multiplayer are **not**
implemented; there is no Channels/WebSocket dependency).

### Server-authoritative progression

- `GameProfile.xp/level/trophies/best_trophies/friendly_played` remain the single progression record.
- XP curve is `xp_to_next(level) = 120 + (level - 1) * 90` (`games/rules.py::xp_to_next`).
- `services.grant_xp()` is the only XP mutator. It clamps to the current level window, creates one
  `LevelRecord` per completed level (unique per `profile` + `level`), pays `LEVEL_UP_GEMS = 8` per level through
  `grant_rewards(reason="level_up")` and reports level-ups to the caller for presentation.
- Phase 1 XP already present at migration time is recorded as `LevelRecord(baseline=True, reward_gems=0)`
  so no retroactive gem payout was invented.

### Event ledger and idempotency

- `GameEvent(profile, kind, reference, amount, metadata)` is append-only with a unique constraint on
  `(profile, kind, reference)`; `services.record_event()` is `get_or_create`, so replaying a battle, chest or
  building completion cannot double-count progress.
- Events are emitted from trusted service paths only: `battle_finished`, `battle_won`, `battle_lost`,
  `trophy_changed`, `xp_earned`, `card_upgraded`, `building_completed`, `chest_claimed`, `friendly_battle`.
- `GameWallet`-equivalent resource changes still go through `LedgerEntry`; mission/achievement payouts use the
  new `mission_reward` / `achievement_reward` reasons and are written in the same transaction as the claim.

### Missions

- Catalogs in `games/rules.py`: three daily missions (`jd2` win a battle, `jd3` claim the daily gift,
  `jd4` finish a friendly battle) and four permanent missions (`jm-battle`, `jm-build`, `jm-friendly`,
  `jm-siege`).
- `MissionProgress(profile, mission_id, period, progress, claimed_at)` with a unique constraint on
  `(profile, mission_id, period)`; `period` is the player-local date for daily missions and `"permanent"`
  for the rest.
- Progress is recomputed from `GameEvent` inside `transaction.atomic()` with `select_for_update()`; the client
  never submits progress or reward amounts. `claim_mission()` re-checks completion and refuses duplicates.
- Discovery/order-dependent prototype missions (`jd1`, `jd5`, `jm-first`, `jm-three`, `jm-order`) and the
  `first`/`city10`/`local` badges stay blocked because City Discovery and order-bound game events are out of
  scope; they are catalogued in `PHASE2_FEATURE_INVENTORY.md`.

### Achievements

- `ACHIEVEMENTS` in `games/rules.py`: `win3` (3 ranked wins), `league` (reach silver), `th4` (town hall 4).
  `th4` is catalogued but unreachable because no approved source grants the required dark elixir/progression
  resource; it is documented rather than faked.
- `AchievementUnlock(profile, achievement_id)` is unique per profile; `evaluate_achievements()` runs after
  settlement and pays the configured reward once, guarded by the unique constraint.

### Daily gift

- `daily_gift_payload()` / `claim_daily_gift()` pay `150 + 40 * town_hall` coins and `DAILY_GIFT_GEMS = 3`
  gems once per player-local date (`reference = "daily-gift:<date>"`).

### Social (non-real-time only)

- `GameFriend` models a symmetric friendship in one row with `status` (`pending`/`accepted`/`rejected`) and
  `requested_by`. Search matches display name only (never phone/email), limited to active users.
- Endpoints: list friends + pending requests, search, request, respond, remove, and `challenge` which starts a
  **friendly** arena battle against the accepted friend's identity.
- Friendly battles are marked `Battle.friendly=True`, award `FRIENDLY_BATTLE_XP = 15`, change no trophies,
  award no chest and do not count toward ranked arena statistics.
- Leaderboard exposes display name, level and trophies only; no private fields.

### API surface added in Phase 2 (`/api/games/`)

`GET profile` (now patchable display name), `GET progress/`, `GET missions/`, `POST missions/claim/`,
`GET achievements/`, `GET daily-gift/`, `POST daily-gift/claim/`, `GET leaderboard/`, `GET friends/`,
`GET friends/search/`, `POST friends/request/`, `POST friends/respond/`, `POST friends/remove/`,
`POST friends/challenge/`. All require authentication and scope querysets to `request.user`.

### Frontend

`frontend/app/play/page.tsx` now hosts nine screens (`آوردگاه`, `مأموریت`, `پیشرفت`, `دوستان`, `پروفایل`,
plus Phase 1 `کارت‌ها`, `دسته`, `صندوق‌ها`, `پایگاه`). `Phase2Screens.tsx` contains the new screens,
`progression.ts` the pure formatting/curve helpers (unit tested with `node --test`), and `jamplay.css` the
Phase 2 layout, including a horizontally scrollable tab strip on mobile.

### Coin → JAM discount contract (not implemented)

The wallet stays independent: no real-money purchase, no player-to-player transfer, no subscription
entitlement, and Commerce never reads or writes game balances. Any future coin redemption requires owner
approval of conversion rate, caps, eligible products, stacking and expiry before implementation; no such rule
exists in code today.
