# Legacy Subscription Compatibility — Removed

**Status:** RETIRED

**Date:** 2026-11-10

The legacy subscription architecture has been removed from JAM. This document is retained only as a historical pointer.

## Removed models and flows

- `subscriptions.SubscriptionPlan`
- `subscriptions.Subscription`
- `subscriptions.ActivationCode`
- `subscriptions.ActivationCodeEvent`
- `commerce.ClubMembership`
- `commerce.ClubMembershipEvent`
- Manual subscription requests, payment instructions, offline checkout, activation-code issuance/redemption, free trials, membership deactivation, and simulated subscription payments.

## Current authority

- `SubscriptionProduct`, `SubscriptionPurchase`, and `SubscriptionEntitlement` are the only subscription models.
- ZarinPal is the only payment route.
- A current entitlement requires `status=ACTIVE` and `starts_at <= now < ends_at`.
- MENU and CLUB access are independent. Gold creates both atomically; revoking one does not revoke the other.
- Public menu, QR, store directory, product editing, product limits, bot editing, and admin views use entitlement-only policy.

There is no grandfathering, dual-model fallback, historical conversion, or manual activation path.
