# ESLint and Code Quality Report

**Date:** 2026-11-08
**Status:** Lint, TypeScript, and production build all pass. Eleven warnings remain; no errors.

## 1. Toolchain

| Tool | Version |
|---|---|
| Node.js | 24.22.0 |
| npm | 11.19.1 |
| Next.js | 15.5.29 |
| ESLint | via `eslint` + `eslint-config-next@15.5.29` |
| TypeScript | project version |

`frontend/package.json` now has:

```json
"lint": "eslint ."
```

The project uses the flat config in `frontend/eslint.config.mjs`, extending Next's core-web-vitals and TypeScript rules.

## 2. Final commands and results

```bash
cd frontend
npm run lint
npx tsc --noEmit
npm run build
```

| Command | Exit | Result |
|---|---:|---|
| `npm run lint` | 0 | 11 warnings, 0 errors |
| `npx tsc --noEmit` | 0 | No type errors |
| `npm run build` | 0 | Production build completed; `/panel/plan`, `/health`, API proxy, and existing routes generated |

The build was rerun after the final changes to the Next.js API proxy and subscription UI.

## 3. Warnings

The 11 warnings are existing or low-risk issues, not suppressed with eslint-disable comments:

| Rule | Count | Locations |
|---|---:|---|
| `@next/next/no-img-element` | 6 | `app/cart/page.tsx:94`, `app/panel/menu/page.tsx:22,139`, `app/panel/plan/page.tsx:224`, `components/features/order-tracking-page.tsx:176`, `components/features/panel-page.tsx:316` |
| `react-hooks/exhaustive-deps` | 3 | `app/revenue/page.tsx:47`, `lib/commerce.tsx:272`, `lib/state.tsx:116` |
| `@typescript-eslint/no-unused-vars` | 2 | `components/ui/input.tsx:15,69` (`error` props) |

### Why they were not mass-fixed

- Replacing `<img>` with `next/image` can change layout behavior, remote image handling, and fallback behavior. That is a UI change outside this deployment-foundation phase.
- The hook dependency warnings touch existing commerce/state behavior. Changing them without dedicated regression coverage could introduce loops or stale-state bugs.
- The unused `error` props are part of an existing input API surface. Removing them would be a component API change.

None are build-blocking, and none were used to hide a failure. They remain visible for a focused follow-up.

## 4. Build output

The production build completed and included the relevant routes, including:

- `/panel/plan`
- `/health`
- `/api/[...path]`
- `/login`
- Existing store, order, panel, revenue, and public menu routes

No environment secret is inlined by the build. The frontend proxy reads `API_INTERNAL_URL` server-side.

## 5. Backend quality checks

Django system checks run as part of the test command and reported no issues. Python has no configured linter in this phase; backend verification relies on tests and Django checks.

## 6. Limitations

- Lint warnings were not reduced to zero.
- No browser-based accessibility or visual regression audit was performed.
- No bundle-size budget was defined.
- No dependency vulnerability scan (`npm audit`/SCA) was part of this phase.
