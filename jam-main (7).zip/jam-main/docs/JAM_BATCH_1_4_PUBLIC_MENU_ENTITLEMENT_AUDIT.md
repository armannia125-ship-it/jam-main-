# JAM Batch 1.4 — Public Menu Entitlement Audit

**Status:** AUDIT COMPLETE — OWNER DECISION REQUIRED  
**Date:** 2026-11-10  
**Branch:** `main`  
**HEAD:** `fdb1add6cf56b852e07aa804a19c3bb7736fac18`  
**Scope completed:** Stage A audit only. No implementation, migration, schema/data change, payment/OTP/Telegram operation, auth/plan/price change, commit, push, or deploy.  
**Deliverable companion:** `JAM_BATCH_1_4_PUBLIC_MENU_ENTITLEMENT_DECISION_BRIEF.md`

## 1. Baseline and scope

### 1.1 Git baseline at audit start

Pre-existing uncommitted changes are preserved and were not modified:

```text
 M .env.example
 M backend/Dockerfile
 M backend/config/health.py
 M backend/config/settings.py
 M backend/config/test_settings.py
 M backend/config/tests.py
 M backend/requirements.lock.txt
 M backend/requirements.txt
 M backend/test_settings.py
?? AGENTS.md
?? JAM_BATCH_1_3_AGENT_GOVERNANCE_AUDIT.md
?? docs/JAM_BATCH_1_1_STAGING_CORRECTIONS_REPORT.md
?? docs/JAM_BATCH_1_2_STAGING_TECHNICAL_CORRECTIONS_REPORT.md
?? docs/JAM_FREE_STAGING_DEPLOYMENT_ASSESSMENT.md
?? docs/deployment/
```

No tracked file was changed by this audit. The only intended new files are the two Batch 1.4 deliverables.

### 1.2 Canonical sources used

- `AGENTS.md`, especially §10 known discrepancy #1.
- `docs/SUBSCRIPTION_ARCHITECTURE.md` lines 36–53.
- `docs/LEGACY_COMPATIBILITY.md` lines 17–33.
- `docs/JAM_MASTER_IMPLEMENTATION_REPORT.md` line 12.
- `backend/subscriptions/migrations/0005_seed_subscription_products.py` lines 9–91.
- `docs/PWA_RUNTIME_VALIDATION.md` and `frontend/public/sw.js`.
- `docs/PRODUCTION_READINESS_BASELINE.md` and `docs/DEPLOYMENT_FOUNDATION_BASELINE.md` as historical context.
- Existing code and tests.

### 1.3 Evidence labels

- `CONFIRMED` — directly established by source code or executed test.
- `INFERRED` — reasoned from source code or documented behavior; not directly tested.
- `UNKNOWN` — not established.
- `ODR` — owner decision required; not resolved by this audit.
- `NOT TESTED` — no automated or manual runtime proof.

## 2. Executive finding

The new subscription system can grant menu management access, but it does not yet grant public menu visibility. Public menu, QR, and store-directory reads still use only the legacy `Subscription` model. Therefore:

- A business with a valid new MENU entitlement and no valid legacy `Subscription` can edit and publish menus, but its public menu URL, QR payload, and store directory entry remain inaccessible.
- A business with a valid legacy `Subscription` continues to be visible.
- A business with both valid records is visible because the legacy record satisfies the old filter.
- Seller Club alone does not grant menu access and is not affected by this bug, but its public club page currently links to `/m/<business-slug>`, which is a menu slug mismatch rather than an entitlement grant.

This is a partial-migration inconsistency, not a data corruption. No records were changed by this audit.

## 3. Entitlement and legacy models

### 3.1 New model chain

Source: `backend/subscriptions/models.py`.

- `SubscriptionProduct.category`: `menu`, `combo`, or `club`.
- `SubscriptionPurchase`: user, business, product, status, server-authoritative price snapshot.
- `SubscriptionEntitlement`: `entitlement_type` (`menu` or `club`), `status`, `starts_at`, `ends_at`, `revoked_at`, unique per `(purchase, entitlement_type)`.

Source: `backend/subscriptions/migrations/0005_seed_subscription_products.py` lines 9–91.

- `basic`, `professional`, `premium`: category `menu`, create MENU entitlements.
- `gold`: category `combo`, creates one MENU and one CLUB entitlement atomically.
- `seller_club`: category `club`, creates CLUB entitlement only.

### 3.2 Validity rules

Source: `backend/subscriptions/models.py` `SubscriptionEntitlement.is_current` and `backend/subscriptions/entitlements.py`.

- An entitlement is current only when `status == ACTIVE` and `starts_at <= now < ends_at`.
- Expiry is lazy; status may remain `active` until a summary/notification path updates it.
- Revocation sets `status = REVOKED` and `revoked_at`.
- Edit/publish gate: `entitlements.menu_access(business)` returns true for current MENU entitlement **or** current legacy `Subscription`.
- Product limit: new MENU entitlement or legacy active subscription, with Basic limited to 80 products and legacy unlimited.

### 3.3 Legacy model

Source: `backend/subscriptions/models.py` lines 56–87 and `docs/LEGACY_COMPATIBILITY.md` lines 17–33.

- Legacy `Subscription` has `status`, `starts_at`, `ends_at`, and is manually activated by code redemption after operator confirmation.
- Active legacy subscriptions continue to grant menu access until expiry.
- Expired or cancelled legacy subscriptions grant nothing.
- No new offline purchase requests are accepted publicly (`410`), but existing records can still be confirmed/redeemed through documented legacy paths.

### 3.4 Invariants

- Entitlements are scoped to both `user` and `business`.
- A menu belongs to one business.
- A business owner can own multiple businesses and multiple menus.
- A MENU entitlement does not create or modify a legacy `Subscription`.
- Revoking a new entitlement does not touch legacy records, and vice versa.
- Expiry does not delete or unpublish `Menu`, `Product`, or `Category` records.

## 4. Public menu and discovery paths

### 4.1 Backend authority paths

| Path | Source | Current filter | New entitlement honored? | Result |
|---|---|---|---:|---|
| `GET /api/public/menus/<slug>/` | `config/urls.py:16` and `businesses/urls.py:11`; `PublicMenuView` in `businesses/views.py:97-117` | `is_active=True`, owner active, legacy `Subscription` active and dated | No | New-only menu: 404 |
| `GET /api/qr/<slug>/` | `businesses/urls.py:12`; `QrCodeView` in `businesses/views.py:120-157` | Same legacy filter | No | New-only menu: 404 |
| `GET /api/commerce/public/stores/` | `commerce/views.py` wrapper; `public_store_directory()` in `commerce/services.py:353-399` | Same legacy filter | No | New-only menu excluded |
| `GET /api/commerce/public/club/stores/` | `commerce/services.py` club path | CLUB entitlement or legacy `ClubMembership` | No menu grant | Club-visible business; no menu access |
| `/api/public/menus/<slug>/` duplicate registration | `config/urls.py:16` before `include("businesses.urls")` | Root registration wins | No | Same behavior; route duplication only |

`PublicMenuView` is a `RetrieveAPIView` with no explicit 404 handling. It returns 404 for either a missing menu or a menu excluded by the filter. `QrCodeView` generates a base64 PNG data URL and public URL from `request.is_secure()`.

### 4.2 Frontend and cache paths

| Path | Source | Behavior |
|---|---|---|
| `/` home | `frontend/app/page.tsx`, `frontend/lib/data.ts` | Uses public store directory; new-only menus absent |
| `/search` | `frontend/components/features/real-search.tsx:28` | Fetches directory directly; new-only menus absent |
| `/m/[slug]` | `frontend/app/m/[slug]/page.tsx`; `frontend/lib/public-menu.ts:127-151` | Fetches public menu with `next: { revalidate: 60 }`; new-only menu becomes 404 |
| `/club` | `frontend/app/club/page.tsx:45` | Links to `/m/${s.slug}` using business slug; club API returns business slug |
| Public QR | No frontend caller found | Backend QR API exists but is not wired into the live panel UI; panel QR is demo-only |
| Next data cache | `frontend/lib/public-menu.ts:127-151`, `frontend/lib/data.ts` | Up to 60 seconds of stale menu/directory visibility |
| Service worker | `frontend/public/sw.js:22,100-124,181-202` | Network-first HTML and JSON menu cache; offline freshness up to 24 hours |
| Public menu serializer | `businesses/serializers.py:70-84` | Public fields only; no owner/private fields |

### 4.3 Adjacent non-public authority paths

- `backend/bot/management/commands/run_telegram_bot.py:43-70` uses `business_has_active_subscription()`, which checks legacy `Subscription` only. This blocks new-entitlement owners from Telegram add/edit product commands. It is not a public exposure path, but it is an adjacent access inconsistency.
- `backend/businesses/views.py:34-45` calls `entitlements.menu_access()` for create/update and publish. This is already dual-model.
- `commerce.public_club_stores` is a separate visibility surface and must remain independent of menu entitlements.

## 5. Menu lifecycle

1. Customer purchases a product and creates a pending `SubscriptionPurchase`.
2. Payment verification activates the purchase and creates entitlements.
3. A MENU entitlement becomes current only at its `starts_at`.
4. An owner creates or edits a menu through the business API.
5. `MenuViewSet.perform_create` forces `is_active=False` if `menu_access()` is false; with new access, a requested published state can remain true.
6. `MenuViewSet.perform_update` allows `is_active=True` only if `menu_access()` is true.
7. Public reads use only legacy subscription filtering, so new-only menus are invisible.
8. QR generation uses the same legacy-only filter.
9. Store directory uses the same legacy-only filter.
10. Expiry or revocation removes edit access but does not unpublish the menu in the database.
11. Frontend caches can continue to show a previously visible menu for up to 60 seconds online and 24 hours offline.
12. Renewal or new purchase can restore access without republishing the menu.

Important lifecycle fact: `Menu.is_active` is a publish flag, not an entitlement timestamp. A menu can remain `is_active=True` while its entitlement has expired. Whether it should remain publicly visible during a grace/cache window is an owner decision.

## 6. Compatibility matrix

Columns: `Edit` and `Publish` are current behavior. `Public URL/QR` and `Directory` are current behavior. `Expected` is `ODR` where no owner-approved explicit policy exists.

| Scenario | Edit | Publish | Public URL/QR actual | Directory actual | Expected / status |
|---|---:|---:|---:|---:|---|
| New active MENU, published, no legacy | Yes | Yes | No | No | ODR; product feature advertises public link and QR |
| New active MENU, unpublished | Yes | Yes | No | No | Hidden (current invariant; ODR if grace window) |
| New expired MENU, published | No | No | No | No | ODR; likely no access |
| New revoked MENU, published | No | No | No | No | ODR; likely no access |
| No MENU, no legacy | No | No | No | No | No |
| Legacy active only, published | Yes | Yes | Yes | Yes | Legacy compatibility intent; public semantics inferred |
| Legacy expired only, published | No | No | No | No | No |
| New active + legacy active | Yes | Yes | Yes | Yes | At least yes through legacy |
| New active + legacy expired | Yes | Yes | No | No | Core bug: ODR whether new access alone should publish |
| New expired/revoked + legacy active | Yes | Yes | Yes | Yes | ODR precedence conflict |
| Seller Club only, published menu if any | No | No | No | No | No for menu; club directory yes |
| Entitlement for another business | No | No | No | No | No cross-business access |
| Multiple active MENU entitlements | Yes | Yes | No | No | ODR; any one should suffice if approved |
| Multiple menus under one business | Yes | Yes | No | No | ODR row-per-menu vs business |
| Gold (MENU + CLUB) | Yes | Yes | No | No | Same as MENU; club separately yes |

### 6.1 Product-specific notes

- Basic: MENU entitlement, 80 product limit, seed feature says "لینک اختصاصی و QR منو".
- Professional: MENU entitlement, unlimited products.
- Premium: MENU entitlement, unlimited products.
- Gold: independent MENU and CLUB entitlements; menu follows MENU row.
- Seller Club: CLUB only; explicitly "بدون اشتراک منو".

### 6.2 Precedence conflicts

If both records are present and one says no while the other says yes, the current `menu_access()` OR means yes. This affects:

- New revoked but legacy active: menu still editable and visible.
- New expired but legacy active: menu still editable and visible.
- New active but legacy expired: menu editable but invisible publicly.

Whether legacy should override a revoked or expired new entitlement is an owner decision. This audit does not resolve it.

## 7. Security and data-integrity assessment

| Area | Assessment | Confidence |
|---|---|---|
| Cross-business isolation | Normal purchase checks `Business.objects.filter(pk=business_id, owner=request.user)`. Entitlement and menu are business-scoped. No cross-business leak found in normal flows. | CONFIRMED |
| Unpublished menus | Public filters require `is_active=True`; unpublished menus are not exposed. | CONFIRMED |
| Expired access | Date comparison is server-side and uses aware UTC timestamps. | CONFIRMED |
| Revocation | Date/status checks happen at request time; no server-side cache of entitlements. | CONFIRMED |
| Stale visibility | Next data cache up to 60 seconds and service worker up to 24 hours can show expired/revoked menus offline. | CONFIRMED |
| Directory overexposure | Directory returns only public fields and excludes inactive or inaccessible menus. | CONFIRMED |
| Multiple legacy subscriptions | `PublicMenuView` has no `.distinct()`; overlapping legacy rows may raise `MultipleObjectsReturned` and produce 500. | INFERRED, NOT TESTED |
| Multiple menus per business | Directory returns one row per active menu; no menu-count limit exists. | CONFIRMED |
| Club link mismatch | Club page uses business slug as menu slug; menu slugs are distinct and often business-slug plus `-menu`. | INFERRED, NOT TESTED |
| Fail-open behavior | Database errors propagate as 500 rather than granting access. Cache fallback can serve stale data only after a prior successful fetch. | CONFIRMED |
| Timezone | Runtime checks use `timezone.now()` aware UTC; product display uses Asia/Tehran only for presentation. | CONFIRMED |
| Enumeration | Inaccessible menus return the same 404 as missing menus. | CONFIRMED |

## 8. Existing test coverage

Targeted command executed:

```text
cd backend && env -u REDIS_URL DJANGO_DEBUG=false DJANGO_SECRET_KEY='test-secret-key-not-real' OTPY_API_KEY='test-otpy-key' TEST_DB_NAME=':memory:' /tmp/jam-lock-verify/bin/python manage.py test businesses.tests subscriptions.tests.PublicMenuAccessTests commerce.tests.APIEndpointTests.test_public_store_directory_requires_active_subscription --settings=config.test_settings --verbosity=2
```

Result: 16 tests OK.

Coverage found:

- `businesses/tests.py`: ownership and publish gating, including legacy active and no subscription.
- `subscriptions/tests.py:PublicMenuAccessTests`: six legacy-only public menu tests.
- `commerce/tests.py`: one legacy-only directory test.
- `subscriptions/tests.py`: entitlement unit tests for `menu_access`, coexistence, and revocation.
- `subscriptions/tests.py`: purchase and Gold activation tests.

Gaps:

- No test grants a new MENU entitlement and expects public menu, QR, or directory visibility.
- No QR endpoint test for new entitlement.
- No expired/revoked new entitlement public test.
- No multi-entitlement or multi-menu public test.
- No cache invalidation test.
- No frontend automated test for this behavior.

The targeted run did not prove the full backend suite. It also did not create or modify data outside the test database.

## 9. Documentation and code discrepancies

- `docs/JAM_MASTER_IMPLEMENTATION_REPORT.md` line 12 claims centralized enforcement at every boundary. The public read paths contradict that claim.
- `docs/SUBSCRIPTION_ARCHITECTURE.md` lines 42–48 documents menu publish/edit and Seller Club visibility, but does not specify public menu URL, QR, or directory semantics.
- `docs/LEGACY_COMPATIBILITY.md` lines 21 and 30 preserve legacy menu access until expiry, but do not state whether public visibility is included beyond edit access.
- `AGENTS.md` §10 already records the inconsistency, but describes it as "may not appear"; source inspection shows deterministic invisibility without legacy access.
- `backend/subscriptions/migrations/0005_seed_subscription_products.py` lines 18–23 advertises "لینک اختصاصی و QR منو" for Basic, while new Basic entitlements currently have no public URL or QR access.
- `frontend/app/club/page.tsx:45` links to `/m/${s.slug}` using a business slug, while the public menu API expects a menu slug.
- `config/urls.py:16` and `businesses/urls.py:11` register the same public menu route; the root registration shadows the nested one.
- `docs/PRODUCTION_READINESS_BASELINE.md` and `docs/DEPLOYMENT_FOUNDATION_BASELINE.md` describe public visibility generically as active subscription; they predate the split between legacy and new entitlements and are historical context.

## 10. Owner decisions required

1. Should a valid new MENU entitlement alone grant public menu URL access?
2. Should the same rule grant QR access?
3. Should the same rule grant store directory access?
4. Should legacy active subscriptions continue to grant public visibility, and until when?
5. If both new and legacy records exist, which one wins when they disagree?
6. Should an expired or revoked new entitlement immediately remove public visibility, or is a cache/offline grace window acceptable?
7. Should unpublished menus remain inaccessible even to valid subscribers? Current behavior says yes, but it is not explicitly owner-approved.
8. Should each active menu be a separate directory row, or should directory be business-level?
9. Should Seller Club standalone businesses ever expose a menu link, given the current slug mismatch?
10. Should Telegram bot product editing use `menu_access()` instead of legacy-only `Subscription` checks?
11. Should the duplicate public menu route be removed as hygiene?

## 11. Excluded assumptions

- No assumption that product marketing copy alone is an owner-approved visibility policy.
- No assumption that public visibility must equal edit access.
- No assumption that legacy subscriptions should be grandfathered indefinitely.
- No assumption that Seller Club grants menu access.
- No assumption that every active menu must appear in the directory.
- No assumption that offline cache must enforce immediate revocation.
- No assumption that multiple menus should be collapsed to one business row.
- No assumption that there is production data matching any scenario.
- No claim that the full backend suite was run.
- No claim that a live QR frontend flow exists.

## 12. Verification performed

- Read all relevant backend, frontend, docs, and migration sources.
- Searched all public menu, QR, directory, search, club, and cache references.
- Ran the targeted 16-test command listed in §8; result: 16 tests OK.
- Ran `git diff --check` before writing documents; result: exit 0.
- Did not run migrations, browser tests, external services, payment, OTP, or Telegram operations.
- Did not modify code, migrations, or pre-existing uncommitted files.

## 13. Appendix: key references

- `AGENTS.md` §10 known discrepancy #1.
- `backend/businesses/views.py:34-45` menu publish/edit gate.
- `backend/businesses/views.py:97-117` `PublicMenuView`.
- `backend/businesses/views.py:120-157` `QrCodeView`.
- `backend/businesses/serializers.py:70-84` `PublicMenuSerializer`.
- `backend/commerce/services.py:353-399` `public_store_directory()`.
- `backend/subscriptions/entitlements.py:41-61` `menu_access()`.
- `backend/subscriptions/entitlements.py:157-203` entitlement activation.
- `backend/subscriptions/entitlements.py:206-215` revocation.
- `backend/subscriptions/models.py:56-87` legacy `Subscription`.
- `backend/subscriptions/models.py:361-429` `SubscriptionEntitlement`.
- `backend/subscriptions/migrations/0005_seed_subscription_products.py:9-91` product seed.
- `backend/bot/management/commands/run_telegram_bot.py:43-70` legacy-only bot access.
- `backend/config/urls.py:16` duplicate public menu route.
- `backend/businesses/urls.py:11-12` nested public menu and QR routes.
- `frontend/lib/public-menu.ts:127-151` 60-second revalidation.
- `frontend/app/club/page.tsx:45` business-slug menu link.
- `frontend/public/sw.js:22` 24-hour menu cache.
- `frontend/public/sw.js:100-124` public menu API cache.
- `frontend/public/sw.js:181-202` menu page cache.
- `docs/SUBSCRIPTION_ARCHITECTURE.md:42-53`.
- `docs/LEGACY_COMPATIBILITY.md:17-33`.

**AUDIT COMPLETE — OWNER DECISION REQUIRED**
