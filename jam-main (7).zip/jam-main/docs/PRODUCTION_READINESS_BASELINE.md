# JAM — Production Readiness Baseline

**Date:** 2026-11-08  
**Branch:** `main` at `5985bcd` (`frontend final refactor`)  
**Working tree:** dirty (previous uncommitted API/PWA work); no commits, tags, or pushes made in this phase.

## 1. Documentation audit

Read: `README.md`, `docs/JAM_LIFE_BACKEND_API_AUDIT.md`,
`docs/JAM_LIFE_FRONTEND_FINAL_VALIDATION.md`. Also inspected the current code
rather than trusting the reports.

Findings:

- No `AGENTS.md`, `CLAUDE.md`, `.env.example`, API/architecture document, or
  migration/deployment runbook exists.
- `docs/JAM_LIFE_BACKEND_API_AUDIT.md` is partly stale: it says the project has a
  `cart` app (true) but describes no order creation endpoint (the new
  `commerce` app now has one) and says media is unconfigured (now configured).
- `docs/JAM_LIFE_FRONTEND_FINAL_VALIDATION.md` claims Docker and full checkout
  verification that is not supported by current state: Docker is not running and
  checkout was demo-only at that time.
- `README.md` still describes carts/orders as out of scope and localStorage
  tokens; the commerce order API and auth UI now exist. It also references a
  non-existent `.env.example`.
- `jam-life.html` is the visual reference only; it is not a specification for the
  new commerce APIs.

## 2. Current architecture (verified from source)

### Backend apps

| App | Role |
|---|---|
| `accounts` | Custom user, OTP request/verify/signup, JWT issuance |
| `businesses` | Business/Menu/Category/Product, public menu, QR (out of scope to extend) |
| `subscriptions` | Plans, subscription status, ZarinPal subscription checkout, activation codes |
| `payments` | `Transaction` bound to a `Subscription`; ZarinPal adapter and callback |
| `cart` | `Cart`/`CartItem`; stores client-supplied name/price and is unused by the frontend |
| `commerce` | New canonical commerce domain: orders, commission, settlement, club, visits, purchase codes, campaigns, agreements |
| `bot` | Telegram linking |

### Canonical catalog and orders

- Canonical catalog: `businesses.Business` → `Menu` → `Category` → `Product`.
  Prices are `PositiveBigIntegerField` Toman. Products have `is_available`;
  menus have `is_active`; public visibility additionally requires an active
  subscription with a valid date range.
- Legacy cart does **not** reference `Product`; it trusts client name/price and
  has no server-side repricing. It is not suitable for order placement.
- Canonical order: `commerce.Order` / `OrderItem`, with status events, commission
  snapshot, settlement entry and idempotency key. `OrderItem.product` points at
  the real `Product`.
- `commerce.services.create_order` resolves product IDs server-side, rejects
  cross-store/unavailable items, rejects quantities outside 1–99, computes
  subtotal/delivery/total from `StoreConfig`, and never accepts client prices.
- No duplicate order model exists; `cart` is only an obsolete cart store.

### Payments

- Only subscription payments are integrated with ZarinPal.
- `Transaction` requires a non-null `Subscription`; it cannot represent an order
  payment.
- Order creation supports `payment_method="online"` but there is **no order
  payment initiation/verification**; the only way to mark an order paid is the
  seller-only simulated endpoint, gated by
  `COMMERCE_ALLOW_SIMULATED_PAYMENTS`.
- Therefore online order payment is a real gap, not a completed feature.

### Frontend

- `lib/api.ts`: same-origin JWT client with single-flight refresh; tokens in
  `localStorage`.
- `/api/[...path]` proxy forwards to Django with trailing slash restoration,
  query, method, body and authorization header; private responses are `no-store`.
- `/m/[slug]`: real backend menu via SSR, but silently falls back to demo stores
  on any backend failure. This is a production data-isolation defect.
- `/`, `/search`, `/store/[id]`: demo catalog from `lib/data.ts`.
- `/cart`, `/checkout`, `/orders`, `/order/[id]`: localStorage demo orders; fake
  gateway; no backend order creation.
- Seller panel (`/panel/*`, `/revenue`, `/club`, `/visit/[storeId]`) is already
  server-backed against `/api/commerce/*`.
- PWA `sw.js` v2 uses explicit public-menu allowlists and excludes private routes.

## 3. Baseline commands and results

Environment: macOS, Python 3.14.5 runtime, Django 5.1.x, Node/npm project deps,
local PostgreSQL accepting connections, no Docker daemon, Chrome installed,
Playwright available through `npx` (not a project dependency).

| Command | Result |
|---|---|
| `cd backend && python3 manage.py test --settings=config.test_settings` | **PASS — 132 tests**, in-memory SQLite |
| `python3 manage.py check --settings=config.test_settings` | **PASS — no issues** |
| `python3 manage.py makemigrations --check --dry-run --settings=config.test_settings` | **PASS — no changes** |
| `cd frontend && npx tsc --noEmit` | **PASS** |
| `npm run build` | **PASS** (25 routes, production build) |
| `npm run lint` | **BLOCKED — no ESLint configuration**; `next lint` prompts interactively and exits non-zero |
| `docker version` | **BLOCKED — daemon not running** |
| `pg_isready -h 127.0.0.1 -p 5432` | **PASS — accepting connections** |

No pre-existing test failures were observed. Existing limitations from the
previous phase (no browser PWA matrix, no PostgreSQL concurrency run) remain
until verified in this phase.

## 4. Identified gaps and dependencies

1. **Customer catalog/checkout gap (critical):** `/m/[slug]` is real, but cart,
   checkout, order history and tracking are localStorage demo flows; home,
   search and store pages are demo catalogs.
2. **No server quote:** checkout cannot show authoritative totals before order
   creation.
3. **No public store directory:** only per-slug public menus and club stores are
   exposed; a production-safe home/search cannot list real stores.
4. **Online order payment absent:** no order-bound transaction model or
   initiation/verification path. Must either be implemented with provider tests
   and credentials documented, or explicitly blocked in the UI/API. It must not
   be simulated as paid.
5. **Demo fallback in production:** `/m/[slug]` falls back to demo data; demo
   routes have no environment gate.
6. **Auth hardening:** localStorage tokens, no server logout/revocation, refresh
   reuse, and single-flight behavior under real concurrent requests need audit
   and tests. Authorization must be tested via direct API calls.
7. **PostgreSQL concurrency:** tests use in-memory SQLite; true row-lock and
   constraint behavior not yet exercised on PostgreSQL.
8. **PWA runtime:** only static review and build; install/offline/update matrix
   not executed.
9. **Deployment:** no `.env.example`, no health endpoints, Docker daemon
   unavailable, production settings not run with `check --deploy`.
10. **Lint:** no ESLint configuration; cannot claim lint passes.

## 5. Architecture decisions for this phase

- Keep `businesses` catalog and `commerce.Order` as canonical. Do **not** revive
  the legacy cart or create a duplicate order model.
- Add a server-side quote endpoint that reuses the same item resolution/pricing
  as order creation.
- Add a public store directory API limited to active, published stores.
- Add real public catalog/cart/checkout/order tracking paths for `/m/[slug]`,
  while keeping demo UI available only behind an explicit demo flag.
- Do not introduce an order-payment provider model without a verified provider
  path; if it cannot be completed safely, reject online order payment and
  document the blocker instead of simulating success.
- Use isolated PostgreSQL database(s) only; never touch the development or
  production database.
