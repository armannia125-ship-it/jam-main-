# JAM Batch 1.5 — Legacy Removal Implementation Plan

**Status:** AUDIT COMPLETE — READY FOR OWNER REVIEW  
**Date:** 2026-11-10  
**Companion audit:** `docs/audits/JAM_BATCH_1_5_LEGACY_REMOVAL_AUDIT.md`  
**Companion decision brief:** `docs/audits/JAM_BATCH_1_5_ARCHITECTURE_DECISION_BRIEF.md`

This plan is not authorized for execution. It is provided for owner review.

## 1. Guiding principles

- Remove legacy compatibility entirely; do not retain dual-model fallbacks.
- Do not change product prices, durations, definitions, entitlement types, or approved access rules.
- Do not migrate or preserve historical records; the owner has stated none exist.
- Use forward-only migrations and preserve historical migration files unless separately approved.
- Keep each batch small and reviewable.
- Update tests and docs in the same removal batch.
- Verify with targeted tests, migration checks, and full regression.

## 2. Recommended batches

### Batch A — Centralized entitlement-only policy

Files:

- `backend/subscriptions/entitlements.py`
- `backend/businesses/views.py`
- `backend/commerce/services.py`
- `backend/bot/management/commands/run_telegram_bot.py`

Changes:

- Remove `Subscription` fallback from `menu_access()`.
- Remove `ClubMembership` fallback from `club_access()`.
- Remove legacy unlimited-product fallback from `product_limit()`.
- Replace public menu and QR filters with valid MENU entitlement filters.
- Replace store directory filters with valid MENU entitlement filters.
- Replace bot legacy check with entitlement-only policy if bot support is retained.

Tests:

- Menu/QR/directory visible for active MENU entitlement.
- Expired/revoked MENU entitlement hidden.
- CLUB-only hidden from menu surfaces.
- Multiple entitlements do not duplicate.

### Batch B — Backend legacy model and API removal

Files:

- `backend/subscriptions/models.py`
- `backend/subscriptions/serializers.py`
- `backend/subscriptions/services.py`
- `backend/subscriptions/views.py`
- `backend/subscriptions/urls.py`
- `backend/subscriptions/admin.py`
- `backend/subscriptions/purchase_views.py`

Changes:

- Remove `SubscriptionPlan`, `Subscription`, `ActivationCode`, `ActivationCodeEvent`.
- Remove legacy plan serializer and subscription serializer.
- Remove `request_manual_subscription`, `canonical_plan`, and `manual_payment_info` if unused.
- Remove legacy views, routes, and 410 compatibility endpoints.
- Remove legacy admin registrations and actions.
- Remove bot activation-code issuance if no longer supported.

Tests:

- Purchase and entitlement flow still works.
- Legacy endpoints are removed or return 404 as appropriate.
- Admin entitlement management still works.

### Batch C — Payment and commerce legacy removal

Files:

- `backend/payments/models.py`
- `backend/payments/views.py`
- `backend/payments/migrations/...` (new migration only)
- `backend/commerce/models.py`
- `backend/commerce/services.py`
- `backend/commerce/admin.py`
- `backend/accounts/admin_views.py`

Changes:

- Remove `Transaction.subscription`.
- Require `Transaction.purchase`.
- Remove legacy payment callback branch.
- Remove `ClubMembership` or replace with non-subscription agreement metadata only if approved.
- Replace simulated membership activation with entitlement activation or remove simulated path.
- Remove legacy counts from admin overview.

Tests:

- Verified payment activates purchase and entitlements.
- Failed/cancelled payment does not activate.
- Club visibility uses CLUB entitlements.
- Admin overview no longer references legacy models.

### Batch D — Frontend contract and UI removal

Files:

- `frontend/lib/subscriptions.ts`
- `frontend/app/panel/plan/page.tsx`
- `frontend/app/panel/subscriptions/page.tsx`
- `frontend/app/admin/subscriptions/page.tsx`
- Any subscription API consumers found during implementation

Changes:

- Replace legacy manual request/payment info/redeem types with purchase and entitlement status.
- Remove or replace manual activation-code redemption UI.
- Update admin subscription views to purchases/entitlements.
- Keep online purchase flow unchanged.

Tests:

- Frontend typecheck/build.
- No references to removed endpoints.
- Purchase and entitlement status display works.

### Batch E — Migration and schema cleanup

Files:

- New migration under `backend/subscriptions/migrations/`
- New migration under `backend/payments/migrations/`
- New migration under `backend/commerce/migrations/` if `ClubMembership` is removed

Changes:

- Drop legacy tables and related indexes/constraints.
- Remove `Transaction.subscription`.
- Drop `ClubMembership` if approved.
- Preserve all prior migrations.
- Do not rewrite migration history without separate approval.

Verification:

- `makemigrations --check`
- Fresh database migration test.
- Existing test database migration where applicable.

### Batch F — Tests, documentation, and final regression

Files:

- `backend/businesses/tests.py`
- `backend/subscriptions/tests.py`
- `backend/subscriptions/test_concurrency.py`
- `backend/subscriptions/test_legacy_compatibility.py`
- `backend/commerce/tests.py`
- `backend/payments/tests.py`
- `docs/LEGACY_COMPATIBILITY.md`
- `docs/MANUAL_SUBSCRIPTION_WORKFLOW.md`
- `docs/MANUAL_ACTIVATION_SECURITY_AUDIT.md`
- `docs/SUBSCRIPTION_ARCHITECTURE.md`
- `docs/SINGLE_SUBSCRIPTION_MODEL.md`
- `docs/PRODUCTION_OPERATIONS_RUNBOOK.md`
- `docs/DEPLOYMENT_FOUNDATION_BASELINE.md`
- `docs/JAM_BATCH_1_3_AGENT_GOVERNANCE_AUDIT.md`
- `docs/JAM_BATCH_1_4_PUBLIC_MENU_ENTITLEMENT_AUDIT.md`
- `docs/JAM_BATCH_1_4_PUBLIC_MENU_ENTITLEMENT_DECISION_BRIEF.md`
- `AGENTS.md`

Changes:

- Replace legacy tests with entitlement-only tests.
- Remove dual-model compatibility tests.
- Update documentation to reflect removal.
- Mark obsolete historical docs appropriately.
- Run full backend and frontend regression.

## 3. Required test matrix

- Basic purchase creates one MENU entitlement.
- Professional purchase creates one MENU entitlement.
- Premium purchase creates one MENU entitlement.
- Gold purchase creates one MENU and one CLUB entitlement.
- Seller Club purchase creates one CLUB entitlement.
- Active entitlement grants access.
- Expired entitlement grants no access.
- Revoked entitlement grants no access.
- MENU entitlement does not grant CLUB access.
- CLUB entitlement does not grant MENU access.
- User/business ownership isolation.
- Public menu access.
- QR access.
- Public directory visibility.
- Unpublished menu remains inaccessible.
- Multiple entitlements do not duplicate or error.
- Legacy code no longer exists.
- API contract regression.
- Frontend typecheck/build.
- Fresh database migration.
- Full backend and frontend regression.

## 4. Migration risks

- `Transaction.subscription` is nullable and protected by `transaction_has_one_target`; removing it requires coordinated model, migration, and test changes.
- `ClubMembership` is referenced by commerce services, admin, tests, and possibly agreement flows; removing it may require retaining agreement metadata separately.
- `ActivationCode` and `Subscription` are deeply referenced by tests; implementation must replace tests in the same batch to avoid a broken suite.
- Frontend legacy UI is stale relative to the online purchase flow; removal must avoid breaking unrelated panel/admin functionality.
- Documentation references legacy behavior extensively; stale docs can mislead operators.

## 5. No implementation performed

This document is an implementation plan only. No source code, migration, database, frontend, infrastructure, commit, push, or deploy action was performed in Batch 1.5.
