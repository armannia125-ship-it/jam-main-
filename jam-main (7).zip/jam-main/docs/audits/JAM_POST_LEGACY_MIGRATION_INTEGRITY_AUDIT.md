# JAM Post-Legacy Migration Integrity Audit

**Date:** 2026-11-10\
**Status:** CONFIRMED / FIXED\
**Database:** PostgreSQL 16.14, isolated local Docker Compose instance\
**Database identity:** `127.0.0.1:55432`; databases `jam_postlegacy_fresh`, `jam_postlegacy_clean`, `jam_postlegacy_legacy`\
**Credentials:** supplied through local environment variables; not recorded here.

## 1. Migration graph

Commands:

```bash
python backend/manage.py makemigrations --check --dry-run --settings=config.test_settings
python backend/manage.py migrate --check --settings=config.test_settings
python backend/manage.py showmigrations --settings=config.test_settings
```

Results:

- `makemigrations --check --dry-run`: **No changes detected**.
- `migrate --check`: **exit 0** against the fully migrated fresh database.
- `showmigrations`: all applicable migrations applied; no missing node or circular dependency.
- Historical migrations were not edited.

## 2. New migrations inspected

### `commerce/0004_remove_clubmembershipevent_business_and_more.py`

Deletes `ClubMembershipEvent` and `ClubMembership` in dependency-safe order. Tested with real rows in both tables.

### `commerce/0005_alter_invoice_kind.py`

Removes `subscription` and `membership` from the `Invoice.Kind` choices and changes the application default to `setup`.

- **CONFIRMED:** no FK/index/constraint operation.
- **CONFIRMED:** Django does not create a database-level default; `column_default` is empty and the application default is `setup`.
- **LIMITATION:** pre-existing invoice rows with the old kinds are not rewritten or deleted. The revenue page renders invoice title/amount, not the kind, so these historical rows do not break the tested UI. No deletion or remapping policy was invented.

### `payments/0004_remove_transaction_transaction_has_one_target_and_more.py`

Operations verified:

1. Run cleanup for transactions with `purchase IS NULL`.
2. Remove `transaction_has_one_target`.
3. Remove `Transaction.subscription`.
4. Make `Transaction.purchase` mandatory (`PROTECT` FK, `NOT NULL`).

**FIXED:** cleanup now queries through `schema_editor.connection.alias` and prints the number of deleted orphan transactions, so the destructive cleanup is explicit in migration output rather than silent.

### `subscriptions/0007_remove_activationcodeevent_code_and_more.py`

Deletes `ActivationCodeEvent`, `ActivationCode`, `Subscription`, and `SubscriptionPlan` after `payments/0004`. Tested with real activation-code and subscription rows.

## 3. Migration scenarios

### Scenario A — fresh database

Database: `jam_postlegacy_fresh`

```bash
POSTGRES_DB=jam_postlegacy_fresh python backend/manage.py migrate --noinput
```

Result: **CONFIRMED**, all migrations applied successfully, exit 0.

### Scenario B — previous state, no legacy records

Database: `jam_postlegacy_clean`

1. Migrate to `payments 0003` (with `commerce 0003` already applied).
2. Migrate to latest.

Result: **CONFIRMED**, exit 0; no orphan cleanup output.

### Scenario C — representative legacy records

Database: `jam_postlegacy_legacy`

Seeded at the pre-removal state:

- user and business,
- `SubscriptionPlan`, active `Subscription`,
- `ActivationCode`,
- `ClubMembership`, `ClubMembershipEvent`,
- canonical product and two paid purchases,
- three transactions:
  - `ORPHAN`: legacy subscription target, `purchase=NULL`,
  - `VALID`: canonical purchase target, `subscription=NULL`,
  - `BOTH`: both legacy subscription and canonical purchase.

Migration output:

```text
Deleting 1 legacy transaction(s) without a canonical purchase before making Transaction.purchase mandatory.
```

Result: **CONFIRMED**.

Final state:

| Check | Result |
|---|---|
| `ORPHAN` transaction exists | No — deleted by explicit cleanup |
| `VALID` transaction exists with purchase | Yes |
| `BOTH` transaction exists with purchase | Yes |
| Transactions with `purchase_id IS NULL` | 0 |
| `payments_transaction.purchase_id` nullable | `NO` |
| `transaction_has_one_target` constraint exists | No |
| `unique_nonempty_transaction_authority` index exists | Yes |
| `subscriptions_subscriptionplan` table | Absent |
| `subscriptions_subscription` table | Absent |
| `subscriptions_activationcode` table | Absent |
| `subscriptions_activationcodeevent` table | Absent |
| `commerce_clubmembership` table | Absent |
| `commerce_clubmembershipevent` table | Absent |

## 4. Cleanup policy

The migration explicitly deletes transactions with no canonical purchase. This preserves valid purchase-linked transactions but does **not** preserve orphaned legacy payment rows. That is the implemented behavior and is now logged by count. No refund or revenue-preservation policy was added because none was approved.

## 5. Final checks

- Fresh migration on PostgreSQL: **CONFIRMED**
- Clean-forward migration: **CONFIRMED**
- Legacy-record cleanup: **CONFIRMED**
- Orphan transaction behavior: **CONFIRMED**
- Valid purchase-linked transaction preservation: **CONFIRMED**
- Final NOT NULL and constraint state: **CONFIRMED**
- Model/migration state consistency: **CONFIRMED**
- Historical migrations unchanged: **CONFIRMED**

No reverse migration was run against a non-disposable database. No external database was touched.
