# JAM Batch 1.5 — Architecture Decision Brief

**Status:** AUDIT COMPLETE — READY FOR OWNER REVIEW  
**Date:** 2026-11-10  
**Companion audit:** `docs/audits/JAM_BATCH_1_5_LEGACY_REMOVAL_AUDIT.md`

## 1. Approved decisions

The owner has approved the following architectural decisions:

- JAM has not been publicly released.
- There are no existing users or historical subscription records requiring preservation.
- Legacy subscription compatibility is unnecessary.
- The legacy `Subscription` system must be completely removed.
- `SubscriptionPurchase` + `SubscriptionEntitlement` is the sole source of truth.
- No grandfathering, dual-model access checks, or legacy fallback behavior.
- Product prices, durations, product definitions, entitlement types, and previously approved business rules remain unchanged.

These are approved architecture decisions, not implementation authorization.

## 2. Target architecture

### 2.1 Core models

- `SubscriptionPurchase`: buyer, business, product, status, price snapshot.
- `SubscriptionEntitlement`: user, business, type, product, purchase, starts/ends, status, revocation metadata.
- `SubscriptionProduct`: canonical catalog with `menu`, `club`, or `combo` category.

### 2.2 Product-to-entitlement mapping

| Product | Entitlements |
|---|---|
| Basic | MENU |
| Professional | MENU |
| Premium | MENU |
| Gold | MENU + CLUB |
| Seller Club | CLUB |

### 2.3 Access-control principle

Every subscription-protected feature must derive access exclusively from valid new-system entitlements. A legacy `Subscription` record must never grant access. MENU and CLUB access must remain independent.

## 3. Centralized entitlement policy

Recommended implementation is a single entitlement policy consumed by all protected boundaries:

- `menu_access(business)` checks only current MENU entitlements.
- `club_access(business, moment)` checks only current CLUB entitlements.
- `product_limit(business)` checks only current MENU entitlements.
- Public menu, QR, and directory use the same MENU entitlement policy.
- Bot editing uses the same MENU entitlement policy if retained.
- Admin dashboards report only new entitlements and purchases.

The policy should be query-level where filtering is needed to avoid duplicate rows and inconsistent results.

## 4. Public visibility rules

After removal:

- A valid MENU entitlement grants public menu URL, QR, and store directory access.
- An expired MENU entitlement grants no access.
- A revoked MENU entitlement grants no access.
- CLUB-only access grants no MENU access.
- Unpublished/inactive menus remain inaccessible.
- Multiple valid entitlements must not create duplicate public rows or server errors.
- Public directory, QR, and public menu must use the same policy.

## 5. Removal direction

Remove all legacy components rather than retaining 410 compatibility endpoints:

- Legacy `Subscription`, `SubscriptionPlan`, `ActivationCode`, and `ActivationCodeEvent`.
- Legacy manual request, payment info, checkout, and redemption endpoints.
- Legacy activation code admin actions.
- Legacy payment callback branch.
- Legacy `ClubMembership` or replace it only if a separate business decision requires retaining non-subscription agreement metadata.
- Legacy frontend manual payment and activation-code UI.
- Legacy fallbacks in entitlements and public reads.
- Legacy tests and documentation claims.

## 6. Migration direction

Use a forward-only cleanup migration after code references are removed:

- Remove legacy tables and related indexes/constraints.
- Remove `Transaction.subscription` and require `Transaction.purchase`.
- Preserve historical migrations.
- Do not rewrite migration history without separate owner approval.
- Verify fresh-database migration and full regression.

## 7. Risks

| Risk | Mitigation |
|---|---|
| Missed legacy reference causes runtime failure | Complete inventory and grep verification before removal |
| Payment target constraint mismatch | Update `Transaction` model and migration together |
| Club visibility regression | Replace `ClubMembership` with CLUB entitlement tests |
| Frontend contract breakage | Update API clients and UI in the same batch |
| Documentation drift | Update all affected docs and mark obsolete references |
| Test suite churn | Replace legacy tests with entitlement-focused tests |

## 8. Remaining unresolved questions

1. Should `ClubMembership` be removed entirely, or should non-subscription agreement metadata be retained separately?
2. Should `SubscriptionPlan` be retained for historical reporting or removed completely?
3. Should manual payment instructions remain as support documentation?
4. Should bot-based product editing remain supported?
5. Should the frontend panel plan page be replaced or removed?
6. Should admin subscription management be replaced by purchase/entitlement management only?

## 9. Final status

AUDIT COMPLETE — READY FOR OWNER REVIEW
