# Dedicated QR — Audit, Correction & Verification Closure

**Date:** 2026-11-13
**Project:** JAM (Jam Life) — Persian-first, RTL marketplace
**Scope:** Dedicated QR code only (seller menu QR, backend endpoint, public URL, tests, docs)
**Constraint:** No deployment, commit, push, tag, release, external provider call, migration, or new dependency.

---

## 0. Pre-implementation audit state

- Branch: `main`, working tree clean at start (HEAD `2dcac3e add QR code`).
- No unrelated modifications were present; none were discarded.
- No nested `AGENTS.md`. Governed by repository `AGENTS.md`.
- Backend stack available locally (system Python, Django 5.1.4 available; project targets 5.2.18; tests use `config.test_settings` and in-memory SQLite).
- **No frontend test runner exists** (no Jest/Vitest config, no test script, no test files). Adding one is a new dependency and requires owner approval per `AGENTS.md` §9.

## 1. Confirmed defects (evidence at HEAD)

| # | Defect | Evidence | Root cause |
|---|---|---|---|
| A | QR panel used demo data, not the selected seller | `frontend/app/panel/menu/page.tsx`: `const s = getStore(String(sid ?? "")) \|\| STORES[0];` | `sid` is a backend business id; `getStore()` searches static demo `STORES` keyed `s1`, `s2`, … so lookup always missed and fell back to `STORES[0]`. |
| B | Wrong identifier passed to the QR endpoint | Same file: `apiFetch(\`/qr/${s.slug}/\`)` | Frontend sent a **business/demo** slug. The endpoint resolves `Menu.slug`; `Business.slug` and `Menu.slug` are independent unique fields and there is no invariant that they match. |
| C | QR destination derived from request headers | `backend/businesses/views.py::QrCodeView`: `request.headers.get("Host")`, `request.is_secure()` | Requests arrive through the Next.js server proxy to `API_INTERNAL_URL`; the upstream `Host`/`X-Forwarded-Host` is an internal or attacker-controlled value, not the public frontend origin. |
| D | Entitlement/publication failures collapsed into one message | Frontend showed a single fallback string | No distinct backend `code` values for entitlement vs unpublished vs no menu vs configuration. |
| E | Misleading print control | Button fired `toast("در نسخهٔ نمایشی در دسترس نیست")` while labelled «چاپ کارت رومیزی» | Non-functional control presented as a real action. |
| F | Wrong copy/open links | `const url = \`/m/${s.slug}\`` | Built from the demo store slug, not the real menu. |

Also corrected: the earlier report claimed the checkout/order-tracking flows were missing. They were already implemented and wired (`app/checkout` → `components/features/api-checkout-page.tsx`, `app/order/[id]` → `components/features/server-orders.tsx`). That premise was wrong; this batch does not touch them.

## 2. Implemented corrections

### 2.1 Backend

- **`PUBLIC_FRONTEND_URL` setting** (`backend/config/settings.py`): `PUBLIC_FRONTEND_URL = os.getenv("PUBLIC_FRONTEND_URL", "").strip()`.
- **Validated URL builder** (`backend/businesses/views.py`): `_public_frontend_base()` accepts only absolute `http`/`https` with a host, rejects credentials/query/fragment/relative values, and strips trailing slashes. `_public_menu_url()` builds `{base}/m/{menu.slug}` (no trailing slash, matching the Next.js `/m/[slug]` route).
- **`QrCodeView` (public, by menu slug)** now builds the destination from `PUBLIC_FRONTEND_URL` only and returns `503 public_frontend_url_unconfigured` when unset/invalid. Request headers are not read for URL construction.
- **New `SellerQrCodeView`** at `GET /api/businesses/<business_id>/qr/` (authenticated, default `IsAuthenticated`):
  - business resolved with `owner=request.user` → cross-owner requests get `404 business_not_found`;
  - `menu_access(business)` (the existing `SubscriptionEntitlement` service) enforced → `404 menu_entitlement_inactive`;
  - menus resolved through `Menu.business` (never `Business.slug`);
  - distinct `code` values: `menu_unavailable`, `menu_unpublished`, `menu_not_published`, `menu_selection_required`;
  - optional `?menu=<Menu.slug>` must be a **published menu of this same business**;
  - response: `{ menuTitle, menuSlug, publicUrl, qrCode }` where `qrCode` is a real `data:image/png;base64,…` PNG.
- Route registered in `backend/businesses/urls.py`.
- No migrations and no model changes.

### 2.2 Frontend (`frontend/app/panel/menu/page.tsx`)

- QR now resolves the **real selected business** from the authenticated `CommerceProvider` (`useCommerce().business(sid)`), not demo `STORES`.
- Calls `/businesses/<id>/qr/` (authenticated); effect re-runs when the selected business or a retry attempt changes.
- Explicit states: `idle` (no business), `loading`, `ready`, and `error` with backend Persian `detail` + `code`, plus a retry button for recoverable failures (network / 5xx / 429).
- QR image and download use the same `ready` payload; filename `qr-<menuSlug>.png`.
- Copy and «باز کردن منو» use the real resolved menu (`publicUrl` / `/m/<menuSlug>`).
- Print now performs a real `window.print()` on a print-ready window containing the QR, menu title, and public URL. Whole-window popups blocked by the browser are reported with a Persian error.
- Demo `STORES` is retained **only** for the visual phone-template preview (`previewStore`) and is never used for QR/menu identity. This preserves the existing preview design without contaminating QR data.

## 3. Menu selection policy

1. Business → its `Menu` rows via the `Menu.business` foreign key.
2. Access requires a current active `MENU` entitlement (`entitlements.menu_access`).
3. Only `is_active=True` (published) menus are eligible.
4. Exactly one published eligible menu → used.
5. Multiple published eligible menus:
   - `?menu=<slug>` selects one explicitly (must belong to the business and be published);
   - without it the endpoint returns **`409 menu_selection_required`** with `{slug,title}` rows and **no QR**. It does **not** silently choose the first row.
6. Zero menus / none published → explicit 404 codes.

**Owner decision (resolved 2026-11-13):** multi-menu businesses use an **explicit Menu Picker**; no automatic default-menu rule is introduced. See §10.

`commerce.services.public_store_directory()` still publishes *all* eligible menus; that directory behavior is unchanged and unrelated to the seller's QR selection.

## 4. Public QR URL

```env
PUBLIC_FRONTEND_URL=https://shop.example
```

Resulting destination: `https://shop.example/m/<Menu.slug>` (for example `https://shop.example/m/cafe-menu`).

- Never derived from `Host`, `X-Forwarded-Host`, or `request.is_secure()`.
- Missing/invalid value → `503 public_frontend_url_unconfigured`; no localhost/internal fallback.
- The value must be an **origin only**: `http`/`https`, a valid hostname, an optional valid port, no credentials, no query, no fragment, and no path other than `/` (see §11.2).
- Documented in `.env.example`, `docs/deployment/STAGING_OPERATIONS.md`, and `docs/deployment/JAM_PHASE_3_1_RECOMMENDED_STAGING_ARCHITECTURE.md`.
- `config/test_settings.py` sets `PUBLIC_FRONTEND_URL = "https://jam.test"` for deterministic tests.

## 5. Tests added — `backend/businesses/test_qr.py` (14 tests)

Coverage: valid PNG; exact public URL; `Menu.slug` vs `Business.slug`; configured-origin use on the public endpoint; forged `Host`/`X-Forwarded-Host`/`X-Forwarded-Proto`; missing and invalid configuration (relative, non-HTTP, query); trailing-slash normalization; inactive entitlement; unpublished menu; business with no menu; cross-owner denial; unauthenticated denial; multi-menu ambiguity + explicit `?menu=`; `?menu=` cannot select another business's menu.

**Payload verification method:** the returned PNG is decoded back to its black/white **module matrix** and compared with an independently generated QR matrix for the exact expected URL (plus PNG format/size assertions). This proves the encoded destination without adding a QR-decoder dependency (which `AGENTS.md` §9 forbids without owner approval). It is not a full BCH/RS string decode — see limitations.

## 6. Verification performed

| Check | Command | Result |
|---|---|---|
| QR suite | `python3 manage.py test businesses.test_qr --settings=config.test_settings` | **14 passed** |
| Businesses + subscriptions | `python3 manage.py test businesses subscriptions --settings=config.test_settings` | **69 passed, 8 skipped** (PostgreSQL-only concurrency tests) |
| Migration drift | `python3 manage.py makemigrations --check --dry-run --settings=config.test_settings` | `No changes detected` (exit 0) |
| Django checks | `python3 manage.py check --settings=config.test_settings` | 0 issues |
| TypeScript | `npx tsc --noEmit` (frontend) | exit 0 |
| ESLint (changed file) | `npx eslint app/panel/menu/page.tsx` | 0 errors, 3 pre-existing `no-img-element` warnings |
| Production build | `npm run build` (frontend) | exit 0; `/panel/menu` compiled |

### Verification status

- **Implemented:** backend public URL source, seller-scoped endpoint, entitlement/publication checks, ambiguity handling, frontend states/retry/print/download.
- **Automated-test verified:** all backend QR behavior listed in §5; TypeScript, ESLint, and production build.
- **Locally integration verified:** *not performed* — no live backend + frontend session, no authenticated seller walkthrough, no business switching against a running stack.
- **Manually verified:** *not performed* — no visual/print review; no physical QR scan.
- **Not verified:** frontend automated tests (no test runner); decoded string payload (no decoder dependency); multi-menu UI selection; real-device scanning.

## 7. Remaining limitations / owner decisions

1. **No frontend test runner** — frontend tests cannot be added without a new dependency/framework (owner approval required). Frontend behavior is covered only by type-check, lint, and production build.
2. **Payload test is module-matrix equality**, not a string decoder. Adding `zxing-cpp`/`opencv`/`pyzbar` requires owner approval.
3. **Multiple published menus**: resolved by the explicit Menu Picker (§10). No automatic default is used; the endpoint still returns `409 menu_selection_required` until the seller selects a menu.
4. **Local integration/browser/print/scan checks were not run.**
5. `PUBLIC_FRONTEND_URL` must be set in every environment where QR is expected to work, or the endpoint fails closed by design.
6. Production readiness status is unchanged; this work does not imply deployment readiness.

## 8. Git state

No commit, push, tag, release, or deployment was performed. Changes are local only; see `git status`.

## 9. Scope confirmation

Order Registration, Order Tracking, JamPlay, tourism map, ZarinPal/payments, OTP/authentication, subscription architecture/pricing, and unrelated dashboard components were **not modified**. Only the QR feature, its configuration/tests, and QR/deployment documentation changed.

## 10. Multi-Menu Picker (2026-11-13)

### 10.1 Owner decision

When a business has more than one eligible (published) menu, the seller must explicitly choose which menu the QR represents. There is no database-first, frontend-first, or automatic default selection, and a demo menu is never used as a fallback. One eligible menu is selected automatically by the backend.

### 10.2 Pre-implementation audit

The picker was **not** implemented before this batch. The frontend received the `409 menu_selection_required` response but only rendered its Persian `detail` plus the menu titles joined as text; it never sent `?menu=`, never showed which menu the QR belonged to, and had no selection persistence. The backend contract (eligible-menu resolution, entitlement/publication checks, `409` payload with `{slug,title}` rows, `?menu=` validation) was already correct and was reused without change.

### 10.3 Behavior

| Situation | Frontend behavior |
|---|---|
| One eligible menu | Backend returns its QR directly; the panel shows the QR and the menu's real title. No picker is shown. |
| Multiple eligible menus, none selected | `409` shows a Persian picker listing every eligible menu by title; no QR, and copy/download/print/open remain unavailable until a menu is chosen. |
| Menu selected | Requests `?menu=<slug>`; while loading the previous QR is removed; on success the QR and its menu title/slug are shown and the picker stays visible for switching. |
| No menu / no published menu / entitlement inactive / configuration error | Distinct backend `detail` messages are shown in the QR placeholder; no QR is rendered. |
| Network/server failure | A separate Persian retry message plus «تلاش دوباره» for network/5xx/429 failures. |
| Business switched | Selection belongs to a business id; the new business starts unresolved, the previous business's options and QR are not rendered even before the refetch resolves, and stale responses are ignored via an effect-local `active` flag. |

Selection persistence is per business id under `localStorage["jam.qr.menu.v1"]`. A stored slug is restored **only** if the server's eligible-menu list for that same business contains it. If a stored selection later becomes unpublished, the panel clears it and re-resolves with no `?menu=` parameter.

### 10.4 API contract used by the frontend

`GET /api/businesses/<business_id>/qr/` (authenticated, owner-scoped)

- `200`: `{ menuTitle, menuSlug, publicUrl, qrCode }`
- `409`: `{ detail, code: "menu_selection_required", menus: [{ slug, title }] }`
- Explicit selection: `GET /api/businesses/<business_id>/qr/?menu=<Menu.slug>`

Selection is validated server-side against published menus of the **same** business; a foreign or unknown slug returns `404 menu_not_published`. The panel displays the persisted selection only from server-validated data; it never trusts the stored slug alone.

### 10.5 QR action consistency

The image, download (`qr-<menuSlug>.png`), copy, open (absolute `publicUrl` from `PUBLIC_FRONTEND_URL`), and print (QR image + `menuTitle` + `publicUrl`) all read the single `ready` payload. None reconstructs a URL from `Business.slug`. Selecting another menu or business discards that payload before new data arrives.

### 10.6 Tests and results

Backend additions in `backend/businesses/test_qr.py`: each published menu generates its own QR/URL; unknown slug is rejected; an unpublished menu is neither counted as eligible nor selectable; a menu from another business owned by the same seller cannot be selected. Existing tests already covered single-menu automatic use, the `409` payload, cross-owner denial, inactive entitlement, and exact encoded URL.

| Check | Command | Result |
|---|---|---|
| QR suite | `python3 manage.py test businesses.test_qr --settings=config.test_settings` | **18 passed** |
| Businesses + subscriptions | `python3 manage.py test businesses subscriptions --settings=config.test_settings` | **73 passed, 8 skipped** (PostgreSQL-only concurrency tests) |
| Migration drift | `python3 manage.py makemigrations --check --dry-run --settings=config.test_settings` | `No changes detected` |
| Django checks | `python3 manage.py check --settings=config.test_settings` | 0 issues |
| TypeScript | `npx tsc --noEmit` | exit 0 |
| ESLint (changed file) | `npx eslint app/panel/menu/page.tsx` | 0 errors, 3 pre-existing `no-img-element` warnings |
| Production build | `npm run build` | exit 0; `/panel/menu` compiled |

### 10.7 Remaining limitations

1. **No frontend test runner** exists, so picker rendering, selection switching, business switching, and action wiring are covered only by type-check, lint, and production build. Adding Jest/Vitest/Playwright requires owner approval.
2. **No local integration walkthrough** was performed: no running authenticated seller session, no visual/print review, no physical QR scan.
3. Selection persistence is browser-local and per business id; it is not synced across devices and is not a server-side preference.
4. `PUBLIC_FRONTEND_URL` remains required for any QR; the endpoint still fails closed.
5. Production readiness status is unchanged.

## 11. Focused Corrections (2026-11-13)

Four defects were reported and confirmed present before changing code. No API shape, ownership rule, entitlement rule, publication rule, or single-menu automatic selection was changed.

### 11.1 Corrected findings

| # | Finding | Present before? | Correction |
|---|---|---|---|
| A | Retry classification only retried `>= 520` and `429`, so `500/502/503/504` offered no retry. | Yes: `retryable: err.status >= 520 || err.status === 429`. | Classification moved to `frontend/lib/qr-retry.ts::isRetryableQrError(status, code)`: every `500–599` is retryable, `429` is retryable, `public_frontend_url_unconfigured` is never retryable, other `4xx` are not. |
| B | `PUBLIC_FRONTEND_URL` accepted path prefixes (e.g. `https://shop.example/m`) and did not validate the port. | Yes: the validator only rejected scheme/netloc/credentials/query/fragment and appended `parsed.path.rstrip("/")`. | `_public_frontend_base()` now validates origin only: `http`/`https`, real hostname (regex/IP), explicit port in `1–65535`, no credentials/query/fragment, and path only `""` or `"/"`. It returns a normalized `scheme://host[:port]`. |
| C | After a selected menu became unpublished, the stored selection was cleared but the stale picker options stayed, so a later `200` could render an obsolete picker. | Yes: the branch only called `writeStoredMenu(...)` and `setSelected(null)`. | The branch also calls `setOptions(null)`; the effect re-runs without `?menu=` and the backend response repopulates the authoritative state. |
| D | Print window called `window.print()` immediately after inserting the image. | Yes. | Print now waits for `load` + `img.decode()` (falling back to a plain `load` when `decode` is unavailable), calls `print()` only after decode succeeds, reports a Persian error on image failure, and times out after 15s with listeners/timer cleaned up. Popup blocking is still reported without claiming success. |
| E | Re-clicking the **already selected** menu removed the QR and left «در حال ساخت QR منوی انتخابشده…» forever, because `selectedSlug` did not change and the fetch effect never re-ran — so a menu unpublished after selection could never reach the invalid-selection branch. | Yes (pre-existing; found in the browser walkthrough). | `pickMenu()` also bumps `attempt`, so every explicit pick re-resolves through the existing effect. One line; no API or state-shape change. |

### 11.2 `PUBLIC_FRONTEND_URL` contract

Valid: `https://shop.example`, `https://shop.example/`, `http://localhost:3000`, `http://localhost:3000/`.

Invalid (→ `503 public_frontend_url_unconfigured`, no `qrCode`): `ftp://shop.example`, `not-a-url`, `/relative/path`, `https://`, `https:///m`, `https://:8080`, `https://user:password@shop.example`, `https://shop.example?x=1`, `https://shop.example#section`, `https://shop.example/m`, `https://shop.example/path/`, `https://shop.example:abc`, `https://shop.example:0`, `https://shop.example:65536`.

Generated destination remains `{origin}/m/{Menu.slug}`. Request `Host` / `X-Forwarded-Host` / `X-Forwarded-Proto` values never contribute to it, including when the setting is missing (they cannot rescue an unconfigured origin).

### 11.3 Files changed

| Path | Purpose |
|---|---|
| `frontend/lib/qr-retry.ts` | New single source of QR retry classification. |
| `frontend/app/panel/menu/page.tsx` | Uses the helper (A); clears stale picker options on invalid selection (C); waits for image readiness before printing (D). |
| `backend/businesses/views.py` | Strict origin-only validation of `PUBLIC_FRONTEND_URL` (B). |
| `backend/businesses/test_qr.py` | 9 new origin/validation regression tests. |
| `docs/audits/JAM_ORDER_TRACKING_QR_IMPLEMENTATION_CLOSURE.md` | This section. |

### 11.4 Tests and results

| Check | Command | Result |
|---|---|---|
| QR suite | `python3 manage.py test businesses.test_qr --settings=config.test_settings` | **27 passed** (18 + 9) |
| Businesses + subscriptions | `python3 manage.py test businesses subscriptions --settings=config.test_settings` | **82 passed, 8 skipped** (PostgreSQL-only concurrency tests) |
| Django checks | `python3 manage.py check --settings=config.test_settings` | 0 issues |
| Migration drift | `python3 manage.py makemigrations --check --dry-run --settings=config.test_settings` | `No changes detected` |
| Retry classification | Node type-stripped assertion script over `isRetryableQrError` | 13/13 cases pass (500/502/503/504/599/429 retryable; 400/401/404/409/200 not; `public_frontend_url_unconfigured` not retryable at 503 and 500) |
| TypeScript | `npx tsc --noEmit` | exit 0 |
| ESLint (changed files) | `npx eslint app/panel/menu/page.tsx lib/qr-retry.ts` | 0 errors, 3 pre-existing `no-img-element` warnings |
| Production build | `npm run build` | exit 0; `/panel/menu` 8.31 kB |

### 11.5 Browser walkthrough (2026-11-13)

A real authenticated seller session was driven in headless Chrome over CDP (Node's built-in `WebSocket`; no dependency added). The backend ran on a throwaway local SQLite database with a seeded seller, one active MENU entitlement, and three published menus; the Next.js dev server proxied `/api` through the existing same-origin route handler with `PUBLIC_FRONTEND_URL=http://localhost:3000`. **30/30 checks passed:**

| Area | Observed |
|---|---|
| Initial state | Picker lists all three published menus by title; no QR image before an explicit pick. |
| Explicit selection | Each menu renders its own QR; picker keeps the selection marked (`aria-pressed`). |
| Same-menu re-click (E) | Re-picking the current menu issues a fresh `?menu=` request and the QR returns — no stuck loading. |
| Scenario A | Selected menu unpublished, seller picks it from the stale list → `404 menu_not_published`, then an unparameterised request → `409` with two menus; old picker replaced by exactly the two current menus, no obsolete QR. |
| Scenario B | Selected menu unpublished and only one menu remains → stale selection cleared, options cleared (picker gone), unparameterised request → `200` for the remaining menu; no obsolete picker. |
| Print ordering (D) | `window.print()` was called only after `decode()` resolved; image `complete=true`, `naturalWidth=450`; title and `https://…/m/qa-breakfast` URL correct. |
| Image failure | Forced `decode()` rejection → no `print()` call, seller sees «تصویر QR بارگیری نشد». |
| Popup blocked | `window.open` returning `null` → error toast, no print claim. |
| Repeated prints | Two prints → two dialog invocations, each with a loaded image; no stale window reuse. |

What the walkthrough does **not** cover: a native print dialog was intercepted rather than shown, so print output/pagination and physical QR scan legibility remain unverified; only a three-menu, single-business, one-entitlement sandbox was exercised.

### 11.6 Remaining limitations

1. **No frontend test runner** (no Jest/Vitest/Playwright, and adding one needs owner approval). The browser walkthrough is a manual harness, not a committed regression suite.
2. **Native print dialog and printed card not visually verified**, and no physical QR scan was performed.
3. The 15s print readiness timeout is a fixed constant; slow devices may need a manual retry.
4. `PUBLIC_FRONTEND_URL` validation is syntactic; it cannot prove the origin is publicly reachable.
5. Local dev observation (not investigated, outside this batch): running `next dev` with `API_INTERNAL_URL` set returned a same-path `301` loop for `/api/.../` requests, while the local default (the `app/api/[...path]` route handler, which restores the trailing slash) returned `200`. The walkthrough used the local default. The cause was not verified, so no claim is made about other environments.
6. Production readiness status is unchanged.

