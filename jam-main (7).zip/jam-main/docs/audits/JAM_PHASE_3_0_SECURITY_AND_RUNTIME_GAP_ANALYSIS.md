# JAM — Phase 3.0 Security and Runtime Gap Analysis

**Date:** 2026-11-10\
**Scope:** Read-only security and runtime analysis for the proposed staging deployment\
**Authorization:** No implementation, provisioning, or deployment\
**Companion document:** `docs/audits/JAM_PHASE_3_0_PRE_STAGING_AUDIT.md`

---

## 1. Purpose and method

This document expands the security-relevant findings from the pre-staging audit. It does not claim a penetration test, a vulnerability scan, or a production security certification. It answers a narrower question:

> If JAM is deployed to a free-tier staging environment, what can break, what can be abused, and what must the owner explicitly accept?

Evidence is cited as `path:line`. Provider claims are from official documentation read on 2026-11-10. Every item carries a status: `CONFIRMED`, `RECOMMENDED`, `INFERRED`, `OWNER DECISION REQUIRED`, `BLOCKED`, or `NOT TESTED`.

---

## 2. Assets and threat model

### 2.1 Assets

| Asset | Why it matters |
|---|---|
| User accounts and phone/email identifiers | Personal data; OTP delivery costs money |
| JWT access/refresh tokens | Full API impersonation until expiry |
| Admin role and admin APIs | Can change roles, revoke entitlements, inspect payments |
| Subscription purchases and entitlements | Direct revenue and access control |
| ZarinPal merchant credentials | Payment initiation and verification |
| OTPy API key | Paid OTP sending; abuse causes cost and spam |
| S3/R2 credentials | Read/write access to all uploaded media |
| Database credentials | Full tenant and payment data |
| Django admin session | Broad data mutation |
| Telegram bot token | Bot identity and message sending |

### 2.2 Relevant adversaries

| Adversary | Capability | Most relevant gaps |
|---|---|---|
| Opportunistic scanner | Finds exposed admin, default hosts, verbose errors | Django admin exposure, `ALLOWED_HOSTS`, DEBUG |
| Malicious end user | Valid account, can call APIs, upload files | Upload validation, IDOR, rate limits, token theft via XSS |
| XSS attacker | Script execution in another user's browser | `localStorage` tokens, no revocation |
| Payment fraudster | Can replay or forge callback parameters | Callback verification, idempotency |
| Credential-stuffing bot | Can hit OTP/login endpoints | OTP throttling, provider quota |
| Insider/operator error | Can run commands, edit env vars | Manual migration path, secret handling, no audit trail |
| Supply-chain attacker | Compromised dependency/image | Unpinned base images, no scan |

### 2.3 Out of scope

- DDoS beyond platform edge protection.
- Physical security and cloud provider compromise.
- Legal/compliance certification (GDPR, PCI DSS, local regulation).
- Real payment fraud analysis with live ZarinPal traffic.
- Social engineering.

---

## 3. Security findings

### S-01 — JWT stored in `localStorage` (High)

**Evidence:** `frontend/lib/api.ts:11` (`AUTH_KEY = "jam.auth.v1"`), `:32` (`localStorage.getItem`), `:44` (`localStorage.setItem`); `frontend/lib/auth.tsx:4` documents the choice.

**What happens:** access and refresh tokens are persisted in browser storage and attached as `Authorization: Bearer ...`. Any JavaScript executing on the origin can read them. React's default escaping reduces, but does not eliminate, XSS risk: a compromised dependency, a `dangerouslySetInnerHTML` sink, a malicious uploaded SVG served from the same origin, or a browser extension can exfiltrate tokens.

**Staging impact:** a single XSS becomes a 30-minute API takeover plus a 7-day refresh capability. Because there is no revocation (`S-02`), the operator cannot cut off the stolen session.

**Options:**

| Option | Trade-off | Status |
|---|---|---|
| Accept for staging with test accounts only | Fastest; residual risk documented | `OWNER DECISION REQUIRED` |
| Move refresh token to `httpOnly; Secure; SameSite` cookie and keep access token in memory | Requires backend/frontend changes and CSRF design | `RECOMMENDED` for production |
| Add a strict Content-Security-Policy and dependency review | Reduces XSS likelihood but not token readability | `RECOMMENDED` supplementary |

**Do not** claim staging is “secure” because the API uses JWTs. The storage choice is the exposure.

---

### S-02 — No server-side logout or refresh-token revocation (Medium)

**Evidence:** `backend/config/settings.py:176-181` enables `ROTATE_REFRESH_TOKENS` but not `BLACKLIST_AFTER_ROTATION`; no `token_blacklist` app is installed; `frontend/lib/auth.tsx:81` implements logout by clearing local state; `frontend/lib/api.ts:50` removes the storage key.

**What happens:** logout is a client-side convenience. The refresh token remains valid until its 7-day expiry. Rotation issues a new refresh token but does not invalidate the old one, so a stolen pre-rotation token can still be replayed (subject to SimpleJWT's own reuse behavior, which is not configured here).

**Staging impact:** compromised test credentials cannot be remotely invalidated. Mitigation is to rotate `DJANGO_SECRET_KEY` (which invalidates all tokens) and accept a global logout, or wait for expiry.

**Recommendation:** for production, enable token blacklisting and a logout endpoint that blacklists the refresh token; consider shorter refresh lifetimes. For staging, document the limitation and use disposable accounts. `OWNER DECISION REQUIRED`.

---

### S-03 — Admin UI is served without authentication; APIs are protected (Medium)

**Evidence:** `frontend/components/features/admin-shell.tsx:49-60` fetches `/auth/me/` in a client effect and redirects unauthorized users; the route itself is still delivered. Every admin API view uses `IsAdmin` (`backend/accounts/admin_views.py`), and `IsAdmin` reads the server-side `User.role` (`backend/accounts/permissions.py:10-17`).

**Assessment:** this is defense-in-depth done correctly at the API layer. The UI guard is a UX control, not a security boundary. An attacker who loads `/admin/subscriptions` sees the shell but cannot retrieve data without an admin JWT.

**Residual risk:** the admin JavaScript bundle and route structure are public; that is normal for a SPA. The real admin attack surface is the API, which is server-authorized, and the Django admin login at `/admin/` (`backend/config/urls.py:11`).

**Recommendation:** keep the API permission classes; do not “fix” this by hiding the route. Protect Django admin with a unique strong password and, where available, network restriction. `CONFIRMED` acceptable.

---

### S-04 — Host, CSRF, and proxy-trust configuration is deployment-critical (High)

**Evidence:** `ALLOWED_HOSTS` defaults to `localhost,127.0.0.1` (`settings.py:19`); `CSRF_TRUSTED_ORIGINS` defaults to empty (`:196`); `SECURE_PROXY_SSL_HEADER` is only set when `DJANGO_TRUST_PROXY_SSL=true` (`:34-35`); `SECURE_SSL_REDIRECT` defaults to `False` (`:28`).

**Failure modes:**

| Misconfiguration | Result |
|---|---|
| Render hostname missing from `ALLOWED_HOSTS` | Django returns 400 for every request |
| Custom domain missing from `ALLOWED_HOSTS` | Works on `onrender.com`, fails on the real domain |
| `DJANGO_TRUST_PROXY_SSL` not set | Django thinks requests are HTTP; secure-cookie/CSRF behavior can be wrong behind Render's TLS edge |
| `DJANGO_SECURE_SSL_REDIRECT=True` without proxy trust | Potential redirect loop or incorrect scheme detection |
| `CSRF_TRUSTED_ORIGINS` missing for a cross-origin admin/form origin | CSRF 403 |

**Recommendation:** for staging, set `DJANGO_ALLOWED_HOSTS` to both Render hostnames and any custom domain; set `DJANGO_CSRF_TRUSTED_ORIGINS` to the HTTPS frontend origin(s); set `DJANGO_TRUST_PROXY_SSL=True`; leave `DJANGO_SECURE_SSL_REDIRECT=False` because Render's edge already redirects. `CONFIRMED` requirement.

---

### S-05 — CORS is localhost-only (Low for same-origin; Medium if split) (Confirmed)

**Evidence:** `CORS_ALLOW_ALL_ORIGINS = DEBUG` and `CORS_ALLOWED_ORIGINS = ["http://localhost:3000"]` (`settings.py:194-195`).

**Assessment:** the documented deployment uses the frontend's same-origin `/api` proxy (`.env.example:71-74`), so browsers never make a cross-origin API request and CORS is irrelevant. If someone sets `NEXT_PUBLIC_API_BASE` to the backend's public URL, the browser origin becomes the frontend and CORS will block it.

**Recommendation:** keep `NEXT_PUBLIC_API_BASE` empty for staging. If a split origin is ever required, add the exact HTTPS frontend origin; do not enable `CORS_ALLOW_ALL_ORIGINS` in production. `CONFIRMED`.

---

### S-06 — TLS, cookies, and HSTS defaults are safe but incomplete (Medium)

**Evidence:** secure cookies default to `not DEBUG` (`settings.py:29-30`); HSTS defaults to `0` (`:31`); Render terminates TLS at its edge and redirects HTTP to HTTPS.

**Assessment:** secure cookies are appropriate behind Render. HSTS being off is a safe initial state: enabling HSTS before the custom domain and certificate are proven can lock users out for the max-age. Once HTTPS is verified, enable `DJANGO_SECURE_HSTS_SECONDS` gradually (e.g., 3600 → 31536000), and only then consider `INCLUDE_SUBDOMAINS`/`PRELOAD`.

**Recommendation:** verify HTTPS on both hostnames, then enable HSTS. Do not submit to the HSTS preload list for staging. `RECOMMENDED`.

---

### S-07 — Secret handling is acceptable, with operator-risk caveats (Medium)

**Evidence:** secrets are read from environment variables (`settings.py`); `.env` is git-ignored (`.gitignore:27-29`); `.env.example` contains placeholders only; the backend build passes dummy values scoped to a single `RUN` instruction (`backend/Dockerfile:8`), not persistent `ENV`.

**Risks:**

- Render environment variables are visible to anyone with dashboard access; there is no vault or per-secret audit trail on Free.
- A one-off migration run from a workstation requires exporting the Neon password and `DJANGO_SECRET_KEY` into a shell; shell history, crash dumps, or screen sharing can leak them.
- `DJANGO_SECRET_KEY` rotation invalidates all JWTs; this is a global logout, not a per-user action.

**Recommendation:** use a password manager or ephemeral shell environment; avoid `export` in shared history; never paste secrets into tickets or logs. `RECOMMENDED`.

---

### S-08 — S3/R2 media access model needs an explicit choice (High)

**Evidence:** `settings.py:102-158` configures `S3Boto3Storage` with `default_acl` from `AWS_DEFAULT_ACL` and optional `custom_domain`; no `AWS_QUERYSTRING_AUTH` or expiry is set.

**Two valid models:**

| Model | Configuration | Consequence |
|---|---|---|
| Private bucket + signed URLs | `AWS_DEFAULT_ACL` empty, `AWS_S3_CUSTOM_DOMAIN` empty | Uploaded media is accessible only via expiring signed URLs; good for private/user content; PWA cannot cache cross-origin images |
| Public bucket + custom domain | Public access enabled, `AWS_S3_CUSTOM_DOMAIN` set | Stable public URLs; good for public menu images and offline caching; anyone with the URL can read the object |

**Risks with the private model:** signed URLs expire (library default is typically one hour; verify), so a cached page can show broken images after expiry. If `AWS_S3_CUSTOM_DOMAIN` is set while the bucket is private, Django will generate unsigned public URLs that return 403.

**Risks with the public model:** product/business images are public by design, but the bucket must not contain sensitive uploads. R2 does not support object ACLs, so “public bucket” is a bucket-level/custom-domain decision, not per-object ACL.

**Recommendation:** for staging, use a **private R2 bucket** and signed URLs; accept that uploaded images are online-only. If offline public menus are an acceptance criterion, choose a public bucket/custom domain and document it. `OWNER DECISION REQUIRED`.

---

### S-09 — Upload validation is image-type only, with no size cap (Medium)

**Evidence:** `businesses/models.py:28,75` use `ImageField`; serializers accept `ImageField` (`businesses/serializers.py:11,45`); no explicit size/dimension validator was found; Compose's Caddy caps request bodies at 20MB (`Caddyfile.common:3-5`), but Render does not run Caddy.

**Risks:**

- Large files consume memory/bandwidth and object storage; a free-tier bucket quota can be exhausted.
- Decompression bombs: Pillow has some protections, but dimensions are not explicitly bounded.
- Polyglot files: `ImageField` verifies that Pillow can open the image, but does not guarantee the file is safe to serve with a user-controlled content type. Serving from a separate object-storage domain reduces same-origin script risk; serving from the app origin increases it.
- No antivirus/malware scanning.

**Recommendation:** add an explicit upload size limit and dimension limit before public uploads; serve media from a separate domain (R2 custom domain) to reduce same-origin risk. `RECOMMENDED`. Not implemented in this phase.

---

### S-10 — Rate limiting depends on Redis, and readiness can amplify failure (Medium)

**Evidence:** DRF throttle classes and rates (`settings.py:165-172`); OTP views use `DevelopmentRateThrottle` with scope `otp` at 5/hour and bypass when `DEBUG=True` (`accounts/views.py:161-175,202-205`); readiness performs Redis `SET`/`GET` (`health.py:56-79`).

**Risks:**

- If Redis is unavailable, throttling may raise errors or fail open depending on DRF/cache behavior; readiness returns 503.
- A Render health check pointed at `/ready/` turns a Redis quota exhaustion into a restart loop.
- OTP throttling is per client IP (`AnonRateThrottle` key), so distributed abuse across IPs is not fully prevented; the upstream OTPy provider is the second line of defense.
- `DEBUG=True` bypasses OTP throttling entirely; never run staging with DEBUG on.

**Recommendation:** use `/api/health/live/` for the Render probe; keep `DEBUG=False`; monitor Upstash command usage; consider a paid Redis plan or a dedicated rate-limit backend for production. `RECOMMENDED`.

---

### S-11 — Payment callback integrity is well designed (Confirmed, positive)

**Evidence:** `payments/views.py:14-84` verifies the authority and amount server-side with ZarinPal before changing state; it locks business → transaction → purchase in a consistent order; it treats a non-`OK` status as failure but never marks a verified success as failed; activation is idempotent via unique constraints and entitlement logic.

**Residual risks:**

- The callback is `AllowAny` by design (provider redirect); this is correct, but it means anyone can hit it with a guessed authority. The 404/200/400 responses are the only oracle; the authority is high-entropy.
- `ZARINPAL_SANDBOX` defaults to `DEBUG`; staging with `DEBUG=False` will use the **production** ZarinPal base URL unless `ZARINPAL_SANDBOX=True` is explicitly set. This is a dangerous default for staging. `CONFIRMED` from `settings.py:205`.
- The callback URL must be the backend's public URL, not the frontend proxy; otherwise ZarinPal redirects to a 404. `CONFIRMED`.

**Recommendation:** explicitly set `ZARINPAL_SANDBOX=True` for staging, and do not run a real payment without owner authorization. `OWNER DECISION REQUIRED`.

---

### S-12 — Telegram and bot surfaces must remain disabled (High if enabled)

**Evidence:** `TELEGRAM_BOT_TOKEN`/`TELEGRAM_BOT_USERNAME` (`settings.py:198-199`); `run_telegram_bot` management command; no worker service in Compose or Render.

**Risks:** polling inside a web container competes with Gunicorn, restarts with the web service, and can process updates concurrently if multiple instances exist. A leaked bot token allows message sending and impersonation. `TelegramVerifyView` is documented as legacy/buggy in `AGENTS.md`.

**Recommendation:** leave Telegram disabled for staging. Do not add a worker until a separate process topology and owner decision exist. `CONFIRMED`.

---

### S-13 — Dependency and image supply chain (Low/Medium)

**Evidence:** Python dependencies are pinned in `requirements.lock.txt`; Node dependencies are pinned by `package-lock.json`; base images are tags (`python:3.12-slim`, `node:20-alpine`), not digests.

**Risks:** a mutable base tag can change between builds; no automated vulnerability scanning or update policy was found.

**Recommendation:** pin image digests for reproducible staging builds; run `pip-audit`/`npm audit` and an image scan before external exposure. `RECOMMENDED`.

---

### S-14 — Logging and error leakage (Low)

**Evidence:** `DEBUG=False` in production; Django's default error pages do not expose stack traces when DEBUG is false; Render captures stdout/stderr. No custom logging configuration or redaction policy was found.

**Risks:** application logs may include identifiers or provider payloads; `gateway_payload` is stored on transactions (`payments/views.py:72`), which may contain provider data. Log access is dashboard-based.

**Recommendation:** review log statements for secrets/PII; avoid logging tokens, OTP codes, merchant IDs, or full provider payloads. `RECOMMENDED`.

---

### S-15 — Django admin exposure (Medium)

**Evidence:** `/admin/` is routed publicly (`config/urls.py:11`); session auth, CSRF, and password validators apply; no IP allowlist or additional MFA.

**Risks:** credential stuffing, password reuse, and exploitation of any future admin-side bug. Render Free cannot restrict inbound IPs.

**Recommendation:** use a unique strong password stored in a password manager; consider disabling Django admin in staging if the custom admin UI covers all needed operations; add MFA only with an owner decision and a supported mechanism. `OWNER DECISION REQUIRED`.

---

## 4. Gap severity matrix

| ID | Gap | Likelihood | Impact | Staging treatment |
|---|---|---|---|---|
| S-01 | JWT in `localStorage` | Medium | High | Accept with test accounts, or change before external testers |
| S-02 | No revocation | Medium | Medium | Accept; rotate secret for global logout |
| S-03 | Admin UI served publicly | High | Low | Accept; APIs protected |
| S-04 | Host/CSRF/proxy misconfiguration | High if unset | High | Must configure correctly |
| S-05 | CORS localhost-only | Low (same-origin) | Medium (split) | Keep same-origin |
| S-06 | HSTS off | — | Low | Enable after HTTPS proof |
| S-07 | Secret handling | Medium | High | Operator discipline; vault later |
| S-08 | Media access model | Medium | High | Decide private vs public |
| S-09 | Upload size/validation | Medium | Medium | Add limit before public uploads |
| S-10 | Redis-dependent throttling/readiness | Medium | Medium | Use `/live/` probe; monitor quota |
| S-11 | Payment sandbox default | Medium | High | Explicitly set sandbox |
| S-12 | Telegram worker topology | Low if disabled | High | Keep disabled |
| S-13 | Supply chain | Low | Medium | Pin digests; scan |
| S-14 | Log leakage | Low | Low | Review/redact |
| S-15 | Django admin exposure | Medium | Medium | Strong unique password |

---

## 5. Staging security acceptance conditions

These are the minimum conditions for exposing a staging environment to anyone beyond the owner. They are recommendations, not implemented changes.

### Must

1. `DJANGO_DEBUG=False`; no stack traces to clients.
2. Strong unique `DJANGO_SECRET_KEY`; never the example value.
3. `DJANGO_ALLOWED_HOSTS` includes every staging hostname; `DJANGO_CSRF_TRUSTED_ORIGINS` includes every HTTPS browser origin.
4. `DJANGO_TRUST_PROXY_SSL=True` behind Render; secure cookies on.
5. `ZARINPAL_SANDBOX=True`; no real payments without approval.
6. `COMMERCE_ALLOW_SIMULATED_PAYMENTS=False`; `COMMERCE_ORDER_ONLINE_PAYMENTS_ENABLED=False`.
7. Telegram bot disabled.
8. S3/R2 bucket private unless a public-media decision is recorded.
9. Redis URL uses `rediss://` (TLS) for Upstash.
10. No secrets in the repository, build logs, or screenshots.

### Should

11. Render health check on `/api/health/live/`; `/ready/` used only for smoke tests.
12. Upload size limit configured before inviting testers with upload rights.
13. Error tracking and uptime alerting enabled.
14. Django admin password unique and stored in a password manager.
15. Dependency/image scan before external exposure.
16. HSTS enabled after HTTPS is verified.

---

## 6. Residual risk statement

After the must-conditions are met, the principal residual risks are:

- token theft via XSS with no per-session revocation;
- public exposure of the Django admin login;
- free-tier Redis quota exhaustion causing readiness failures;
- expiring signed media URLs and no offline uploaded images;
- manual migrations with no platform audit trail;
- no error tracking or intrusion detection.

These are acceptable only for a controlled staging pilot with non-production data and a small, trusted user set. They are **not** a production security posture, and this document does not certify production readiness.

**Phase 3.0 security status:** `GAP ANALYSIS COMPLETE — OWNER DECISIONS REQUIRED`
