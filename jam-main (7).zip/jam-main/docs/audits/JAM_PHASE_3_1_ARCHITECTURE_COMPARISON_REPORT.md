# JAM — Phase 3.1 Architecture Comparison Report

**Document ID:** `JAM-PHASE-3.1-ARCHITECTURE-COMPARISON-REPORT-2026-11-11`
**Date:** 2026-11-11
**Scope:** Documentation and research only. No code, configuration, infrastructure, database, account, billing, or deployment action was performed.

---

## 1. Overall status

**ARCHITECTURE COMPARISON COMPLETE — READY FOR OWNER DECISIONS**

Three architectures (A: Netlify + Supabase + Render + Upstash; B: Netlify + Neon + Render + Upstash; C: Render + Neon + Upstash, baseline) were compared under the binding strict-$0, no-card, cloud-hosting, local-migration constraints. A layered recommendation is provided. No single architecture satisfies every constraint; the least-risk compromise is stated explicitly.

## 2. Four deliverables created

1. `docs/deployment/JAM_PHASE_3_1_ARCHITECTURE_COMPARISON.md` — full three-architecture comparison, provider facts with citations, JAM-specific compatibility, cost and failure-mode analysis, recommendation.
2. `docs/deployment/JAM_PHASE_3_1_NETLIFY_SUPABASE_COMPATIBILITY_AUDIT.md` — focused Netlify + Supabase compatibility audit, repository findings, database connection analysis, storage analysis, migration feasibility, unverified items.
3. `docs/deployment/JAM_PHASE_3_1_PROVIDER_ACCESS_PREFLIGHT.md` — provider-by-provider Iran availability findings, official terms evidence, owner-side verification steps, no circumvention.
4. `docs/audits/JAM_PHASE_3_1_ARCHITECTURE_COMPARISON_REPORT.md` — this report.

## 3. Research methodology

- Read all six existing Phase 3.1 documents in full.
- Inspected the repository: `frontend/next.config.mjs`, `frontend/app/api/[...path]/route.ts`, `frontend/app/health/route.ts`, `frontend/lib/api.ts`, `frontend/lib/public-menu.ts`, `frontend/Dockerfile`; `backend/config/settings.py`, `backend/Dockerfile`, `backend/config/urls.py`, `backend/commerce/migrations/0004...`, `backend/config/health.py`.
- Verified provider facts via web search of official documentation and pricing pages (Netlify, Supabase, Neon, Render, Upstash, Cloudflare R2). `read_url` to render.com and developers.cloudflare.com is blocked by network policy, so those facts rely on search snippets and are flagged for console re-verification.
- Distinguished verified facts, repository-derived facts, engineering analysis, unverified assumptions, and owner decisions throughout.

## 4. Main findings

1. **Netlify is a credible frontend host for JAM.** Unlike a Render Static Site, Netlify's current Next.js adapter fully supports every JAM frontend feature that previously blocked static export: `rewrites()`, the catch-all `force-dynamic` route handler, `force-dynamic` pages, dynamic routes without `generateStaticParams`, and runtime `API_INTERNAL_URL`. The same-origin proxy and JWT-in-`localStorage` model are preserved. Netlify Free allows commercial use (unlike Vercel Hobby) and is $0 with a hard 300-credit/month limit and no card.
2. **Supabase is a viable but weaker database than Neon for this project.** Supabase Free offers 500 MB DB, Nano compute, no automated backups, pause after 1 week inactivity, 60 direct connections (IPv6-only direct host), and a 50 MB max file size on Storage. Neon offers 100 CU-hours/project, 1 GB storage, a 6 h/1 GB restore window, scale-to-zero after 5 min, no pause-after-1-week, and no IPv6 caveat. On restore, pause, and compatibility grounds, Neon is the better database for JAM.
3. **Supabase Storage is the best verified $0 media option** (1 GB, 50 MB max file, S3-compatible via AWS Sig V4 with path-style addressing). R2 remains blocked by the card requirement. If uploads must be demonstrated in staging, Supabase Storage is the candidate; for a pilot where uploads are not required, disabling uploads is simpler.
4. **Media is not actually disabled by current code.** `FileSystemStorage` accepts writes to ephemeral disk with no size limit (A-13). All three architectures share this gap; a true disable requires an owner-authorised code flag (B-11).
5. **Geographic availability is unverified for every provider.** No explicit Iran ban was found in the terms reviewed, but no provider confirms support. This is a blocking preflight item for all architectures; no circumvention is recommended.
6. **Strict $0 compliance:** Architectures A, B, and C are all $0-compliant on paper, provided limits are respected and no upgrade/card is added. R2 is the only component that fails the $0 rule.

## 5. Recommendation (layered)

- **Best strict-$0 pilot:** Architecture C (Render + Neon + Upstash) — fewest providers, lowest operational complexity, no Netlify credit budget.
- **Best technical fit (frontend):** Netlify (A or B) if the owner values the Netlify SSR DX and accepts the 300-credit budget and the added provider.
- **Best database:** Neon (over Supabase).
- **Best media option if uploads must be demonstrated:** Supabase Storage (within 1 GB / 50 MB), with a documented max-file-size caveat — or R2 only if the owner authorises a card.
- **Least-risk compromise if no single architecture fits:** Architecture C for the pilot, with Netlify evaluated as a frontend swap later.

Do not mix Supabase Storage into Architecture C unless uploads are a hard requirement for the pilot.

## 6. Unresolved risks

1. Geographic/account availability unverified for all providers (blocking preflight).
2. Supabase Free has no automated backups and pauses after 1 week inactivity.
3. Supabase direct host is IPv6-only; migration via session pooler is UNVERIFIED.
4. Netlify 300 credits/month is tight for frequent redeploys.
5. Media uploads not enforced at the application layer (B-11).
6. Upstash command-quota contradiction (500k/month vs 10k/day) unresolved.
7. Render 750 shared instance hours and 5 GB bandwidth across two services.
8. Neon 5 GB transfer shared with Object Storage.

## 7. Owner decisions required

See `JAM_PHASE_3_1_ARCHITECTURE_COMPARISON.md` §8 and the compatibility audit. At minimum:
- Accept Supabase as a PostgreSQL provider? (Recommendation: no, prefer Neon unless Supabase Storage is needed.)
- Prefer Netlify over Render for the frontend? (Recommendation: optional; evaluate after pilot.)
- Accept Supabase Storage if technically compatible and strictly $0? (Recommendation: only if uploads must be demonstrated.)
- Block uploads at the application layer before staging? (Recommendation: yes, if uploads are not a required pilot feature.)
- Port-binding approach (Option A dashboard override vs Option B Dockerfile change)?
- Accept Free Tier sleep/pause/quota/availability limitations?
- Confirm geographic/account availability before selecting a provider?

None of these is decided by this report.

## 8. Verification status

- `git status --short` recorded before and after (see §9).
- `git diff --check` to be run on the working tree.
- Markdown structure and internal links reviewed by inspection.
- Citations and source URLs present in the comparison and audit documents.
- Sources not independently confirmed: render.com and developers.cloudflare.com (blocked by network policy); Supabase IPv6/session-pooler migration path (UNVERIFIED); Netlify commercial-use allowance on Free (verified via blog).
- No implementation, provisioning, migration, or deployment occurred.

## 9. Repository changes and working-tree verification

This comparison added four new documentation files under `docs/`:
- `docs/deployment/JAM_PHASE_3_1_ARCHITECTURE_COMPARISON.md`
- `docs/deployment/JAM_PHASE_3_1_NETLIFY_SUPABASE_COMPATIBILITY_AUDIT.md`
- `docs/deployment/JAM_PHASE_3_1_PROVIDER_ACCESS_PREFLIGHT.md`
- `docs/audits/JAM_PHASE_3_1_ARCHITECTURE_COMPARISON_REPORT.md`

The existing Phase 3.1 zero-cost documents were **not** modified by this comparison; their historical conclusions are preserved and any changed assessment is explained here. No code, configuration, infrastructure, database, account, billing, or deployment action was performed. The dirty working tree (64 entries at baseline) is preserved; only the four new doc files were added.

## 10. Explicit confirmation

No application code, frontend/backend configuration, Dockerfile, Compose file, environment variable, database, migration, provider account, billing/payment method, secret, DNS record, service, or deployment was created, modified, started, stopped, or deleted. This task produced documentation and research only. Phase 3.2 is not authorised or ready to execute by this report.