# JamPlay — Implementation Status Audit

Read-only audit performed 2026-11-13 against the working tree at commit `d88ec34` (branch `main`, dirty tree).
No application source, schema, configuration, dependency, database or Git state was changed.
Prototype inspected: `jam-life.html` (repository root, untracked, 7,162 lines / 4,111,057 bytes).

Status vocabulary is the one mandated by the audit brief:
`PRODUCTION_IMPLEMENTED`, `PRODUCTION_PARTIAL`, `PROTOTYPE_ONLY`, `DEMO_OR_MOCK`, `DOCUMENTED_ONLY`, `NOT_FOUND`, `UNVERIFIED`.

---

## 1. Overall status

**JamPlay has no production implementation.** There is no `games` Django app, no game model, no game
migration, no game endpoint, no game service, no game test and no game component in the Next.js app.

What exists is:

1. A single-file, browser-only HTML prototype (`jam-life.html`) containing a complete local arena/siege
   game, base building, cards, progression, missions, chests, a seeded leaderboard and a local coupon
   simulator. It talks to no server at all.
2. Two planning documents (`docs/jam play/JAMPLAY_ARCHITECTURE.md`,
   `docs/jam play/JAMPLAY_IMPLEMENTATION_PLAN.md`) written in future/intent voice.
3. A production route `/play` that renders an explicit "not available in this web demo" placeholder
   (`frontend/app/play/page.tsx:1-31`), reached from the header and bottom navigation.

The one place where JAM production code is already coupled to the game is *navigation and copy*, not
gameplay: `frontend/components/header.tsx:134-136`, `frontend/components/bottom-nav.tsx:12`,
`frontend/components/features/home.tsx:352-358`, `frontend/components/body-sync.tsx:17`.

Verified absence evidence:

| Probe | Result |
|---|---|
| `backend/games/` directory | absent (`ls backend`) |
| `games` in `INSTALLED_APPS` | absent (`backend/config/settings.py:44-49`) |
| `games` route in `backend/config/urls.py` | absent (whole file inspected) |
| `games` in `docker-compose*.yml` / Dockerfiles | no match |
| Any model class containing `Game`, `Battle`, `Card`, `Deck`, `Arena`, `Siege`, `Trophy`, `Mission`, `Inventory` | no match outside docs |
| `channels` / `daphne` / `uvicorn` / `websocket` in `backend/requirements*.txt` | no match |
| `channels` / `consumers` / `routing` modules | absent |
| Game-related tests | none (`backend/*/test*.py` inspected) |

---

## 2. Production implementation inventory

| Capability | Status | Evidence |
|---|---|---|
| `/play` route exists | `PRODUCTION_IMPLEMENTED` (placeholder only) | `frontend/app/play/page.tsx:6-29` — card + "این بخش در نسخهٔ نمایشی وب در دسترس نیست." and a back link. No game code, no API call. |
| Navigation entry to JamPlay | `PRODUCTION_IMPLEMENTED` | `frontend/components/header.tsx:134`, `frontend/components/bottom-nav.tsx:12`, `frontend/components/body-sync.tsx:17` (`/play` → `play` chrome mode) |
| Marketing/entry copy ("جم‌پلی · انتخابی برای وقت آزاد") | `PRODUCTION_IMPLEMENTED` | `frontend/components/features/home.tsx:352-358` |
| Game identity, profile, progression | `NOT_FOUND` | no model, endpoint or component |
| Arena / siege gameplay | `NOT_FOUND` | no server or client implementation |
| Cards, decks, inventory | `NOT_FOUND` | no model/endpoint/component |
| Base/towers | `NOT_FOUND` | no model/endpoint/component |
| Rewards, currency balances | `NOT_FOUND` | see §6 wallet finding in `ARCHITECTURE_AUDIT.md` |
| Missions/achievements | `NOT_FOUND` | no model/endpoint/component |
| Leaderboard/social | `NOT_FOUND` | no model/endpoint/component |
| Multiplayer / matchmaking / presence | `NOT_FOUND` | no ASGI routing, no Channels dependency, no WebSocket code |
| Battle history / replay | `NOT_FOUND` | no model, no storage |

**Production-side total: zero gameplay capability.**

---

## 3. Prototype-only functionality (`jam-life.html`)

The prototype embeds the Jam marketplace demo and the game in one file. The game module starts at
`window.GAMES=(function(JAM,REAL){...` (`jam-life.html:3887`) and runs to the end of the file
(`jam-life.html:7162`).

| Feature | Status | Evidence (symbol / lines) |
|---|---|---|
| Arena battle (two teams, cards, towers, king tower, 3 crowns, 180 s limit, overtime) | `PROTOTYPE_ONLY` | `class CombatSession` `4227-5867`; constructor mode/limits `4228-4255`; `crowns(team)` `4776`; `updateArena(dt)` `4915`; king/overtime finish `5019-5021`; `finish(reason)` `4354-4388` |
| Siege battle (isometric base, walls, buildings, destruction %, 1–3 stars, 150 s limit, loot) | `PROTOTYPE_ONLY` | `initSiege()` `5110`; loot formula `5112`; `destruction()` `5215`; `siegeStars()` `5221-5225`; `updateSiege(dt)` `5228`; wall pathfinding `siegePath` `5375` |
| Canvas renderer + pointer/touch input | `PROTOTYPE_ONLY` | `<canvas id="combatCanvas">` `4266`; `getContext("2d")` `4273`; `resize()` `4410`; `bind()` pointer handlers `4424+` |
| AI opponent (local deck, wait timer, affordability choice) | `DEMO_OR_MOCK` (prototype implementation, not a server AI) | `this.aiHand/this.aiQueue/this.aiWait` `4744-4746`; `this.aiWait -= dt` `4922`; AI choice `5044-5108` |
| 12 cards with cost/hp/dmg/rate/speed/range/splash/spell/freeze/heal | `PROTOTYPE_ONLY` | `const CARDS` `4070-4162` |
| 8-card deck, 4-card hand, card levels 1–6, upgrade costs | `PROTOTYPE_ONLY` | `START_CARDS` `4044`; `CARD_UP`/`CARD_COST`/`CARD_MAX` `4042`; `this.hand = S.deck.slice(0,4)` `4741`; `cardSheet` `6366` |
| Base layout, 9 building types, upgrade timers/costs, town-hall DP gating | `PROTOTYPE_ONLY` | `BT` `4016-4025`; `BASE_LAYOUT` `4027-4031`; `TH_DP` `4032`; `upCost`/`upTime` `5981-5982`; `baseSVG` `6303` |
| XP/levels, trophies, 6 leagues, league floors | `PROTOTYPE_ONLY` | `xpNeed`/`lvlInfo` `5967-5968`; `LEAGUES` `4033-4036`; `league()` `6003`; floor logic in `combatEnded` `6381-6386` |
| 5 daily challenges + 7 permanent missions + 6 badges | `PROTOTYPE_ONLY` | `CHALS` `4045-4053`; `JG_MISSIONS` `6462-6470`; `BADGES` `4051-4056`; claim logic `6104` |
| Chests (silver/gold/discovery, 4 slots, timers, card unlocks) | `PROTOTYPE_ONLY` | `CHEST_T` `4037-4041`; `rollChest` `6093`; `applyChest` `6097`; initial slots `5907` |
| Coins / gems / discovery points | `DEMO_OR_MOCK` | held only in browser state `S.coins/gems/dp`; `grant()` `5990-5994` |
| City discovery map (pins, "visit" rewards) | `PROTOTYPE_ONLY`, explicitly deferred by scope | `renderCity`/map `6165`; `jamPlace` `6453`; disclaimer "ثبت حضور … شبیه‌سازی است و GPS را تأیید نمی‌کند" `6165` |
| Friends list, local friend add, seeded leaderboard | `DEMO_OR_MOCK` | `FRIENDS` `4059`; `board()` `6396` uses seeded RNG; `renderClub` `6399` states "دوستان و جدول این نسخه نمایشی‌اند؛ نبردها با هوش مصنوعی اجرا می‌شوند و اتصال چندنفره ندارند." |
| Friendly battle | `DEMO_OR_MOCK` | `startBattle(..., {friendly:true})` `6376`; reward branch `6380`; still AI-driven |
| Coupon/reward simulator + campaign budgets | `DEMO_OR_MOCK` | `JG_OFFERS` `6461`; `redeemJam` `6472`; `window.JLRevenue` `6803`; local code registry via `JAM.coupons` `6563`; "کدها فقط در پرداخت نمایشی همین فایل قابل استفاده‌اند" `6471` |
| Local backup export/import | `DEMO_OR_MOCK` | `exportSave` `6418`; `importSave` `6419` accepts arbitrary `play` JSON |
| Persistence | `DEMO_OR_MOCK` | `localStorage` key `jam.state.v1` `2287`, `2563`, `2564`; header comment `2280-2283` |

The prototype's own banner is unambiguous (`jam-life.html:2280-2283`):
> "جم — نسخه فرانت‌اند (تک‌فایلی) — داده‌ها نمونه هستند و در localStorage نگهداری می‌شوند.
> برای اتصال به بک‌اند (Django REST)، توابع بخش «API» را جایگزین کنید."

And `jam-life.html:6410` (profile screen) states:
> "سرور، پرداخت بانکی، ضدتقلب، دوستان آنلاین و GPS تأییدشده در فایل‌های مبدا وجود ندارند.
> این نسخه رفتار محلی آن‌ها را صریحاً نمایشی نگه می‌دارد."

Prototype ↔ backend coupling: **none**. `grep -c 'fetch(' jam-life.html` → `0`; no
`XMLHttpRequest`, no `/api/` request path, no token handling. Its "integration" is in-memory calls to
the same file's market demo (`window.GAMES` host API at `jam-life.html:6559-6568`).

---

## 4. Partially implemented functionality

Only one item qualifies, and it is a shell rather than a game:

| Item | Status | What exists | What is missing |
|---|---|---|---|
| JamPlay entry point in the production frontend | `PRODUCTION_PARTIAL` | route, navigation links, home promo copy | any game UI, data, API, state, rendering, or feature |

Everything else that looks "partial" in the prototype (e.g. friendly PvP) is complete *as a local demo*
and zero percent implemented as production: classify those as `PROTOTYPE_ONLY` / `DEMO_OR_MOCK`.

---

## 5. Missing functionality (target scope, no implementation at all)

- Server-side battle domain engine (arena, siege) — no code, no specification outside prototype JS.
- Server-authoritative battle session lifecycle, seed/version, outcome determination, settlement.
- AI opponent generation/decisions on the server.
- Player game profile, XP/level/trophy/league persistence.
- Cards, decks, inventory, upgrades persistence.
- Base/tower state and upgrade timers.
- Missions, achievements, chests.
- Game resource ledger / balances (no wallet exists anywhere in JAM — see `ARCHITECTURE_AUDIT.md` §6).
- Battle history and replay.
- Anti-cheat, rate limiting for game actions, idempotent settlement.
- Multiplayer: Channels/ASGI consumers, matchmaking, presence, reconnect, timeout handling.
- Social: real friends, leaderboards, feeds.
- Game APIs, serializers, permissions, admin surfaces.
- Game tests, migrations, CI coverage.

---

## 6. Mocked / demo functionality that must not be mistaken for production

| Item | Where | Why it is demo-only |
|---|---|---|
| All balances (coins/gems/XP/trophies/DP) | `S.*` in browser state | client-owned, no server record, editable via devtools and via `importSave` |
| Battle outcome and rewards | `combatEnded()` `6379-6388`, `grant()` `5990` | computed in the browser after a local simulation |
| Opponent generation | `makeFoe()` `6375`, `genOpp()` `6378` | random names from a hardcoded list, scaled by local trophies |
| Leaderboard | `board()` `6396` | seeded RNG (`seeded(42)`) over `PLAYERS` `4058` |
| Friends / online presence | `FRIENDS` `4059`, `renderClub` `6399` | static array; `on` flag is cosmetic |
| City visits / GPS | `jamPlace` `6453`, map `6165` | explicit simulation disclaimer |
| Coupons | `JG_OFFERS` `6461`, `JLRevenue.issue` `6803` | generated and validated in the same browser; no server issuance |
| Market orders/payments/revenue | `jam-life.html` market section | separate local demo of JAM, not the Django API |

The backend *does* contain explicit simulation affordances unrelated to JamPlay, which must not be
reused as game economy: `OrderSimulatePaymentView` (`backend/commerce/views.py:535-554`) gated by
`COMMERCE_ALLOW_SIMULATED_PAYMENTS` (`backend/config/settings.py:219-221`, default `false`;
enabled only in `config/test_settings.py:41` and `config/concurrency_settings.py:23`), and
`Invoice.Status.SIMULATED_PAID` (`backend/commerce/models.py:451-457`). `SettlementEntry` documents
"Real payouts are not implemented" (`backend/commerce/models.py:216-218`).

---

## 7. What the prototype *does* prove (and what it does not)

Proves:
- A playable arena and siege ruleset exists as executable JavaScript, including card stats, targeting,
  splash/freeze/heal, tower/king win conditions, walls, destruction percentage and star scoring.
- A coherent progression/card/base/mission loot loop was designed and can be evaluated for feel.
- The visual/UI language exists and is Persian/RTL.

Does not prove:
- That the rules are server-portable: they are welded to DOM, canvas, `requestAnimationFrame`,
  `performance.now`, `innerWidth` and `Image` (see `ARCHITECTURE_AUDIT.md` §4).
- That outcomes are reproducible: the loop uses a variable timestep and `Math.random()`.
- That any of it is authorized, persisted, validated, balanced for real players, or integrated.
- That the prototype belongs to the JAM repository: `jam-life.html` is **untracked** (`git status` →
  `?? jam-life.html`) and is referenced by **neither** JamPlay document.

---

## 8. Verification limitations

- No tests were run: the brief forbids commands that could create test databases, bytecode caches or
  dependency state, and this audit did not install or activate a Python environment. The AGENTS.md
  baseline of "236 tests OK" is therefore **not re-verified here**.
- No build, typecheck or lint was run (would write `.next`/`tsbuildinfo`/ESLint cache).
- Browser execution of the prototype was not performed (would require launching a browser and writing
  profile/temp data). All prototype findings are static-inspection findings.
- Production runtime behavior, Staging, Redis connectivity, S3 and payment providers are outside this
  audit and unverified.
