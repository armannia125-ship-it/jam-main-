# JamPlay — Architecture Audit

Read-only audit performed 2026-11-13 against working tree at `d88ec34` (branch `main`, dirty tree).
No source, schema, config, dependency, database or Git state was changed.

Status vocabulary: `PRODUCTION_IMPLEMENTED`, `PRODUCTION_PARTIAL`, `PROTOTYPE_ONLY`, `DEMO_OR_MOCK`,
`DOCUMENTED_ONLY`, `NOT_FOUND`, `UNVERIFIED`.

---

## 1. What actually exists

There are three disjoint artifacts that the documentation treats as one system:

| Artifact | Nature | Server contact |
|---|---|---|
| `jam-life.html` (7,162 lines, root, untracked) | Browser-only single-file prototype of the whole JAM app plus a complete JamPlay game module | **None** — 0 `fetch(`, 0 `XMLHttpRequest`, no `/api/` request |
| `docs/jam play/*.md` (2 files, untracked) | Intent/future-tense architecture and phase plan | n/a |
| JAM production tree (Django + Next.js) | Marketplace/menu platform with subscriptions, orders, payments | n/a — contains **no** game code |

The only production-side JamPlay artifact is a placeholder page and navigation chrome. There is no
runtime path from JAM to any game logic.

```
Next.js (frontend/)                       Django (backend/)
  /play  → placeholder only                 accounts   (User, OTP, JWT, role, AdminAction)
  /api/[...path] → proxy ────────────────►  businesses (menu, public menu, QR)
                                            subscriptions (5 products, entitlements, purchase)
                                            payments    (Transaction, ZarinPal adapter)
                                            commerce    (orders, settlement, invoice, codes)
                                            bot, cart   (bot: Telegram; cart: legacy/dead)
                                            ── no games app, no game tables, no game routes ──
PostgreSQL: JAM domain only                 Redis: cache + readiness probe only
```

JamPlay prototype (`jam-life.html`) is a third, isolated runtime: `localStorage['jam.state.v1']`
(`jam-life.html:2287`) is its only store; its "leaderboard", "friends", offers and missions are
computed in-page from constants and a seeded RNG (`seeded(42)` at `jam-life.html:6396`).

---

## 2. Backend boundaries

Verified: `backend/config/settings.py:44-49` INSTALLED_APPS = `accounts, businesses, subscriptions,
payments, cart, bot, commerce` (+ DRF/admin/static). `backend/config/urls.py` mounts each app under
`/api/`; there is no game route.

Strengths worth preserving in any game design:

- **Layering already exists.** `views.py` → `services.py` → `models.py` is the established pattern in
  `commerce/services.py` and `subscriptions/*`; domain logic is not in views.
- **Money transitions are transactional.** 51 occurrences of `transaction.atomic`/`select_for_update`
  across `backend/`, concentrated in `commerce`, `payments`, `subscriptions`.
- **Idempotency has a precedent.** `commerce.Order.idempotency_key` with a unique constraint
  (`backend/commerce/models.py:119,132-134`).
- **Error contract is uniform.** `{"detail": ..., "code": ...}` with Persian user text; e.g.
  `payment_provider_unconfigured` at `backend/subscriptions/purchase_views.py:127-137`.
- **Ownership is scoped server-side** and cross-owner access returns 404 (`CommerceBaseView.owned_business`).
- **Auth is a real identity system**, not a stub: custom `User` (`backend/accounts/models.py:48`),
  server-side `role:60`, `IsAdmin`, OTP login, SimpleJWT.

Weaknesses that will propagate into JamPlay if reused naively:

- `backend/payments/models.py:6` `Transaction` has a foreign key to **`SubscriptionPurchase` only**.
  There is no generic payable, no order-bound payment and no wallet/ledger. Any game purchase cannot be
  represented by the existing payment model without a schema change.
- `backend/commerce/views.py:535-554` `OrderSimulatePaymentView` exists behind
  `COMMERCE_ALLOW_SIMULATED_PAYMENTS` (default false, `settings.py:219-221`). It is seller-only and
  returns 503 when disabled, but it is an in-tree "mark paid" path — a game economy must not reuse it.
- `backend/cart/` is legacy/dead per `AGENTS.md` §3 and must not be extended.
- `backend/bot/views.py::TelegramVerifyView` is known dead/buggy legacy; do not build on it.
- No scheduler: notifications use the `notify_expiring_entitlements` management command run externally.
  Any game season/energy/cooldown timer inherits this gap.
- `backend/products/` exists as an **empty directory** — not an app, not importable. Do not mistake it
  for an inventory/catalog home.

---

## 3. Frontend boundaries

- `frontend/app/api/[...path]/route.ts` is a same-origin proxy to `API_INTERNAL_URL`; it preserves
  Django trailing slashes, forwards auth/body, never caches, and serves `/api/media-proxy/*`. This is the
  correct place for a future game API; do not call Django directly from the browser.
- `frontend/lib/api.ts` is the single authenticated client (JWT in `localStorage['jam.auth.v1']`,
  single-flight refresh, 401 retry). Game calls should use it.
- `frontend/lib/auth.tsx` exposes the client auth context; server role is resolved via
  `GET /api/auth/me/`, never stored as an authority.
- `/play` is a client-side placeholder (`frontend/app/play/page.tsx:1-31`) with a back link only.
  `components/body-sync.tsx:17` switches the shell into a `play` chrome mode for that route.
- RTL/Persian-first design system: `<html lang="fa" dir="rtl">`; CSS variables and existing component
  classes. Any game UI must be Persian/RTL and mobile-first, and must not import a canvas-only shell
  that ignores `prefers-reduced-motion` and touch input.

Frontend gap: there is no game state layer, no game API module, no canvas/WebGL renderer, no input
abstraction, no asset pipeline for game sprites, and no service worker/offline game path.

---

## 4. Reusable JAM capabilities (for a future game)

| Capability | Current implementation | Reusability | Limitations / required decision |
|---|---|---|---|
| Identity / session | `accounts.User`, OTP, SimpleJWT (`settings.py:183-188`), `/api/auth/me/` | **High** — directly reusable as player identity | JWT in `localStorage` is XSS-exposed; no revocation/blacklist; refresh 7d. Reuse means accepting existing posture, not fixing it inside JamPlay. |
| Authorization | Server-side `role`, `IsAdmin`, ownership-scoped querysets → 404 | **High** | Only `user`/`admin` exist; no moderator/support role for anti-cheat or bans. |
| Atomic money/state | `transaction.atomic` + `select_for_update`, idempotency key | **High as a pattern** | Pattern, not a library. Game must add its own constraints. |
| Orders | `commerce.Order` (+ items, statuses, idempotency) | **Medium** | Built for offline/marketplace commerce; game purchases are not orders today. |
| Payments | `payments.Transaction` + `ZarinPalGateway`, server-side callback verification | **Low for games as-is** | `Transaction` FK is subscription-only; no generic payable. ZarinPal unconfigured fails safely with 503 and creates nothing (`purchase_views.py:120-137`). |
| Entitlements | `subscriptions/entitlements.py` `menu_access`/`club_access`, atomic Gold MENU+CLUB | **Medium as a pattern** | Access is entitlement-derived; extending entitlements to *game benefits* is an **unapproved** business change. |
| Wallet | none | **None** | `grep -i 'wallet\|ledger' backend --include=*.py` matches only merchant settlement ledger code (`SettlementEntry`, "Real payouts are not implemented"). No customer balance, no coin ledger, no spend path. |
| Coupons/discounts | prototype only (`JG_OFFERS`, `jam-life.html:6461`) | **None** | No server coupon model; docs' coupon/payment integration lines are aspirational. |
| Notifications | `Notification` + 5-day expiry command, subscriptions only | **Low** | No in-game events, no push, no scheduler. |
| Health/readiness | `/api/health/live/`, `/api/health/ready/` (DB+cache; 503 unhealthy) | **High** | Readiness does not cover a game subsystem; must not be extended to leak internals. |
| Admin RBAC/audit | `IsAdmin` + `AdminAction` model, audited mutations, last-admin protection | **High** | No game-specific admin surface (grant coins, ban, rollback match) exists or is designed. |

**Conclusion:** identity, authorization, transaction discipline, error contract and admin audit are
genuinely reusable. Economy (wallet/ledger), game payments, coupons, match state and realtime are not
present in any form and are not "available" despite documentation language.

---

## 5. Prototype combat engine assessment

The engine is real code, but it is a **DOM-coupled client simulation**, not a server engine.

| Dimension | Finding | Evidence |
|---|---|---|
| Location | One IIFE game module inside the HTML file | `window.GAMES` `jam-life.html:3887` → `7162` |
| Size | ~3,275 lines of game code, of which `class CombatSession` is ~1,640 lines | `4227-5867` |
| Mode separation | Arena and siege are **methods on one class** (`initArena` 4740, `initSiege` 5110, `updateSiege` 5228) | good conceptual precedent for one shared domain |
| Rules location | Constants + inline methods only; no data-driven rule table, no serializable schema | constants `4016-4069`; `CARD_UP`/`CARD_COST` 4042; `upCost`/`upTime` 5981-5982 |
| Rendering coupling | `document`, `#cv` canvas 2d, `requestAnimationFrame`, `performance.now`, `innerWidth`, `getBoundingClientRect`, `Image` all inside the combat class | `resize` 4410, `bind` 4424, loop `4286-4293` |
| Time model | Variable `dt` clamped to 45 ms (`Math.min(0.045,(t-last)/1000)`) | `4286-4293` |
| Randomness | `Math.random()` inside combat (spawn/crit/AI choice), **not seeded** | `4922`, `5044-5108` |
| Outcomes | Win/loss, crowns, stars, rewards all decided and applied client-side | `finish` 4354, `crowns` 4776, `destruction` 5215, `siegeStars` 5221, `combatEnded` 6379, `grant` 5990 |
| AI | Rule-based heuristics embedded in the class (threat scoring, deploy timing, card selection) | `4744-4746`, `4922`, `5044-5108` |
| Persistence | Saves whole mutable `S` object to `localStorage`; `importSave` accepts arbitrary `play` JSON | `state` 5901-5964, `exportSave` 6418, `importSave` 6419 |
| Determinism | None end-to-end: unseeded RNG + variable dt + frame-driven input | as above |

Assessment: the prototype proves *game feel and content breadth*, not *serverside authority*. Extracting
it into "one shared battle domain engine for AI and multiplayer" is a rewrite, not a port:

1. rules must move out of DOM-coupled methods into a pure, dependency-free module with explicit state
   in/state out and an RNG seam;
2. time must become tick-based (fixed step, server-advanced) with a replay/verification contract;
3. outcome/reward computation must move server-side; the client may only render predictions;
4. AI must consume the same engine API as a remote player, with no privileged access to hidden state;
5. the renderer becomes a consumer of snapshots/events, not the owner of truth.

Until 1–4 exist there is no "engine in progress" in the production tree — only a client prototype.

---

## 6. Persistence and state architecture

Current reality:

- **PostgreSQL** holds only JAM marketplace/subscription/commerce state. No game tables, no match
  history, no player profile, no inventory, no currency ledger.
- **Redis** is configured as cache (`settings.py:196-199`) and probed by readiness; with no `REDIS_URL`
  the project falls back to `LocMemCache`. It is **not** used for any realtime, pub/sub, presence,
  matchmaking or lock. Any claim that Redis "supports the game's realtime layer" is unverified.
- **localStorage** is the prototype's system of record: `jam.state.v1` (`2287`), history capped at 20
  entries, plus `jamFriends`. It is user-editable and forgeable; `importSave` (`6419`) accepts any JSON.
- **No migration** exists for game state; 30 migrations total, none game-related.

Mandated target (per brief) — PostgreSQL persistent state, Redis ephemeral only — is **consistent with
the current stack** but requires new schema and new services; nothing exists to build on except the
transaction/idempotency patterns.

---

## 7. Security and economy assessment

| Risk | Finding | Severity |
|---|---|---|
| Client-authoritative outcomes | Prototype grants coins/XP/trophies/cards locally (`grant` 5990, `combatEnded` 6379, `applyChest` 6097) | Critical if ported |
| Forgeable save | `importSave` (`6419`) imports arbitrary `play` object; no signature, no server check | Critical if ported |
| Unseeded RNG | combat randomness not reproducible, cannot be audited or replayed | High |
| No economy ledger | no wallet, no double-entry, no balance invariant, no spend audit | Critical for any paid currency |
| Paid currency w/o payment path | `Transaction` FK → `SubscriptionPurchase` only; no generic payable | High (blocks monetization) |
| Coupon simulator | `JG_OFFERS` cost coins for marketplace discounts (`6461`) — cross-domain value transfer with no server model | High if ported |
| Subscription→game gating | docs propose Gold/premium game benefits; **not approved**, and entitlement code has no game concept | Policy risk |
| JWT in localStorage | documented XSS exposure; no revocation | Medium (inherited) |
| No anti-cheat surface | no rate limits on game actions, no server validation, no ban tooling | High |
| No match audit | no match record, no seed/replay, no dispute evidence | High for ranked/PvP |

Positive: the JAM codebase already demonstrates the correct patterns for the parts that matter —
server-side authorization, atomic state transitions, unique idempotency keys, hashed one-time codes
(`commerce.PurchaseCode`), provider-vs-simulated separation in `Invoice`.

---

## 8. Multiplayer readiness

| Requirement | Status | Evidence |
|---|---|---|
| ASGI app | `PRODUCTION_PARTIAL` — file exists, plain Django | `backend/config/asgi.py` `get_asgi_application()` |
| WebSocket protocol | `NOT_FOUND` | no `channels`/`daphne`/`uvicorn` in `requirements.lock.txt`; only `django-redis`, `redis` |
| Consumers / routing | `NOT_FOUND` | no modules |
| Server runtime | WSGI only | `backend/Dockerfile` runs `gunicorn config.wsgi:application` |
| Matchmaking / rooms | `NOT_FOUND` | none |
| Presence / reconnect | `NOT_FOUND` | none |
| Authoritative tick loop | `NOT_FOUND` | no server game loop anywhere |
| Latency/throughput evidence | `UNVERIFIED` | no benchmark, no load test, no profiling in repo |
| Redis pub/sub for fan-out | `NOT_FOUND` | Redis used as cache only |

**Multiplayer readiness: not ready, and not close.** The blocker is not the missing WebSocket library;
it is that no authoritative simulation exists to synchronize. Adding Channels before a headless engine
would produce two competing truths.

Required sequence (architectural, not implementation): headless deterministic engine with tick API →
single-player AI on that engine → server-owned match state with command log → transport decision backed
by a measured tick-bandwidth/latency benchmark → matchmaking/presence/reconnect.

---

## 9. Architectural risks

1. **Two sources of truth if the prototype is embedded as-is.** `jam-life.html` runs its own app shell
   (`TABS` 6016, shell 6019) and its own save; mounting it next to Next.js would duplicate auth, routing
   and state.
2. **Rewriting rules twice.** Keeping AI-only rules client-side and PvP rules server-side would violate
   the mandated single-engine constraint and guarantee divergence.
3. **Schema lock-in from `payments.Transaction`.** Its subscription-only FK forces either a new payable
   abstraction or a parallel payment table; choosing ad hoc creates a second money path.
4. **Redis scope creep.** Use of Redis for authoritative match state would contradict the
   "PostgreSQL persistent / Redis ephemeral" constraint and lose state on eviction (relevant on the
   Staging free tier).
5. **Scheduler absence.** Seasons, energy regeneration, cooldowns and expiry have no scheduler; current
   notifications depend on an externally-run command.
6. **Free-tier hosting.** Render Free cold starts and ephemeral filesystem are hostile to a realtime,
   stateful game; this is an environment constraint, not a code bug.
7. **Unapproved economy coupling.** Coins→marketplace discount and subscription-gated game benefits are
   business decisions with financial and legal weight; implementing them by inference is a governance
   violation.

---

## 10. Unsupported assumptions in the planning documents

| Assumption in docs | Reality |
|---|---|
| A `games` app "will be created" with models/endpoints | It does not exist; no migrations, routes or tests (`IMPLEMENTATION_STATUS.md` §1) |
| Wallet / `WalletLedger` available for game currency | No wallet or customer ledger exists anywhere in `backend/` |
| Coupon/payment integration for game offers | No server coupon model; `Transaction` cannot pay for a non-subscription |
| Premium/Gold subscription grants game benefits | Not approved; entitlements have no game concept |
| Arena/siege "engine in progress", "multiplayer in progress" | No server-side code; only a client prototype |
| Redis provides realtime/pub-sub for the game | Redis is cache-only here; LocMemCache fallback exists |
| ASGI/Channels ready for realtime | ASGI is plain Django; runtime is gunicorn WSGI; no Channels dependency |
| "Commerce/wallet available" for game economy | Commerce exists for marketplace orders; wallet does not exist |

These are intent statements, not implementation claims, **except** the present-tense integration lines in
`docs/jam play/JAMPLAY_ARCHITECTURE.md:187,189-190,193`, which are false as written. See
`DOCUMENTATION_CLAIMS_AUDIT.md`.
