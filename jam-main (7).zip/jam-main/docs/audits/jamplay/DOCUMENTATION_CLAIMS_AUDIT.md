# JamPlay — Documentation Claims Audit

Read-only audit performed 2026-11-13 against the working tree at branch `main` (dirty tree).
No source, schema, configuration, dependency, database or Git state was changed.

**Documents audited**

| Document | Tracked? | Nature |
|---|---|---|
| `docs/jam play/JAMPLAY_ARCHITECTURE.md` (247 lines) | No — `git status` → `?? "docs/jam play/"` | Mix of future-tense intent and present-tense statements |
| `docs/jam play/JAMPLAY_IMPLEMENTATION_PLAN.md` (160 lines) | No — same untracked directory | Phase plan written in future/imperative voice |
| `jam-life.html` (7,162 lines, repository root) | No — `git status` → `?? jam-life.html` | Browser-only single-file prototype |

No other document in the repository mentions JamPlay. `grep -rni "jamplay" docs` returns only the two
files above (plus the two pre-existing JamPlay audit reports in `docs/audits/jamplay/`). In particular
`README.md`, `docs/JAM_MASTER_IMPLEMENTATION_REPORT.md` and
`docs/JAM_LIFE_FRONTEND_IMPLEMENTATION_SPEC.md` do **not** describe JamPlay at all — the game is
absent from every canonical project document in `AGENTS.md` §11.

Status vocabulary for claims: `VERIFIED`, `PARTIALLY_VERIFIED`, `FALSE`, `UNVERIFIED`, `OUTDATED`.
Classifier legend for the underlying artefacts: `PRODUCTION_IMPLEMENTED`, `PRODUCTION_PARTIAL`,
`PROTOTYPE_ONLY`, `DEMO_OR_MOCK`, `DOCUMENTED_ONLY`, `NOT_FOUND`.

---

## 1. The twelve mandated claims

| # | Document Claim | Status | Evidence | Required Correction |
|---|---|---|---|---|
| 1 | A Django `games` app has already been created | **FALSE** | `backend/` contains only `accounts, businesses, subscriptions, payments, commerce, cart, bot, products(empty), config` (`ls backend`). `INSTALLED_APPS` = `accounts, businesses, subscriptions, payments, cart, bot, commerce` (`backend/config/settings.py:44-49`). `backend/config/urls.py:10-19` mounts no game route. `backend/products/` exists but is an empty directory, not an app. | Delete any implication that an app exists. `JAMPLAY_ARCHITECTURE.md:63` says "**will be** created" — that sentence is correct as a plan; the defect is using the planned tree as the system description without a status marker. Add an explicit "Status: not started (0% of files exist)" banner. |
| 2 | Combat session models exist | **FALSE** | No Django model class matching `Game|Battle|Arena|Siege|Card|Deck|Trophy|Mission|Inventory|Matchmak` anywhere in `backend/` (`grep -rniE 'class (Game|Battle|…)' backend --include=*.py` → 0 matches). 30 migrations exist (`backend/*/migrations/*.py` minus `__init__.py`), none game-related. The only `CombatSession` is a JavaScript class in the prototype (`jam-life.html:4227`). | State that no server model exists; `CombatSession` is prototype-only and cannot be imported or referenced as a database concept. |
| 3 | Player progression is implemented | **FALSE in production** / `PROTOTYPE_ONLY` | XP/level/trophy/league logic lives only in `jam-life.html` (`xpNeed`/`lvlInfo` `5967-5968`, `LEAGUES` `4033-4036`, `league()` `5978`) inside browser state `S` persisted to `localStorage['jam.state.v1']` (`2287`, `2563-2564`). No backend model, endpoint or test. | Mark as prototype-only. |
| 4 | Subscription integration is completed | **FALSE (for JamPlay)** | Subscriptions exist for *menu/club* entitlements only: `SubscriptionEntitlement.Type` = `MENU`, `CLUB` (`backend/subscriptions/models.py:103-105`); access helpers `menu_access`/`club_access` (`backend/subscriptions/entitlements.py:31-58`). There is no game concept, no game entitlement type, no game-gated endpoint. | Remove "completed". Subscription-to-game benefits are explicitly unapproved requirements; document them as excluded pending owner decision (see `ARCHITECTURE_DECISIONS_REQUIRED.md` D-03). |
| 5 | Arena combat is implemented | **FALSE in production** / `PROTOTYPE_ONLY` | `class CombatSession {` (`jam-life.html:4227`); `initArena` (`4740`); `updateArena(dt)` (`4915`); crowns (`4776`). It renders to `<canvas id="combatCanvas">` inside the same class and is driven by `requestAnimationFrame`. No server counterpart, no API. | Classify `PROTOTYPE_ONLY`; do not claim implementation. |
| 6 | Siege combat is implemented | **FALSE in production** / `PROTOTYPE_ONLY` | `initSiege()` (`jam-life.html:5110`), `updateSiege(dt)` (`5228`), `destruction()` (`5215`), `siegeStars()` (`5221-5225`). Same class, same canvas, browser-only. | Same as #5. |
| 7 | The combat engine is in progress | **FALSE / UNVERIFIED** | There is no engine in the repository to be "in progress". `backend/` has no `games/domain`, `engine`, `simulation` or `services/battle_service.py`. The only executable rules are welded to DOM APIs (`document`, `innerWidth`, `getContext("2d")`, `requestAnimationFrame`, `performance.now`) inside `jam-life.html:4227-5867`. | Say "no server engine exists; a client prototype demonstrates the intended feel only". |
| 8 | Multiplayer support is in progress | **FALSE** | `channels`, `daphne`, `uvicorn` absent from `backend/requirements.txt` and `backend/requirements.lock.txt` (lock contains `django-redis`, `redis`, `gunicorn`). `backend/config/asgi.py` is plain `get_asgi_application()` with no routing. Runtime is WSGI: `backend/Dockerfile:14` → `gunicorn config.wsgi:application`. Prototype copy itself says "اتصال چندنفره ندارند" (`jam-life.html:6399`). | Say "not started". Multiplayer must follow the AI engine per the approved order. |
| 9 | Frontend integration is in progress | **PARTIALLY_VERIFIED** — limited to a placeholder shell | `/play` renders a static card: "این بخش در نسخهٔ نمایشی وب در دسترس نیست." (`frontend/app/play/page.tsx:4-28`). Navigation/chrome: `frontend/components/header.tsx:134`, `frontend/components/bottom-nav.tsx:12`, `frontend/components/body-sync.tsx:17` (`/^\//play/ → "play"`), home promo `frontend/components/features/home.tsx:349-359`. No game state, renderer, API module or canvas anywhere in `frontend/app|components|lib` (`grep -rniE 'CombatSession|arena|siege|battle|deck|troph|jamplay'` → 0 production matches). | Replace with: "a placeholder route and navigation entry exist; no game client exists." |
| 10 | Existing commerce and wallet integration is available | **FALSE for wallet; PARTIALLY_VERIFIED for commerce** | Commerce is real (`backend/commerce/models.py`: `Order` `94-166`, `OrderItem`, `CommissionEntry`, `SettlementEntry` `209-234`, `PurchaseCode`); but `SettlementEntry` documents "Real payouts are not implemented" (`209-210`) and is a *merchant settlement* ledger. No customer wallet: `grep -rni 'wallet' backend --include=*.py` → 0 matches; only `ledger` hits are `SettlementEntry` references (`commerce/views.py:362`, `commerce/urls.py:41`). | State: "marketplace order/commission *patterns* are reusable; no wallet or customer balance exists." |
| 11 | Existing Django authentication is directly reusable | **VERIFIED with caveats** | Custom `User` (`backend/accounts/models.py:48`), phone/email identity, `role` (`:60`), `is_admin` property, `AdminAction` audit (`:90`); OTP login + `TokenRefreshView` routes (`backend/accounts/urls.py`); DRF `JWTAuthentication` default (`settings.py:171-173`). Caveats: JWT lives in browser `localStorage` (`frontend/lib/api.ts`; documented XSS risk in `AGENTS.md` §5); no revocation/blacklist; only `user`/`admin` roles; no link from `User` to any game profile because none exists. | Keep "reusable", add the caveats and note that player identity linkage is a P1 deliverable, not an existing feature. |
| 12 | API endpoints listed in the documentation actually exist and function | **FALSE / NOT-AS-DOCUMENTED** | The documents do not list concrete URLs; they list module names (`battle_api.py`, `profile_api.py`, `inventory_api.py`, `progression_api.py`, `rewards_api.py` — `JAMPLAY_ARCHITECTURE.md:119-124`). None of these modules or URLs exist; `backend/config/urls.py` has no game mount. | Do not imply endpoints. If endpoints are later specified, they must be validated against `config/urls.py` and per-app `urls.py`, which is the contract source of truth (`AGENTS.md` §11). |

**Result: 1 of 12 claims verified, 1 partially verified, 10 false or not as documented.** No claim of
implemented JamPlay behaviour survives repository inspection.

---

## 2. Claims in `JAMPLAY_ARCHITECTURE.md`

| Line | Claim | Status | Evidence | Required Correction |
|---|---|---|---|---|
| 63 | "The `games` app **will be created** with the following structure" | **VERIFIED as intent** (`DOCUMENTED_ONLY`) | Future tense is honest; nothing exists. | Keep, but add an explicit status line so the tree diagram is not read as current architecture. |
| 65-136 | Directory tree with `domain/`, `engine/`, `models/`, `services/`, `api/`, `realtime/`, `tasks/`, `tests/` | **DOCUMENTED_ONLY** | No directory, no file. | Label "proposed layout — 0 files exist". |
| 144-147 | "Server-Authoritative Design … server validates … determines outcomes" | **DOCUMENTED_ONLY** (design principle, not a fact) | No server code. Prototype is client-authoritative (`combatEnded` `6379`, `grant` `5990`). | Keep as a stated *requirement*; do not present as achieved. |
| 149-160 | Battle lifecycle diagram (session → seed → rules version → settlement) | **DOCUMENTED_ONLY** | No session model, no seed/version field, no settlement service. | Keep as target; note that the prototype has no seed and no rules version. |
| 173 | "Wallet Ledger as the authoritative transaction history" | **FALSE** | No wallet/ledger model for customers anywhere in `backend/`. | Remove or rephrase to "proposed game ledger (does not exist)". |
| 182-184 | "Uses existing `accounts` app authentication … JWT … User identity linked to game profile through foreign key" | **PARTIALLY_VERIFIED** | Auth/JWT verified; the "game profile FK" does not exist because no game profile exists. | Correct to: "auth is reusable; player-profile linkage must be built." |
| 187 | "Game economy connects to existing wallet system" | **FALSE** | No wallet system exists (`grep -rni wallet backend --include=*.py` → 0). | Remove; wallet ownership is an open decision (D-01). |
| 189 | "Coupon issuance integrates with payment infrastructure" | **FALSE** | No coupon model server-side. Prototype coupons are local (`JG_OFFERS` `6461`, `redeemJam` `6472`, note "کدها فقط در پرداخت نمایشی همین فایل قابل استفاده‌اند" `6471`). `payments.Transaction` FK is `SubscriptionPurchase` only (`backend/payments/models.py:11`). | Remove; discount/coupon issuance is not implemented or approved for games. |
| 190 | "Atomic redemption process prevents fraud" | **FALSE** | Nothing to redeem. JAM's atomic/idempotent patterns exist (`30` `transaction.atomic`, `21` `select_for_update`, order idempotency `commerce/models.py:119,132-134`) but no game redemption. | Rephrase as a reuse requirement. |
| 193 | "Premium subscription entitlements **can** unlock advanced game features" | **FALSE + NOT APPROVED** | No game entitlement exists; entitlement types are `MENU`/`CLUB` only (`subscriptions/models.py:103-105`). Subscription-gated gameplay is explicitly outside approved scope per the audit brief. | Remove the capability claim; either drop the idea or record it as an owner decision (D-03). |
| 194 | "Progression and rewards linked to active subscriptions" | **FALSE + NOT APPROVED** | Same as 193; no link in code. | Remove. |
| 195 | "Gold subscription creates both menu and club entitlements" | **VERIFIED** (unrelated to JamPlay) | Implemented and owner-approved (`AGENTS.md` §4; `subscriptions/entitlements.py`). | Keep — but it is a marketplace rule, not a game rule; move out of the JamPlay integration section to avoid implying game effect. |
| 199 | "we'll leverage Django's ASGI and Channels with Redis" | **UNVERIFIED / currently impossible as stated** | `channels` not installed; `asgi.py` has no routing; runtime is gunicorn WSGI; Redis is cache-only (`settings.py:190-199`). | Mark as a *candidate* transport requiring a benchmark + dependency + owner approval (D-08). |
| 207-214 | Multiplayer features: matchmaking, presence, reconnect, anti-cheat | **DOCUMENTED_ONLY** | No consumers, no queues, no presence code. | Mark all as unbuilt. |
| 234 | "All client inputs are validated server-side" | **FALSE** | No game server endpoint exists to validate anything. | Remove present tense. |
| 235 | "Battle state is managed in Redis for temporary data" | **FALSE** | Redis is cache-only; no battle state anywhere. | Remove; note the PostgreSQL-persistent/Redis-ephemeral constraint. |
| 236 | "Settlement endpoints handle duplicate requests gracefully" | **FALSE** | No settlement endpoint. | Remove. |
| 237 | "Complete wallet ledger tracks all resource changes" | **FALSE** | No ledger. | Remove. |
| 240-247 | Performance considerations (indexing, Redis caching, background tasks, canvas optimization, horizontal scaling) | **DOCUMENTED_ONLY / UNVERIFIED** | No benchmarks, no load tests, no profiling artefacts in the repository. No Celery/beat or worker. | State "no performance evidence exists"; required before choosing a multiplayer simulation/transport. |

---

## 3. Claims in `JAMPLAY_IMPLEMENTATION_PLAN.md`

| Line | Claim | Status | Evidence | Required Correction |
|---|---|---|---|---|
| 16 | "Backend: Django with PostgreSQL and Redis" | **VERIFIED (with nuance)** | PostgreSQL via `psycopg`, `django-redis` configured; falls back to `LocMemCache` without `REDIS_URL` (`settings.py:190-199`). | Clarify Redis is cache-only today. |
| 18 | "Commerce system already handles orders, payments, and revenue" | **VERIFIED** | `commerce` app: `Order`, `OrderItem`, `CommissionEntry`, `SettlementEntry`, revenue/metrics endpoints under `/api/commerce/` (`config/urls.py:17`). Payments are subscription-bound only (`payments/models.py:11`), and payouts are not implemented. | Keep, but scope precisely: marketplace orders/commission, not a general payment or payout facility. |
| 19 | "Subscription system manages entitlements for menu and club access" | **VERIFIED** | `subscriptions/entitlements.py:31-58`; five-product catalog per `AGENTS.md` §4. | Keep. |
| 20 | "Redis is available for temporary state management" | **PARTIALLY_VERIFIED** | Available as cache backend; not used for locks/sessions/queues. `django-redis` present. | Say "available as a cache; realtime/session use is unproven." |
| 23-37 (P1) | "Create `games` app", `GameProfile`, `WalletLedger`, inventory | **DOCUMENTED_ONLY** (future tense) | Nothing exists. | Keep as planned work; ensure no downstream text treats it as done. |
| 38-53 (P2) | "Create domain engine … server-authoritative … AI controller … Canvas renderer" | **DOCUMENTED_ONLY** | Only a DOM-coupled prototype exists. | Add explicit note that the prototype is not the engine and requires extraction/rewrite (see `ARCHITECTURE_AUDIT.md` §5). |
| 54-95 (P3-P7) | Siege, cards/base, progression, economy, multiplayer plans | **DOCUMENTED_ONLY** | No code. | Keep, but add phase gates and acceptance criteria (see `IMPLEMENTATION_GAP_ANALYSIS.md`). |
| 79-87 (P6) | "Connect game economy to existing commerce … coupon issuance … atomic redemption … existing wallet ledger" | **FALSE premise** | No wallet ledger; coupons do not exist server-side; `Transaction` cannot pay for non-subscription goods. | Rewrite P6 as blocked pending owner decisions D-01/D-02. |
| 88-96 (P7) | "Set up real-time communication via Django Channels/ASGI" | **UNVERIFIED** | No dependency, no routing, WSGI runtime; no latency/throughput evidence. | Require benchmark + approval before committing to Channels. |
| 135, 144-147 | "Integration with existing commerce — use existing wallet system and payment flows"; "Wallet ledger system connects to existing commerce models" | **FALSE (wallet) / PARTIAL (payments)** | Wallet absent; payment provider is ZarinPal-only and subscription-bound. `AGENTS.md` §4: "ZarinPal is the only approved online payment provider." | Remove wallet assumption; payment reuse needs a payable abstraction decision. |
| 149-151 | "Game progression and rewards **can** be linked to subscription entitlements"; "Premium subscription benefits could include game features" | **NOT APPROVED** | Explicitly outside approved requirements per the audit brief; no code. | Delete or convert to an owner decision item. |
| 153-160 | Security considerations (server validation, ledger audit, settlement idempotency) | **DOCUMENTED_ONLY** | All are requirements; none implemented. | Mark as requirements, not properties of the system. |
| — | `jam-life.html` is never referenced by either document | **OUTDATED / GAP** | `grep -i "jam-life\|prototype\|prototype" docs/jam play/*.md` → no match. The prototype is the only executable statement of the game's rules and content. | Add a section naming `jam-life.html` as the current rules/content reference and its status (`PROTOTYPE_ONLY`, untracked, 4.1 MB), plus how it is to be governed. |

---

## 4. Documentation omissions that matter as much as the false claims

1. **No status marker anywhere.** Both documents read as system description; neither states "0 %
   implemented". A reader cannot tell design from fact without inspecting the tree.
2. **The prototype is undocumented.** It is the de facto rules and content source (cards, stats, costs,
   missions, leagues, loot formulas) yet appears in neither JamPlay document and is not tracked by Git.
3. **The production placeholder is undocumented.** `/play` exists and explicitly disclaims availability
   (`frontend/app/play/page.tsx:4-28`) — the only production-side JamPlay artefact — and no document
   mentions it.
4. **No AI-vs-multiplayer ordering constraint is written down.** The plan lists P2 (AI) before P7
   (multiplayer) but never states that multiplayer is gated on AI acceptance and a shared engine, which
   is the approved implementation order.
5. **No city-discovery exclusion note.** The prototype contains city discovery (`renderCity` `6165`,
   `jamPlace` `6453`); no document says it is deferred outside P0–P9.

---

## 5. Verification limitations

- Claims were verified by static inspection only. No test suite, build, typecheck, lint or Django
  management command was run, because each would write state (test database, `.pyc`, `.next`,
  `tsbuildinfo`, caches) and the brief forbids mutating repository/environment state.
- The prototype was not executed in a browser; all prototype findings are source-read findings.
- The `jam-life.html` file is 4.1 MB / 7,162 lines with long single-line blocks; line-number evidence is
  exact at the cited lines but a line number does not prove absence of other occurrences.
- `docs/audits/jamplay/IMPLEMENTATION_STATUS.md` and `ARCHITECTURE_AUDIT.md` (untracked, pre-existing in
  the working tree) were read for consistency; their cited line numbers were spot-checked and matched
  this audit's findings. They were **not modified**.
