# JamPlay — Implementation Gap Analysis

Read-only audit performed 2026-11-13 against branch `main` (dirty tree). No files, schema,
configuration, dependencies, databases or Git state were changed.

Scope: map every requirement implied by `docs/jam play/JAMPLAY_ARCHITECTURE.md` and
`docs/jam play/JAMPLAY_IMPLEMENTATION_PLAN.md` — plus the approved constraints (server-authoritative
gameplay, PostgreSQL persistent / Redis ephemeral, one shared engine, AI before multiplayer, no wallet
assumption, no subscription-gated benefits, City Discovery deferred) — to what exists in the repository,
phase by phase, with acceptance criteria and a verification approach for each gap.

**Baseline:** production gameplay implementation is 0 %. The only executable game code is the untracked
browser prototype `jam-life.html` (7,162 lines), which is `PROTOTYPE_ONLY` and not reusable as a server
engine (see `ARCHITECTURE_AUDIT.md` §5 and `IMPLEMENTATION_STATUS.md`).

Status vocabulary: `PRODUCTION_IMPLEMENTED`, `PRODUCTION_PARTIAL`, `PROTOTYPE_ONLY`, `DEMO_OR_MOCK`,
`DOCUMENTED_ONLY`, `NOT_FOUND`, `UNVERIFIED`.

---

## 1. Summary matrix

| Phase | Theme | Gaps | Implemented in production | Blocking decisions |
|---|---|---:|---:|---|
| P0 | Discovery & decisions | 4 | 0 | D-01…D-15 |
| P1 | Game foundation (app, identity, persistence) | 4 | 0 | D-09, D-13 |
| P2 | Arena engine + AI (shared domain engine) | 7 | 0 | D-04, D-05, D-06, D-07 |
| P3 | Siege | 4 | 0 | D-04, D-05 |
| P4 | Cards, deck, base/tower | 4 | 0 | D-05, D-09 |
| P5 | Progression, missions, leagues | 5 | 0 | D-10, D-13 |
| P6 | Game economy, ledger, rewards | 5 | 0 | D-01, D-02, D-03 |
| P7 | Multiplayer | 5 | 0 | D-08, D-14 |
| P8 | Social graph, leaderboards, discovery-adjacent UI | 3 | 0 | D-10, D-15 |
| P9 | Hardening, anti-cheat, operations, evidence | 6 | 0 | D-11, D-12, D-13 |
| Future | City Discovery (deferred, outside P0–P9) | 1 | 0 | — |

---

## 2. P0 — Discovery and decisions (no code may start before these close)

| ID | Gap | Current state | Target | Dependencies | Risk if unaddressed | Phase | Acceptance criteria | Verification approach |
|---|---|---|---|---|---|---|---|---|
| G-00-1 | Authoritative rules specification outside the prototype | `PROTOTYPE_ONLY`: rules only exist as DOM-coupled JS in `jam-life.html:3887-7162` | Versioned, engine-readable rules spec (units, stats, costs, damage formulas, tick semantics, win conditions) approved by owner | D-09 | Any "port" becomes a silent redesign; balance disputes unresolvable | P0 | Spec covers every constant used by `initArena`/`updateArena`/`initSiege`/`updateSiege` and is reviewed against the prototype | Diff spec constants against prototype constants; engineering + owner sign-off |
| G-00-2 | Persistent vs ephemeral state classification | `NOT_FOUND` | Table of every game entity → PostgreSQL or Redis, with TTL and durability rationale | D-07 | Redis used as a database → lost matches/progress on eviction | P0 | Each entity in G-01-1…G-05-4 has an explicit store and TTL; no entity marked "Redis, permanent" | Design review against `AGENTS.md` §6 storage rules |
| G-00-3 | Simulation authority model & performance budget | `NOT_FOUND` | Decision: full server tick simulation vs command validation + deterministic replay; measured tick cost per battle | D-04, D-05 | Choosing full simulation on a single gunicorn worker makes P7 impossible | P0 | Benchmark artefact showing CPU per 60 s battle at target tick rate on target host class | Timing harness run in an isolated environment (not Staging); numbers recorded |
| G-00-4 | Documentation status correction | `OUTDATED` — both JamPlay docs read as if the system exists | Docs state status, scope, exclusions (subscription benefits, City Discovery) | — | Stakeholders plan against fiction; agents implement unapproved features | P0 | `DOCUMENTATION_CLAIMS_AUDIT.md` corrections applied to both docs by their owner | Re-read docs; confirm every present-tense claim maps to code or is marked "proposed" |

---

## 3. P1 — Game foundation

| ID | Gap | Current state | Target | Dependencies | Risk | Phase | Acceptance criteria | Verification approach |
|---|---|---|---|---|---|---|---|---|
| G-01-1 | `games` Django app | `NOT_FOUND` — not in `INSTALLED_APPS` (`backend/config/settings.py:44-49`), no route (`config/urls.py:10-19`) | App registered, URL mount under `/api/games/`, trailing-slash routes | — | Parallel service/duplicate domain logic instead of staying in Django apps | P1 | `manage.py check` clean; `makemigrations --check` clean; app appears in `INSTALLED_APPS` and `config/urls.py` | `python manage.py check --settings=config.test_settings`; `makemigrations --check --dry-run` |
| G-01-2 | Player profile linked to `accounts.User` | `NOT_FOUND`; `User` has phone/email/role only (`accounts/models.py:48-88`) | `GameProfile` OneToOne to `User` with server-owned progression fields | G-01-1 | Identity duplication or client-supplied identity | P1 | One profile per user enforced by DB constraint; profile never accepts client-supplied owner id | Migration review + test asserting duplicate profile creation fails and cross-user access is 404 |
| G-01-3 | Persistence schema for battles and inventory | `NOT_FOUND`; 30 existing migrations, none game (`backend/*/migrations`) | Additive migrations for profile, inventory, battle session, battle event log | G-00-2, G-01-2 | Destructive or drifted schema; SQLite-only assumptions leaking into PostgreSQL | P1 | Migrations additive; `makemigrations --check` clean; reviewed for indexes and constraints | `makemigrations --check --dry-run`; PostgreSQL migration smoke test in an isolated instance |
| G-01-4 | Server-side game API skeleton | `NOT_FOUND` | DRF viewsets/`APIView`s with `IsAuthenticated`, owner-scoped querysets, `{"detail","code"}` errors, Persian messages | G-01-1, G-01-2 | Endpoint sprawl, cross-owner leakage, English error copy | P1 | Every endpoint scoped by `request.user`; cross-owner returns 404; errors structured | `APITestCase` covering auth-required, 404 cross-owner, error shape |

---

## 4. P2 — Arena and the shared engine (the critical phase)

| ID | Gap | Current state | Target | Dependencies | Risk | Phase | Acceptance criteria | Verification approach |
|---|---|---|---|---|---|---|---|---|
| G-02-1 | Headless battle domain engine | `PROTOTYPE_ONLY`: `class CombatSession` (`jam-life.html:4227-5867`) directly touches `document`, `innerWidth`, `getContext("2d")`, `requestAnimationFrame`, `performance.now` | Pure Python (or otherwise server-runnable) engine with no I/O, no wall-clock, no randomness except an injected seeded PRNG | G-00-1, G-00-3 | A client engine on the server cannot be tested, replayed or trusted | P2 | Engine importable without Django/DB/DOM; same seed + same command list ⇒ identical state hash across 1,000 runs | Unit tests: determinism replay, no-I/O import test, hash equality |
| G-02-2 | Explicit tick/command protocol | `NOT_FOUND` | Server tick loop with integer time, command types (deploy, cast, move), validation and rejection reasons | G-02-1 | Client authority re-enters through the command channel | P2 | Invalid commands rejected server-side and logged; no client-supplied outcome is trusted | Tests: forged command payloads, out-of-phase commands, replay injection |
| G-02-3 | AI opponent driving the same engine | `PROTOTYPE_ONLY` — AI logic sits inside the same client class | Server-side AI controller consuming only engine state + difficulty profile | G-02-1, G-02-2 | AI forks into a second rules implementation (violates "one shared engine") | P2 | AI and (future) human matches run the identical engine entrypoint; AI path has no engine fork | Code review for single engine import; AI-vs-AI soak test (10k ticks) with no divergence |
| G-02-4 | Battle session lifecycle | `NOT_FOUND` | Session states (created → active → finished/abandoned), server timestamps, resumability rules | G-01-3, G-02-2 | Orphan sessions; double settlement | P2 | State transitions enforced in DB + service; illegal transition raises structured error | `APITestCase` transition matrix; concurrency test on finish |
| G-02-5 | Server-side battle settlement | `NOT_FOUND`; prototype settles in browser (`combatEnded` `6379`, `grant` `5990`) | Atomic settlement in `transaction.atomic()` + `select_for_update()`, idempotent per battle id | G-02-4, G-05-1 | Duplicate rewards, negative balances | P2 | Re-running settlement for the same battle changes nothing; balances never negative | Concurrency test (PostgreSQL-only) and idempotency test |
| G-02-6 | Frontend battle client (renderer/input) | `DEMO_OR_MOCK`: `/play` placeholder (`frontend/app/play/page.tsx:4-28`), no game code in `frontend/app|components|lib` | Client that renders server state and sends commands via `frontend/lib/api.ts` + same-origin proxy | G-02-2 | Duplicated client-side rules; auth bypass via raw fetch | P2 | Zero rule logic in client beyond presentation; all calls through `lib/api.ts`; no `any` | `npx tsc --noEmit`; `npm run lint`; code review for duplicated constants |
| G-02-7 | Arena rules parity & balance sign-off | `DOCUMENTED_ONLY` | Documented, approved arena rules; win condition/timer; reward curve | G-00-1, G-02-1 | Shipping prototype balance that was never reviewed | P2 | Owner sign-off on rules table; automated test asserts each constant equals spec | Table-driven test vs spec; owner review record |

---

## 5. P3 — Siege

| ID | Gap | Current state | Target | Dependencies | Risk | Phase | Acceptance criteria | Verification approach |
|---|---|---|---|---|---|---|---|---|
| G-03-1 | Siege mode in the shared engine | `PROTOTYPE_ONLY`: `initSiege` `5110`, `updateSiege` `5228`, `destruction` `5215` | Siege implemented as engine mode, not a second engine | G-02-1, G-02-2 | Forking siege into its own loop (divergence, double maintenance) | P3 | Both modes share one tick entrypoint; mode selected by parameter | Engine test instantiating both modes from one entrypoint |
| G-03-2 | Siege objectives, destruction, star rating | `PROTOTYPE_ONLY` (`siegeStars` `5221-5225`) | Server-computed objectives and result; stars derived server-side | G-03-1, G-02-5 | Client-computed stars ⇒ reward fraud | P3 | Client cannot influence stars; recomputation matches stored result | Tests: tampered result payload rejected; recompute equals stored |
| G-03-3 | Siege content (maps/layouts) | `DEMO_OR_MOCK` inside prototype | Versioned content data separate from engine code | G-00-1 | Balance changes requiring code deploys | P3 | Content loads from data files/tables with explicit version | Content-loading test; version recorded per battle |
| G-03-4 | Siege tests and replay fixtures | `NOT_FOUND` | Deterministic replay fixtures for 3 representative sieges | G-03-1 | Regressions undetectable | P3 | Fixture replays reproduce identical hashes | Replay test suite in CI-equivalent local run |

---

## 6. P4 — Cards, deck, base and tower

| ID | Gap | Current state | Target | Dependencies | Risk | Phase | Acceptance criteria | Verification approach |
|---|---|---|---|---|---|---|---|---|
| G-04-1 | Card catalog and deck model | `PROTOTYPE_ONLY` (card data embedded in `jam-life.html`; no server model) | PostgreSQL catalog + per-player owned cards + deck composition with limits | G-01-3 | Deck exploits via client-supplied ownership | P4 | Deck validation server-side; unknown/unowned cards rejected | Tests: deck with unowned card, duplicate card, over-limit |
| G-04-2 | Deck validation & loadout rules | `NOT_FOUND` | Server rules for size, duplicates, cost curve | G-04-1 | Pay-to-win or impossible decks | P4 | Rule violations return structured 400 with Persian message | Parameterized rule tests |
| G-04-3 | Base/tower layout and upgrade timers | `PROTOTYPE_ONLY` (base UI in prototype; `localStorage` persistence) | Server-owned layout + upgrade state with deterministic time source | G-01-3, D-12 | Client clock manipulation gives free upgrades | P4 | Upgrades computed from server time; client time ignored | Tests with skewed client timestamps |
| G-04-4 | Card/base content pipeline | `DOCUMENTED_ONLY` | Data-driven content with versioning, reviewed balance tables | G-00-1 | Undocumented magic numbers | P4 | Content version stored per battle; spec table matches data | Data/spec diff test |

---

## 7. P5 — Progression, missions, leagues

| ID | Gap | Current state | Target | Dependencies | Risk | Phase | Acceptance criteria | Verification approach |
|---|---|---|---|---|---|---|---|---|
| G-05-1 | XP/level/trophy/league model | `PROTOTYPE_ONLY` (`xpNeed`/`lvlInfo` `5967-5968`, `LEAGUES` `4033-4036`, `league()` `5978`; state in `localStorage`) | Server-owned progression with atomic updates per settled battle | G-02-5 | Client-side XP forgery | P5 | Progression changes only through settlement; monotonic where required | Settlement tests; tampered-payload tests |
| G-05-2 | Missions/achievements | `PROTOTYPE_ONLY` (mission chains in prototype IIFE) | Server-evaluated missions with idempotent claim | G-05-1 | Double-claim of rewards | P5 | Claim endpoint idempotent; one claim per mission per player | Concurrency test on claim |
| G-05-3 | Chests/loot | `PROTOTYPE_ONLY` (loot rolls in prototype) | Server-rolled loot with recorded seed and audit trail | G-05-1, D-13 | Client-side reroll abuse | P5 | Roll executed server-side; seed and result stored | Test that client cannot supply loot result |
| G-05-4 | Seasonal/reset semantics | `DOCUMENTED_ONLY`; no scheduler in repo (`no Celery/beat`; only `notify_expiring_entitlements`) | Season boundaries and reset jobs with external scheduler wiring | D-12 | Seasons never roll over; inconsistent trophies | P5 | Season rollover idempotent and re-runnable | Management-command tests + documented cron |
| G-05-5 | Leaderboard read model | `DEMO_OR_MOCK` (prototype seeded board `6396`) | Server-side ranking (scope decided in D-10) with bounded query cost | G-05-1, D-10 | Full-table scans; privacy leaks | P5 | Query plan reviewed; p95 latency measured under synthetic volume | Index/EXPLAIN review + local benchmark |

---

## 8. P6 — Game economy (blocked on unapproved premises)

| ID | Gap | Current state | Target | Dependencies | Risk | Phase | Acceptance criteria | Verification approach |
|---|---|---|---|---|---|---|---|---|
| G-06-1 | Game currency ledger | `NOT_FOUND` — no customer wallet anywhere (`grep -rni wallet backend --include=*.py` → 0); `SettlementEntry` is merchant-only (`commerce/models.py:209-234`) | Append-only ledger owned by an explicitly decided domain (D-01) | D-01 | Two competing balance sources; unreconcilable money | P6 | Balance = sum of ledger entries; every mutation writes an entry | Ledger-sum property test; no direct balance writes |
| G-06-2 | Earn rules (battle/mission rewards) | `PROTOTYPE_ONLY` | Server-side earn rules with caps and anti-farming limits | G-06-1, G-02-5 | Economy inflation / bot farming | P6 | Daily caps enforced server-side; abuse tests fail closed | Cap tests; burst-request tests |
| G-06-3 | Spend rules (upgrades, chests, entries) | `PROTOTYPE_ONLY` | Atomic spend with insufficient-funds protection | G-06-1 | Negative balances under concurrency | P6 | Concurrent spends cannot overdraw | PostgreSQL concurrency test with `select_for_update` |
| G-06-4 | Discount/coupon issuance to commerce | `FALSE premise`: no coupon model server-side; prototype coupons are local-only (`JG_OFFERS` `6461`, note at `6471`); `payments.Transaction` FK is `SubscriptionPurchase` only (`payments/models.py:11`) | Only if approved (D-02): a payable abstraction + coupon model integrated with real order discounting | D-01, D-02 | Owner rules on discounts/prices changed by implication; fraud | P6 | Owner-approved design; discounts applied through existing order pricing, never trusted from client | Pricing tests; fraud tests on reuse |
| G-06-5 | Real-money purchase of game currency | `NOT_FOUND`; ZarinPal is the only approved provider and is subscription-bound | Blocked unless owner approves a new payable path | D-02 | Unauthorized monetization / provider violation | P6 | Explicit owner approval recorded before any code | N/A until approved |

**Note:** G-06-4/G-06-5 are the exact items the planning docs assert as existing integration
(`JAMPLAY_ARCHITECTURE.md:187,189-190`; `JAMPLAY_IMPLEMENTATION_PLAN.md:135,144-147`). Those claims are false.

---

## 9. P7 — Multiplayer

| ID | Gap | Current state | Target | Dependencies | Risk | Phase | Acceptance criteria | Verification approach |
|---|---|---|---|---|---|---|---|---|
| G-07-1 | Transport (WebSocket/ASGI) | `NOT_FOUND`: no `channels`/`daphne`/`uvicorn` in `requirements.txt`/`requirements.lock.txt`; `config/asgi.py` is plain `get_asgi_application()`; `backend/Dockerfile:14` runs gunicorn WSGI | Transport selected per D-08, benchmarked, with dependency + runtime change approved | D-08, G-02-2 | WSGI deployment cannot serve WS; silent Staging failure | P7 | Benchmark shows target concurrent matches at p95 latency; runtime config validated | Load test in isolated environment; config validation |
| G-07-2 | Matchmaking queue | `NOT_FOUND` | Rating-based pairing with bounded wait and cancel | G-07-1, G-05-1 | Unbounded queues; stale matches | P7 | Queue TTL enforced; cancel removes entry | Queue simulation tests |
| G-07-3 | Presence / connection lifecycle | `NOT_FOUND` | Connect, disconnect, reconnect-within-grace, forfeit rules | G-07-1, G-02-4 | Abandoned matches; exploited disconnects | P7 | Disconnect grace + forfeit tested; no double settlement | Integration tests with simulated drops |
| G-07-4 | Shared-engine parity AI vs PvP | `NOT_FOUND` | Both modes run the identical engine entrypoint | G-02-3, G-07-1 | Two rule implementations diverge | P7 | Parity test: same seed/commands ⇒ same hash in AI and PvP modes | Cross-mode determinism test |
| G-07-5 | Multiplayer anti-abuse baseline | `NOT_FOUND` | Rate limits, per-connection command quotas, replay detection | G-07-1 | DoS, command flooding | P7 | Throttles enforced; violations logged and rejected | Load + abuse tests |

**Gate:** P7 must not begin before P2 acceptance (AI engine accepted). This ordering is an approved
constraint; `JAMPLAY_IMPLEMENTATION_PLAN.md` implies it but never states it as a gate.

---

## 10. P8 — Social graph and leaderboards

| ID | Gap | Current state | Target | Dependencies | Risk | Phase | Acceptance criteria | Verification approach |
|---|---|---|---|---|---|---|---|---|
| G-08-1 | Friends / challenges | `DEMO_OR_MOCK` (`FRIENDS` `4059`, "حریف نمایشی" in `renderClub` `6399`) | Server-side friend requests, accepted graph, friend challenges | G-05-1, D-10 | Harassment, enumeration of users | P8 | Requests consent-based; user discovery does not leak phone numbers | Permission tests; enumeration tests |
| G-08-2 | Leaderboard scopes | `DEMO_OR_MOCK` (`board()` `6396`, seeded with `seeded(42)`) | Decided scopes (global/league/friends) with privacy rules | G-05-5, D-10 | Privacy exposure; cost | P8 | Each scope documented; no PII in responses | Response-shape tests |
| G-08-3 | Social UI in Next.js | `NOT_FOUND` | Persian/RTL social surfaces using existing design tokens | G-08-1, G-02-6 | LTR-only or English copy creeping in | P8 | RTL verified; no hardcoded English user-facing copy | `npm run lint`, `npx tsc --noEmit`, RTL review |

---

## 11. P9 — Hardening, anti-cheat, operations

| ID | Gap | Current state | Target | Dependencies | Risk | Phase | Acceptance criteria | Verification approach |
|---|---|---|---|---|---|---|---|---|
| G-09-1 | Server-side validation completeness | `NOT_FOUND` for games (claim at `JAMPLAY_ARCHITECTURE.md:234` is false) | Every command/state transition validated; fuzz-resistant parsers | G-02-2 | Trivial cheating | P9 | Fuzz + property tests; no 500s on malformed input | Fuzz harness; error-shape assertions |
| G-09-2 | Anti-cheat signals | `NOT_FOUND` | Detect impossible command rates, impossible outcomes, replay divergence; alert + block | G-07-5, G-09-1 | Undetected farming | P9 | Documented signals and thresholds; blocking is auditable | Synthetic cheat scenarios must be flagged |
| G-09-3 | Game audit trail / admin tooling | `NOT_FOUND`; JAM has `AdminAction` precedent (`accounts/models.py:90`) | Audit records for sensitive game mutations; admin-only read tools | G-09-2 | Unreviewable grants/bans | P9 | Every sensitive mutation writes an audit row; endpoints require `IsAdmin` | Tests asserting non-admin 403 and audit row creation |
| G-09-4 | Scheduler wiring for timers/seasons/notifications | `NOT_FOUND`; `AGENTS.md` §4 lists scheduler ownership as an open decision; only `notify_expiring_entitlements` exists | Approved external scheduler with documented runbook | D-12, G-05-4 | Timers never fire; duplicated jobs on multi-instance | P9 | Idempotent commands; runbook with interval and failure handling | Dry-run of each command; runbook review |
| G-09-5 | Observability for game | `NOT_FOUND` | Metrics/logs for match creation, settlement failures, latency; no secrets/PII | G-09-2 | Blind operations | P9 | Dashboards/alerts defined; log redaction verified | Log inspection for PII/secrets; alert dry run |
| G-09-6 | Automated verification baseline | `NOT_FOUND` for games; repository has no CI config (no `.github/`, `.gitlab-ci.yml`, `Jenkinsfile`) and 16 test files total, none game-related | Game tests in the existing Django runner; documented local command set | all | Regressions ship silently | P9 | Test suite covers determinism, idempotency, ownership, economy invariants | `python manage.py test --settings=config.test_settings` (skipped PostgreSQL-only tests reported) |

---

## 12. Future — City Discovery (deferred, outside P0–P9)

| ID | Gap | Current state | Target | Dependencies | Risk | Phase | Acceptance criteria | Verification approach |
|---|---|---|---|---|---|---|---|---|
| G-F-1 | City discovery | `PROTOTYPE_ONLY` (`renderCity` `6165`, `jamPlace` `6453`) | Not scheduled | Separate owner decision after P9 | Scope creep delaying P2/P7 | Future | No code or schema for discovery before explicit approval | Review of `games` app for discovery code |

---

## 13. Cross-cutting gaps

| ID | Gap | Evidence | Risk | Recommended handling |
|---|---|---|---|---|
| X-1 | No CI/CD at all | No `.github/workflows`, `.gitlab-ci.yml`, `Jenkinsfile`; `AGENTS.md` §7 states checks are local/manual | Regressions depend on human discipline | Not a JamPlay-specific fix; do not add CI inside this programme without approval |
| X-2 | Untracked 4.1 MB prototype in repo root | `git status` → `?? jam-life.html` | Accidental commit of a demo artefact; governance ambiguity | Owner decision D-09 (keep as reference vs move to `docs/` vs delete) |
| X-3 | JWT in `localStorage`, no revocation | `frontend/lib/api.ts`; `AGENTS.md` §5 documents the XSS risk | Game accounts inheriting a weak session model | Do not change auth architecture inside JamPlay; record as inherited risk |
| X-4 | SQLite test default hides PostgreSQL concurrency defects | `config.test_settings` uses in-memory SQLite; concurrency tests skip | Ledger/settlement bugs invisible locally | Run PostgreSQL-only tests in an isolated instance before accepting P2/P6 |
| X-5 | Plan documents assume a wallet and coupon integration | `JAMPLAY_ARCHITECTURE.md:173,187,189-190`; `JAMPLAY_IMPLEMENTATION_PLAN.md:135,144-147` | Building an unapproved financial subsystem | Close D-01/D-02 first; see `DOCUMENTATION_CLAIMS_AUDIT.md` §2–§3 |

---

## 14. Critical path

```
P0 (G-00-1 spec, G-00-2 state map, G-00-3 authority/perf, G-00-4 docs)
   └─ P1 (G-01-1 app → G-01-2 profile → G-01-3 schema → G-01-4 API)
        └─ P2 (G-02-1 engine → G-02-2 tick/commands → G-02-3 AI → G-02-4 lifecycle → G-02-5 settlement)
             ├─ P3 siege (shares engine)
             ├─ P4 cards/base
             ├─ P5 progression (needs settlement)
             │    └─ P8 social/leaderboards
             ├─ P6 economy — BLOCKED on D-01/D-02
             └─ P7 multiplayer — BLOCKED until P2 accepted and D-08 closed
                  └─ P9 hardening
```

No P1+ work is currently authorized: the approved order requires the accepted AI engine before
multiplayer, and the brief limits this engagement to P0 discovery.

---

## 15. Verification limitations

- Static inspection only. Nothing was executed: no tests, builds, typechecks, lints, migrations or
  management commands, because each would write state (test DB, `.pyc`, `.next`, `tsbuildinfo`, caches)
  against the brief's read-only constraint. All "acceptance criteria" above are therefore proposals, not
  results.
- Absence claims rest on recursive grep over `backend/` and `frontend/app|components|lib` excluding
  `node_modules`, plus directory listings; they are strong but not mathematical proofs.
- No production, Staging or Docker environment was contacted. The Staging topology is documented but
  unprovisioned per `AGENTS.md` §8.
