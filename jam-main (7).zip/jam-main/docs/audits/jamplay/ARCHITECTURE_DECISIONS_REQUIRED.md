# JamPlay — Architecture Decisions Required

Read-only audit output, 2026-11-13. Branch `main`, dirty tree. Nothing was implemented or modified.

These are decisions the repository cannot answer for itself. Each one is **blocking** for at least one
phase, and several are decisions the planning documents silently assume rather than state. Per
`AGENTS.md` §1, an AI agent may not choose arbitrarily between conflicting or missing owner decisions;
where the code contradicts a decision, work stops and reports.

Priority key: **P0-blocking** = must close before any code; **phase-gating** = must close before the
named phase; **non-blocking** = can be decided during the phase but before its acceptance review.

---

## D-01 — Ownership of game currency and balances

**Question.** Does JamPlay's soft currency (coins/gems) and any real-money balance live inside a new
game ledger owned by the `games` domain, or does it extend a platform-level wallet that `commerce` owns?

**Why it matters.** No customer wallet or ledger exists today: `grep -rni 'wallet' backend --include=*.py`
returns 0 matches, and the only ledger is the merchant settlement ledger
(`backend/commerce/models.py:209-234`, "Real payouts are not implemented"). The planning documents assert
"Game economy connects to existing wallet system" (`JAMPLAY_ARCHITECTURE.md:187`) and "Wallet Ledger as
the authoritative transaction history" (`:173`) — both describe something that does not exist. Choosing
wrongly creates two competing balance sources, or embeds marketplace money rules inside a game app.

**Options.**
- **A.** Game-only ledger in `games`; no interaction with commerce money. Simplest, no financial risk,
  cannot later be spent on marketplace purchases without a bridge.
- **B.** Platform ledger in `commerce` that both game and marketplace spend from. Higher blast radius;
  touches owner-approved commission/settlement rules.
- **C.** Game ledger now, explicit bridge table later (deferred integration).

**Constraints.** Integer Toman convention for money (`AGENTS.md` §2); no new service/architecture without
approval; no changes to prices, plans, or settlement rules.

**Recommendation.** A, with the bridge explicitly out of scope until separately approved. Record the
choice in `docs/SUBSCRIPTION_ARCHITECTURE.md`-style canonical form — a game ledger is *not* a wallet.

**Blocks:** G-06-1, G-06-3, P6. **Priority:** P0-blocking (because P6 premises currently contradict code).

---

## D-02 — Monetization of the game (real money → game value)

**Question.** May players buy game currency, chests, or battle entries with real money, and if so through
which payable path?

**Why it matters.** `payments.Transaction` has a `purchase = ForeignKey(SubscriptionPurchase)` only
(`backend/payments/models.py:11`); there is no generic payable abstraction. ZarinPal is the only approved
online provider and is subscription-bound (`AGENTS.md` §4). The plan asserts coupon/payment integration
as if it exists (`JAMPLAY_IMPLEMENTATION_PLAN.md:135,144-147`) and the architecture doc asserts "Coupon
issuance integrates with payment infrastructure" (`:189`).

**Options.**
- **A.** No real-money game purchases (earn-only economy). No payment work.
- **B.** Generic payable abstraction shared with subscriptions (larger change to `payments`, explicit
  owner approval required; must preserve "server-side verification only" rule).
- **C.** Separate game purchase model duplicating provider handling (rejected pattern: duplicates
  existing domain logic, `AGENTS.md` §6).

**Constraints.** Browser redirect is never proof of payment; only server verification promotes state;
unconfigured provider must fail with `503 payment_provider_unconfigured`; no discounts or price changes
without owner approval.

**Recommendation.** A for P0–P9. If B is ever chosen, it needs its own approved design, not a plan
footnote.

**Blocks:** G-06-4, G-06-5, P6. **Priority:** P0-blocking.

---

## D-03 — Subscription-gated game benefits

**Question.** Do any subscription plans grant game benefits (extra energy, currency multiplier, exclusive
cards, premium battle modes)?

**Why it matters.** The brief states subscription-gated game benefits are **not approved**. The
architecture document nonetheless claims "Premium subscription entitlements **can** unlock advanced game
features" (`:193`) and "Progression and rewards linked to active subscriptions" (`:194`). Implementing
this would change owner-approved plan semantics without an owner decision, and `AGENTS.md` §9 forbids
adding plan-feature enforcement that does not exist today.

**Options.**
- **A.** Explicitly exclude. Document the exclusion so no future agent "restores" the claim.
- **B.** Approve a specific matrix (plan → game benefit) with prices unchanged and tests. Requires owner
  decision plus updates to canonical subscription documentation.

**Constraints.** `SubscriptionProduct` prices/durations are authoritative and immutable without owner
approval; entitlement types today are `MENU`/`CLUB` only (`backend/subscriptions/models.py:103-105`).

**Recommendation.** A. Record in both JamPlay documents and in the subscription architecture doc that
subscriptions grant no game benefits.

**Blocks:** correctness of P5/P6 scope. **Priority:** P0-blocking (cheap to close, expensive to unwind).

---

## D-04 — Simulation authority granularity

**Question.** Does the server simulate every battle tick (full authoritative simulation), or does it
validate commands and verify a deterministic replay produced elsewhere?

**Why it matters.** The approved constraint is server-authoritative gameplay. Full simulation at a
playable tick rate is the simplest to trust but the most CPU-expensive; replay verification is cheaper
but requires bit-exact determinism and careful anti-tamper design. There is no benchmark in the
repository, and `JAMPLAY_ARCHITECTURE.md:240-247` lists performance ideas without evidence.

**Options.**
- **A.** Full server tick loop; clients are pure renderers.
- **B.** Server-issued seed + command log; server replays deterministically to verify.
- **C.** Hybrid: server simulates authoritative state, replays only for dispute/audit.

**Constraints.** One shared engine for AI and multiplayer; PostgreSQL for persistent state; Redis only
for ephemeral data; existing single gunicorn process (`backend/Dockerfile:14`); Render Free limitations
documented in `AGENTS.md` §8.

**Recommendation.** C. It preserves trust and keeps replay as an audit tool rather than the primary
trust mechanism, but the decision must be made against a measured CPU budget (G-00-3), not intuition.

**Blocks:** G-00-3, G-02-1, G-02-2, P7 capacity planning. **Priority:** P0-blocking.

---

## D-05 — Time model, tick rate and battle duration

**Question.** What is the authoritative tick rate, integer time unit, maximum battle duration, and how
does the client interpolate between server states?

**Why it matters.** The prototype runs at display refresh rate with wall-clock deltas
(`jam-life.html:4227-4300`: `performance.now()`, `requestAnimationFrame(dt)`). Ported naively, that is
both non-deterministic and server-expensive. Determinism tests (G-02-1) are impossible without a fixed
time step.

**Options.** Fixed 20/30/60 Hz server tick with client interpolation; battle cap of N minutes; hard
timeout resolution rules. All are engineering choices but the *battle duration* is a product choice.

**Constraints.** Integer arithmetic for determinism; no wall-clock in the engine; server computes all
outcomes.

**Recommendation.** Fixed 20 Hz server tick, client interpolation, 3-minute arena cap, siege cap set with
content review. Confirm with a CPU measurement before P2 acceptance.

**Blocks:** G-02-1, G-03-1, G-00-3. **Priority:** phase-gating (P2).

---

## D-06 — AI difficulty and reward fairness

**Question.** How does AI difficulty scale, and are rewards identical for AI and PvP wins?

**Why it matters.** The prototype's reward path is client-side (`grant` `jam-life.html:5990`,
`combatEnded` `6379`) and its AI is inside the same class. If AI matches pay like PvP matches, bot farming
is the default exploit; if they pay less, the single-player loop (the entire P2 deliverable) feels
pointless. This is a product/economic decision, not purely technical.

**Options.** Difficulty tiers with capped AI rewards; AI rewards identical but daily-capped; AI-only
progression track.

**Constraints.** Server-side settlement only; idempotent; no negative balances; no wallet assumption
(D-01).

**Recommendation.** Difficulty tiers with a documented reward multiplier and a hard daily cap, decided
together with D-01's ledger rules.

**Blocks:** G-02-3, G-02-5, G-06-2. **Priority:** phase-gating (P2), final before P6.

---

## D-07 — Persistent vs ephemeral state boundary (Redis role)

**Question.** Which game entities are durable (PostgreSQL) and which are ephemeral (Redis), and what are
the TTLs and loss tolerances?

**Why it matters.** The approved constraint says PostgreSQL holds persistent state and Redis is
ephemeral only. Today Redis is a **cache** with a `LocMemCache` fallback (`backend/config/settings.py:
190-199`) and `CACHE_REQUIRE_REDIS` guarding production. The docs claim battle state in Redis
(`JAMPLAY_ARCHITECTURE.md:235`) with no classification.

**Options.** Explicit per-entity table (battle session, command queue, presence, matchmaking ticket:
Redis; profile, inventory, progression, ledger, results: PostgreSQL). Alternative: PostgreSQL-only for
P2 and add Redis only when presence/matchmaking arrives (P7).

**Constraints.** Redis eviction and Render/Upstash limits are real (`AGENTS.md` §8); no Redis as a
database; readiness must not claim external Redis when LocMem is active.

**Recommendation.** PostgreSQL-only for P2/P3/P4/P5; introduce Redis at P7 for presence/matchmaking
tickets only, with TTLs documented per key.

**Blocks:** G-00-2, G-01-3, G-07-1. **Priority:** P0-blocking (state map), Redis specifics phase-gating.

---

## D-08 — Multiplayer transport and hosting

**Question.** Do we adopt Django Channels/ASGI (with a channel layer), or a separate managed realtime
service; and does the deployment target change accordingly?

**Why it matters.** No `channels`/`daphne`/`uvicorn` dependency exists; `backend/config/asgi.py` is plain
`get_asgi_application()`; runtime is gunicorn WSGI (`backend/Dockerfile:14`). Adding ASGI is an
architecture change requiring approval, plus a hosting change (Render Free has no shell and documented
limits). The doc asserts ASGI/Channels as a settled choice (`:199`).

**Options.**
- **A.** Channels + Redis channel layer on ASGI, replacing gunicorn with an ASGI server (or Daphne+worker).
- **B.** External managed realtime service (new third-party dependency; needs vetting and credentials).
- **C.** Polling/HTTP long-poll first, WebSocket later — cheapest, worst feel.

**Constraints.** No new architecture/dependency without owner approval; no Telegram bot start in
Staging; readiness and health behavior must remain truthful; PostgreSQL persistent / Redis ephemeral.

**Recommendation.** A, but only after G-00-3 measurement and an explicit dependency/hosting approval.
Until then, P7 stays closed.

**Blocks:** G-07-1…G-07-5. **Priority:** phase-gating (P7).

---

## D-09 — Governance and licensing of the `jam-life.html` prototype

**Question.** Is the prototype (a) the approved rules/content source of truth, (b) a disposable
reference, or (c) removed from the repository; and under what licence/attribution?

**Why it matters.** `jam-life.html` is 7,162 lines / 4.1 MB, **untracked** (`git status` → `?? jam-life.html`),
never referenced by either JamPlay document, yet it is the only executable statement of game rules,
content and balance. Its own header says data is sample data and persistence is `localStorage`
(`:2280-2287`). The settings page states art/engine were "transferred from the Isfahan project" and that
server, banking, anti-cheat, online friends and verified GPS do not exist in source files (`:6410`) —
a provenance/licensing question, not just a technical one.

**Options.** Track it as `docs/jamplay/prototype/` with a status header; keep untracked and reference by
path; delete after the rules spec (G-00-1) is approved.

**Constraints.** Do not commit a demo artefact as production code; do not copy third-party game art
without rights; no implementation from the prototype without the spec.

**Recommendation.** Extract and approve the rules spec first (G-00-1); then either track the prototype
under `docs/` with a `PROTOTYPE_ONLY` banner or delete it. Never let it be treated as the engine.

**Blocks:** G-00-1, G-02-1. **Priority:** P0-blocking.

---

## D-10 — Social identity, friend model and leaderboard scope

**Question.** Who can find whom; is the friend graph symmetric; are leaderboards global, per-league, or
friends-only; and what identity is exposed?

**Why it matters.** JAM users are identified by phone (`accounts/models.py:48-88`). A leaderboard that
exposes names/phones creates a privacy problem; the prototype's board is seeded fake data
(`board()` `jam-life.html:6396`, `seeded(42)`) and its "friends" are labelled "حریف نمایشی" (`:6399`).
`AGENTS.md` §5 forbids exposing full phone numbers.

**Options.** Display name only (never phone); friends-only by default; global leaderboard opt-in.

**Constraints.** Structured error shape; owner-scoped querysets; 404 not 403 for cross-owner access;
Persian/RTL UI.

**Recommendation.** Display-name-only identity, friends-only default, opt-in global leaderboard, scopes
fixed before P8 design.

**Blocks:** G-05-5, G-08-1, G-08-2. **Priority:** phase-gating (P5 leaderboard read model).

---

## D-11 — Anti-cheat enforcement and account actions

**Question.** What happens when cheating is detected — silent flagging, reward reversal, temporary
suspension, permanent ban — and who can trigger it?

**Why it matters.** Today the only privileged role is `user`/`admin` (`accounts/models.py:60`), and
sensitive admin mutations are audited via `AdminAction` (`:90`). Adding bans or reward clawbacks means
new authority over user accounts and money-like balances. The doc asserts anti-cheat exists
(`JAMPLAY_ARCHITECTURE.md:210,237`) — it does not.

**Options.** Flag-only for P9; reversible holds; suspension via `is_active`; a new moderator role.

**Constraints.** `role` is server-side only; last active admin cannot be demoted; no new role without a
documented authorization matrix; no destructive data operations.

**Recommendation.** P9 ships flagging + audited admin review only. Automated bans are out of scope
without a separate owner decision.

**Blocks:** G-09-2, G-09-3. **Priority:** phase-gating (P9).

---

## D-12 — Scheduler ownership for timers, seasons and notifications

**Question.** What runs scheduled game jobs (tower upgrades maturing, chest timers, season rollover,
energy regeneration, expiry notifications), and where?

**Why it matters.** There is no Celery/beat, no worker process, and no CI/CD. The only scheduled command
is `notify_expiring_entitlements`, and `AGENTS.md` §4 lists scheduler ownership as an **open owner
decision**. Adding game timers without it produces features that silently never fire.

**Options.** External cron calling management commands; a dedicated worker; lazy evaluation on read
(no scheduler at all).

**Constraints.** Render Free has no shell/one-off jobs; no automatic migrations at startup; commands must
be idempotent; no new queue/scheduler dependency without approval.

**Recommendation.** Lazy evaluation for timers where semantics allow, plus external cron for
season/notification jobs once the owner names the scheduler.

**Blocks:** G-04-3, G-05-4, G-09-4. **Priority:** phase-gating (P4/P5).

---

## D-13 — Data retention, replay storage and privacy

**Question.** How long are battle records, command logs and replays retained; what is stored about
opponents; and what is deleted on account deletion?

**Why it matters.** Replay-based verification (D-04B/C) implies storing command logs; battle history in
the prototype is capped at 20 entries client-side (`jam-life.html:5944`). Retention is a privacy and cost
decision, and `AGENTS.md` §5 restricts what may be logged (no phone numbers, no tokens).

**Options.** Keep last N battles per player; keep replays 30 days; aggregate-only analytics.

**Constraints.** No PII in logs; `PROTECT`/`SET_NULL` conventions already used in the codebase; additive
migrations only.

**Recommendation.** Keep last 50 battle summaries per player indefinitely, raw command logs 30 days,
no opponent PII beyond display name.

**Blocks:** G-01-3, G-02-4, G-05-3. **Priority:** phase-gating (P1 schema).

---

## D-14 — Localization and content authority

**Question.** Is all JamPlay copy authored in Persian first, and who approves game content text
(card names, mission copy, tutorial)?

**Why it matters.** The platform is Persian/RTL with no hardcoded English user-facing copy
(`AGENTS.md` §3). The prototype carries a large body of Persian content whose tone matches JAM; the
planning documents are English-only and say nothing about content ownership. Backend errors must be
Persian with `{"detail","code"}`.

**Options.** Owner-approved content file per release; engineering-authored copy with owner review;
external writer.

**Constraints.** RTL, existing design tokens, no English copy in UI; backend user-facing messages in
Persian.

**Recommendation.** Engineering drafts, owner approves; content lives in versioned data, not in engine
code (supports G-03-3/G-04-4).

**Blocks:** G-03-3, G-04-4, G-08-3. **Priority:** non-blocking until P3 content work.

---

## D-15 — Discoverability of JamPlay in navigation and marketing copy

**Question.** Should `/play` keep its current navigation entry and home promo while the feature is a
placeholder, or should it be hidden until P2 ships?

**Why it matters.** `/play` is linked from the header (`frontend/components/header.tsx:134`), bottom nav
(`frontend/components/bottom-nav.tsx:12`), and a home promo promising rewards
(`frontend/components/features/home.tsx:349-359`), while the page itself says the section is unavailable
(`frontend/app/play/page.tsx:4-28`). The promo states a reward rule ("confirmed in-person purchase or
delivered online order + play ⇒ budgeted reward") that does not exist server-side. This is a
truthfulness/product decision, not a bug to silently fix.

**Options.** Hide links until P2; keep links with honest "coming soon" copy; keep as-is.

**Constraints.** No unapproved marketing claims (`AGENTS.md` §4 discount rule is the precedent: never
market a benefit that does not exist); no unrelated visual redesign.

**Recommendation.** Keep the route, replace promo copy with an explicit "not yet available" state, and
hide the bottom-nav entry until P2 acceptance — owner to confirm.

**Blocks:** none technically; affects trust. **Priority:** P0 (documentation/UX truthfulness), trivial
scope.

---

## Decision dependency graph

```
D-09 (prototype governance) ──► G-00-1 rules spec ──► D-05 (time) ──► D-04 (authority) ──► P2
D-01 (ledger owner) ──► D-02 (monetization) ──► D-03 (subscription benefits) ──► P6
D-07 (state boundary) ──► P1 schema ──► P2 sessions ──► D-08 (transport) ──► P7
D-10 (social privacy) ──► P5 leaderboards ──► P8
D-11 (anti-cheat) + D-12 (scheduler) + D-13 (retention) ──► P9
D-15 (marketing truthfulness) ──► P0 communications
```

## What is *not* an open decision

For the avoidance of doubt, the following are already decided and must not be reopened by an agent:

- Server-authoritative gameplay; AI before multiplayer; one shared engine for both modes.
- PostgreSQL for persistent state; Redis ephemeral only.
- No subscription-gated game benefits (unless D-03 explicitly reverses this).
- No wallet-integration assumption; ZarinPal remains the only approved online payment provider.
- City Discovery deferred outside P0–P9.
- Money in integer Toman; existing subscription prices and rules unchanged.

## Verification limitations

Static inspection only; no code was executed and no environment was contacted. Decision options and
recommendations are engineering judgement based on the repository state, not owner policy, and carry no
authority until the owner records a choice.
