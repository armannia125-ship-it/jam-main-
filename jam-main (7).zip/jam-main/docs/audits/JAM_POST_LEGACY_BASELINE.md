# JAM Post-Legacy Verification — Phase A Baseline

**Date:** 2026-11-10\
**Branch:** `main`\
**HEAD:** `fdb1add6cf56b852e07aa804a19c3bb7736fac18`\
**Working tree at start:** dirty, with the completed Batch 2.0–2.7 changes and pre-existing changes.

## 1. Protected baseline

`git diff --check` exited `0` at baseline.

### Pre-existing tracked modifications

The following files were already modified before this verification task:

- `.env.example`
- `backend/Dockerfile`
- `backend/accounts/admin_views.py`
- `backend/bot/management/commands/run_telegram_bot.py`
- `backend/bot/urls.py`
- `backend/businesses/tests.py`
- `backend/businesses/views.py`
- `backend/commerce/admin.py`
- `backend/commerce/models.py`
- `backend/commerce/serializers.py`
- `backend/commerce/services.py`
- `backend/commerce/tests.py`
- `backend/commerce/urls.py`
- `backend/commerce/views.py`
- `backend/config/health.py`
- `backend/config/settings.py`
- `backend/config/test_settings.py`
- `backend/config/tests.py`
- `backend/config/urls.py`
- `backend/payments/models.py`
- `backend/payments/tests.py`
- `backend/payments/views.py`
- `backend/requirements.lock.txt`
- `backend/requirements.txt`
- `backend/subscriptions/admin.py`
- `backend/subscriptions/entitlements.py`
- `backend/subscriptions/models.py`
- `backend/subscriptions/purchase_views.py`
- `backend/subscriptions/serializers.py`
- `backend/subscriptions/services.py`
- `backend/subscriptions/tests.py`
- `backend/subscriptions/urls.py`
- `backend/subscriptions/views.py`
- `backend/test_settings.py`
- `docs/LEGACY_COMPATIBILITY.md`
- `docs/MANUAL_SUBSCRIPTION_WORKFLOW.md`
- `docs/PRODUCTION_OPERATIONS_RUNBOOK.md`
- `docs/SUBSCRIPTION_ARCHITECTURE.md`
- `frontend/app/admin/page.tsx`
- `frontend/app/admin/subscriptions/page.tsx`
- `frontend/app/panel/plan/page.tsx`
- `frontend/app/revenue/page.tsx`
- `frontend/app/subscriptions/checkout/page.tsx`
- `frontend/lib/commerce.tsx`
- `frontend/lib/subscriptions-api.ts`

### Pre-existing deletions

- `backend/subscriptions/test_concurrency.py`
- `backend/subscriptions/test_legacy_compatibility.py`
- `frontend/lib/subscriptions.ts`

### Pre-existing untracked files

- `AGENTS.md`
- `backend/commerce/migrations/0004_remove_clubmembershipevent_business_and_more.py`
- `backend/commerce/migrations/0005_alter_invoice_kind.py`
- `backend/payments/migrations/0004_remove_transaction_transaction_has_one_target_and_more.py`
- `backend/subscriptions/migrations/0007_remove_activationcodeevent_code_and_more.py`
- `docs/JAM_BATCH_1_1_STAGING_CORRECTIONS_REPORT.md`
- `docs/JAM_BATCH_1_2_STAGING_TECHNICAL_CORRECTIONS_REPORT.md`
- `docs/JAM_BATCH_1_3_AGENT_GOVERNANCE_AUDIT.md`
- `docs/JAM_BATCH_1_4_PUBLIC_MENU_ENTITLEMENT_AUDIT.md`
- `docs/JAM_BATCH_1_4_PUBLIC_MENU_ENTITLEMENT_DECISION_BRIEF.md`
- `docs/JAM_FREE_STAGING_DEPLOYMENT_ASSESSMENT.md`
- `docs/audits/`
- `docs/deployment/`

These files are protected and must not be reset, stashed, cleaned, or overwritten.

## 2. Database configuration observed

`backend/config/settings.py` uses PostgreSQL by default:

- Engine: `django.db.backends.postgresql`
- Default database: `jam`
- Default user: `jam`
- Default host: `localhost`
- Default port: `5432`
- `CONN_MAX_AGE=60`

`backend/config/test_settings.py` overrides the database to in-memory SQLite and uses locmem cache. The repository also contains a separate legacy `backend/test_settings.py` SQLite configuration.

Docker Compose is the project-supported local PostgreSQL setup:

- `docker-compose.yml` and `docker-compose.dev.yml` use `postgres:16-alpine`.
- Database defaults: `jam` / `jam` / `jam-local-password`.
- Redis service: `redis:7-alpine`.

Local environment observations:

- PostgreSQL 18.4 is installed through Postgres.app and is listening on `127.0.0.1:5432`.
- The project’s `jam` credentials do not authenticate against that local server.
- Docker is installed but no containers were running.
- Redis is not listening on `6379`.

## 3. Verification constraints

- Use an isolated local PostgreSQL database only.
- Do not touch external, staging, or production databases.
- No real ZarinPal calls, payments, Telegram polling, or OTP.
- Preserve all pre-existing changes.
- Historical migrations must remain unchanged.
- No commit, push, tag, release, or deployment.

## 4. Planned verification path

1. Start the compose PostgreSQL/Redis services with an isolated host port override, without editing repository compose files.
2. Add an explicit PostgreSQL test-settings path while retaining SQLite as the default fast test path.
3. Run existing PostgreSQL concurrency tests.
4. Add deterministic concurrency coverage for purchase activation, callback replay, entitlements, and product limits where missing.
5. Verify fresh migrations and legacy-cleanup migration scenarios on disposable databases.
6. Start backend and frontend locally and smoke-test the canonical flows with mocked payment boundaries.
7. Record all results under `/docs/audits/`.
