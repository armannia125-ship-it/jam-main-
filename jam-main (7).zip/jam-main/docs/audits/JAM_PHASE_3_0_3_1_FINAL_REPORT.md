# JAM — Phase 3.0 + 3.1 Final Report

**Date:** 2026-11-10\
**Scope:** Comprehensive pre-staging audit and infrastructure/deployment plan\
**Mode:** Read-only audit and evidence-based planning\
**Implementation authorization:** **NOT GRANTED**\
**Deployment authorization:** **NOT GRANTED**\
**External provisioning authorization:** **NOT GRANTED**

---

## 1. Final status

# `PHASE 3.0 + 3.1 COMPLETE — READY FOR OWNER DECISIONS`

This status means the audit and planning work is complete and internally consistent. It does **not** mean JAM is ready to deploy. Deployment remains blocked on six explicit items and fifteen owner decisions, all recorded below.

The alternative status `PARTIALLY COMPLETE — BLOCKERS REMAIN` was considered and rejected: every required deliverable was produced, every claim was checked against current source, and no audit area was left unfinished. The remaining blockers are deployment prerequisites and unanswered owner decisions, not gaps in the analysis.

---

## 2. What was commissioned

A read-only Phase 3.0 pre-staging audit and Phase 3.1 infrastructure/deployment plan for JAM, with six evidence-based documents under `docs/`, no code or configuration changes, no provisioning, no deployment, no migration, and no service start or stop.

The audit was required to:

- verify the current source rather than repeat historical claims;
- identify security and runtime gaps;
- compare viable free/paid infrastructure options;
- recommend a staging architecture;
- produce an executable, gated deployment plan;
- preserve the existing dirty working tree exactly.

All of that was done.

---

## 3. Baseline

| Item | Value |
|---|---|
| Branch | `main` |
| HEAD | `fdb1add6cf56b852e07aa804a19c3bb7736fac18` |
| Working tree | Dirty before and after this work; intentionally preserved |
| Tracked files changed | 50 (pre-existing Batch 2.0–2.7 work) |
| Untracked | Migrations, `AGENTS.md`, prior reports, `docs/audits/`, `docs/deployment/` |
| Containers | Stopped; none started for this phase |
| External services | None provisioned or contacted |
| Files added by this phase | Six Markdown documents under `docs/` |

The dirty tree is not incidental. It is a deployment blocker in its own right: Render deploys a Git commit, not local files. See §7, B-01.

---

## 4. Deliverables

| # | Document | Purpose | Status |
|---|---|---|---|
| 1 | `docs/audits/JAM_PHASE_3_0_PRE_STAGING_AUDIT.md` | Source-cited pre-staging audit and findings register | Complete |
| 2 | `docs/audits/JAM_PHASE_3_0_SECURITY_AND_RUNTIME_GAP_ANALYSIS.md` | Threat model, 15 security/runtime gaps, acceptance conditions | Complete |
| 3 | `docs/deployment/JAM_PHASE_3_1_INFRASTRUCTURE_DECISION_MATRIX.md` | Provider options, limits, costs, 15-item owner decision register | Complete |
| 4 | `docs/deployment/JAM_PHASE_3_1_RECOMMENDED_STAGING_ARCHITECTURE.md` | Target topology, environment contract, failure modes | Complete |
| 5 | `docs/deployment/JAM_PHASE_3_1_DEPLOYMENT_EXECUTION_PLAN.md` | Gated 10-phase procedure with rollback and stop conditions | Complete |
| 6 | `docs/audits/JAM_PHASE_3_0_3_1_FINAL_REPORT.md` | This consolidated report | Complete |

No other file was created, edited, or deleted.

---

## 5. Method and evidence standard

- The repository was treated as the technical source of truth.
- Historical reports were read as evidence and checked against current source; stale claims were not repeated as facts.
- Configuration, Dockerfiles, Compose, Caddy, auth, admin, payments, commerce, subscriptions, health, storage, and management commands were inspected.
- Official provider documentation was read on 2026-11-10 for Render, Neon, Upstash, Cloudflare R2, and AWS S3.
- Existing verification evidence (PostgreSQL 16.14: 189 tests OK; migration scenarios; runtime smoke) was used only where it directly supports a claim.
- Every finding carries a status label: `CONFIRMED`, `RECOMMENDED`, `INFERRED`, `OWNER DECISION REQUIRED`, `BLOCKED`, or `NOT TESTED`.

No penetration test, vulnerability scan, load test, or external connectivity test was performed.

---

## 6. Executive findings

### 6.1 The application is sound; the deployment target is not a drop-in replacement

The prior PostgreSQL verification is strong: 189 tests passed with no skips, migration scenarios passed on fresh/clean/legacy databases, and the backend/frontend runtime smoke passed. The application is not the problem.

The Compose production stack relies on four things Render Free does not provide together:

1. Caddy serving `/media/*` from a persistent volume;
2. local PostgreSQL and Redis;
3. a persistent disk for uploads;
4. shell/one-off execution for migrations and admin promotion.

Replacing Compose with Render Free without addressing these produces a service that builds and starts but breaks on uploads, migrations, and media delivery.

### 6.2 Four findings dominate

| # | Finding | Severity | Status |
|---|---|---|---|
| 1 | Uploaded media is unreachable in filesystem mode on Render | Critical | `CONFIRMED` |
| 2 | Backend binds `8000`, not Render's `$PORT` | High | `CONFIRMED` |
| 3 | Render Free has no migration/admin execution path | High | `BLOCKED` |
| 4 | Readiness health check burns free Redis quota and amplifies outages | High | `INFERRED` |

### 6.3 Media is the clearest hard failure

Django serves `/media/` only when `DEBUG=True`. In production, the Compose stack compensates with Caddy and a shared volume. Render Free has neither. The backend writes uploads to an ephemeral `/app/media`, and the frontend's `/api/media-proxy/*` forwards to a backend path that has no route. Every uploaded logo or product image 404s.

**Object storage is therefore mandatory** for any Render staging deployment that includes uploads. This is not a performance optimization; it is a correctness requirement.

### 6.4 The port defect is easy to miss and easy to fix

The backend Dockerfile runs Gunicorn on `0.0.0.0:8000`. Render forwards traffic to `$PORT`, default `10000`, and documents binding to `0.0.0.0:$PORT` as the contract. Render can sometimes detect a non-default bound port, but relying on detection is not a deployment plan.

Two fixes: set Render `PORT=8000` (no code change), or change the bind to `0.0.0.0:${PORT:-8000}` (durable code change). Neither has been applied.

### 6.5 Migrations are the governance blocker

Render Free has no shell, SSH, or one-off jobs. A one-off job requires a paid base service. The repository correctly does **not** migrate at container start. That leaves three paths:

1. promote the backend to Starter and use a one-off job;
2. run migrations from an operator workstation against Neon's **direct** endpoint;
3. add CI/CD.

All three require owner approval. Automatic startup migrations were rejected: they race, fail partially, and hide schema changes.

### 6.6 The health-check choice is a cost decision

`/api/health/ready/` performs a Redis `SET` and `GET` on every probe. At a 5-second interval, that is over one million commands per month against a 500K free allowance. At 10 seconds, it is still over. A cache outage also turns readiness into a restart loop.

**Use `/api/health/live/` for Render.** Use `/ready/` once after deploy. This is a configuration choice, not a code change, but it materially affects whether the free Redis tier survives.

### 6.7 Security posture is acceptable only for a controlled pilot

The main accepted risks are:

- JWTs in `localStorage`, readable by any XSS;
- no server-side logout or refresh-token revocation;
- admin UI served before authentication (APIs are correctly protected);
- Django admin publicly reachable;
- HSTS off by default;
- no error tracking or uptime alerting.

None of these is a reason to rewrite the app. They are reasons not to invite external testers until the must-conditions in the security document are met.

### 6.8 There is a deployment blocker outside the code

Render builds from Git. The audited working tree is dirty: 50 modified tracked files, untracked migrations, and untracked docs. Deploying the repository without committing the intended snapshot would deploy code that does not contain the audited changes or migrations.

**No commit or push was performed or authorized.** This must be resolved before any deployment.

---

## 7. Deployment blockers

| ID | Blocker | Why it blocks | Resolution | Owner decision |
|---|---|---|---|---|
| B-01 | Audited code is uncommitted | Render deploys a Git commit; the dirty tree is invisible to it | Authorize a commit/push of the staging snapshot, or identify an existing commit | Required |
| B-02 | Media unreachable on Render | Uploads 404; no persistent disk; no `/media/` route | Enable R2/S3 | OD-04 |
| B-03 | No Free migration/admin path | Schema cannot be applied; admin cannot be created | Operator-run migration or Starter backend | OD-06 |
| B-04 | Backend port mismatch | Render may not route traffic to `8000` | `PORT=8000` or Dockerfile bind fix | Technical/OD-01 |
| B-05 | Provider access absent | Nothing can be provisioned | Owner authorization and credentials | Required |
| B-06 | Payment mode unresolved | `ZARINPAL_SANDBOX` defaults to `DEBUG`; staging could hit production URLs | Set sandbox explicitly or defer payment testing | OD-09 |

---

## 8. Findings summary

### 8.1 Audit register

The pre-staging audit records **24 findings**:

| Severity | Count | Examples |
|---|---|---|
| Critical | 1 | Production media unreachable |
| High | 7 | Port binding, migration path, Redis/readiness, JWT storage, host/CSRF, payment callback, Telegram topology |
| Medium | 11 | Instance hours, revocation, admin UI, proxy trust, signed-URL offline behavior, upload limits, CI/CD, scheduler, observability, database choice, backups |
| Low | 5 | HSTS, pooling, duplicate proxy, forwarded headers, image pinning |

### 8.2 Security register

The security document records **15 entries**. They overlap the audit register and are not additive. The highest-impact items are token storage/revocation, host/CSRF/proxy configuration, media access model, payment sandbox default, and Telegram/worker topology.

### 8.3 Positive confirmations

Not everything is a gap. The following were confirmed and should not be “fixed”:

- Server-side ZarinPal verification with atomic, idempotent activation.
- Server-side `IsAdmin` enforcement on every admin API.
- Fail-closed S3 configuration.
- PostgreSQL-only settings and verified migration integrity.
- Non-root backend and frontend containers.
- Static file collection at build and WhiteNoise serving.
- Same-origin API proxy design that avoids browser CORS.
- Simulated payments and order-bound online payments disabled by default.
- No migration at container start.

---

## 9. Owner decision register (summary)

Full options and costs are in the decision matrix.

| ID | Decision | Recommendation | Blocks deploy |
|---|---|---|---|
| OD-01 | Compute plan | Free frontend + Starter backend ($7) | Yes |
| OD-02 | Database | Neon Free | Yes |
| OD-03 | Cache | Upstash Free + `/live/` probe | Yes |
| OD-04 | Media storage | Private Cloudflare R2 | Yes, if uploads in scope |
| OD-05 | Media visibility | Private signed URLs | Yes |
| OD-06 | Migration path | Operator workstation first; Starter if repeatable | Yes |
| OD-07 | Health check | `/api/health/live/` | Yes |
| OD-08 | Auth storage | Accept for internal pilot; fix before external testers | Conditional |
| OD-09 | Payment mode | Sandbox only | Yes, for payment tests |
| OD-10 | Domain | `onrender.com` first; custom domain before external testers | No |
| OD-11 | Offline uploaded images | Accept online-only for staging | No |
| OD-12 | Observability | Error tracking + uptime before external testers | Conditional |
| OD-13 | Instance warmth | Idle-free pilot; pay only if testing requires | No |
| OD-14 | Telegram | Disabled | Yes |
| OD-15 | Django admin | Keep with unique strong password | No |

---

## 10. Recommended architecture (summary)

```text
Browser
  │ HTTPS
  ▼
Render Free/Starter: Next.js frontend
  ├─ /api/*  ──server-side HTTPS──▶ Render backend (Django/Gunicorn)
  ├─ /admin/* ─────────────────────▶ same backend
  └─ /health (frontend liveness)

Render backend
  ├─ Neon PostgreSQL (pooled runtime; direct for migrations)
  ├─ Upstash Redis (rediss://)
  └─ Cloudflare R2 (private; signed URLs)

ZarinPal ──browser redirect──▶ backend /api/payments/zarinpal/callback/
```

Key choices:

- Two web services, not one combined container.
- Browser traffic same-origin through the frontend proxy; `NEXT_PUBLIC_API_BASE` empty.
- Backend public URL for `API_INTERNAL_URL` because Render Free cannot receive private traffic.
- Neon pooled connection for runtime, direct for migrations.
- R2 private bucket; `AWS_DEFAULT_ACL` empty; region `auto`.
- Render health check `/api/health/live/`; readiness used only for smoke tests.
- No Telegram worker; no scheduler; no automatic migrations.

Full environment contract: `JAM_PHASE_3_1_RECOMMENDED_STAGING_ARCHITECTURE.md §5`.

---

## 11. Cost scenarios

Monthly list prices, USD, excluding tax and domain registration. Read 2026-11-10; not verified at checkout.

| Scenario | Composition | Monthly | Verdict |
|---|---|---|---|
| A — Zero-cost pilot | Render Free ×2 + Neon Free + Upstash Free + R2 free tier | **$0** | Viable only for a short internal smoke test; cold starts, no in-platform migrations |
| B — Operable minimum | Render Free frontend + Starter backend + Neon Free + Upstash Free + R2 | **$7** | **Recommended** for the staging pilot |
| C — Always-on | Render Starter ×2 + Neon Free + Upstash PAYG (~1M commands) + R2 | **~$16** | Use if cold starts or instance hours interfere |
| D — Always-on + DB headroom | Render Starter ×2 + Neon Launch (~$20) + Upstash PAYG (~$2) + R2 | **~$36** | If free DB compute is exhausted |
| E — No uploads | Render Free ×2 + Neon Free + Upstash Free, filesystem media | **$0** | **Not viable** if uploads are in scope; media 404s |

The free-tier arithmetic is unforgiving: two free services kept warm 24/7 need 1,440 instance hours against a 750-hour allowance, and a 5-second readiness probe needs over one million Redis commands against a 500K allowance.

---

## 12. Execution plan summary

The deployment plan has ten gated phases:

| Phase | Outcome | Gate |
|---|---|---|
| P0 | Freeze and identify the deploy commit | G0 |
| P1 | Provision Neon (pooled + direct) | G1 |
| P2 | Provision Upstash (TLS) | G2 |
| P3 | Provision private R2 bucket | G3 |
| P4 | Deploy backend with health `/live/` | G4 |
| P5 | Snapshot, migrate via direct endpoint, create admin | G5 |
| P6 | Deploy frontend with `API_INTERNAL_URL` | G6 |
| P7 | Smoke test, upload persistence, authorized payment/OTP | G7 |
| P8 | Custom domain, TLS, HSTS | G8 |
| P9 | Authorized provider tests | G9 |
| P10 | Evidence, access handover, rollback point | G10 |

The plan includes explicit stop conditions and a rollback procedure. It does not authorize any phase.

---

## 13. Residual risks if the recommended path is approved

Even after the must-conditions are met:

- a stolen refresh token remains valid for up to 7 days;
- XSS can read `localStorage` tokens;
- Django admin is publicly reachable;
- free Redis quota can be exhausted by traffic or probes;
- signed media URLs expire and uploaded images are not available offline;
- migrations run manually have no platform audit trail;
- there is no error tracking, uptime alerting, or intrusion detection;
- staging data has only Neon's free restore window;
- Free services cold-start in roughly a minute.

These are acceptable only for a controlled staging pilot with non-production data and a small, trusted user set. They are not a production posture.

---

## 14. What was not tested

`NOT TESTED` — not passes:

- No Render build or deploy.
- No Neon/Upstash/R2/S3 provisioning or connectivity.
- No container image build during this phase.
- No external migration.
- No DNS, TLS, or custom domain.
- No real Zarinpal request, payment, or refund.
- No real OTP delivery.
- No Telegram polling or message.
- No browser automation of `localStorage` login/logout.
- No load, stress, or soak test.
- No dependency vulnerability scan or image scan.
- No backup restore drill.

---

## 15. Governance and verification statement

- No application code, configuration, Dockerfile, Compose file, Caddyfile, dependency, migration, or environment file was modified.
- No service was started or stopped.
- No database was migrated or queried externally.
- No provider was provisioned.
- No commit, push, tag, release, or deployment occurred.
- The pre-existing dirty working tree was preserved exactly.
- The only additions are the six Markdown documents listed in §4, all under `docs/`.
- No secret values are recorded in any deliverable.

Verification performed for this report:

- Confirmed HEAD is `fdb1add6cf56b852e07aa804a19c3bb7736fac18`.
- Confirmed the pre-existing modified/untracked set is unchanged.
- Confirmed all six deliverables exist.
- Cross-checked every cited source line against the current files.
- Re-read provider limits and prices from official documentation on 2026-11-10.

---

## 16. Conclusion

JAM's application logic and transactional behavior are in good shape. The staging plan is not a deployment instruction; it is a decision package.

The shortest safe path is:

1. answer OD-01 through OD-15;
2. authorize a commit/push of the intended staging snapshot;
3. enable R2, Neon, and Upstash;
4. correct the backend port contract;
5. deploy the backend, migrate via the direct Neon endpoint, create the admin;
6. deploy the frontend with the backend public URL;
7. use `/api/health/live/` for Render;
8. run the gated smoke tests;
9. keep payments in sandbox and Telegram disabled until separately authorized.

Until those steps are authorized and completed, the correct statement is: **audited, planned, and not deployed.**

---

# `PHASE 3.0 + 3.1 COMPLETE — READY FOR OWNER DECISIONS`
