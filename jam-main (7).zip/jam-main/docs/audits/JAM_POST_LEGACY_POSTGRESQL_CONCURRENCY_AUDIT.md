# JAM Post-Legacy PostgreSQL Concurrency Audit

**Date:** 2026-11-10\
**Status:** CONFIRMED / FIXED\
**Database:** PostgreSQL 16.14 (local Docker Compose `postgres:16-alpine`)\
**Database identity:** `127.0.0.1:55432`, isolated local compose instance; test database `test_jam_postlegacy`\
**Credentials:** supplied through local environment variables; not recorded here.

## 1. Setup

- Existing supported setup: Docker Compose PostgreSQL 16 + Redis 7.
- Compose was started with a temporary host-port override (`55432`/`56379`) so the unrelated local PostgreSQL 18.4 instance on `5432` was untouched.
- No repository compose file was edited.
- `backend/config/test_settings.py` now supports `TEST_DB_ENGINE=postgresql` with:
  - local-host-only guard,
  - `POSTGRES_TEST_DB_NAME` that must start with `test_`,
  - Django `TEST.NAME` isolation.
- Default SQLite test behavior remains unchanged.

## 2. Existing PostgreSQL tests

Command (app labels explicitly supplied because Django's bare test discovery finds zero tests in this project):

```bash
TEST_DB_ENGINE=postgresql \
POSTGRES_HOST=127.0.0.1 POSTGRES_PORT=55432 \
POSTGRES_DB=jam POSTGRES_USER=jam \
POSTGRES_TEST_DB_NAME=test_jam_postlegacy \
python backend/manage.py test \
  subscriptions.test_payment_concurrency commerce.test_concurrency \
  --settings=config.test_settings --noinput --verbosity=2
```

Result before fixes: **FAILED (errors=10)**. Every commerce concurrency test failed in `setUp` because `TransactionTestCase` flushes migration-seeded catalog rows and the helper called `SubscriptionProduct.objects.get(slug="seller_club")`.

**FIXED:** `backend/commerce/tests.py::activate_club` now uses `get_or_create` for the agreement and product, making the tests independent of seed survival.

Result after fix: **12 tests, OK**. These are no longer skipped on PostgreSQL.

## 3. Concurrency findings and fixes

### 3.1 Duplicate pending purchase creation — FIXED

**Path:** `subscriptions/purchase_views.py::SubscriptionPurchaseView.post`

**Race:** Two concurrent purchase requests both read “no pending purchase” and both insert. The existing idempotency check had no lock.

**Fix:** The pending lookup and creation now run inside `transaction.atomic()` after `Business.objects.select_for_update()`.

**Test:** `test_concurrent_purchase_requests_create_one_pending_purchase` — 8 parallel authenticated requests produce exactly one pending purchase and one transaction.

### 3.2 Overlapping renewal windows — FIXED

**Path:** `subscriptions/entitlements.py::activate_entitlements_for_purchase`

**Race:** Two paid purchases for the same business/type concurrently computed the same `Max(ends_at)` base and created overlapping windows.

**Fix:** Activation locks the owning `Business` row before computing the renewal base, serializing renewals per business. The row lock covers only the activation transaction; no broad table lock is used.

**Test:** `test_concurrent_renewals_do_not_overlap` — two concurrent paid purchases create two entitlements and the later window starts at or after the earlier one ends.

### 3.3 Product-limit overshoot — FIXED

**Path:** `businesses/views.py::ProductViewSet.perform_create`

**Race:** Count-then-insert had no lock. Concurrent requests near a plan limit could all observe a count below the limit and insert.

**Fix:** The count-and-insert runs inside `transaction.atomic()` after locking the owning `Business` row.

**Test:** `test_concurrent_creation_cannot_exceed_product_limit` — limit 2, one existing product, 8 parallel creates → exactly one 201, seven 403, two total products.

### 3.4 Concurrent entitlement creation raised IntegrityError — FIXED

**Path:** `subscriptions/entitlements.py`

**Race:** Concurrent direct activation calls both passed the existence check; the unique `(purchase, entitlement_type)` constraint rejected the loser. This protected duplicates but surfaced an error instead of idempotent success.

**Fix:** Each entitlement insert uses a savepoint and catches `IntegrityError`; the loser continues. The outer activation remains atomic, so non-uniqueness failures still roll back.

**Test:** existing `test_concurrent_entitlement_creation_respects_unique_constraint` now asserts exactly one MENU and one CLUB entitlement and all callers succeed.

### 3.5 Lock-order deadlock risk — FIXED

**Paths:** `payments/views.py::ZarinPalCallbackView.get`, `subscriptions/purchase_views.py`

**Risk:** Purchase initiation locked business then transaction; callback previously locked transaction then might wait for the business lock during activation. A mixed order could deadlock.

**Fix:** Callback now locks in the same order: business → transaction → purchase. The payment is pre-read without a lock solely to discover the business, then re-read under `SELECT FOR UPDATE` after the business lock.

## 4. Confirmed invariants

| Invariant | Status | Evidence |
|---|---|---|
| Duplicate successful callbacks create exactly two Gold entitlements | CONFIRMED | Existing concurrent callback test, PostgreSQL |
| Duplicate callback does not reset entitlement expiry | CONFIRMED | Existing idempotency test |
| Gold creates one MENU + one CLUB entitlement | CONFIRMED | Strengthened concurrent activation test |
| Failed Gold activation leaves no partial entitlement | CONFIRMED | Forced second-insert failure test |
| Verification failure leaves purchase pending and no entitlement | CONFIRMED | `PaymentCallbackRollbackTests` |
| Revoking MENU does not revoke CLUB | CONFIRMED | Independent revocation test |
| Expired/revoked MENU does not grant access | CONFIRMED | Existing entitlement and public-menu tests |
| Product creation under active MENU at limit | CONFIRMED | PostgreSQL concurrency test |

## 5. Tests added

`backend/subscriptions/test_postgres_concurrency.py`:

- `PurchaseInitiationConcurrencyTests.test_concurrent_purchase_requests_create_one_pending_purchase`
- `EntitlementActivationConcurrencyTests.test_concurrent_renewals_do_not_overlap`
- `EntitlementActivationConcurrencyTests.test_failed_gold_activation_rolls_back_both_entitlements`
- `PaymentCallbackRollbackTests.test_verification_failure_leaves_no_entitlement_and_no_paid_purchase`
- `ProductLimitConcurrencyTests.test_concurrent_creation_cannot_exceed_product_limit`
- `ProductLimitConcurrencyTests.test_revocation_does_not_remove_the_other_entitlement_type`

## 6. Full regression

PostgreSQL command:

```bash
TEST_DB_ENGINE=postgresql \
POSTGRES_HOST=127.0.0.1 POSTGRES_PORT=55432 \
POSTGRES_DB=jam POSTGRES_USER=jam \
POSTGRES_TEST_DB_NAME=test_jam_postlegacy \
python backend/manage.py test \
  accounts bot businesses cart commerce payments subscriptions \
  --settings=config.test_settings --noinput
```

Result: **Ran 189 tests — OK, 0 skipped.**

SQLite regression result: **Ran 189 tests — OK, 18 skipped** (12 existing PostgreSQL-only plus 6 new PostgreSQL-only tests). No PostgreSQL test was reported as passed on SQLite.

## 7. Limitations

- Concurrent access-vs-revoke semantics are last-commit-wins at the database snapshot level; no deterministic test asserts a particular interleaving beyond the revocation-independence test.
- No load or stress testing was performed; these are deterministic barrier-based concurrency tests.
- No real ZarinPal verification or Telegram operation was performed.
