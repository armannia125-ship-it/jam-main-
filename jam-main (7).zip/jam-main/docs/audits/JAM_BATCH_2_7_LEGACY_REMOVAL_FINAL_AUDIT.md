# JAM Batch 2.7 — Legacy Removal Final Audit

**Status:** COMPLETE  
**Date:** 2026-11-10  
**Scope:** Full legacy subscription and ClubMembership removal

## 1. Removed architecture

Removed models:

- `subscriptions.SubscriptionPlan`
- `subscriptions.Subscription`
- `subscriptions.ActivationCode`
- `subscriptions.ActivationCodeEvent`
- `commerce.ClubMembership`
- `commerce.ClubMembershipEvent`

Removed runtime flows:

- Manual subscription requests, payment instructions, checkout, and code redemption.
- Activation-code issuance from admin and bot.
- Free trials, membership deactivation, and simulated subscription payment.
- Legacy access fallbacks in `menu_access`, `club_access`, and `product_limit`.
- Legacy public menu, QR, and store-directory subscription filters.
- Legacy invoice kinds `subscription` and `membership`; invoice default is now `setup`.
- Legacy transaction `subscription` target and `transaction_has_one_target`.
- Legacy bot subscription checks.
- Legacy frontend manual-payment and activation-code UI.
- Legacy admin payment/subscription counts and actions.

## 2. Canonical architecture

- `SubscriptionProduct` is the only catalog.
- `SubscriptionPurchase` snapshots price and status.
- `SubscriptionEntitlement` is the only access authority.
- ZarinPal is the only payment route.
- MENU and CLUB access are independent.
- Gold creates both entitlements atomically.
- Product limit comes from the current MENU entitlement product.
- Public menu, QR, directory, product editing, bot editing, and admin views use entitlement-only checks.

## 3. Forward-only migrations

- `backend/commerce/migrations/0004_remove_clubmembershipevent_business_and_more.py`
- `backend/commerce/migrations/0005_alter_invoice_kind.py`
- `backend/payments/migrations/0004_remove_transaction_transaction_has_one_target_and_more.py`
- `backend/subscriptions/migrations/0007_remove_activationcodeevent_code_and_more.py`

Historical migrations were not rewritten. The new migrations delete obsolete tables, remove legacy invoice kinds, and remove the legacy transaction target. A guarded cleanup removes any pre-existing transaction with no purchase before making `Transaction.purchase` mandatory.

## 4. Verification

- Backend suite: **182 tests, OK, 12 skipped**.
- Skipped tests: PostgreSQL-only concurrency tests (`commerce/test_concurrency.py`, `subscriptions/test_payment_concurrency.py`).
- `makemigrations --check --dry-run`: **No changes detected**.
- Frontend TypeScript: **no errors**.
- Frontend ESLint: **0 errors, 10 pre-existing warnings**.
- Frontend production build: **succeeded**, 33 static pages generated.
- `git diff --check`: **exit 0**.

## 5. Residual references

Runtime code no longer imports or queries the removed models. Historical migration files still name the removed tables by design. Audit and historical documentation may mention the removed architecture as history; current canonical docs describe the entitlement-only contract.

## 6. Unchanged constraints

- No real ZarinPal API call or payment.
- No OTP or Telegram polling.
- No external service provisioning.
- No deployment, commit, push, or migration against an external database.
- Pre-existing unrelated working-tree changes were preserved.
