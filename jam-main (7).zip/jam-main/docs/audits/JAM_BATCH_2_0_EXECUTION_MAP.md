# JAM Batch 2.0 — Execution Map

**Status:** COMPLETE  
**Date:** 2026-11-10

## Dependency order

1. Batch 2.1: remove legacy models and fallbacks; add forward-only cleanup migrations.
2. Batch 2.2: update public menu, QR, and directory to entitlement-only policy.
3. Batch 2.3: remove manual payment flows and legacy transaction target.
4. Batch 2.4: update Telegram bot to entitlement-only policy.
5. Batch 2.5: replace frontend legacy subscription UI with purchase/entitlement experience.
6. Batch 2.6: replace admin legacy views with purchase/entitlement management.
7. Batch 2.7: update docs, run full regression, verify migration state, produce closure.

## Cross-cutting constraints

- Preserve pre-existing uncommitted changes.
- No historical migration rewrites.
- No real payments, OTP, Telegram polling, or external provisioning.
- Keep all new audit/closure documents under `/docs/audits`.
- Run targeted tests after each batch and full regression at closure.
