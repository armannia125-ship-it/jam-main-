# JAM — Phase 3.1 Zero-Cost Revision Report

**Document ID:** `JAM-PHASE-3.1-ZERO-COST-REVISION-REPORT-2026-11-11`
**Date:** 2026-11-11
**Scope:** Documentation-only revision of the Phase 3.1 infrastructure decision set under binding owner zero-cost decisions.
**Status (final, exactly one):** **ZERO-COST REVISION COMPLETE — CLOUD STAGING PLAN READY FOR OWNER EXECUTION**

---

## A. Executive summary

The Phase 3.1 infrastructure decision set has been revised to comply with the binding owner zero-cost decisions ($0 budget, no payment method/billing activation to bypass a Free Tier, R2 only if usable without charges, migrations from the owner's local dev environment, no provisioning/commit/push/deployment). The previous "paid-minimum $7/month" recommendation is withdrawn. The recommended staging topology is now **Render Free (Hobby workspace) for both frontend and backend, Neon Free for PostgreSQL, Upstash Free for Redis, and media operationally disabled (Scenario B)**, because Cloudflare R2 cannot be enabled without a payment method on file and has uncapped overage, which violates the $0 rule. The frontend cannot be a Render Static Site (it is incompatible with this Next.js App Router app) and therefore runs as a Render Free Web Service, which is genuinely $0 but consumes shared instance hours and 5 GB/month bandwidth. Database migrations and admin promotion are documented as owner-run local procedures against Neon's direct endpoint. No code, env, Dockerfile, Compose, Caddy, migration, or dependency file was changed, and no external service was provisioned.

## B. Binding owner decisions applied

1. Cloud staging on Free Tiers only; $0 budget; no paid upgrades.
2. No payment method or billing activation solely to bypass a Free Tier restriction.
3. Cloudflare R2 for media only if usable without charges.
4. Database migrations run from the owner's local dev environment.
5. No provisioning, no git commit/push, no deployment in this revision.
6. Frontend must be a genuinely zero-cost hosting option; if a free option breaks required product functionality it is not acceptable.

## C. What changed (documents)

Created:
- `docs/deployment/JAM_ZERO_COST_STAGING_PROVIDER_VERIFICATION.md` — verified free-tier facts, zero-cost safety conclusions, scenario comparison, frontend static-site incompatibility proof, port options, Redis budget arithmetic, media posture.
- `docs/deployment/JAM_ZERO_COST_LOCAL_MIGRATION_RUNBOOK.md` — owner-run migration procedure with identity verification, backup, execution, verification, recovery, cleanup.
- `docs/audits/JAM_PHASE_3_1_ZERO_COST_REVISION_REPORT.md` — this report.

Updated (rewritten):
- `docs/deployment/JAM_PHASE_3_1_INFRASTRUCTURE_DECISION_MATRIX.md` — withdrawn paid-minimum; zero-cost decision register OD-01..OD-15 revised; scenario comparison; carried-over A-01..A-24 dispositions; new blockers B-07..B-12; git snapshot procedure; cost table.
- `docs/deployment/JAM_PHASE_3_1_RECOMMENDED_STAGING_ARCHITECTURE.md` — Mermaid topology; component contracts; env contract; failure modes; rejected alternatives; rollback.
- `docs/deployment/JAM_PHASE_3_1_DEPLOYMENT_EXECUTION_PLAN.md` — stages 3.2.0–3.2.6, 3.3, 3.4 with gates G0–G8; rollback; authorisation boundaries.

No other file was touched.

## D. Verified free-tier facts (summary)

| Provider | Key free allowance | Card required? | Overage without card | Zero-cost safe? |
|---|---|---|---|---|
| Render (Hobby + Free compute) | 750 instance h/workspace/mo; 5 GB outbound bandwidth; 500 build min; 0.1 CPU/512 MB; spins down after 15 min | No | Suspension (no billing) | Yes, with monitoring |
| Neon (Free) | 100 CU-h/project/mo; 1 GB storage; 5 GB transfer; scale-to-zero 5 min; no card; permanent | No | Compute suspended / writes blocked | Yes |
| Upstash (Free) | 500k commands/mo; 256 MB; 10 GB bandwidth; 1 DB; TLS | No | Command errors | Yes, with conservative 300k target |
| Cloudflare R2 | 10 GB-mo storage; 1M Class A; 10M Class B; egress free | **Yes** | n/a (card required to enable) | **No** under $0 rule |
| Vercel (Hobby) | 100 GB transfer; non-commercial use only | No | Account suspension/termination | **No** (commercial use prohibited) |
| Cloudflare Workers/Pages (Free) | 100k req/day; 10 ms CPU | No | Throttling | Conditional (code changes required) |

Sources and check date: `JAM_ZERO_COST_STAGING_PROVIDER_VERIFICATION.md` §2, checked 2026-11-11 via official-doc web search. `read_url` to render.com / developers.cloudflare.com is blocked by network policy, so facts are attributed to official-doc search snippets and must be re-verified on the live console before any action.

## E. Frontend hosting decision

**Decision: Render Free Web Service (Docker/Node), not a Render Static Site.**

A Render Static Site cannot host this frontend. Verified from source (`frontend/next.config.mjs`, `frontend/app/api/[...path]/route.ts`, `frontend/app/health/route.ts`, `frontend/app/page.tsx`, and four dynamic routes without `generateStaticParams`):
1. `rewrites()` is unsupported with `output: 'export'`.
2. Two `force-dynamic` route handlers (catch-all API proxy + health).
3. `app/page.tsx` is `force-dynamic`.
4. `/m/[slug]`, `/order/[id]`, `/store/[id]`, `/visit/[storeId]` have no `generateStaticParams`.
5. `API_INTERNAL_URL` is read at server runtime.
6. Static export would force browser→Django cross-origin calls, breaking the same-origin auth model and requiring CORS/localhost changes.

Vercel Hobby is also rejected (commercial use prohibited; JAM is a marketplace). Cloudflare Workers/Pages free is genuinely $0 but requires adapter/code changes not authorised here (conditional/deferred).

## F. Media decision (BLOCKER)

R2 is **CONDITIONAL/BLOCKED** under the $0 rule: enabling R2 requires an R2 subscription checkout with a payment method on file, and usage is uncapped (billed monthly). This conflicts with the binding owner decision "no payment method or billing activation solely to bypass a Free Tier restriction."

**Recommended default: Scenario B — uploads operationally disabled.**
- `DEFAULT_FILE_STORAGE_BACKEND=django.core.files.storage.FileSystemStorage`; all `AWS_*` empty.
- Upload endpoints still accept writes to ephemeral disk; those bytes are lost on restart/spin-down and are not served in production (`DEBUG=False` disables `static()`). This is a documented limitation, not a durable media solution.
- There is no enforced "uploads disabled" code flag; this is an operational restriction. A hard disable requires an owner-authorised code change (B-11).
- **Forbidden:** reverting to the ephemeral filesystem as if it were durable media (A-01).

**Candidate (UNVERIFIED):** Neon Object Storage (5 GB/project, S3-compatible, no card) — plausible zero-cost target, but recently introduced, shares the 5 GB transfer allowance, and its compatibility with `django-storages` 1.14 is unverified. Owner-approved spike only.

R2 remains available if the owner explicitly authorises adding a card and accepts the uncapped-overage risk, with a spend alert and an operational upload cap.

## G. Migration decision

Migrations and admin promotion run from the owner's local dev environment against Neon's **direct** (non-pooled) host, with SSL, identity verification, a pre-migration backup (Neon branch or `pg_dump`), and owner confirmation gates. Full procedure: `JAM_ZERO_COST_LOCAL_MIGRATION_RUNBOOK.md`. Key points:
- Never use the pooled host for migrations.
- Never run migrations against an unverified target.
- Django migrations are not universally reversible (e.g. `payments` 0004 removes rows); forward-fix or restore from backup.
- No automatic migration at container startup (forbidden).
- Render Free has no shell/one-off jobs, so Render cannot run migrations.

## H. Redis command-budget conclusion

`/api/health/ready/` performs `cache.set` + `cache.get` = 2 commands per call. Render probes every few seconds:
- 5 s → 1,036,800 commands/month
- 10 s → 518,400
- 30 s → 172,800

All exceed or approach the 500k Upstash allowance when combined with application traffic. **Rule: Render health check path = `/api/health/live/` (zero Redis commands).** `/api/health/ready/` is a manual smoke-test endpoint only. No external uptime pinger. Application traffic (JWT auth = 0 Redis commands; DRF throttling ≈ 2 commands per throttled request) targets ≤ 300,000 commands/month combined.

## I. Port / bind resolution

Backend `Dockerfile` binds `0.0.0.0:8000`. Render injects `PORT` (default 10000).
- Option A (try first, no code change): set `PORT=8000` in the Render backend env. Unverified on Free — validate during the authorised deploy.
- Option B (durable, requires authorised change): change Gunicorn bind to `--bind 0.0.0.0:${PORT:-8000}`. One-line Dockerfile edit; out of scope for this docs revision.
- Frontend is unaffected (`next start` honours `PORT`).

Do not silently edit the Dockerfile in this revision.

## J. Verification performed

Documentation consistency:
- All six deliverables created/updated under `docs/` (no root-level docs).
- Markdown structure reviewed; one Mermaid diagram in the architecture doc.
- Cross-references between the six documents are consistent (decision register, scenario table, gate IDs, runbook references).
- No contradictions found between the new docs and AGENTS.md business rules (no discount claim, no free plan/trial, no cancellation/refund/proration, Zarinpal-only, admin server-side, OTP preserved, no plan-gating enforcement claimed).

Stale-claim search (performed on the six docs):
- "Render Starter" / "$7" / "7/month" — appears only as explicitly superseded context in the decision matrix (labelled withdrawn). No active recommendation.
- "Persistent Disk media" — not recommended; ephemeral FS explicitly labelled non-durable.
- "auto-migration" / "migrate on startup" — explicitly forbidden.
- "100 GB" bandwidth — not used; corrected to 5 GB.
- "100 GB" Vercel — only in the rejected-alternatives context (Vercel Hobby), correctly attributed.

Git checks:
- `git diff --check` — to be run on the working tree (no code changes expected; only doc additions/edits).
- `git status --short` — to be compared against the 64-entry baseline; expected new untracked doc files + modified existing docs.

Checks not run / not applicable:
- No code compile/typecheck/test run (documentation-only revision; no code changed).
- No external provider verification beyond web-search snippets (network policy blocks direct fetch of render.com / developers.cloudflare.com).
- No Mermaid rendering engine available locally; syntax reviewed by inspection.
- No link checker available; links are relative paths within `docs/` and were checked by inspection.

## K. Residual risks and next steps

Residual risks:
1. R2 remains blocked under the $0 rule; media is operationally disabled, not enforced by code (B-11).
2. Two Free web services share 750 instance hours; a continuously busy staging pilot could exhaust them (monitor first month).
3. 5 GB/month outbound bandwidth is tight for image-heavy staging (compress images; no keep-alive pingers).
4. Upstash command budget depends on keeping `/ready/` out of the Render probe (operational discipline).
5. Neon restore window is 6 h / 1 GB; no automated backup job (A-24).
6. Vercel Hobby rejected; if the owner wants a Vercel-like frontend, it requires a paid plan (not $0).
7. Cloudflare Workers/Pages free requires code/adapter changes not authorised here.

Recommended next steps (owner-authorised, separate from this revision):
1. Decide R2 vs Scenario B (B-07) — and, if R2, authorise adding a card + spend alert.
2. Decide the port binding approach (OD-12 Option A vs B).
3. Decide whether an enforced "uploads disabled" flag is required (B-11) and authorise the code change.
4. Execute Stage 3.2.0 pre-flight (local) per the execution plan.
5. Only after G0–G8 gates pass, claim staging is operational (still not production-ready).

---

## Final status

**ZERO-COST REVISION COMPLETE — CLOUD STAGING PLAN READY FOR OWNER EXECUTION**