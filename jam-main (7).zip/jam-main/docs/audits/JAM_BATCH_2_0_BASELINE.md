# JAM Batch 2.0 — Baseline and Contract Lock

**Status:** COMPLETE  
**Date:** 2026-11-10  
**Branch:** `main`  
**HEAD:** `fdb1add6cf56b852e07aa804a19c3bb7736fac18`  
**Scope:** Read-only baseline. No implementation changes.

## 1. Working tree

Pre-existing changes preserved:

- 9 tracked files modified: `.env.example`, `backend/Dockerfile`, `backend/config/health.py`, `backend/config/settings.py`, `backend/config/test_settings.py`, `backend/config/tests.py`, `backend/requirements.lock.txt`, `backend/requirements.txt`, `backend/test_settings.py`.
- Pre-existing untracked files include `AGENTS.md`, Batch 1.1–1.5 audit/decision documents, deployment assessment, and `docs/deployment/`.
- Batch 1.5 created only `/docs/audits/JAM_BATCH_1_5_*`.

No source files were modified by Batch 2.0.

## 2. Verified starting point

- Branch: `main`
- HEAD: `fdb1add6cf56b852e07aa804a19c3bb7736fac18`
- `git diff --check`: exit 0
- Targeted legacy tests: 16 tests OK

## 3. Contract lock

Canonical purchase/entitlement contract:

- `SubscriptionProduct`: catalog; categories `menu`, `club`, `combo`.
- `SubscriptionPurchase`: user, business, product, price snapshot, status.
- `SubscriptionEntitlement`: user, business, type, product, purchase, starts/ends, status, revocation metadata.
- Product mapping: Basic/Professional/Premium → MENU; Gold → MENU + CLUB; Seller Club → CLUB.
- Current entitlement only when `status=ACTIVE` and `starts_at <= now < ends_at`.
- Gold entitlements are independent and atomically created.
- Public visibility, QR, directory, editing, product limits, and bot access use entitlement-only policy.

Legacy contract to remove:

- `Subscription`, `SubscriptionPlan`, `ActivationCode`, `ActivationCodeEvent`, `ClubMembership`
- manual request/payment info/checkout/redeem flows
- activation-code issuance and redemption
- legacy fallbacks in entitlements and public reads
- legacy payment callback branch
- manual payment frontend UI

## 4. Authorization

Owner authorization received to execute all subsequent batches sequentially.
