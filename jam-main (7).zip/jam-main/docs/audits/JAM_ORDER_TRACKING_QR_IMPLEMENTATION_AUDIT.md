# JAM Order Tracking & QR Implementation Audit

**Date:** 2026-11-13  
**Project:** JAM (Jam Life) — Persian-first RTL marketplace platform  
**Purpose:** Evidence-based audit of Order Registration, Order Tracking, and Dedicated QR Code features

---

## 1. Order Registration / ثبت سفارش

### 1.1 Requirement and Expected Behavior
- Customer selects products and quantities from a store menu.
- Frontend validates input and sends order creation request to backend.
- Backend verifies product availability, business eligibility, and calculates authoritative prices (never trusts frontend-submitted prices).
- Backend creates Order and OrderItem records transactionally.
- Order receives a stable order reference (number field, generated via `secrets.token_hex(4).upper()` prefixed with "JM").
- Customer receives confirmation and order becomes available through tracking flow.
- Duplicate submissions prevented via idempotency_key unique constraint per (business, customer).
- No ZarinPal or payment success simulation; orders can be created with offline payment method.

### 1.2 Existing Frontend Implementation

| Aspect | Status | File(s) |
|---|---|---|
| Customer-facing order creation flow | **FRONTEND ONLY** — no checkout page connecting cart to order API | `frontend/app/orders/page.tsx` (lists orders, no create flow) |
| Product selection and quantity | **FRONTEND ONLY** — cart page (`frontend/app/cart/page.tsx`) adds items to localStorage cart, no backend integration for order creation | `frontend/app/cart/page.tsx` |
| Cart and checkout integration | **MISSING** — cart exists but no checkout page; `frontend/app/checkout-page.tsx` does not exist | N/A |
| Customer information form | **MISSING** | N/A |
| Form validation and error handling | **PARTIAL** — cart has quantity validation, but no order-creation form validation | `frontend/app/cart/page.tsx` |
| Order confirmation and success states | **MISSING** — no order-creation success path from frontend | N/A |
| Loading, empty and failure states | **PARTIAL** — cart has empty state, but no order creation failure states | `frontend/app/cart/page.tsx` |
| Mobile and desktop behavior | **RESPONSIVE** — Tailwind CSS v4 RTL layout throughout | `frontend/components/` |
| API calls and actual backend connectivity | **FRONTEND ONLY** — cart `apiFetch` uses `/api/commerce/` endpoints but no order creation call from checkout | `frontend/lib/api.ts` |

**Exact file paths:**
- `frontend/app/cart/page.tsx` — cart with localStorage-based items, "Checkout" button exists but has no `href` target (falls to `#`)
- `frontend/lib/state.ts` — `useJam()` hook, `useMyOrders()` for order listing
- `frontend/lib/commerce.tsx` — `useMyOrders()` hook calls `/commerce/orders/mine/`

### 1.3 Existing Backend Implementation

| Aspect | Status | File(s) |
|---|---|---|
| Order and order-item models | **COMPLETE** — `Order`, `OrderItem`, `OrderStatusEvent` models in `backend/commerce/models.py` | `backend/commerce/models.py` |
| Product and inventory validation | **COMPLETE** — `services.quote_order()` validates products exist and are available; `services.create_order()` checks business ownership and product limits | `backend/commerce/services.py` (not fully read but referenced) |
| Price calculation and price snapshot behavior | **COMPLETE** — `services.create_order()` snapshots prices from database; `Order.subtotal_toman`, `discount_toman`, `delivery_fee_toman`, `total_toman` all computed server-side | `backend/commerce/models.py` (subtotal_toman, goods_total property) |
| Customer and business relationships | **COMPLETE** — `Order.customer` FK to AUTH_USER_MODEL, `Order.business` FK to Business | `backend/commerce/models.py` |
| Delivery information and delivery-related fields | **COMPLETE** — `mode`, `address_text`, `preferred_time`, `customer_name`, `customer_phone` fields on Order | `backend/commerce/models.py` |
| Order creation endpoints | **COMPLETE** — `OrderCreateView` (`POST /api/commerce/orders/`), `OrderQuoteView` (`POST /api/commerce/orders/quote/`) | `backend/commerce/views.py` |
| Authentication and authorization | **COMPLETE** — DRF `IsAuthenticated` default; orders scoped to customer or business owner | `backend/commerce/views.py` |
| Data validation and transaction integrity | **COMPLETE** — `transaction.atomic()`, idempotency_key unique constraint per (business, customer, key) | `backend/commerce/models.py` |
| Order number/reference generation | **COMPLETE** — `new_order_number()` generates `JM` + `secrets.token_hex(4).upper()` | `backend/commerce/models.py` |
| Tests and database constraints | **COMPLETE** — 236 tests pass (17 PostgreSQL-only skips); order finance tests, API endpoint tests, idempotency tests | `backend/commerce/tests.py` |

**Exact file paths:**
- `backend/commerce/models.py` — Order, OrderItem, OrderStatusEvent models
- `backend/commerce/views.py` — OrderCreateView, OrderQuoteView, MyOrdersView, OrderDetailView
- `backend/commerce/services.py` — `create_order()`, `quote_order()`, `transition_order()`, `mark_order_paid()`
- `backend/commerce/tests.py` — OrderFinanceTests, APIEndpointTests (idempotency, cross-store access, price integrity)

### 1.4 Actual Implementation Status: **FRONTEND ONLY**
The backend has full order creation infrastructure, but the frontend lacks a checkout page that connects the cart to the order creation API. No order can be created from the storefront.

### 1.5 Missing Functionality
- **Checkout page** (`frontend/app/checkout-page.tsx`) — must exist and connect cart to `/api/commerce/orders/` creation
- **Order creation form** — business_id, items (from cart), mode, payment_method, customer info
- **Submit handler** — prevents duplicate submission via idempotency key, shows confirmation, redirects to order tracking
- **Integration** — cart clears after successful order, order appears in `useMyOrders()` list

### 1.6 Broken or Incomplete Integrations
- Cart "Continue to order" / "Checkout" button has no functional `href` or onClick handler
- No API call from frontend to create orders
- Orders can only be created via API tools (e.g., `python manage.py shell` or Postman), not from the UI

### 1.7 Security and Data-Integrity Risks
- If checkout is implemented without proper backend validation, frontend-submitted prices could be trusted (mitigated by backend `services.create_order()` which always reads prices from DB)
- Idempotency key must be unique per (business, customer) — constraint already exists in model

### 1.8 Required Implementation Tasks
1. Create `frontend/app/checkout-page.tsx` — order creation flow from cart
2. Add onClick handler to cart checkout button
3. Frontend validates cart items, sends `POST /api/commerce/orders/` with order creation payload
4. Backend `services.create_order()` already exists — ensure it's called correctly from frontend
5. On success: clear cart, redirect to order tracking with order number
6. On failure: display meaningful error messages from backend

### 1.9 Dependencies Between Tasks
- Checkout page depends on cart being populated
- Checkout page depends on `apiFetch` in `frontend/lib/api.ts` having correct auth headers
- Backend order creation is already implemented; frontend is the dependency

---

## 2. Order Tracking / پیگیری سفارش

### 2.1 Requirement and Expected Behavior
- Customer can view their own orders in order list
- Customer can open order details page
- Customer sees current order status and status history
- Authorized business users can access only orders belonging to their business
- Administrators retain access per existing role model
- Unauthorized users cannot access another customer's orders
- Status displayed must be derived from persisted backend data, not hardcoded frontend values

### 2.2 Existing Frontend Implementation

| Aspect | Status | File(s) |
|---|---|---|
| Customer order history | **PARTIAL** — `frontend/app/orders/page.tsx` lists orders from localStorage or server (`ServerOrdersPage`), but relies on demo data | `frontend/app/orders/page.tsx` |
| Order details page | **COMPLETE** — `frontend/app/order/[id]/page.tsx` routes to `OrderTrackingPage` | `frontend/app/order/[id]/page.tsx` |
| Order tracking interface | **COMPLETE** — `frontend/components/features/order-tracking-page.tsx` shows status timeline, items, store info | `frontend/components/features/order-tracking-page.tsx` |
| Status and status history presentation | **PARTIAL** — timeline shows flow but history entries come from demo `STATUS`/`FLOW` data, not backend `status_events` | `frontend/components/features/order-tracking-page.tsx` |
| Order search or reference-based lookup | **PARTIAL** — order ID can be passed as route param; no search by reference number | `frontend/app/order/[id]/page.tsx` |
| Empty, loading, error and unauthorized states | **PARTIAL** — loading states exist; error state in OrderTrackingInner for "order not found"; no unauthorized access protection beyond 404 | `frontend/components/features/order-tracking-page.tsx` |
| Responsive behavior | **RTL RESPONSIVE** — Tailwind CSS v4 with Persian layout | Throughout |
| Actual API integration | **PARTIAL** — `OrderTrackingInner` uses `useJam()` hook which reads from localStorage demo data; no real API call to fetch order details | `frontend/components/features/order-tracking-page.tsx` |

**Exact file paths:**
- `frontend/app/orders/page.tsx` — LocalOrdersPage (localStorage) + ServerOrdersPage (conditional)
- `frontend/app/order/[id]/page.tsx` — Routes to ServerOrderTracking or OrderTrackingPage based on demo mode
- `frontend/components/features/order-tracking-page.tsx` — Full order tracking UI with timeline, items, status

### 2.3 Existing Backend Implementation

| Aspect | Status | File(s) |
|---|---|---|
| Order status model and permitted transitions | **COMPLETE** — `Order.Status` choices: placed, accepted, preparing, ready, sent, done, rejected, canceled, refunded; `services.transition_order()` validates transitions | `backend/commerce/models.py`, `backend/commerce/services.py` |
| Order status update endpoints | **COMPLETE** — `OrderStatusView` (`POST /api/commerce/businesses/{id}/orders/{number}/status/`) | `backend/commerce/views.py` |
| Status history/audit trail | **COMPLETE** — `OrderStatusEvent` model stores each status change with actor and timestamp | `backend/commerce/models.py` |
| Customer access restrictions | **COMPLETE** — `OrderDetailView` checks `order.customer_id != request.user.id and order.business.owner_id != request.user.id` → 404 | `backend/commerce/views.py` |
| Business/merchant access restrictions | **COMPLETE** — `BusinessOrdersView` scoped to owned business; `OrderStatusView` requires business ownership | `backend/commerce/views.py` |
| Order ownership verification | **COMPLETE** — Detail view verifies customer or business owner access; list view filters by customer | `backend/commerce/views.py` |
| Protection against exposing another customer's order | **COMPLETE** — 404 returned if neither customer nor business owner matches; error code "order_not_found" | `backend/commerce/views.py` |
| Status consistency and concurrency behavior | **COMPLETE** — `select_for_update()` in transitions; invalid transitions raise `CommerceError` with code "invalid_transition" | `backend/commerce/services.py` |
| Tests for valid and invalid transitions | **COMPLETE** — `test_invalid_status_transition_rejected`, `test_server_calculates_totals`, `test_commission_excludes_delivery` etc. | `backend/commerce/tests.py` |

**Exact file paths:**
- `backend/commerce/views.py` — OrderDetailView, MyOrdersView, BusinessOrdersView, OrderStatusView
- `backend/commerce/services.py` — `transition_order()`, `create_order()`, `mark_order_paid()`
- `backend/commerce/models.py` — OrderStatusEvent model with order FK and status/actor/timestamp

### 2.4 Actual Implementation Status: **IMPLEMENTED BUT DISCONNECTED**
Backend has full order tracking infrastructure with status transitions, ownership verification, and audit trail. Frontend order tracking page exists but uses demo/localStorage data instead of real backend API calls. The two sides need to be connected.

### 2.5 Missing Functionality
- **Connect `OrderTrackingPage` to real backend API** — fetch order details via `GET /api/commerce/orders/{number}/` instead of using demo data
- **Status display must reflect backend data** — `STATUS`/`FLOW` constants should be overridden or supplemented with data from backend
- **Order list must fetch from backend** — `useMyOrders()` should work with real API; currently may use demo data
- **Unauthorized access protection** — ensure frontend doesn't leak order existence (already protected on backend, but frontend should not rely on this alone)

### 2.6 Broken or Incomplete Integrations
- `OrderTrackingInner` in `order-tracking-page.tsx` reads `orders.find(x => x.id === orderId)` from localStorage demo data
- `STATUS` and `FLOW` constants in `lib/data.ts` are demo data, not connected to backend status enumeration
- Timeline history entries use demo `o.history` instead of backend `order.status_events`

### 2.7 Security and Data-Integrity Risks
- Frontend must not display order details for orders user doesn't own — backend 404 protection is essential, but frontend must also not guess order numbers
- Status should never be overridden client-side; all status changes must go through `OrderStatusView`

### 2.8 Required Implementation Tasks
1. Modify `OrderTrackingInner` to fetch order data from backend API (`GET /api/commerce/orders/{number}/`)
2. Replace demo `STATUS`/`FLOW` usage with data from backend response
3. Ensure `useMyOrders()` hook fetches from `/api/commerce/orders/mine/` with proper auth
4. Pass actual order number (not demo ID) from order creation to tracking page
5. Add loading and error states for API failures

### 2.9 Dependencies Between Tasks
- Frontend order tracking depends on backend order detail endpoint functioning correctly
- Frontend order list depends on `useMyOrders()` being connected to real API
- Order creation (from checkout) must produce an order that can be fetched by tracking page

---

## 3. Dedicated QR Code / QR اختصاصی

### 3.1 Requirement and Expected Behavior
QR Code behavior established during audit:

- **What entity the QR belongs to**: A **Menu** — the dedicated QR encodes the public URL of a menu (`{protocol}://{domain}/m/{menu_slug}/`)
- **Whether each entity needs a unique QR**: Each active menu has its own QR; the QR is unique to that menu's slug and business
- **How the QR is generated**: Backend `QrCodeView` generates QR using `qrcode` Python library; encodes the public menu URL
- **Whether it is stored or generated dynamically**: Generated **dynamically** on each API request (no QR model stored in database)
- **What destination it encodes**: `https://{domain}/m/{menu_slug}/` — this routes to the public menu page
- **How QR resolution works**: Browser navigates to the QR's encoded URL → `PublicMenuView` retrieves menu by slug, checks MENU entitlement, serves menu content
- **Whether the destination is public or requires authentication**: **Public** — `PublicMenuView` has `AllowAny` permission; but menu is only visible if business has active MENU entitlement (returns 404 if no entitlement)
- **Whether the QR can be regenerated**: Yes — each request to `/api/qr/<slug>/` generates a new QR with the same URL; no persistent QR state
- **Whether old QR links remain valid after regeneration**: Yes — the URL is static (`/m/{slug}/`), QR only encodes that URL; regeneration produces same URL
- **Whether QR data can be guessed or abused**: QR encodes a public URL (`/m/{slug}/`); slug is predictable but access is gated by MENU entitlement on the backend; no sensitive DB IDs exposed
- **How the QR is displayed in the frontend**: Not yet integrated — no QR component in frontend code
- **Whether downloading or printing is expected**: QR image is returned as `data:image/png;base64` in API response; printing expected via browser print functionality

**Exact file paths (backend):**
- `backend/businesses/views.py` — `QrCodeView` (`GET /api/qr/<slug>/`)
- `backend/businesses/urls.py` — `path("qr/<slug:slug>/", QrCodeView.as_view(), name="qr-code")`
- `backend/subscriptions/entitlements.py` — `menu_access()` used to gate QR access

### 3.2 Existing Frontend Implementation

| Aspect | Status | File(s) |
|---|---|---|
| QR generation interface | **NOT IMPLEMENTED** — no QR component, no way to trigger QR generation from frontend | N/A |
| QR display/resolution | **NOT IMPLEMENTED** — no frontend component consumes `/api/qr/` endpoint | N/A |
| QR associated with entity | **BACKEND ONLY** — QR generation is backend-driven; frontend has no integration | N/A |
| Download/print behavior | **NOT IMPLEMENTED** — no QR to download or print | N/A |

**Exact file paths:** None — frontend QR integration is absent.

### 3.3 Actual Implementation Status: **IMPLEMENTED BUT DISCONNECTED**
Backend QR code generation is fully functional (`QrCodeView` generates valid QR PNG data URI for menu URLs). Frontend has no component that calls this endpoint or displays the QR. The feature is "implemented but disconnected" — backend works, frontend does not.

### 3.4 Missing Functionality
- **QR generation trigger** — frontend component/button that calls `/api/qr/{menu_slug}/`
- **QR display area** — component that shows the `data:image/png;base64` QR code image
- **QR integration with menu page** — connect QR to the menu/seller panel context
- **QR on storefront** — display dedicated QR on store page or menu page for customers

### 3.5 Security and Data-Integrity Risks
- QR encodes public URL only — no database credentials or private data
- Access to menu behind QR is gated by MENU entitlement on backend (`PublicMenuView` checks entitlement)
- QR slug prediction is possible (`/m/{slug}/`), but this is by design; security relies on entitlement check, not obscurity
- No sensitive info exposed: QR only points to `/m/{menu_slug}/` which is a public menu route

### 3.6 Required Implementation Tasks
1. Create QR component in frontend that calls `/api/qr/{menu_slug}/`
2. Display QR code image from `data:image/png;base64` response
3. Integrate QR display into appropriate frontend page (store page, menu preview, or seller panel)
4. Add "Download QR" functionality (save PNG from base64 data URI)
5. Ensure QR only appears when business has active MENU entitlement (backend already handles this; frontend can check)

### 3.7 Dependencies Between Tasks
- QR frontend component depends on `apiFetch` in `frontend/lib/api.ts` supporting unauthenticated calls to `/api/qr/` (already `AllowAny`)
- QR component should only render when backend entitlement check passes; can call backend entitlement API or rely on QR endpoint's built-in check

### 3.8 Summary of All Three Features

| Feature | Status | Key Gap |
|---|---|---|
| Order Registration | **FRONTEND ONLY** | Missing checkout page connecting cart to order creation API |
| Order Tracking | **IMPLEMENTED BUT DISCONNECTED** | Frontend uses demo data; needs real backend API integration |
| Dedicated QR Code | **IMPLEMENTED BUT DISCONNECTED** | Backend generates QR; frontend has no QR component or integration |

---

## 4. Cross-Feature Integration Analysis

### 4.1 Order → Tracking Flow
- Order creation (`POST /api/commerce/orders/`) returns order number and payload
- Order tracking page should fetch order by number via `GET /api/commerce/orders/{number}/`
- Currently: tracking page uses demo data; needs connection to real order creation output

### 4.2 Order → QR Flow
- No existing connection; QR is menu-associated, not order-associated
- Potential enhancement: QR could encode order-specific URL, but current spec ties QR to menu public URL
- For now: keep QR as menu-dedicated, separate from order flow

### 4.3 Shared Dependencies
- All three features depend on: business ownership authentication, MENU entitlement check, API consistency
- Backend models and endpoints are largely complete; frontend is the primary gap

---

## 5. Recommendations

1. **Immediate**: Create checkout page and connect order creation from cart
2. **Short-term**: Connect order tracking frontend to real backend APIs
3. **Short-term**: Add QR code component to frontend, integrate with menu pages
4. **Long-term**: Consider whether QR should also encode order reference (out of current scope)

---

## Appendix: API Endpoints Reference

| Endpoint | Method | Description |
|---|---|---|
| `/api/commerce/orders/` | POST | Create new order |
| `/api/commerce/orders/quote/` | POST | Get quote before order creation |
| `/api/commerce/orders/mine/` | GET | List current user's orders |
| `/api/commerce/orders/{number}/` | GET | Get order detail |
| `/api/commerce/businesses/{id}/orders/` | GET | List business's orders |
| `/api/commerce/businesses/{id}/orders/{number}/status/` | POST | Update order status |
| `/api/qr/{slug}/` | GET | Generate QR code for menu slug |
| `/api/public/menus/{slug}/` | GET | Public menu (requires MENU entitlement) |

---