# JAM Batch 2.7 — Execution Closure

**Status:** COMPLETE  
**Date:** 2026-11-10  
**Authorization:** Owner authorized sequential execution of Batches 2.0–2.7.

## Batch outcomes

| Batch | Outcome |
|---|---|
| 2.0 | Baseline and execution map created under `/docs/audits/`. |
| 2.1 | Legacy subscription and ClubMembership models, fallbacks, admin, services, and tests removed; forward-only migrations added. |
| 2.2 | Public menu, QR, and directory now require a current MENU entitlement; duplicate public-menu route removed. |
| 2.3 | Manual subscription flows and legacy transaction target removed; purchase is mandatory for transactions. |
| 2.4 | Bot product editing uses the centralized MENU entitlement policy; activation-code endpoint removed. |
| 2.5 | Plan page and frontend subscription utilities now use products, purchases, and entitlements; manual activation UI removed. |
| 2.6 | Admin overview, payments, and subscription views use purchases/entitlements only. |
| 2.7 | Canonical docs updated; full backend and frontend verification completed. |

## Final acceptance criteria

- No active legacy subscription or ClubMembership architecture remains.
- No manual payment or activation-code flow remains.
- ZarinPal is the only payment route.
- Public, frontend, bot, and admin access follow entitlement-only policy.
- Migration history is forward-only and fresh-database migration succeeds through the test suite.
- Results and skipped tests are documented.

## Verification commands

```bash
# Backend
env -u REDIS_URL DJANGO_DEBUG=false DJANGO_SECRET_KEY='test-secret-key-not-real' \
  OTPY_API_KEY='test-otpy-key' TEST_DB_NAME=':memory:' \
  /tmp/jam-lock-verify/bin/python backend/manage.py test \
  accounts bot businesses cart commerce payments subscriptions \
  --settings=config.test_settings --verbosity=1

# Migration state
env -u REDIS_URL DJANGO_DEBUG=false DJANGO_SECRET_KEY='test-secret-key-not-real' \
  OTPY_API_KEY='test-otpy-key' TEST_DB_NAME=':memory:' \
  /tmp/jam-lock-verify/bin/python backend/manage.py makemigrations \
  --check --dry-run --settings=config.test_settings

# Frontend
cd frontend && npx tsc --noEmit --pretty false
cd frontend && npm run lint
cd frontend && npm run build
```

## Result

**LEGACY REMOVAL COMPLETE — READY FOR OWNER ACCEPTANCE.**
