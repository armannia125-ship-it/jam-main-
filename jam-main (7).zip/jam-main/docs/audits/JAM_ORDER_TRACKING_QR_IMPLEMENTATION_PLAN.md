# JAM Order Tracking & QR Implementation Plan

**Date:** 2026-11-13  
**Project:** JAM (Jam Life)  
**Purpose:** Roadmap for completing Order Registration, Order Tracking, and Dedicated QR Code features

---

## 1. Implementation Phases

### Phase 1: Order Registration (Checkout Flow)
**Goal:** Enable customers to create orders from the storefront cart.

| Task | Description | File(s) | Dependency |
|---|---|---|---|
| T1.1 | Create `frontend/app/checkout-page.tsx` — order creation form from cart | `frontend/app/checkout-page.tsx` | T1.2, T1.3 |
| T1.2 | Add onClick handler to cart checkout button (in `cart/page.tsx`) | `frontend/app/cart/page.tsx` | T1.1 |
| T1.3 | Frontend sends `POST /api/commerce/orders/` with order payload | `frontend/lib/api.ts` | T1.1, T1.2 |
| T1.4 | Backend `services.create_order()` processes request, persists order transactionally | `backend/commerce/services.py` | T1.3 (backend already implemented) |
| T1.5 | On success: clear cart, redirect to order tracking with order number | `frontend/app/checkout-page.tsx` | T1.4 |
| T1.6 | On failure: display meaningful error messages from backend | `frontend/app/checkout-page.tsx` | T1.3 |

### Phase 2: Order Tracking Frontend-Backend Connectivity
**Goal:** Frontend fetches and displays real order data from backend.

| Task | Description | File(s) | Dependency |
|---|---|---|---|
| T2.1 | Modify `useMyOrders()` hook in `frontend/lib/commerce.tsx` to fetch from real API | `frontend/lib/commerce.tsx` | Phase 1 complete |
| T2.2 | Modify `OrderTrackingInner` in `frontend/components/features/order-tracking-page.tsx` to fetch order by number from `GET /api/commerce/orders/{number}/` | `frontend/components/features/order-tracking-page.tsx` | Phase 1 complete |
| T2.3 | Replace demo `STATUS`/`FLOW` constants with data from backend response | `frontend/lib/data.ts` | T2.2 |
| T2.4 | Add loading, error, and empty states for API failures | `frontend/components/features/order-tracking-page.tsx` | T2.2, T2.3 |
| T2.5 | Ensure order number from order creation is passed to tracking page | `frontend/app/order/[id]/page.tsx` | Phase 1 complete |

### Phase 3: Dedicated QR Code Frontend Integration
**Goal:** Frontend can generate and display dedicated QR codes for menus.

| Task | Description | File(s) | Dependency |
|---|---|---|---|
| T3.1 | Create QR component that calls `GET /api/qr/{menu_slug}/` | New component: `frontend/components/features/qr-code-display.tsx` | Backend QrCodeView already implemented |
| T3.2 | Display QR code image from `data:image/png;base64` response | Same component | T3.1 |
| T3.3 | Add "Download QR" functionality (save PNG from base64 data URI) | Same component | T3.1 |
| T3.4 | Integrate QR component into store page / menu preview / seller panel | `frontend/app/store-page.tsx` or `frontend/app/panel/menu/page.tsx` | T3.1 |
| T3.5 | Ensure QR only renders when business has active MENU entitlement | Backend already gates this; frontend can check or rely on backend | T3.1 |

### Phase 4: End-to-End Verification
**Goal:** Verify all three features work together.

| Task | Description | File(s) |
|---|---|---|
| T4.1 | Execute Scenario A: Order registration end-to-end | Local test environment |
| T4.2 | Execute Scenario B: Order tracking end-to-end | Local test environment |
| T4.3 | Execute Scenario C: Dedicated QR generation and resolution | Local test environment |
| T4.4 | Run full backend test suite | `python manage.py test --settings=config.test_settings` |
| T4.5 | Run frontend typecheck and lint | `npx tsc --noEmit`, `npm run lint` |

---

## 2. Task Dependencies Summary

```
T1.1 (checkout page) → T1.2 (cart checkout handler) → T1.3 (API call) → T1.4 (backend create_order)
        ↘                                                      ↓
T2.1 (useMyOrders API)                              T1.5 (success: clear cart + redirect)
                                                                        ↘
T2.2 (tracking page API)                              T1.6 (failure: error messages)
                                                                        ↓
T2.3 (replace demo data)                              T2.4 (loading/error states)
                ↘                                               ↓
T2.5 (pass order number to tracking)          T3.1 (QR component) → T3.2 (display QR) → T3.3 (download) → T3.4 (integrate into page)
                                                ↘                                                   ↓
                                              T3.5 (entitlement check)
```

---

## 3. Files Likely to Be Modified

### Backend (minimal changes — mostly existing code)
- `backend/commerce/services.py` — verify `create_order()`, `quote_order()`, `transition_order()` work correctly; may need minor fixes
- `backend/commerce/views.py` — no changes expected; endpoints already exist
- `backend/commerce/models.py` — no changes expected; models already support orders, items, status events
- `backend/subscriptions/entitlements.py` — no changes expected; `menu_access()` already gated
- `backend/businesses/views.py` — no changes expected; `QrCodeView` already exists
- `backend/businesses/urls.py` — no changes expected; `qr/<slug:slug>/` already registered

### Frontend (primary changes)
- `frontend/app/checkout-page.tsx` — **NEW FILE** — order creation flow
- `frontend/app/cart/page.tsx` — add onClick to checkout button
- `frontend/lib/commerce.tsx` — modify `useMyOrders()` for real API
- `frontend/components/features/order-tracking-page.tsx` — fetch from backend API instead of demo data
- `frontend/lib/data.ts` — supplement STATUS/FLOW with backend data or remove demo dependency
- `frontend/components/features/qr-code-display.tsx` — **NEW FILE** — QR generation and display
- `frontend/app/panel/menu/page.tsx` or `frontend/app/store-page.tsx` — integrate QR component
- `frontend/app/order/[id]/page.tsx` — ensure order number passed to tracking

### Database / Migrations
- **NO new migrations required** — all models and constraints already exist
- Existing migrations are compatible; no schema changes needed
- Verify fresh database migration works: `python manage.py migrate --noinput`

---

## 4. Database Migration Requirements

| Requirement | Status |
|---|---|
| New migrations needed? | **NO** — all models, constraints, and endpoints already exist |
| Historical migrations to preserve? | Yes — all existing migrations in `backend/subscriptions/migrations/`, `backend/commerce/migrations/` |
| Migration consistency check? | Run `python manage.py makemigrations --check --dry-run --settings=config.test_settings` |
| Fresh database migration test? | `python manage.py migrate --noinput` — should succeed |
| Upgrade migration test? | Apply migrations to representative existing database; verify no data loss |

**Rationale:** The backend has complete order models (Order, OrderItem, OrderStatusEvent), subscription entitlements (SubscriptionProduct, SubscriptionEntitlement), and QR infrastructure (QrCodeView). No new database tables or columns are needed. The frontend is the primary integration point.

---

## 5. API Contract Changes

### Existing Endpoints (no changes needed)
| Endpoint | Method | Notes |
|---|---|---|
| `POST /api/commerce/orders/` | Create order | Already exists; frontend needs to call it |
| `POST /api/commerce/orders/quote/` | Get quote | Already exists |
| `GET /api/commerce/orders/mine/` | List user orders | Already exists; `useMyOrders()` hook |
| `GET /api/commerce/orders/{number}/` | Get order detail | Already exists; tracking page needs to use it |
| `POST /api/commerce/businesses/{id}/orders/{number}/status/` | Update status | Already exists |
| `GET /api/qr/{slug}/` | Generate QR | Already exists; frontend needs component |
| `GET /api/public/menus/{slug}/` | Public menu | Already exists; QR encodes this URL |

### No New API Endpoints Required
All necessary endpoints exist. The implementation is purely frontend-facing and backend-utilization.

---

## 6. Frontend/Backend Integration Strategy

### Order Registration Integration
1. Cart page "Checkout" button triggers onClick handler
2. Handler reads cart items, business ID (selected store), mode (delivery/pickup), customer info
3. Frontend calls `POST /api/commerce/orders/` with:
   - `business_id`: selected store's ID
   - `items`: array of `{product_id, quantity}` from cart
   - `mode`: delivery or pickup
   - `payment_method`: "offline" (per approved business rule — no ZarinPal)
   - Optional: `customer_name`, `customer_phone`, `address_text`, `note`, `preferred_time`, `idempotency_key`
4. Backend `services.create_order()` validates:
   - Business exists and is active
   - Products exist and are available (is_available=True)
   - Customer has MENU entitlement (via `menu_access()`)
   - Product count respects `max_products` limit (Basic: 80, others: unlimited)
   - Prices snapshotted from database (not trusted from frontend)
   - Idempotency key checked for duplicate prevention
5. On success: order number returned, cart cleared, redirect to `/order/{number}/`
6. On failure: DRF error response with `{"detail": "...", "code": "..."}` displayed to user

### Order Tracking Integration
1. User navigates to `/order/{number}/` where number is from order creation
2. `OrderTrackingPage` fetches order via `GET /api/commerce/orders/{number}/`
3. Response includes: number, status, items, business, customer, history (from `status_events`)
4. Frontend displays: current status, status timeline, items, store info, delivery details
5. Status is derived from backend `order.status`; not hardcoded
6. Status history from `order.status_events.all()` displayed as timeline

### Dedicated QR Integration
1. QR component calls `GET /api/qr/{menu_slug}/`
2. Backend `QrCodeView`:
   - Retrieves menu by slug, checks MENU entitlement (active, not expired)
   - Generates public URL: `{protocol}://{domain}/m/{menu_slug}/`
   - Creates QRCode with `qrcode` library, encodes that URL
   - Returns `data:image/png;base64` PNG image
3. Frontend displays QR image; adds download button that saves the base64 PNG
4. QR only rendered when business has active MENU entitlement (backend handles gate; frontend can verify or trust backend)
5. Download: user clicks "Download QR", browser saves `data:image/png;base64,...` as PNG file

---

## 7. Security Considerations

### Order Registration
- **IDOR prevention**: `OrderDetailView` returns 404 if user is neither customer nor business owner
- **Price integrity**: Backend always snapshots prices from DB; frontend never trusted with totals
- **Duplicate prevention**: Idempotency key unique constraint per (business, customer, key)
- **Concurrent safety**: `transaction.atomic()` in `services.create_order()`; `select_for_update()` on business
- **Product eligibility**: `is_available` check; `max_products` limit enforcement

### Order Tracking
- **Ownership enforcement**: All order queries scoped to `request.user` or `business.owner`
- **Cross-customer access**: `OrderDetailView` returns 404 if `order.customer_id != request.user.id and order.business.owner_id != request.user.id`
- **Cross-business access**: Similarly scoped to owned business
- **Status transition validation**: `services.transition_order()` validates permitted transitions; invalid → 400 with code "invalid_transition"
- **No client-controlled status**: All status changes go through `OrderStatusView` API endpoint

### Dedicated QR
- **Entitlement gating**: `QrCodeView` checks active MENU entitlement before generating QR; returns 404 if no entitlement
- **No sensitive data in QR**: Encodes only public URL (`/m/{menu_slug}/`); no database IDs, phone numbers, or private info
- **Predictable slug**: QR slug (`menu_slug`) is by design; security relies on backend entitlement check, not URL obscurity
- **Abuse prevention**: Each QR request regenerates QR; no persistent state; rate-limiting could be added but not required by spec
- **Download printing**: Browser-mediated; no server-side download storage; QR image is ephemeral API response

### General
- **Authentication**: DRF `IsAuthenticated` default; public endpoints (`/api/qr/`, `/api/public/menus/`) explicitly set `AllowAny` with `authentication_classes = []`
- **Error formatting**: Structured errors `{"detail": "...", "code": "..."}`; user-facing messages in Persian; no stack traces leaked
- **Input validation**: DRF serializers validate all incoming data; `min_value`, `max_value`, `choice` constraints on models

---

## 8. Test Strategy

### Backend Tests (run: `python manage.py test --settings=config.test_settings`)
| Test Category | Existing Tests | New Tests Needed |
|---|---|---|
| Order creation | `test_server_calculates_totals`, `test_order_idempotency_key_prevents_duplicates`, `test_inactive_product_cannot_be_ordered` | Test checkout-to-order flow from frontend payload |
| Order tracking | `test_cross_store_order_access_denied`, `test_order_item_price_comes_from_database` | Test order detail API endpoint returns correct data |
| Status transitions | `test_invalid_status_transition_rejected`, `test_commission_excludes_delivery` | Test status update flow with auth |
| QR code | None (backend only) | Test `QrCodeView` returns 200 with valid QR for entitled business, 404 for non-entitled |
| Cross-customer access | `test_cross_store_order_access_denied` | Ensure no order leak via tracking page |
| Price integrity | `test_server_calculates_totals`, `test_order_item_price_comes_from_database` | Verify frontend sends correct payload |

### Frontend Tests
| Test Type | Command | Scope |
|---|---|---|
| TypeScript check | `npx tsc --noEmit` | All `.tsx` files; must exit 0 |
| ESLint | `npm run lint` | Must not introduce new errors (11 pre-existing warnings OK) |
| Production build | `npm run build` | Verify no build errors; `.next` generated |
| Component tests | Vitest/React Testing Library if available | Order form, QR display, tracking page |

### End-to-End Scenarios
| Scenario | Steps | Verification |
|---|---|---|
| **A — Order registration** | 1. Open storefront 2. Select products 3. Click checkout 4. Backend persists order 5. Frontend receives order reference 6. Customer opens created order | Execute locally; verify order appears in `useMyOrders()` list |
| **B — Order tracking** | 1. Customer logs in 2. Opens order list 3. Selects order 4. Sees persisted status from backend 5. Business user updates status via panel 6. Customer sees updated status 7. Different customer cannot access order | Execute locally; verify status reflects backend data |
| **C — Dedicated QR** | 1. Business with active MENU entitlement 2. Generate QR via `/api/qr/{slug}/` 3. Decode QR destination (should be `/m/{slug}/`) 4. Resolve through app 5. Verify it points to correct menu 6. Verify invalid/unauthorized access rejected | Execute locally; verify QR PNG data URI and entitlement gate |

---

## 9. Acceptance Criteria

- [ ] Checkout page creates order via `POST /api/commerce/orders/` with real backend persistence
- [ ] Order appears in customer's order list (`/api/commerce/orders/mine/`)
- [ ] Order tracking page fetches and displays real backend order data
- [ ] Order status is derived from backend, not hardcoded frontend values
- [ ] Unauthorized users cannot access another customer's order (404 returned)
- [ ] Business users can update order status via `POST /api/commerce/businesses/{id}/orders/{number}/status/`
- [ ] Dedicated QR generates via `GET /api/qr/{menu_slug}/` and returns valid PNG data URI
- [ ] QR resolves to correct menu public URL (`/m/{menu_slug}/`)
- [ ] QR access gated by active MENU entitlement (404 if no entitlement)
- [ ] No production flow depends on hardcoded demo data
- [ ] All existing backend tests pass (236 tests, 17 PostgreSQL-only skips)
- [ ] Frontend typecheck (`npx tsc --noEmit`) passes
- [ ] Frontend lint (`npm run lint`) passes with no new warnings
- [ ] Production build (`npm run build`) succeeds

---

## 10. Risks and Mitigations

| Risk | Mitigation |
|---|---|
| Frontend order creation sends invalid payload | Backend `services.create_order()` validates all fields; DRF serializer catches errors; meaningful error codes returned |
| Status displayed incorrectly on tracking page | Frontend reads `order.status` from backend response; `STATUS` constants used only as fallback |
| QR generated but entitlement check missed | Backend `QrCodeView` entitlement check is mandatory; frontend can optionally check but must not rely on it alone |
| Duplicate orders from repeated submissions | Idempotency key unique constraint in model; `services.create_order()` checks for existing order with same key |
| Cart checkout without entitlement | Backend `services.create_order()` checks `menu_access(business)`; returns 403 if no MENU entitlement |
| Lint/typecheck failures from new files | Follow existing conventions; run `npx tsc --noEmit` and `npm run lint` before finalizing |

---