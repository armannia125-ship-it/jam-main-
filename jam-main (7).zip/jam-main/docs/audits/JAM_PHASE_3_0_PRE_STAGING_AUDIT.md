# JAM — Phase 3.0 Pre-Staging Audit

**Date:** 2026-11-10\
**Scope:** Read-only audit of the repository at `main` / `fdb1add6cf56b852e07aa804a19c3bb7736fac18`\
**Authorization:** Implementation **NOT GRANTED** · Deployment **NOT GRANTED** · External provisioning **NOT GRANTED**\
**Method:** Source inspection, configuration inspection, existing verification reports, and official provider documentation. No service was started, provisioned, migrated, or deployed during this phase.\
**Document status:** `CONFIRMED` unless a row is explicitly labelled otherwise.

---

## 1. Executive summary

The application is functionally coherent and its previous local verification is strong: PostgreSQL migrations, concurrency behavior, backend runtime, and frontend route serving were verified on 2026-11-10. The repository is nevertheless **not deployable to the proposed Render Free topology as-is** without owner decisions.

Four findings dominate:

1. **Production media is unreachable without object storage.** Django only serves `/media/` when `DEBUG=True`; the Compose stack compensates with Caddy serving a shared volume. Render has neither that Caddy route nor a persistent disk on Free. Uploaded business/product images will 404 unless S3-compatible storage is enabled. `CONFIRMED`.
2. **The backend does not bind to Render's `$PORT`.** Gunicorn is hardcoded to `0.0.0.0:8000`, while Render forwards traffic to `$PORT` (default `10000`). Render can sometimes detect a non-default port, but the documented contract is `0.0.0.0:$PORT`. This is a deployment reliability defect. `CONFIRMED`.
3. **Render Free has no shell, SSH, or one-off jobs.** `migrate`, `make_admin`, and manual command execution have no verified in-platform path on Free. This remains a hard blocker, not something the audit may paper over. `BLOCKED`.
4. **The readiness endpoint is a poor Render health-check target on Upstash Free.** `/api/health/ready/` performs a cache `SET` and `GET` on every probe. At a 5–10 second probe interval this alone approaches or exceeds the Upstash free monthly command allowance, and a cache outage causes Render to restart the service in a loop. `INFERRED` from confirmed code and documented limits.

The correct planning conclusion is **not** “deploy and see.” It is: fix or explicitly accept the media, port, migration, and health-check decisions first, then deploy.

### 1.1 Readiness verdict

| Dimension | Verdict | Basis |
|---|---|---|
| Application code integrity | `CONFIRMED` | Prior PostgreSQL suite 189/189; migration scenarios passed; runtime smoke passed |
| Container build definition | `CONFIRMED` with defects | Non-root users, static collection, but hardcoded backend port |
| Staging configuration completeness | `BLOCKED` | Media backend, migration execution path, and provider credentials unresolved |
| Security posture for staging | `OWNER DECISION REQUIRED` | JWT storage, revocation, admin exposure, HSTS choices |
| Deployment automation | `BLOCKED` | No `render.yaml`, no CI/CD, no automated migration path |
| Observability | `RECOMMENDED` gap | Logs only; no error tracking, metrics, or alerting |
| **Overall** | **NOT READY TO DEPLOY** | Ready to decide, not ready to ship |

---

## 2. Audit basis and evidence rules

- The repository is the technical source of truth. Historical documents were treated as evidence only and were checked against current source.
- The working tree is intentionally dirty with Batch 2.0–2.7 changes. It was not reset, stashed, cleaned, or modified.
- No file outside `docs/` was created, edited, or deleted.
- Provider limits and prices were read from official documentation on **2026-11-10**. Prices are published list prices, not quotes, and were not verified at checkout.
- Status vocabulary used throughout: `CONFIRMED`, `RECOMMENDED`, `INFERRED`, `OWNER DECISION REQUIRED`, `BLOCKED`, `NOT TESTED`.

### 2.1 Baseline

| Item | Value |
|---|---|
| Branch | `main` |
| HEAD | `fdb1add6cf56b852e07aa804a19c3bb7736fac18` |
| Working tree | Dirty (50 tracked files changed, plus untracked migrations/docs) |
| Documented test baseline | PostgreSQL 16.14: 189 tests OK, 0 skipped; SQLite: 189 OK, 18 skipped |
| Migration baseline | Fresh, clean-forward, and legacy-data scenarios passed; `makemigrations --check` clean |
| Containers | Stopped; none started for this phase |

---

## 3. Runtime and repository inventory

### 3.1 Confirmed stack

| Layer | Version / choice | Evidence |
|---|---|---|
| Python | 3.12 (container) | `backend/Dockerfile:1` |
| Django | 5.2.18 | `backend/requirements.lock.txt:5` |
| DRF | 3.18.3 | `backend/requirements.lock.txt:8` |
| SimpleJWT | 5.5.1 | `backend/requirements.lock.txt:9` |
| psycopg | 3.3.6 | `backend/requirements.lock.txt:16` |
| Gunicorn | 23.0.0 | `backend/requirements.lock.txt:10` |
| Redis client | 8.1.0 | `backend/requirements.lock.txt:20` |
| django-redis | 5.4.0 | `backend/requirements.lock.txt:7` |
| django-storages / boto3 | 1.14.6 / 1.35.28 | `backend/requirements.lock.txt:26-27` |
| WhiteNoise | 6.12.0 | `backend/requirements.lock.txt:25` |
| Next.js | 15.5.29 | `frontend/package-lock.json` |
| React | 19.3.1 | `frontend/package-lock.json` |
| Node (container) | 20-alpine | `frontend/Dockerfile:1,16` |
| Database | PostgreSQL only | `backend/config/settings.py:69-78` |

### 3.2 Process model

| Characteristic | Finding | Status |
|---|---|---|
| Web process | Gunicorn, 3 workers, 60s timeout | `CONFIRMED` — `backend/Dockerfile:14` |
| Background worker | None (no Celery, no RQ, no Dramatiq) | `CONFIRMED` |
| Scheduler | None | `CONFIRMED` |
| Management commands | `make_admin`, `notify_expiring_entitlements`, `run_telegram_bot` | `CONFIRMED` |
| Migrations at container start | None | `CONFIRMED` — `backend/Dockerfile:14` |
| Static files | Collected at image build; WhiteNoise serves them | `CONFIRMED` — `backend/Dockerfile:8`; `settings.py:53` |
| Media files | Filesystem `/app/media` unless S3 enabled | `CONFIRMED` — `settings.py:95-96`, `102-158` |
| Frontend server | `next start` via `npm start` | `CONFIRMED` — `frontend/Dockerfile:45` |
| Frontend standalone output | Not enabled | `CONFIRMED` — `frontend/next.config.mjs` has no `output` key |
| Infrastructure as code | No `render.yaml`, no `.github/` workflows | `CONFIRMED` — both absent |

### 3.3 Topology in the repository

The Compose production stack is four services plus Caddy:

- Caddy terminates TLS, routes `/admin/*` and `/static/*` to the backend, `/media/*` to a shared read-only volume, and everything else to Next.js (`Caddyfile.common:7-20`).
- Backend and frontend are separate containers on an internal network.
- PostgreSQL and Redis are local containers with named volumes (`docker-compose.prod.yml`).
- Media is a named volume mounted into backend and Caddy (`docker-compose.prod.yml:15,44`).

**Consequence:** the repository's production media contract depends on Caddy plus a persistent volume. Neither exists in the proposed Render Free topology.

---

## 4. Configuration and environment inventory

### 4.1 Required production-fail-closed variables

The backend refuses to start in production without these:

| Variable | Enforcement | Evidence |
|---|---|---|
| `DJANGO_SECRET_KEY` | Raises `ImproperlyConfigured` if empty and `DEBUG=False` | `settings.py:6-11` |
| `OTPY_API_KEY` | Raises `ImproperlyConfigured` if empty and `DEBUG=False` | `settings.py:13-17` |
| S3 credentials, if S3 backend selected | Raises if backend is non-filesystem and any of bucket/key/secret is missing | `settings.py:114-129` |

This fail-closed behavior is correct: a misconfigured S3 deployment stops rather than silently writing ephemeral local files.

### 4.2 Production defaults that require explicit values

| Setting | Default | Staging implication | Status |
|---|---|---|---|
| `DJANGO_DEBUG` | `False` | Correct for staging | `CONFIRMED` |
| `DJANGO_ALLOWED_HOSTS` | `localhost,127.0.0.1` | Must include both Render hostnames and custom domains or every request is 400 | `CONFIRMED` — `settings.py:19` |
| `DJANGO_CSRF_TRUSTED_ORIGINS` | empty | Required for trusted HTTPS origins that submit forms/admin | `CONFIRMED` — `settings.py:196` |
| `DJANGO_SECURE_SSL_REDIRECT` | `False` | Render's edge already redirects HTTP→HTTPS; enabling app-level redirect without proxy trust can loop | `CONFIRMED` — `settings.py:28` |
| `SESSION_COOKIE_SECURE` | `True` when not DEBUG | Correct behind Render TLS; breaks plain-HTTP local runs if copied blindly | `CONFIRMED` — `settings.py:29` |
| `CSRF_COOKIE_SECURE` | `True` when not DEBUG | Same | `CONFIRMED` — `settings.py:30` |
| `SECURE_HSTS_SECONDS` | `0` | Safe initial default; enable only after HTTPS is proven | `CONFIRMED` — `settings.py:31` |
| `CORS_ALLOW_ALL_ORIGINS` | `DEBUG` | False in staging | `CONFIRMED` — `settings.py:194` |
| `CORS_ALLOWED_ORIGINS` | `http://localhost:3000` only | Irrelevant for same-origin proxy traffic; would block a cross-origin frontend | `CONFIRMED` — `settings.py:195` |
| `REDIS_URL` | empty → LocMemCache | With `CACHE_REQUIRE_REDIS=True` (production default), readiness returns 503 without Redis | `CONFIRMED` — `settings.py:183-192`; `health.py:22-32` |
| `ZARINPAL_CALLBACK_URL` | `http://localhost:8000/...` | Must be the public backend callback URL, not the frontend | `CONFIRMED` — `settings.py:206` |
| `EMAIL_BACKEND` | console | No transactional email is sent; OTP uses OTPy, not Django email | `CONFIRMED` — `settings.py:197` |
| `COMMERCE_ALLOW_SIMULATED_PAYMENTS` | `False` | Correct; must remain false in staging unless explicitly approved | `CONFIRMED` — `settings.py:210-212` |
| `COMMERCE_ORDER_ONLINE_PAYMENTS_ENABLED` | `False` | Order-bound online payment remains disabled | `CONFIRMED` — `settings.py:213-215` |

### 4.3 Frontend build-time variables

`NEXT_PUBLIC_*` values are inlined at build time. `.env.example:4-5` states this explicitly. Setting `NEXT_PUBLIC_API_BASE` only at runtime after the image is built has no effect.

The documented deployment mode is same-origin: leave `NEXT_PUBLIC_API_BASE` empty and let Next proxy `/api/*` to the backend (`.env.example:71-74`; `frontend/app/api/[...path]/route.ts`). This is the correct staging choice because it keeps tokens and cookies on one origin and avoids CORS.

---

## 5. Authentication, authorization, and session behavior

### 5.1 Token storage and lifecycle

| Finding | Evidence | Status |
|---|---|---|
| Access and refresh tokens are stored in `localStorage` under `jam.auth.v1` | `frontend/lib/api.ts:11,32,44` | `CONFIRMED` |
| Access token lifetime 30 minutes; refresh 7 days | `settings.py:176-181` | `CONFIRMED` |
| Refresh rotation enabled | `settings.py:179` | `CONFIRMED` |
| Rotation blacklist **not** enabled | No `BLACKLIST_AFTER_ROTATION`, no token blacklist app | `CONFIRMED` |
| Logout is client-side removal only | `frontend/lib/auth.tsx:81`; `frontend/lib/api.ts:50` | `CONFIRMED` |
| No server-side logout/revocation endpoint | Auth URLs inspected | `CONFIRMED` |
| `localStorage` is readable by any successful XSS | Browser storage semantics | `CONFIRMED` |

**Impact:** a stolen refresh token remains usable for up to 7 days even after the user “logs out,” and rotation does not invalidate the previous token. This is acceptable only as an explicitly accepted staging risk, not as a production posture.

### 5.2 Admin protection

| Layer | Finding | Status |
|---|---|---|
| Admin API | Every admin view uses `IsAdmin`; effective role is read from the server-side `User.role` field | `CONFIRMED` — `accounts/admin_views.py:54-392`; `accounts/models.py:57-84` |
| Admin UI | Client-side guard calls `/auth/me/` and redirects; the route is still served to anyone | `CONFIRMED` — `frontend/components/features/admin-shell.tsx:49-60` |
| Django admin | Publicly reachable at `/admin/`; session auth and CSRF apply | `CONFIRMED` — `config/urls.py:11` |

The client-side UI guard is not a security boundary, and does not need to be: server APIs enforce `IsAdmin`. The real exposure is the Django admin login surface, which must use a strong unique password and, ideally, network restriction that Render Free cannot provide.

### 5.3 Proxy and CSRF behavior

- `SECURE_PROXY_SSL_HEADER` is only set when `DJANGO_TRUST_PROXY_SSL=true` (`settings.py:34-35`). Render terminates TLS at its edge and sets `X-Forwarded-Proto: https`; the flag must be enabled for correct `request.is_secure()` behavior.
- The Next proxy copies `x-forwarded-proto`, `x-forwarded-host`, and `x-forwarded-for` from the incoming request (`frontend/app/api/[...path]/route.ts:24-37`). Render's edge is expected to overwrite the proto header, but the proxy should not forward client-supplied forwarding headers as a general rule. `INFERRED` low risk; validate during staging.
- CORS is localhost-only. With the same-origin proxy this is harmless; with a split frontend/backend browser origin it would fail. `CONFIRMED`.

---

## 6. Payments, subscriptions, and scheduled work

| Area | Finding | Status |
|---|---|---|
| Payment initiation | Server-side ZarinPal adapter; merchant ID never sent to browser | `CONFIRMED` — `payments/gateways/zarinpal.py` |
| Sandbox switch | `ZARINPAL_SANDBOX` defaults to `DEBUG`; must be explicitly set for staging | `CONFIRMED` — `settings.py:205` |
| Callback | Dedicated backend route `/api/payments/zarinpal/callback/` | `CONFIRMED` — `config/urls.py:19` |
| Callback verification | Server-side verify before activation; does not trust query `Status` | `CONFIRMED` — prior payment tests and `payments/views.py` |
| Unconfigured provider | Returns 503 and creates no purchase row | `CONFIRMED` — prior runtime verification |
| Simulated payments | Disabled by default | `CONFIRMED` — `settings.py:210-212` |
| Renewal/entitlement concurrency | Locked and verified on PostgreSQL 16.14 | `CONFIRMED` — prior concurrency audit |
| Expiry notifications | `notify_expiring_entitlements` management command; no scheduler | `CONFIRMED` |
| Telegram bot | `run_telegram_bot` polls Telegram; no worker service in Compose or Render | `CONFIRMED` |

**Staging consequence:** real payment success cannot be claimed until a ZarinPal sandbox or production merchant is configured and an owner-authorized end-to-end test is run. Expiry notifications will not run on their own. The Telegram bot must remain disabled; starting it inside a web service would compete with Gunicorn and is not a supported topology.

---

## 7. Media and object storage

### 7.1 The core defect

| Fact | Evidence | Status |
|---|---|---|
| Django serves `/media/` only when `DEBUG=True` | `config/urls.py:22-25` | `CONFIRMED` |
| Compose serves `/media/*` from a Caddy-mounted volume | `Caddyfile.common:14-17`; `docker-compose.prod.yml:15,44` | `CONFIRMED` |
| Render Free has no persistent disk | Official Render Free documentation | `CONFIRMED` |
| Backend container writes media to `/app/media` | `settings.py:96`; Dockerfile creates `/app/media` | `CONFIRMED` |
| Frontend converts backend media URLs to `/api/media-proxy/...` | `frontend/lib/public-menu.ts:29-33` | `CONFIRMED` |
| Media proxy forwards to `${API_TARGET}/media/...` | `frontend/app/api/[...path]/route.ts:14-19` | `CONFIRMED` |

**Therefore:** in filesystem mode on Render, uploaded images are written to an ephemeral container path and are never served. Every uploaded logo or product image returns 404. Static demo images under `frontend/public/media` still work; uploaded media does not. `CONFIRMED` by code path.

**Mitigation:** enable S3-compatible storage (`DEFAULT_FILE_STORAGE_BACKEND=storages.backends.s3boto3.S3Boto3Storage`) with a private bucket. This is not optional for a Render staging deployment if uploads are in scope.

### 7.2 S3 behavior that must be planned

| Behavior | Finding | Status |
|---|---|---|
| Fail-closed | Missing bucket/key/secret prevents startup | `CONFIRMED` — `settings.py:114-129` |
| Credentials are server-side only | No `NEXT_PUBLIC_*` S3 variables | `CONFIRMED` |
| Uploads are server-side | DRF `ImageField` through the backend; no direct browser-to-S3 flow | `CONFIRMED` — `businesses/serializers.py:11,45` |
| Default URL behavior | `django-storages` signs URLs by default; expiry is a library default, not configured here | `INFERRED` — library default; verify at runtime |
| Custom domain | `AWS_S3_CUSTOM_DOMAIN` switches to public-style URLs; a private bucket plus custom domain breaks images | `CONFIRMED` by configuration semantics |
| R2 ACL | R2 does not support object ACLs; `AWS_DEFAULT_ACL` must stay empty | `CONFIRMED` — provider docs |
| PWA offline images | Service worker ignores cross-origin requests and only caches `/media/` and `/api/media-proxy/` | `CONFIRMED` — `frontend/public/sw.js:97-98,131-140` |

**PWA consequence:** an absolute S3/R2 URL is cross-origin, so the service worker returns early and never caches it. An offline public menu will show cached JSON but not uploaded images. This is a product tradeoff, not a deployment bug, and needs an owner decision if offline menus are a staging acceptance criterion.

### 7.3 Upload validation

- `ImageField` applies Pillow image validation, but there is no explicit application-level file-size or dimension limit.
- Compose Caddy enforces `max_size 20MB` (`Caddyfile.common:3-5`). Render does not run Caddy, so that limit disappears.
- Django's `FILE_UPLOAD_MAX_MEMORY_SIZE` controls memory spooling, not a hard maximum.

**Status:** `RECOMMENDED` — add an explicit upload size limit before exposing uploads publicly. Not implemented in this phase.

---

## 8. Health, readiness, and Redis dependency

### 8.1 Endpoint semantics

| Endpoint | Behavior | Evidence |
|---|---|---|
| `/api/health/live/` | Process liveness only; no dependency checks; unthrottled | `config/health.py:43-53` |
| `/api/health/ready/` | Executes `SELECT 1` and performs cache `SET`/`GET`; 503 if either fails | `config/health.py:56-79` |
| Cache status | Redis required in production; LocMemCache is reported unavailable when `CACHE_REQUIRE_REDIS=True` | `config/health.py:11-40` |

### 8.2 Render health-check interaction

Render HTTP health checks send periodic GETs and restart an instance after sustained failures. Pointing Render at `/api/health/ready/` means every probe writes and reads Redis.

Arithmetic using published Upstash Free allowance (500,000 commands/month):

| Probe interval | Probes/month | Redis commands/month (SET+GET) | Free allowance |
|---|---|---|---|
| 5 s | 518,400 | 1,036,800 | Exceeded ~2× |
| 10 s | 259,200 | 518,400 | Exceeded |
| 30 s | 86,400 | 172,800 | Within |

The exact Render probe interval is not documented as a fixed number; “every few seconds” is the documented behavior. The calculation is therefore `INFERRED`, but the risk is concrete. A second problem is failure amplification: if Upstash is unavailable or over quota, readiness returns 503, and Render restarts the service repeatedly.

**Recommendation:** use `/api/health/live/` as the Render health-check path, and run `/api/health/ready/` as an explicit post-deploy smoke check. Alternatively, use a paid Redis plan with headroom. `OWNER DECISION REQUIRED`.

### 8.3 Rate limiting coupling

DRF throttling uses the default cache (`settings.py:165-172`). With Redis required in production, every throttled request also consumes Redis commands. Under staging traffic this is small, but it is another reason the free Redis allowance is not a guarantee.

---

## 9. Database and migrations

| Finding | Evidence | Status |
|---|---|---|
| PostgreSQL only; no SQLite fallback in settings | `settings.py:69-78` | `CONFIRMED` |
| `CONN_MAX_AGE=60` persistent connections | `settings.py:77` | `CONFIRMED` |
| 23 migrations across apps | `find backend -path "*/migrations/*.py"` | `CONFIRMED` |
| No migration on container start | `backend/Dockerfile:14` | `CONFIRMED` |
| Migration history verified on PostgreSQL 16.14 | Prior migration integrity audit | `CONFIRMED` |
| Legacy orphan transactions are explicitly deleted | `payments/migrations/0004...`; prior audit | `CONFIRMED` |
| Legacy invoice kinds remain readable | `commerce/migrations/0005...`; prior audit | `CONFIRMED` |

### 9.1 Neon-specific constraints

- Neon's pooled endpoint is PgBouncer in transaction mode. Django's web runtime should use the pooled connection string.
- `manage.py migrate`, `pg_dump`, and operations requiring session state must use the **direct** (non-pooled) endpoint. Neon's own documentation lists `django-admin migrate` as requiring a direct connection. `CONFIRMED` from provider docs.
- `CONN_MAX_AGE=60` is compatible with transaction pooling, but long-lived connections can pin server resources; staging scale makes this negligible.

### 9.2 Migration execution path on Render Free

Render Free web services do not support one-off jobs or shell access. A one-off job uses a base service's build and environment, so a **paid** base service is required.

Options, all requiring owner approval:

1. Promote the backend to Render Starter (`$7/month` list) and run migrations as a one-off job. `RECOMMENDED` for repeatability.
2. Run `python manage.py migrate` from a trusted operator workstation against Neon's **direct** endpoint, with credentials supplied through the environment. `RECOMMENDED` only as a documented manual procedure; it is not CI and leaves no platform audit trail.
3. Do not deploy until a CI/CD migration mechanism exists. `BLOCKED` otherwise.

Automatic migrations at container start are explicitly rejected: they race across instances, can fail after partial application, and are not the repository's contract.

---

## 10. Frontend runtime and proxy

| Finding | Evidence | Status |
|---|---|---|
| Same-origin API proxy route restores Django's trailing slash | `frontend/app/api/[...path]/route.ts:12-19` | `CONFIRMED` |
| `next.config.mjs` also rewrites `/api/:path*` to the backend | `frontend/next.config.mjs:12-16` | `CONFIRMED` |
| Two proxy mechanisms target the same backend | Route handler + rewrite | `CONFIRMED` |
| Rewrites read `API_INTERNAL_URL` at server start | `next.config.mjs:13` | `CONFIRMED` |
| API responses are `no-store`; media proxy is `public, max-age=86400` | `route.ts:62` | `CONFIRMED` |
| `next start` honors `PORT` per Render's documentation | Provider docs | `CONFIRMED` |
| Frontend image remote patterns are localhost-only | `next.config.mjs:7-9` | `CONFIRMED` |

**Proxy redundancy:** the route handler is the component that restores the trailing slash and forwards the body; the rewrite is a second path to the same backend. Depending on Next's route precedence, one may shadow the other. Both currently produce the same destination, so this is a maintenance risk rather than a functional defect. `RECOMMENDED`: remove one mechanism in a future code change, after testing. Not changed here.

**Image configuration:** uploaded media is rendered with plain `<img>` and absolute/S3 URLs, not `next/image`, so the localhost-only `remotePatterns` does not block it. `CONFIRMED` from `public-menu.ts` and component usage.

**Cold start:** Free web services spin down after 15 minutes idle and take roughly a minute to cold start. Both frontend and backend are affected. Staging will feel unavailable after idle periods. `CONFIRMED` from provider docs.

---

## 11. Container and deployment mechanics

| Item | Finding | Status |
|---|---|---|
| Backend base image | `python:3.12-slim`, not digest-pinned | `CONFIRMED` |
| Backend user | Non-root `app` | `CONFIRMED` — `Dockerfile:9-12` |
| Backend port | Hardcoded `8000`; `EXPOSE 8000` | `CONFIRMED` — `Dockerfile:13-14` |
| Backend workers | 3 | `CONFIRMED` |
| Frontend base image | `node:20-alpine`, not digest-pinned | `CONFIRMED` |
| Frontend user | Non-root `appuser` | `CONFIRMED` — `Dockerfile:39` |
| Frontend port | `EXPOSE 3000`; `next start` reads `PORT` | `CONFIRMED` |
| Frontend build | Full `.next` copied; no standalone server | `CONFIRMED` — `Dockerfile:30-31` |
| Static collection at build | Uses build-only dummy secrets | `CONFIRMED` — `Dockerfile:8` |
| Build-time secrets persisted | No; `ENV` is scoped to the `RUN` instruction | `CONFIRMED` |

### 11.1 Render port binding defect

Render's documented requirement is to bind `0.0.0.0` on `$PORT` (default `10000`). The backend binds `0.0.0.0:8000`. Render's port scanner can sometimes detect a non-default bound port, but relying on detection is not a deployment contract. The frontend is less exposed because `next start` reads `PORT`.

Two remediation paths, both requiring owner authorization because they change code or service config:

- **No code change:** set Render's `PORT` environment variable to `8000`, matching the Dockerfile. `RECOMMENDED` for the first staging deploy, subject to verifying Render honors the override.
- **Code change:** change the Gunicorn bind to `0.0.0.0:${PORT:-8000}`. `RECOMMENDED` as the durable fix.

### 11.2 Render Free instance-hour budget

Render Free includes 750 instance hours per workspace per month. Two free web services running continuously would consume 1,440 hours. Because free services spin down when idle, actual consumption depends on traffic and any keep-alive pings. A staging environment that is kept warm 24/7 will exceed the allowance. `CONFIRMED` from provider docs; staging usage pattern is an `OWNER DECISION REQUIRED`.

---

## 12. Observability, backups, and operations

| Area | Finding | Status |
|---|---|---|
| Application logging | stdout/stderr; Render captures service logs | `CONFIRMED` |
| Error tracking | None (no Sentry or equivalent) | `CONFIRMED` |
| Metrics/APM | None | `CONFIRMED` |
| Uptime alerting | None | `CONFIRMED` |
| Database backups | Neon free restore window only; no application-level backup job | `CONFIRMED` |
| Object storage backups/versioning | None configured | `CONFIRMED` |
| Deploy rollback | Render retains a limited number of recent deploys; database migrations are not rolled back | `CONFIRMED` from provider docs |
| Secrets management | Render environment variables; no vault | `CONFIRMED` |

**Gap:** a staging incident will be diagnosed from logs alone. This is acceptable for a short staging pilot only if the owner accepts it. `RECOMMENDED`: add error tracking and an uptime check before inviting external testers.

---

## 13. Findings register

Severity reflects staging impact, not production criticality.

| ID | Finding | Severity | Status | Evidence | Required action |
|---|---|---|---|---|---|
| A-01 | Uploaded media unreachable in filesystem mode on Render | Critical | `CONFIRMED` | `config/urls.py:22-25`; `Caddyfile.common:14-17`; Render Free docs | Enable R2/S3 before deploy, or declare uploads out of scope |
| A-02 | Backend binds `8000`, not Render `$PORT` | High | `CONFIRMED` | `backend/Dockerfile:14`; Render web-service docs | Set `PORT=8000` or change bind command |
| A-03 | No Render Free path for migrations/admin promotion | High | `BLOCKED` | Render Free docs; no shell/one-off jobs | Paid backend, operator-run migration, or defer |
| A-04 | Readiness probe burns Redis quota and amplifies outages | High | `INFERRED` | `health.py:56-79`; Upstash free docs | Health-check `/live/`, smoke-test `/ready/` |
| A-05 | Two free services can exceed 750 instance hours | Medium | `CONFIRMED` | Render Free docs | Accept cold starts, schedule uptime, or pay |
| A-06 | JWT in `localStorage` is XSS-readable | High | `CONFIRMED` | `frontend/lib/api.ts:11,32,44` | Accept for staging or move to httpOnly cookies |
| A-07 | No server-side logout/revocation; rotation not blacklisted | Medium | `CONFIRMED` | `settings.py:176-181`; `auth.tsx:81` | Accept for staging; plan revocation for production |
| A-08 | Admin UI served to unauthenticated users; APIs protected | Medium | `CONFIRMED` | `admin-shell.tsx:49-60`; `admin_views.py` | Accept; protect Django admin credentials |
| A-09 | Production host/CSRF values are placeholders | High | `CONFIRMED` | `.env.example:11-12`; `settings.py:19,196` | Set both Render hostnames and custom domains |
| A-10 | App-level SSL redirect off; proxy trust off by default | Medium | `CONFIRMED` | `settings.py:28,34-35` | Set `DJANGO_TRUST_PROXY_SSL=True`; rely on Render edge redirect |
| A-11 | HSTS disabled by default | Low | `CONFIRMED` | `settings.py:31` | Enable after HTTPS verification |
| A-12 | S3 signed URLs break PWA offline image caching | Medium | `CONFIRMED` | `sw.js:97-98,131-140` | Owner decision; proxy media or accept online-only images |
| A-13 | No application-level upload size limit | Medium | `CONFIRMED` | `businesses/serializers.py:11,45`; no Caddy on Render | Add limit before public uploads |
| A-14 | No CI/CD or `render.yaml` | Medium | `CONFIRMED` | Files absent | Manual deploy runbook for staging |
| A-15 | Expiry notifications have no scheduler | Medium | `CONFIRMED` | No Celery/Beat/cron service | Run manually or add scheduler later |
| A-16 | Telegram bot has no worker topology | High if enabled | `CONFIRMED` | `run_telegram_bot`; no worker service | Keep disabled |
| A-17 | Zarinpal callback must target backend, not frontend | High if wrong | `CONFIRMED` | `settings.py:206`; `urls.py:19` | Set exact backend callback URL |
| A-18 | No error tracking or uptime alerting | Medium | `CONFIRMED` | No integration | Add before external testers |
| A-19 | `CONN_MAX_AGE=60` with pooled Neon | Low | `CONFIRMED` | `settings.py:77`; Neon pooling docs | Use pooled URL for web, direct for migrations |
| A-20 | Duplicate API proxy mechanisms | Low | `CONFIRMED` | `next.config.mjs:12-16`; `route.ts` | Consolidate in a later code change |
| A-21 | Forwarded headers copied from client by Next proxy | Low | `INFERRED` | `route.ts:24-37` | Validate spoofing behavior during staging |
| A-22 | Build images are not digest-pinned | Low | `CONFIRMED` | Dockerfiles | Pin digests when reproducibility matters |
| A-23 | Free Postgres unsuitable (expiry/limits) | Medium | `CONFIRMED` | Render Free docs | Use Neon Free, not Render Postgres |
| A-24 | No database backup job | Medium | `CONFIRMED` | No backup automation | Rely on Neon restore window; document |

---

## 14. What was not tested

The following are `NOT TESTED` and must not be read as passes:

- No Render service was created, built, or deployed.
- No Neon, Upstash, R2, or S3 resource was provisioned or connected.
- No container image was built during this phase.
- No external database migration was executed.
- No DNS, TLS certificate, or custom domain was configured.
- No real Zarinpal request, payment, callback, or refund occurred.
- No real OTP was sent or verified.
- No Telegram polling or message occurred.
- No browser automation drove the `localStorage` login/logout flow.
- No load, stress, or soak test was run.
- No dependency vulnerability scan or container image scan was run.
- No backup restore was performed.

---

## 15. Audit conclusion

The application is internally consistent and its core transactional behavior has been verified. The staging plan cannot treat Render Free as a drop-in replacement for the Compose stack:

- media requires object storage;
- migrations require an execution path Render Free does not provide;
- the backend port contract must be corrected;
- health checks must not depend on a free Redis quota.

These are decisions and small, explicit changes — not reasons to rewrite the application. They are carried into the Phase 3.1 decision matrix, architecture, and execution plan.

**Phase 3.0 status:** `AUDIT COMPLETE — BLOCKERS IDENTIFIED FOR OWNER DECISION`
