# JAM Post-Legacy Runtime Verification

**Date:** 2026-11-10\
**Status:** CONFIRMED / FIXED\
**Database:** PostgreSQL 16.14, isolated local compose instance `jam_postlegacy_runtime`\
**Cache:** Redis 7, isolated local compose instance on `127.0.0.1:56379`\
**Credentials:** supplied through local environment variables; not recorded here.

## 1. Backend startup

Command shape:

```bash
DJANGO_DEBUG=true \
POSTGRES_HOST=127.0.0.1 POSTGRES_PORT=55432 \
POSTGRES_DB=jam_postlegacy_runtime POSTGRES_USER=jam \
REDIS_URL=redis://127.0.0.1:56379/1 CACHE_REQUIRE_REDIS=true \
python manage.py runserver 127.0.0.1:8001 --noreload
```

Results:

| Check | Result |
|---|---|
| Process starts | CONFIRMED |
| PostgreSQL connection | CONFIRMED |
| Redis cache reachable | CONFIRMED |
| Model import errors | None |
| Missing migration errors | None |
| `GET /api/health/live/` | 200 `{"status":"live"}` |
| `GET /api/health/ready/` | 200 `{"status":"ready","checks":{"database":"ok","cache":"ok"}}` |

## 2. Runtime bug found and fixed

### Password-setting failure — FIXED

`AUTH_PASSWORD_VALIDATORS` in `backend/config/settings.py` was a list of strings. Django expects a list of `{"NAME": ...}` dictionaries. Any real `set_password()` call raised:

```text
TypeError: string indices must be integers, not 'str'
```

The automated tests missed this because they create users without passwords.

**Fix:** validators are now in Django's required dictionary format.\
**Regression test:** `accounts.tests.PasswordConfigurationTests.test_create_superuser_with_password_uses_valid_validator_config`.

## 3. Runtime data

Created in the isolated runtime database:

- admin/superuser with a real password,
- business, active menu, category, product,
- paid canonical purchase and MENU entitlement,
- business/menu without an entitlement.

This exercised canonical purchase and entitlement model imports and writes.

## 4. Backend smoke results

| Path | Result |
|---|---|
| `GET /api/subscriptions/products/` | 200, five seeded products |
| `GET /api/public/menus/runtime-menu/` | 200, canonical menu payload |
| `GET /api/qr/runtime-menu/` | 200, public URL + PNG data URI |
| `GET /api/commerce/public/stores/` | 200, only entitled store listed |
| `GET /api/public/menus/no-ent-menu/` | 404, no MENU entitlement |
| `GET /api/products/` with JWT | 200 |
| `POST /api/products/` with MENU entitlement | 201 |
| `POST /api/products/` without MENU entitlement | 403 |
| `GET /api/admin/overview/` with admin JWT | 200 |
| `GET /api/admin/subscriptions/` with admin JWT | 200 |
| `GET /api/admin/payments/` with admin JWT | 200 |
| `POST /api/subscriptions/purchases/` without configured provider | 503 `payment_provider_unconfigured` |

The 503 test also confirmed **no purchase row was created** (count unchanged at 1).

## 5. Frontend runtime

Command shape:

```bash
API_INTERNAL_URL=http://127.0.0.1:8001 \
NEXT_PUBLIC_API_BASE=/api \
npm run dev -- --hostname 127.0.0.1 --port 3000
```

Results:

| Route | Result |
|---|---|
| `/` | 200, rendered home page |
| `/subscriptions` | 200, canonical product catalog |
| `/panel/plan` | 200, purchase/entitlement plan page |
| `/admin/subscriptions` | 200, admin shell route |
| `/m/runtime-menu` | 200, public menu for entitled business |

Next.js compiled each route successfully. No runtime exception, missing module, or removed-legacy API error appeared in the frontend or backend logs.

**Limitation:** the admin route was verified as a served route and its admin APIs were verified with an authenticated JWT. The browser’s `localStorage` session flow was not driven with browser automation because no Playwright/Puppeteer dependency exists in the project. No new browser automation dependency was added.

## 6. External boundaries

- No real ZarinPal request or payment.
- No Telegram polling or message.
- No OTP operation.
- No deployment or external database access.
- Purchase initiation was exercised only through the safe unconfigured-provider path; mocked provider success/callback behavior is covered by the backend tests.

## 7. Shutdown

Backend and frontend processes started for this verification were stopped after the smoke checks. The compose PostgreSQL/Redis services and disposable databases were local-only.
