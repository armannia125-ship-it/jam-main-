# JAM Batch 1.5 — Legacy Subscription Removal Audit

**Status:** AUDIT COMPLETE — READY FOR OWNER REVIEW  
**Date:** 2026-11-10  
**Branch:** `main`  
**HEAD:** `fdb1add6cf56b852e07aa804a19c3bb7736fac18`  
**Scope:** Read-only audit and documentation only. No application code, schema, migration, database, frontend, infrastructure, commit, push, or deploy changes were made.

## 1. Owner decisions applied

The owner has explicitly decided that JAM is unreleased, has no existing users or historical subscription records, legacy compatibility is unnecessary, and the legacy `Subscription` system must be completely removed. The new `SubscriptionPurchase` + `SubscriptionEntitlement` architecture must be the sole source of truth. No backward compatibility, grandfathering, dual-model access checks, or legacy fallback behavior may be introduced. Product prices, durations, product definitions, entitlement types, and previously approved business rules must remain unchanged.

## 2. Baseline

Pre-existing uncommitted changes were preserved and remain unchanged:

- 9 tracked files modified: `.env.example`, `backend/Dockerfile`, `backend/config/health.py`, `backend/config/settings.py`, `backend/config/test_settings.py`, `backend/config/tests.py`, `backend/requirements.lock.txt`, `backend/requirements.txt`, `backend/test_settings.py`.
- Pre-existing untracked files include `AGENTS.md`, Batch 1.3/1.4 documents, deployment assessment, and `docs/deployment/`.
- This batch adds only the three requested documents under `/docs/audits/`.
- No root-level audit/decision document was created by this batch. Existing root-level Batch 1.3/1.4 documents are reported separately as documentation-governance observations.

## 3. Evidence labels

- `CONFIRMED` — directly established by source code, migration, or executed test.
- `INFERRED` — reasoned from source behavior; not directly tested.
- `ODR` — owner decision required.
- `NOT TESTED` — no automated/manual runtime proof.

## 4. Legacy dependency inventory

### 4.1 Backend subscription models

| Symbol | Location | Legacy role | Removal impact |
|---|---|---|---|
| `SubscriptionPlan` | `backend/subscriptions/models.py` | Legacy single plan catalog | Remove model, admin, serializer, service, migration table |
| `Subscription` | `backend/subscriptions/models.py:56-87` | Legacy subscription record and access source | Remove model, admin, serializer, services, views, migration table |
| `ActivationCode` | `backend/subscriptions/models.py:93-230` | Offline activation code issuance/redemption | Remove model and admin |
| `ActivationCodeEvent` | `backend/subscriptions/models.py:249-270` | Audit events for legacy codes | Remove model and admin |
| `Subscription` serializer | `backend/subscriptions/serializers.py` | Legacy API serialization | Remove or replace with purchase/entitlement serializers |
| `SubscriptionPlanSerializer` | `backend/subscriptions/serializers.py` | Legacy plan serialization | Remove |
| `request_manual_subscription` | `backend/subscriptions/services.py` | Creates pending legacy subscriptions | Remove |
| `canonical_plan` | `backend/subscriptions/services.py` | Exposes legacy plan | Remove |
| `manual_payment_info` | `backend/subscriptions/services.py` | Legacy manual payment instructions | Remove or replace with online purchase documentation only |

### 4.2 Backend access-control fallbacks

| Location | Legacy dependency | Required replacement |
|---|---|---|
| `backend/subscriptions/entitlements.py:41-61` `menu_access()` | Checks `Subscription` after MENU entitlement | Remove fallback; MENU entitlement only |
| `backend/subscriptions/entitlements.py:63-86` `club_access()` | Checks `ClubMembership` after CLUB entitlement | Remove fallback; CLUB entitlement only |
| `backend/subscriptions/entitlements.py:88-106` `product_limit()` | Legacy active subscription grants unlimited products | Remove fallback; entitlement product limit only |
| `backend/businesses/views.py:107-130` `PublicMenuView` and `QrCodeView` | Filter `business__subscriptions` | Filter valid MENU entitlement |
| `backend/commerce/services.py:360-370` `public_store_directory()` | Filter `business__subscriptions` | Filter valid MENU entitlement |
| `backend/bot/management/commands/run_telegram_bot.py:43-50` `business_has_active_subscription()` | Queries legacy `Subscription` | Use `menu_access()` or a new entitlement-only helper |

### 4.3 Backend API, admin, and payment paths

| Location | Legacy dependency | Required replacement |
|---|---|---|
| `backend/subscriptions/urls.py` | `plans/`, `mine/`, `request/`, `payment-info/`, `redeem/`, `checkout/` legacy endpoints | Remove legacy endpoints; retain only product/purchase/notification endpoints |
| `backend/subscriptions/views.py` | `PlanListView`, `MySubscriptionsView`, `PaymentInfoView`, `ManualSubscriptionRequestView`, `CheckoutView`, `RedeemCodeView`, `BotActivationCodeView` | Remove or replace with entitlement/purchase status APIs |
| `backend/subscriptions/purchase_views.py` | `LegacyManualSubscriptionView` returns 410 for removed flow | Remove after frontend/API consumers are updated |
| `backend/subscriptions/admin.py` | Registers `Subscription`, `ActivationCode`, `SubscriptionPlan` and manual actions | Remove legacy registrations and actions |
| `backend/payments/views.py:78-95` | Legacy `subscription` target and `PAYMENT_CONFIRMED` transition | Remove legacy branch; purchase-only verification |
| `backend/payments/models.py` | `Transaction.subscription` FK and `transaction_has_one_target` constraint | Remove FK and update constraint to require purchase |
| `backend/accounts/admin_views.py:343-344` | Counts active legacy subscriptions | Remove count |
| `backend/accounts/admin_views.py:75-76` | Counts active/trial legacy `ClubMembership` | Remove legacy count; count new CLUB entitlements only |

### 4.4 Commerce and club membership

| Location | Legacy dependency | Required replacement |
|---|---|---|
| `backend/commerce/models.py:303` `ClubMembership` | Legacy club visibility and trial state | Remove model or replace with a non-subscription agreement record if a business decision requires retaining agreement metadata |
| `backend/commerce/services.py:160-225` | Creates/updates `ClubMembership` | Replace with CLUB entitlement creation/revocation |
| `backend/commerce/services.py:244-270` | Simulated payment activates `ClubMembership` | Replace with entitlement activation or remove simulated path |
| `backend/commerce/admin.py:46` | Registers `ClubMembership` | Remove registration |
| `backend/commerce/services.py:959-973` `club_access`-related logic | Legacy `ClubMembership` fallback | CLUB entitlement only |

### 4.5 Telegram bot and frontend

| Location | Legacy dependency | Required replacement |
|---|---|---|
| `backend/bot/management/commands/run_telegram_bot.py:11,43-70` | Legacy `Subscription` and code issuance | Use entitlement policy and new purchase flow if bot support is retained |
| `frontend/lib/subscriptions.ts` | Manual request, payment info, redeem, legacy status types | Replace with purchase/entitlement status APIs |
| `frontend/app/panel/plan/page.tsx` | Manual payment request and activation-code redemption | Replace with new purchase/entitlement UI or remove |
| `frontend/app/panel/subscriptions/page.tsx` | Legacy subscription types/status assumptions | Replace with purchase/entitlement types |
| `frontend/app/admin/subscriptions/page.tsx` | Legacy admin subscription views | Replace with purchase/entitlement admin views |

### 4.6 Migrations

| Migration | Legacy content |
|---|---|
| `backend/subscriptions/migrations/0001_initial.py` | Creates `Subscription` |
| `backend/subscriptions/migrations/0002_add_payment_confirmed_and_activation_code.py` | Creates `ActivationCode`, adds `PAYMENT_CONFIRMED` |
| `backend/subscriptions/migrations/0003_secure_activation_codes.py` | Secures legacy activation codes |
| `backend/payments/migrations/0003_transaction_purchase_alter_transaction_subscription_and_more.py` | Adds nullable `Transaction.subscription` and `transaction_has_one_target` |
| `backend/commerce/migrations/0001_initial.py` | Creates `ClubMembership` |

New architecture migrations:

- `backend/subscriptions/migrations/0004_subscriptionproduct_subscriptionpurchase_and_more.py`
- `backend/subscriptions/migrations/0005_seed_subscription_products.py`
- `backend/subscriptions/migrations/0006_entitlementnotification.py`

### 4.7 Tests

Legacy-dependent tests include:

- `backend/businesses/tests.py` uses `Subscription`, `SubscriptionPlan`
- `backend/subscriptions/tests.py` extensive legacy subscription and activation code tests
- `backend/subscriptions/test_concurrency.py` legacy code concurrency tests
- `backend/subscriptions/test_legacy_compatibility.py` dual-model compatibility tests
- `backend/commerce/tests.py` legacy subscription and `ClubMembership` tests
- `backend/payments/tests.py` legacy subscription tests
- Frontend legacy manual subscription UI tests if any

These tests must be replaced or removed in implementation batches; no tests were changed in this audit.

### 4.8 Documentation

Documentation requiring update or obsolescence marking includes:

- `docs/LEGACY_COMPATIBILITY.md`
- `docs/MANUAL_SUBSCRIPTION_WORKFLOW.md`
- `docs/MANUAL_ACTIVATION_SECURITY_AUDIT.md`
- `docs/SUBSCRIPTION_ARCHITECTURE.md`
- `docs/SINGLE_SUBSCRIPTION_MODEL.md`
- `docs/PRODUCTION_OPERATIONS_RUNBOOK.md`
- `docs/DEPLOYMENT_FOUNDATION_BASELINE.md`
- `docs/DEPLOYMENT_FOUNDATION_FINAL_REPORT.md`
- `docs/PAYMENT_AND_FINANCIAL_INTEGRITY_AUDIT.md`
- `docs/JAM_BATCH_1_3_AGENT_GOVERNANCE_AUDIT.md`
- `docs/JAM_BATCH_1_4_PUBLIC_MENU_ENTITLEMENT_AUDIT.md`
- `docs/JAM_BATCH_1_4_PUBLIC_MENU_ENTITLEMENT_DECISION_BRIEF.md`
- `AGENTS.md`

## 5. New architecture sufficiency assessment

The new architecture is sufficient to replace the legacy system for subscription access control, with the following confirmed capabilities:

1. `SubscriptionPurchase` records buyer, business, product, status, and price snapshot.
2. `SubscriptionEntitlement` independently represents MENU and CLUB access.
3. Gold creates MENU and CLUB entitlements atomically.
4. Seller Club creates CLUB only.
5. MENU products create MENU only.
6. Validity is server-side: `status=ACTIVE` and `starts_at <= now < ends_at`.
7. Renewal stacking is deterministic: `max(now, latest current entitlement end)`.
8. Revocation is isolated to the targeted entitlement.
9. Expiry does not delete business data.
10. Purchase ownership is enforced by `Business.objects.filter(pk=business_id, owner=request.user)`.

Gaps that must be closed before legacy removal:

- `menu_access()` still falls back to legacy `Subscription`.
- `club_access()` still falls back to `ClubMembership`.
- `product_limit()` still grants unlimited products for legacy subscriptions.
- Public menu, QR, and directory still filter legacy `Subscription`.
- Bot editing still checks legacy `Subscription`.
- Payment callback still has a legacy branch.
- Admin overview and admin subscription UI still reference legacy models.
- Frontend still exposes manual request, payment info, and redemption flows.
- `Transaction.subscription` still permits legacy payment targets.

No business rule gap was found that requires changing product prices, durations, entitlement types, or approved access semantics.

## 6. Public access verification requirements

After removal, the following must be verified:

- A valid MENU entitlement grants public menu URL, QR, and directory access.
- An expired MENU entitlement grants no access.
- A revoked MENU entitlement grants no access.
- CLUB-only access grants no MENU access.
- Unpublished/inactive menus remain inaccessible.
- Multiple valid entitlements do not cause duplicate rows or server errors.
- Public directory, QR, and public menu use the same policy.
- No legacy `Subscription` record grants access.

## 7. Migration and removal strategy

Recommended strategy is a forward-only cleanup migration after all code references are removed:

1. Remove all legacy model references from application code, admin, serializers, services, views, tests, and frontend contracts.
2. Add a new migration that removes `Subscription`, `SubscriptionPlan`, `ActivationCode`, `ActivationCodeEvent`, and `ClubMembership` tables and related indexes/constraints.
3. Alter `Transaction` to remove `subscription` and retain `purchase` as the only target; replace `transaction_has_one_target` with a `purchase` not-null constraint or equivalent.
4. Preserve all historical migrations; do not rewrite migration history without separate owner approval.
5. Verify `makemigrations --check` and fresh database migration in a non-production test database.
6. Verify full backend and frontend regression suites.

No migration or database change was performed in this batch.

## 8. Unresolved questions

1. Should `ClubMembership` be removed entirely, or should any non-subscription agreement metadata be retained separately?
2. Should `SubscriptionPlan` be retained solely for historical reporting, or removed completely?
3. Should the manual payment instruction endpoint remain for support documentation, or be removed with the offline flow?
4. Should bot-based product editing remain supported after legacy removal?
5. Should the frontend panel plan page be replaced by purchase history/entitlement status, or removed?
6. Should admin subscription management be replaced by purchase/entitlement management only?

## 9. Verification performed

- Read `AGENTS.md`, Batch 1.3 and 1.4 documents, canonical subscription docs, and relevant source files.
- Searched backend, frontend, migrations, and docs for legacy dependencies.
- Inspected models, services, views, URLs, admin, payments, commerce, bot, tests, and frontend subscription code.
- Previously executed targeted test command: 16 tests OK.
- Did not run migrations, browser tests, external services, payment, OTP, or Telegram operations.
- Did not modify tracked source files or pre-existing uncommitted files.

## 10. Final status

AUDIT COMPLETE — READY FOR OWNER REVIEW
