# JAM — Phase 3.1 Recommended Staging Architecture (Zero-Cost)

**Document ID:** `JAM-PHASE-3.1-ARCHITECTURE-ZERO-COST-2026-11-11`
**Companion:** `JAM_ZERO_COST_STAGING_PROVIDER_VERIFICATION.md`, `JAM_PHASE_3_1_INFRASTRUCTURE_DECISION_MATRIX.md`, `JAM_PHASE_3_1_DEPLOYMENT_EXECUTION_PLAN.md`, `JAM_ZERO_COST_LOCAL_MIGRATION_RUNBOOK.md`.
**Scope:** Documentation only. No provisioning, billing, code, or deployment.

---

## 1. Binding owner decisions (OWNER DECISION)

$0 budget; no payment method/billing activation to bypass a Free Tier; R2 only if usable without charges; migrations from owner's local dev; no provisioning/commit/push/deployment; frontend must be a genuinely zero-cost option that does not break required product functionality.

---

## 2. Approved zero-cost topology (RECOMMENDATION)

```mermaid
flowchart LR
    U[Browser / PWA] -->|HTTPS| FE[Render Free Web Service<br/>Next.js Node server<br/>port $PORT]
    FE -->|same-origin /api proxy<br/>API_INTERNAL_URL| BE[Render Free Web Service<br/>Django + Gunicorn<br/>port 8000 or $PORT]
    BE -->|pooled -pooler host<br/>CONN_MAX_AGE=60| DB[(Neon Free Postgres<br/>direct host for migrations)]
    BE -->|rediss:// TLS| CA[(Upstash Free Redis)]
    BE -. media disabled in Scenario B .-> FS[(Ephemeral FS<br/>not durable)]
    R2[(Cloudflare R2<br/>CONDITIONAL: card required)] -. only if owner authorises card .-> BE
    FE -. static assets / Next image .-> CDN[Render edge / Next]
```

Notes:
- Both compute services are **Free web services** on one Hobby workspace; they share 750 instance hours and 5 GB outbound bandwidth.
- Telegram bot stays disabled (no worker topology).
- No persistent disk anywhere in the topology.
- Media is either (a) R2 if the owner authorises a card (CONDITIONAL), or (b) operationally disabled (Scenario B, recommended).

---

## 3. Component contracts

### 3.1 Frontend (Render Free Web Service, Docker/Node)

- Image: `frontend/Dockerfile` (Node 20, `npm ci`, `npm run build`, `npm start`).
- Port: honours `PORT` (Render injects 10000); `EXPOSE 3000` is informational.
- Required env (server-side, never `NEXT_PUBLIC_`):
  - `API_INTERNAL_URL=http://<backend-service>.onrender.com` (or private service URL) — **no trailing slash**.
  - `NEXT_PUBLIC_API_BASE=` (empty — same-origin proxy).
  - `NEXT_PUBLIC_DEMO_MODE=False` (mandatory for staging/production).
- Health probe: Render HTTP GET on `/` or a shallow path; **not** `/api/health/ready/` (that is backend-only).
- Cold start: ~1 min; Render shows a loading page. Acceptable for a staging pilot.

### 3.2 Backend (Render Free Web Service, Docker/Python)

- Image: `backend/Dockerfile` (Python 3.12, Gunicorn, `collectstatic` at build).
- Port: see §6 (port mismatch).
- Required env:
  - `DJANGO_DEBUG=False`
  - `DJANGO_SECRET_KEY=<strong random, ≥50 chars>` (not in repo)
  - `OTPY_API_KEY=<provider key>` (not in repo)
  - `POSTGRES_HOST=<neon direct host for migrations; pooled host for runtime>` — runtime should use the **pooled** (`-pooler`) host; migrations use the **direct** host (runbook).
  - `POSTGRES_PORT=5432`, `POSTGRES_DB`, `POSTGRES_USER`, `POSTGRES_PASSWORD`
  - `REDIS_URL=rediss://:<password>@<upstash-host>:6379` (TLS)
  - `CACHE_REQUIRE_REDIS=True` (default when `DEBUG=False`)
  - `DJANGO_ALLOWED_HOSTS=<frontend-host>,<backend-host>` (both Render hostnames + any custom domain)
  - `DJANGO_CSRF_TRUSTED_ORIGINS=https://<frontend-host>,https://<backend-host>`
  - `DJANGO_TRUST_PROXY_SSL=True`
  - `ZARINPAL_SANDBOX=True` (explicit; do not rely on the `DEBUG` default)
  - `ZARINPAL_MERCHANT_ID=` (empty until authorised)
  - `DEFAULT_FILE_STORAGE_BACKEND=django.core.files.storage.FileSystemStorage`
  - `AWS_*` all empty (Scenario B)
- Health probe: **`/api/health/live/`** (process only, zero Redis commands). `/api/health/ready/` is a manual smoke test.
- Cold start: ~1 min; Gunicorn `--timeout 60`.

### 3.3 Database (Neon Free)

- Pooled host (`-pooler`) for the running backend (`CONN_MAX_AGE=60`).
- Direct host (no `-pooler`) for `python manage.py migrate`, `pg_dump`, and any `SET`/session work.
- SSL: Neon requires TLS; psycopg default `sslmode=prefer` negotiates it. No `sslmode` env exists in settings — acceptable for Neon; verify the connection string includes `sslmode=require` if a stricter posture is wanted (that would be a settings change — out of scope here).
- Scale-to-zero after 5 min (fixed on Free); first request after idle pays a ~hundreds-of-ms wake-up. Acceptable.
- Restore window 6 h / 1 GB change history — the only backup for staging.

### 3.4 Cache (Upstash Free)

- Single database, TLS `rediss://`.
- Conservative command budget: target ≤ 300,000 commands/month (see provider verification §2.3).
- No external uptime pinger.

### 3.5 Media (Scenario B default)

- `DEFAULT_FILE_STORAGE_BACKEND=django.core.files.storage.FileSystemStorage`; all `AWS_*` empty.
- Upload endpoints still accept writes to the backend's ephemeral disk; those bytes are lost on restart/spin-down and are not served in production (`settings.DEBUG=False` disables `static()`). This is a **documented limitation**, not a durable media solution.
- `frontend/lib` `mediaSrc()` rewrites `/media/...` to `/api/media-proxy/...`, which proxies to `${API_INTERNAL_URL}/media/...`; with `DEBUG=False` that returns 404. Therefore staging testers must not be told uploads work.
- If the owner authorises a card, switch to R2 by setting `DEFAULT_FILE_STORAGE_BACKEND=storages.backends.s3boto3.S3Boto3Storage` and the three `AWS_*` credentials; `AWS_S3_ENDPOINT_URL=https://<account>.r2.cloudflarestorage.com`; `AWS_DEFAULT_ACL=` (empty, R2 has no ACLs); public access via custom domain or `r2.dev`. This requires a spend alert and an operational upload cap (B-07).

---

## 4. Why the frontend is not a Render Static Site (VERIFIED FACT)

See provider verification §4. Summary: `rewrites()` in `next.config.mjs`, two `force-dynamic` route handlers (`app/api/[...path]/route.ts`, `app/health/route.ts`), `app/page.tsx` `force-dynamic`, four dynamic routes without `generateStaticParams`, and the server-only `API_INTERNAL_URL` proxy. Static export would also force browser→Django cross-origin calls, breaking the same-origin auth model and requiring CORS/localhost changes. **Conclusion: frontend runs as a Render Free Web Service.** This is genuinely $0 (no card) but costs shared instance hours and bandwidth.

---

## 5. Environment contract (additive to `.env.example`)

No code or `.env.example` changes in this revision. The following documents the intended staging values (placeholders only — never commit real values):

| Variable | Staging value (illustrative) | Owner of value |
|---|---|---|
| `DJANGO_DEBUG` | `False` | deploy config |
| `DJANGO_SECRET_KEY` | (generated, ≥50 chars) | owner |
| `OTPY_API_KEY` | (provider key) | owner |
| `POSTGRES_HOST` | pooled host (runtime) / direct host (migrations) | Neon console |
| `POSTGRES_PORT` | `5432` | Neon console |
| `POSTGRES_DB` / `POSTGRES_USER` / `POSTGRES_PASSWORD` | staging-only credentials | owner |
| `REDIS_URL` | `rediss://:...@...upstash.io:6379` | Upstash console |
| `CACHE_REQUIRE_REDIS` | `True` | deploy config |
| `DJANGO_ALLOWED_HOSTS` | `frontend.onrender.com,backend.onrender.com` | deploy config |
| `DJANGO_CSRF_TRUSTED_ORIGINS` | `https://frontend.onrender.com,https://backend.onrender.com` | deploy config |
| `PUBLIC_FRONTEND_URL` | `https://frontend.onrender.com` | deploy config (required for QR codes; fails closed when unset) |
| `DJANGO_TRUST_PROXY_SSL` | `True` | deploy config |
| `ZARINPAL_SANDBOX` | `True` | deploy config |
| `ZARINPAL_MERCHANT_ID` | (empty until authorised) | owner |
| `DEFAULT_FILE_STORAGE_BACKEND` | `django.core.files.storage.FileSystemStorage` | deploy config |
| `AWS_*` | (empty) | n/a |
| `API_INTERNAL_URL` (frontend) | `http://backend.onrender.com` | deploy config |
| `NEXT_PUBLIC_API_BASE` | (empty) | deploy config |
| `NEXT_PUBLIC_DEMO_MODE` | `False` | deploy config |

---

## 6. Port mismatch resolution (OD-12)

See provider verification §5. Options:
- **A (try first, no code change):** set `PORT=8000` in the Render backend service env. Render routes to the port the service listens on; with `PORT=8000` the proxy targets 8000. Unverified on Free — validate during the authorised deploy.
- **B (durable, requires authorised change):** change the Gunicorn bind in `backend/Dockerfile` to `--bind 0.0.0.0:${PORT:-8000}`. One-line edit; out of scope for this docs revision.
- Frontend is unaffected (`next start` honours `PORT`).

**Rule:** do not silently edit the Dockerfile in this revision. Escalate to Option B only after Option A is observed to fail.

---

## 7. Failure modes and mitigations

| Failure | Impact | Mitigation |
|---|---|---|
| Bandwidth exhausted (5 GB) | All Free services suspended for rest of month | Monitor usage weekly; compress images; no keep-alive pingers; avoid large exports |
| Instance hours exhausted (750) | All Free web services suspended | Accept cold starts; never run keep-alive pingers; monitor first month |
| Build minutes exhausted (500) | New builds paused; last build keeps running | Batch deploys; avoid unnecessary rebuilds |
| Neon compute/storage exceeded | Compute suspended / writes blocked | Monitor CU-hours; keep staging data small; no load testing against staging |
| Neon transfer exceeded (5 GB) | Compute suspended | Avoid large media; Scenario B helps |
| Upstash commands exceeded (500k) | Cache command errors (throttling/auth may degrade) | `/live/` probe only; no pinger; monitor |
| Render cold start (~1 min) | First request after idle is slow; proxy may 502 if backend not yet up | Frontend should tolerate retry; no SLA for staging |
| Ephemeral filesystem wiped | Uploaded media lost | Scenario B: do not promise uploads |
| R2 payment failure (if approved) | R2 inaccessible; data deleted after 30 days | Spend alert; operational upload cap; restore from backup |
| Neon scale-to-zero wake-up | First query after 5 min idle is slower | Acceptable; no keep-alive |
| Secret leakage | Full compromise | Env vars only in Render dashboard; never in repo; `.env` git-ignored |

---

## 8. Security posture carried into staging (VERIFIED FACT / RECOMMENDATION)

- Admin authorisation remains server-side (`IsAdmin`); client checks cosmetic.
- `make_admin --phone` promotes an existing active user only; first admin must already exist as a user.
- JWT stays in `Authorization: Bearer` via `frontend/lib/api.ts`; `localStorage` remains (documented XSS risk; not changed here).
- Payment state changes only after server-side Zarinpal verification; callback targets the backend (`/api/payments/zarinpal/callback/`).
- `ZARINPAL_SANDBOX=True` explicit for staging; merchant ID empty until authorised.
- Readiness reports only `ok`/`unavailable`; no URLs/credentials/stack traces.
- Public media is public; no sensitive documents in `MEDIA_ROOT`/R2.
- No OTP bypass; no real OTP sends without authorisation.

---

## 9. Rejected alternatives (with reasons)

| Alternative | Reason rejected |
|---|---|
| Render Static Site for frontend | Incompatible (§4) |
| Vercel Hobby for frontend | Commercial use prohibited (JAM is a marketplace) |
| Cloudflare Workers/Pages free for frontend | Requires code/adapter changes not authorised here |
| Render Free Postgres | Expires 30 days after creation |
| Render Free Key Value | 25 MB, non-persistent |
| R2 as default media | Requires card + uncapped overage (BLOCKER under $0) |
| Ephemeral filesystem as durable media | Data loss on restart/spin-down; not a media solution |
| Auto-migration at container startup | Forbidden (Render Free has no shell; startup migration is an unreviewed destructive path) |
| Keep-alive pingers | Would exhaust 750 instance hours and defeat spin-down |

---

## 10. Rollback posture

- Render: rollback to the two most recent previous deploys is supported on Free. A failed health check keeps the previous deploy live.
- Neon: restore from the 6-hour / 1 GB change-history window, or restore from a branch created before the migration. **Django migrations are not universally reversible** (e.g. `payments` 0004 removes rows); forward-fix or branch restore, never `migrate --fake` or hand-edited down-migrations.
- Upstash: no restore; cache is ephemeral by design.
- R2 (if approved later): versioning not assumed; treat as append-only.

---

## 11. What this document does not authorise

No provisioning, account creation, billing activation, code/env/Dockerfile/Compose/Caddy/migration/dependency changes, git commit/push, or deployment. Those require separate explicit owner authorisation.