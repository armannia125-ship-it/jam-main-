# JAM — Phase 3.1 Architecture Comparison: Netlify + Supabase vs Neon vs Render

**Document ID:** `JAM-PHASE-3.1-ARCHITECTURE-COMPARISON-2026-11-11`
**Companion:** `JAM_PHASE_3_1_NETLIFY_SUPABASE_COMPATIBILITY_AUDIT.md`, `JAM_PHASE_3_1_PROVIDER_ACCESS_PREFLIGHT.md`, `JAM_PHASE_3_1_ARCHITECTURE_COMPARISON_REPORT.md`, and the existing Phase 3.1 zero-cost set.
**Checked date:** 2026-11-11 (official provider docs/pricing via web search).
**Scope:** Documentation and research only. No provisioning, billing, code, migration, or deployment.

---

## 1. Binding owner decisions (OWNER DECISION)

1. Cloud hosting preferred.
2. Strict $0 budget; no paid upgrades.
3. No payment method or billing activation solely to bypass a Free Tier limitation.
4. R2 only if usable without charges.
5. Database migrations from the owner's local environment.
6. No provisioning, commit/push, or deployment in this revision.
7. Frontend must be a genuinely zero-cost option that does not break required product functionality.

## 2. Architectures compared

- **Architecture A — Netlify + Supabase + Render + Upstash:** Netlify (Next.js frontend), Supabase (PostgreSQL + Storage), Render Free (Django backend), Upstash Free (Redis).
- **Architecture B — Netlify + Neon + Render + Upstash:** Netlify (frontend), Neon Free (PostgreSQL), Render Free (backend), Upstash Free (Redis); media = R2 only if it satisfies the $0 policy, otherwise uploads disabled.
- **Architecture C — Render Free + Neon + Upstash (baseline):** Render Free (frontend + backend), Neon Free (PostgreSQL), Upstash Free (Redis); media uploads disabled operationally.

Media is evaluated separately from the database in every architecture.

## 3. Provider facts (VERIFIED FACT, checked 2026-11-11)

### 3.1 Netlify (Free, credit-based)

| Item | Value | Source |
|---|---|---|
| Cost | $0, 300 credits/month, hard limit, no auto-recharge, no card | netlify.com/pricing; docs.netlify.com billing | 2026-11-11 |
| Credit costs | Production deploy 15; compute 10/GB-hour; bandwidth 20/GB; web requests 2/10k; forms free; preview/branch deploys free | netlify.com/pricing | 2026-11-11 |
| Commercial use | Allowed on Free plan (Netlify blog "Introducing Netlify's Free plan") | netlify.com/blog/introducing-netlify-free-plan | 2026-11-11 |
| Overage behaviour | Site suspended for remainder of month; no billing on Free | netlify.com/blog/introducing-netlify-free-plan | 2026-11-11 |
| Next.js App Router | Full support (SSR, ISR, PPR, RSC, Server Actions, streaming, Middleware via Edge Functions, Route Handlers, rewrites, image optimization) | docs.netlify.com frameworks/next-js/overview | 2026-11-11 |
| Card required | No | netlify.com/pricing | 2026-11-11 |

### 3.2 Supabase (Free)

| Item | Value | Source |
|---|---|---|
| Projects | 2 active Free projects per account | supabase.com/docs/guides/platform/billing-on-supabase | 2026-11-11 |
| Database size | 500 MB (read-only beyond); 2 GB fixed disk | supabase.com/docs/guides/platform/database-size | 2026-11-11 |
| Compute | Nano: shared CPU, up to 0.5 GB RAM | supabase.com/docs/guides/platform/compute-and-disk | 2026-11-11 |
| Connections (Nano) | 60 direct; 200 pooler clients; default pool size 15 | supabase.com/docs/guides/platform/compute-and-disk | 2026-11-11 |
| Egress | 5 GB/month (cached 5 GB) | supabase.com/pricing | 2026-11-11 |
| Storage | 1 GB; max file size 50 MB on Free | supabase.com/docs/guides/storage/pricing; supabase.com/storage | 2026-11-11 |
| Pause | Free projects pause after 1 week inactivity; unpausing restores | supabase.com/pricing | 2026-11-11 |
| Backups | None on Free (Pro gets 7-day daily) | supabase.com/docs/guides/platform/billing-on-supabase | 2026-11-11 |
| Card required | No; overage prevented by hard caps | supabase.com/pricing | 2026-11-11 |
| S3 compatibility | Yes (AWS Sig V4), addressing_style=path, endpoint `https://<project>.supabase.co/storage/v1/s3` | supabase.com/docs/guides/storage/s3/compatibility | 2026-11-11 |

### 3.3 Neon (Free) — re-verified

| Item | Value | Source |
|---|---|---|
| Projects | 100 per account | neon.com/docs/introduction/plans | 2026-11-11 |
| Compute | 100 CU-hours/project/month; autoscale to 2 CU; scale-to-zero after 5 min (fixed) | neon.com/docs/introduction/plans | 2026-11-11 |
| Storage | 1 GB/project (20 GB total) | neon.com/docs/introduction/plans | 2026-11-11 |
| Transfer | 5 GB/project/month, shared across Postgres/Object Storage/Functions | neon.com/docs/introduction/plans | 2026-11-11 |
| Branches | 10 per project | neon.com/docs/introduction/plans | 2026-11-11 |
| Restore | 6 hours / 1 GB change history | neon.com/docs/introduction/plans | 2026-11-11 |
| Object Storage | 5 GB/project, S3-compatible | neon.com/docs/introduction/plans | 2026-11-11 |
| Card required | No; compute suspended / writes blocked on exceed | neon.com/docs/introduction/plans | 2026-11-11 |
| Pooling | PgBouncer transaction mode (`-pooler`); direct required for migrations | neon.com/docs/connect/connection-pooling | 2026-11-11 |

### 3.4 Render (Free) — re-verified

| Item | Value | Source |
|---|---|---|
| Instance hours | 750/workspace/month, shared across all Free web services; spun-down services consume none; exhaustion suspends all until next month | render.com/docs/free | 2026-11-11 |
| Compute | 0.1 CPU / 512 MB; 1 instance; spins down after 15 min idle; ~1 min cold start | render.com/docs/free | 2026-11-11 |
| Bandwidth | 5 GB/workspace/month (Hobby); overage suspends without card, bills $0.15/GB with card | render.com/docs/outbound-bandwidth | 2026-11-11 |
| Build minutes | 500/workspace/month; exhaustion pauses new builds | render.com/docs/free | 2026-11-11 |
| Filesystem | Ephemeral; no persistent disk on Free | render.com/docs/free | 2026-11-11 |
| Shell/one-off jobs | Not available on Free | render.com/docs/free | 2026-11-11 |
| Port | Default `PORT=10000`; bind `0.0.0.0`; Render usually detects a different bound port | render.com/docs/web-services | 2026-11-11 |
| Health checks | TCP by default; HTTP GET path configurable; every few seconds on running instances | render.com/docs/health-checks | 2026-11-11 |
| Card required | No | render.com/docs/free | 2026-11-11 |

### 3.5 Upstash (Free) — re-verified

| Item | Value | Source |
|---|---|---|
| Data size | 250 MB (256 MB in some docs) | upstash.com/pricing/redis | 2026-11-11 |
| Commands | 500,000/month (FAQ says 10,000/day — unreconciled) | upstash.com/pricing/redis; upstash.com/docs/redis/help/faq | 2026-11-11 |
| Bandwidth | 10 GB/month | upstash.com/pricing/redis | 2026-11-11 |
| Databases | 1 | upstash.com/pricing/redis | 2026-11-11 |
| Throughput | 10,000 commands/s; 10 MB request; 100 MB record | upstash.com/pricing/redis | 2026-11-11 |
| TLS | `rediss://` | upstash.com/docs/redis | 2026-11-11 |
| Overage | Command errors (inferred); auto-upgrade can bill if a card is added — keep disabled | upstash.com/docs/redis/features/auto-upgrade | 2026-11-11 |
| Card required | No | upstash.com/pricing/redis | 2026-11-11 |

### 3.6 Cloudflare R2 (media)

| Item | Value | Source |
|---|---|---|
| Free tier | 10 GB-month storage; 1M Class A; 10M Class B; egress free | developers.cloudflare.com/r2/pricing | 2026-11-11 |
| Activation | Requires R2 subscription via checkout with a payment method on file | developers.cloudflare.com/r2/get-started | 2026-11-11 |
| Billing | Usage-based, no hard cap; monthly billing; payment failure → access errors, data deleted after 30 days | developers.cloudflare.com/billing/understand/faq | 2026-11-11 |
| Card required | Yes | developers.cloudflare.com/r2/get-started | 2026-11-11 |

**Conclusion:** R2 is not $0-compliant under the binding owner decision (payment method required + uncapped overage).

---

## 4. JAM-specific compatibility (repository-derived)

### 4.1 Netlify frontend compatibility (full detail in compatibility audit)

All six items that blocked a Render Static Site are supported by Netlify's current adapter:
1. `rewrites()` — supported.
2. Catch-all route handler `app/api/[...path]/route.ts` (`force-dynamic`, all methods) — supported (Route Handlers).
3. `app/health/route.ts` (`force-dynamic`) — supported.
4. `app/page.tsx` (`force-dynamic`) — SSR supported.
5. Four dynamic routes without `generateStaticParams` — SSR supported.
6. Runtime `API_INTERNAL_URL` — read at runtime by the adapter's serverless function.

Additional: same-origin `/api` proxy and JWT-in-`localStorage` model preserved; no CORS changes needed. Two config items need attention: `images.remotePatterns` (add the production media host) and the duplicate proxy mechanisms (keep both; do not remove without testing).

### 4.2 Django / database compatibility

- **Neon**: transaction pooling via PgBouncer (`-pooler`); direct host for migrations. JAM uses `select_for_update` and `transaction.atomic`; compatible with transaction pooling in principle (no session-level state detected). `CONN_MAX_AGE=60` acceptable. SSL via psycopg default `prefer`.
- **Supabase**: transaction pooler (Supavisor, port 6543) and session pooler (port 5432). Same caveat as Neon. Direct host is IPv6-only → use pooler for runtime; session pooler for migrations if local env is IPv4-only (UNVERIFIED). Max 60 direct connections on Nano (not binding if pooler used). Max file size 50 MB on Free storage. No backups on Free.

### 4.3 Media safety

Current code accepts uploads to `FileSystemStorage` (ephemeral on Render) with no application-level size limit (A-13). Deploying with `FileSystemStorage` does **not** disable uploads; it merely makes them ephemeral and unserved in production. A true disable requires an owner-authorised code flag (B-11). This applies to all three architectures. **Do not claim uploads are disabled unless code enforces it.**

### 4.4 Migration feasibility

Binding decision: migrations run from the owner's local environment. Both Neon and Supabase support this in principle, with the Supabase IPv4/IPv6 caveat above. Django migrations are not universally reversible (`commerce/migrations/0004` deletes two models). Forward-fix or restore from backup. No automatic migration at startup (forbidden).

---

## 5. Cost and $0 compliance (ENGINEERING ANALYSIS)

| Architecture | Guaranteed monthly cost | Payment method required | Billing risk | Strict $0 compliant? |
|---|---|---|---|---|
| A (Netlify + Supabase + Render + Upstash) | $0 if all limits respected | No (none of the four requires a card on Free) | Low — all four hard-stop or suspend on exceed; Supabase Free has no overage billing; Netlify Free hard limit; Render suspends; Upstash returns errors | **Yes, subject to limits and no upgrade** |
| B (Netlify + Neon + Render + Upstash) | $0 if all limits respected | No (Neon/Render/Upstash/Netlify need no card; R2 is not used) | Low — same hard-stop behaviour; media disabled | **Yes** (with uploads disabled) |
| C (Render + Neon + Upstash, baseline) | $0 if all limits respected | No | Low — same; but two Render services share 750 hours and 5 GB bandwidth | **Yes** (with uploads disabled) |

Notes:
- Architecture A adds Supabase Storage (1 GB, 50 MB max file) as a media option. If used, it stays $0 only within those caps; uploads beyond 50 MB fail.
- R2 is excluded from $0 compliance (card required + uncapped overage). If the owner later authorises a card, R2 can be added to B or C as a conditional media layer.
- Netlify's 300 credits/month is the tightest single constraint in A and B: 15 credits per production deploy means 20 deploys exhausts the month; a staging workflow with frequent redeploys will hit the wall. Plan deploys carefully.

---

## 6. Failure modes (top five per architecture)

### Architecture A (Netlify + Supabase + Render + Upstash)
1. Netlify credits exhausted → site suspended for remainder of month. Mitigation: batch deploys; preview deploys are free; monitor credit usage.
2. Supabase Free project pauses after 1 week inactivity → first request slow/fails until unpaused. Mitigation: unpause before testing; accept pause.
3. Supabase 500 MB DB / 1 GB storage cap → read-only / upload rejection. Mitigation: keep staging data small; monitor.
4. Render 750 shared instance hours / 5 GB bandwidth → suspension. Mitigation: accept cold starts; no keep-alive pingers; monitor.
5. Upstash 500k commands → cache command errors; throttling degrades. Mitigation: `/live/` probe only; no pinger; conservative 300k target.

### Architecture B (Netlify + Neon + Render + Upstash)
1. Netlify credits exhausted → suspension. Mitigation: as above.
2. Neon compute suspended on CU-hour/transfer exceed → DB unavailable until next period. Mitigation: keep staging data and traffic small; monitor.
3. Render suspension (hours/bandwidth) → as above.
4. Upstash command exhaustion → as above.
5. Media: uploads disabled operationally only (no code flag) → silent acceptance of ephemeral files. Mitigation: document; owner-authorised flag if needed.

### Architecture C (Render + Neon + Upstash, baseline)
1. Render 750 shared instance hours with two services → suspension risk higher than A/B (frontend on Render also consumes hours). Mitigation: accept cold starts; monitor first month.
2. Render 5 GB bandwidth shared across frontend assets + API → suspension. Mitigation: compress images; no large exports.
3. Neon suspension → as above.
4. Upstash command exhaustion → as above.
5. Media: same operational-disable gap.

---

## 7. Comparison matrix

| Dimension | Architecture A (Netlify + Supabase + Render + Upstash) | Architecture B (Netlify + Neon + Render + Upstash) | Architecture C (Render + Neon + Upstash, baseline) |
|---|---|---|---|
| Frontend hosting | Netlify Free (SSR via adapter) | Netlify Free (SSR via adapter) | Render Free Web Service (Docker/Node) |
| Next.js compatibility | Full (App Router, SSR, RSC, Server Actions, Route Handlers, rewrites, middleware) | Full (same) | Full (Node server) |
| Backend hosting | Render Free Web Service | Render Free Web Service | Render Free Web Service |
| Database | Supabase Free (Postgres 15+, Nano compute) | Neon Free (Postgres, 100 CU-h/project) | Neon Free |
| Django compatibility | Compatible with caveats (IPv6 direct host, transaction pooling, no backups) | Compatible (transaction pooling, direct host, SSL) | Compatible (same as B) |
| Redis | Upstash Free | Upstash Free | Upstash Free |
| Media storage | Supabase Storage (1 GB, 50 MB max file, S3-compatible) — optional | Disabled (or R2 if card authorised) | Disabled (or R2 if card authorised) |
| Strict $0 compliance | Yes, if limits respected and no upgrade | Yes | Yes |
| Payment method required | No | No | No |
| Billing risk | Low (hard caps) | Low (hard caps) | Low (hard caps) |
| Geographic availability | Unverified for all providers | Unverified for all providers | Unverified for all providers |
| Database pause behaviour | Pauses after 1 week inactivity | Scale-to-zero after 5 min inactivity | Scale-to-zero after 5 min inactivity |
| Backup and recovery | Manual dumps only (no auto backups on Free) | Neon branch + 6 h/1 GB restore window | Neon branch + 6 h/1 GB restore window |
| Deployment complexity | Higher (3 providers + Netlify adapter + Supabase Storage config) | Medium (3 providers) | Lower (2 providers, one workspace) |
| Operational maintenance | Higher (more quotas to monitor) | Medium | Lower |
| Main failure mode | Netlify credit exhaustion / Supabase pause | Netlify credit exhaustion / Neon suspension | Render instance-hour/bandwidth exhaustion |
| Required code changes | Image remotePatterns config (optional); no mandatory code change | None mandatory | None mandatory (port binding decision pending) |
| Overall suitability | Best technical fit for Next.js; highest operational complexity | Best balance of compatibility and simplicity | Best strict-$0 pilot; lowest operational complexity |

---

## 8. Recommendation

Under the binding constraints (strict $0, no card, cloud hosting, local migrations, no unapproved code changes, no deployment authorisation):

1. **Most practical under strict $0:** Architecture C (Render + Neon + Upstash). Fewest providers, fewest quotas to monitor, no Netlify credit budget, no Supabase pause/backup weakness. Best for a first staging pilot.
2. **Most technically compatible with the current JAM codebase:** Architecture A or B (Netlify frontend). Netlify's adapter supports every JAM frontend feature that blocked a Render Static Site, and the same-origin proxy model is preserved. If the owner values Next.js SSR quality and the Netlify DX, A or B is the better frontend.
3. **Lowest operational risk:** Architecture C. Two providers, one workspace, well-understood limits. Architecture A adds Supabase (pause, no backups, IPv6 caveat) and Netlify credits.
4. **Easiest recovery when a Free Tier limit is reached:** Architecture B/C (Neon). Neon offers a branch-based restore window and `pg_dump` portability; Supabase Free has no automated backups.
5. **Is Netlify + Supabase materially better than Netlify + Neon?** On the database side, Neon is materially better for this project: better restore window, no pause-after-1-week, no IPv6 caveat, more CU-hours, and no storage max-file-size constraint on the DB. Supabase Storage (1 GB, 50 MB max file) is a real, S3-compatible media option that Neon Object Storage (5 GB, unverified django-storages compatibility) is not yet. So: **Netlify + Neon for the database, and consider Supabase Storage only if a verified, $0 media layer is required** — but mixing Supabase Storage with a Neon database adds a third provider for a 1 GB media bucket, which is usually not worth it versus disabling uploads.
6. **Does Supabase Storage provide a real advantage over disabling uploads?** Yes, conditionally: it is S3-compatible, public/private buckets, signed URLs, and genuinely $0 within 1 GB / 50 MB per file. But it adds provider complexity, RLS policy management, and the 50 MB cap. For a staging pilot where uploads are not a required feature, disabling uploads is simpler and lower-risk. For a pilot that must demonstrate uploads, Supabase Storage is the best verified $0 media option (R2 is blocked by the card requirement).
7. **Is a multi-provider architecture worth the complexity?** For staging: no, unless a specific capability (Netlify SSR DX, Supabase Storage uploads) is required. For production: out of scope (not production-ready).
8. **Unavoidable trade-offs under strict $0:** cold starts, sleep/pause, quota ceilings, no backups on some providers, no persistent disk, no shell/one-off jobs, no scheduler. These are inherent to Free Tiers and cannot be engineered away without spending money.

**Recommendation (layered, not a single winner):**
- **Best strict-$0 pilot:** Architecture C (Render + Neon + Upstash).
- **Best technical fit (frontend):** Netlify (A or B) if the owner values the Netlify SSR DX and accepts the 300-credit budget and the added provider.
- **Best media option if uploads must be demonstrated:** Supabase Storage (within 1 GB / 50 MB), with a documented max-file-size caveat — or R2 only if the owner authorises a card.
- **Best database:** Neon (over Supabase) on restore, pause, and compatibility grounds.

If no single architecture satisfies all constraints, the least-risk compromise is **Architecture C for the pilot**, with Netlify evaluated as a frontend swap later if the Render Free frontend proves inadequate. Do not mix Supabase Storage into Architecture C unless uploads are a hard requirement for the pilot.

---

## 9. What this document does not authorise

No provisioning, billing, code, migration, or deployment. Documentation and research only.