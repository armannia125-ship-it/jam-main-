# JAM — Zero-Cost Cloud Staging: Provider Verification

**Document ID:** `JAM-ZERO-COST-PROVIDER-VERIFICATION-2026-11-11`
**Status:** Documentation-only revision. No provisioning, no billing activation, no code, no deployment.
**Checked date:** 2026-11-11 (official provider docs via web search; `read_url` to render.com / developers.cloudflare.com is blocked by network policy, so facts below are attributed to official-doc search snippets and must be re-verified on the live console before any action).
**Cross-references:** `JAM_PHASE_3_1_INFRASTRUCTURE_DECISION_MATRIX.md`, `JAM_PHASE_3_1_RECOMMENDED_STAGING_ARCHITECTURE.md`, `JAM_PHASE_3_1_DEPLOYMENT_EXECUTION_PLAN.md`, `JAM_ZERO_COST_LOCAL_MIGRATION_RUNBOOK.md`.

---

## 1. Binding owner decisions applied (OWNER DECISION)

1. Cloud staging only on Free Tiers; **$0 budget**; no paid upgrades.
2. No payment method or billing activation solely to bypass a Free Tier restriction.
3. Media may use Cloudflare R2 **only** if R2 can be used without any charges.
4. Database migrations run from the owner's local dev environment.
5. No provisioning, no git commit/push, no deployment, no external-service account creation in this revision.
6. Frontend must remain a genuinely zero-cost hosting option; if a free option breaks required product functionality it is not acceptable.

---

## 2. Provider verification register (VERIFIED FACT)

Legend: `CARD` = payment method required on file; `BILLING` = charges possible above allowance; `SUSPEND` = service suspension (no charge) when allowance exhausted without a card.

### 2.1 Render (Hobby workspace + Free compute)

| Item | Value | Source | Checked |
|---|---|---|---|
| Workspace plan | Hobby = $0; 1 member; up to 25 services; 5 GB outbound bandwidth/month (shared); 500 build pipeline minutes; 2 custom domains | render.com/pricing | 2026-11-11 |
| Free web service | 0.1 CPU / 512 MB RAM; 1 instance; no scaling; spins down after 15 min with no inbound HTTP/WebSocket; ~1 min cold start; ephemeral filesystem; no persistent disk; no shell/one-off jobs | render.com/docs/free | 2026-11-11 |
| Free instance hours | 750 per workspace per calendar month; consumed only while running; spun-down services consume none; exhaustion suspends **all** Free web services until next month; unused hours do not roll over | render.com/docs/free | 2026-11-11 |
| Outbound bandwidth overage | Hobby includes 5 GB/month shared across all services including static sites. Over allowance: **with a payment method on file → billed $0.15/GB**; **without a payment method → all Free services suspended for remainder of month** | render.com/docs/outbound-bandwidth | 2026-11-11 |
| Build minutes overage | New builds paused for remainder of month if 500 minutes exceeded; running services keep their last build | render.com/docs/free | 2026-11-11 |
| Static sites | Free; no server-side processing; count against bandwidth/build minutes; do not spin down (no compute); cannot run Next.js route handlers or `rewrites()` | render.com/docs/free | 2026-11-11 |
| Free Postgres | 1 GB storage; **expires 30 days after creation** (+ 14-day upgrade grace); 1 per workspace; not suitable for staging data | render.com/docs/free | 2026-11-11 |
| Free Key Value (Redis) | 25 MB data; **not persistent** (in-memory only) | render.com/docs/free | 2026-11-11 |
| Health checks | TCP by default; HTTP GET path configurable; sent every few seconds to **running** instances; used to gate deploys and restart unhealthy instances | render.com/docs/health-checks | 2026-11-11 |
| Shell / one-off jobs on Free | Not supported (Free compute limitations) — confirmed by absence from supported-features list | render.com/docs/free | 2026-11-11 |
| Commercial use restriction | No commercial-use ban found on checked pages; Render advises Free instances are for testing/hobby, not production | render.com/docs/free | 2026-11-11 |
| Card required for $0 operation | **No.** Hobby workspace + Free compute run without a payment method; overage is handled by suspension, not billing, when no card is on file | render.com/docs/free, outbound-bandwidth | 2026-11-11 |

**Zero-cost safety conclusion (RECOMMENDATION):** Render is the only genuinely $0 compute host that can run the existing Dockerised Next.js frontend and Django backend without a payment method. The cost of staying $0 is: (a) 5 GB/month outbound bandwidth shared across both services + any static assets; (b) 750 shared instance hours; (c) 500 build minutes; (d) ephemeral filesystems; (e) cold starts; (f) no persistent disk, shell, or one-off jobs. Any of (a)–(c) being exhausted suspends services or builds until the next month — never bills, provided **no payment method is added**.

**CONDITIONAL / BLOCKER:** Two continuously-awake Free web services (frontend + backend) consume 1,488 hours in a 31-day month, exceeding 750. In practice idle spin-down keeps both under 750 for a low-traffic staging pilot, but this must be monitored; a single always-on service is safe (744 h). Do not add external keep-alive pingers — they would defeat spin-down and exhaust hours. It is **unverified** whether Render's own health probes count as inbound traffic that prevents spin-down; treat as a risk to validate in the dashboard during the first pilot month.

### 2.2 Neon (Free plan) — PostgreSQL

| Item | Value | Source | Checked |
|---|---|---|---|
| Plan cost | $0; no credit card required; permanent (not a trial) | neon.com/docs/introduction/plans | 2026-11-11 |
| Projects | 100 per account | neon.com/docs/introduction/plans | 2026-11-11 |
| Compute | 100 CU-hours per project per month; autoscaling up to 2 CU; scale-to-zero after 5 min (fixed on Free, cannot disable) | neon.com/docs/introduction/plans; scale-to-zero guide | 2026-11-11 |
| Storage | 1 GB per project (20 GB account total) | neon.com/docs/introduction/plans | 2026-11-11 |
| Network transfer | 5 GB per project per month, **shared across Postgres, Object Storage and Functions** | neon.com/docs/introduction/plans | 2026-11-11 |
| Branches | 10 per project | neon.com/docs/introduction/plans | 2026-11-11 |
| Restore window | 6 hours (capped at 1 GB change history) | neon.com/docs/introduction/plans | 2026-11-11 |
| Object Storage | 5 GB per project (S3-compatible; counts against the 5 GB transfer allowance) | neon.com/docs/introduction/plans | 2026-11-11 |
| Pooling | PgBouncer transaction mode; `-pooler` host; up to 10,000 client connections; direct (no `-pooler`) required for migrations, `pg_dump`/`pg_restore`, `LISTEN/NOTIFY`, `SET`, temp tables, session locks | neon.com/docs/connect/connection-pooling | 2026-11-11 |
| Exhaustion behaviour | Compute suspended / writes blocked when limits exceeded; **no charge**; data not deleted | neon.com docs (plan notes) | 2026-11-11 |
| Connection limit (direct) | ~100–4,000 depending on compute size | neon.com/docs/connect/choose-connection | 2026-11-11 |

**Zero-cost safety conclusion (RECOMMENDATION):** Neon Free is the approved staging database. It is the only provider in scope that is (a) permanent, (b) requires no card, (c) hard-caps compute/storage/egress with suspension rather than billing, and (d) offers a restore window. **Must use the direct (non-pooled) endpoint for `python manage.py migrate`** because Django migrations use session-level statements. Application runtime should use the pooled (`-pooler`) endpoint with `CONN_MAX_AGE=60` (A-19).

**CONDITIONAL / BLOCKER:** IP allow-listing and private networking are Scale-plan only; staging DB is reachable from the public internet with password auth. Mitigate with a strong random password, a dedicated staging database/user, and Neon's branch isolation. Also the 5 GB transfer allowance is shared with Object Storage — media-heavy pilots can exhaust it.

### 2.3 Upstash (Free Redis)

| Item | Value | Source | Checked |
|---|---|---|---|
| Plan cost | $0; no credit card required | upstash.com/pricing/redis | 2026-11-11 |
| Data size | 256 MB (250 MB on some docs) | upstash.com/pricing/redis | 2026-11-11 |
| Commands | 500,000 per month | upstash.com/pricing/redis | 2026-11-11 |
| Bandwidth | 10 GB per month | upstash.com/pricing/redis | 2026-11-11 |
| Databases | 1 free database | upstash.com/pricing/redis | 2026-11-11 |
| Throughput / request | 10,000 commands/s; 10 MB max request; 100 MB max record | upstash.com/pricing/redis | 2026-11-11 |
| Protocol | TLS `rediss://` (use `rediss://` in `REDIS_URL`) | upstash.com/docs/redis | 2026-11-11 |
| Exhaustion behaviour | Free plan has no overage billing; exceeding the monthly command allowance returns command errors (INFERRED from "no credit card required" + free-tier docs; verify in console) | upstash.com/docs/redis/overall/billing | 2026-11-11 |
| Doc discrepancy | Some Upstash pages quote 10,000 commands/day instead of 500,000/month; plan against the lower figure until reconciled | upstash.com docs | 2026-11-11 |

**Zero-cost safety conclusion (RECOMMENDATION):** Upstash Free is the approved cache. **Must not point Render's HTTP health check at `/api/health/ready/`**: that endpoint performs `cache.set` + `cache.get` = 2 commands per probe. Render probes every few seconds → ~1.04M commands/month at 5 s, ~518k at 10 s, ~173k at 30 s — all above or near the 500k allowance. Use `/api/health/live/` (zero Redis commands) as the Render probe; invoke `/api/health/ready/` only manually during smoke tests.

**Budget arithmetic (VERIFIED FACT, local):**
- `/ready/` cost: 2 commands per call (1 `SET`, 1 `GET`).
- 5 s interval → 17,280 calls/day → 518,400/month (wait — recompute: 86,400 s/day ÷ 5 = 17,280 calls/day; × 2 = 34,560 commands/day; × 30 = 1,036,800/month). Corrected: **1,036,800/month at 5 s**.
- 10 s → 518,400/month.
- 30 s → 172,800/month.
- Application traffic (JWT auth does not touch Redis; DRF throttling does ~2 commands per throttled request): at 1,000 throttled requests/day → 60,000/month. Combined with a 30 s ready probe → ~232,800/month, inside 300,000 (conservative target). Conclusion: keep the probe on `/live/` and do not add any external uptime pinger.

### 2.4 Cloudflare R2 (media storage) — CONDITIONAL / BLOCKER

| Item | Value | Source | Checked |
|---|---|---|---|
| Free tier | 10 GB-month Standard storage; 1,000,000 Class A ops/month; 10,000,000 Class B ops/month; **egress free** | developers.cloudflare.com/r2/pricing | 2026-11-11 |
| Activation | R2 requires completing a checkout to add an **R2 subscription** and a **valid payment method on file** before R2 can be enabled | developers.cloudflare.com/r2/get-started; billing/get-started/create-billing-profile | 2026-11-11 |
| Billing model | Usage is **metered monthly with no hard cap**; overage is billed at published rates | developers.cloudflare.com/r2/pricing | 2026-11-11 |
| Failure mode | If payment fails, R2 access errors; data may be deleted after 30 days | developers.cloudflare.com/billing/understand/faq | 2026-11-11 |
| ACLs | R2 does not support object ACLs; public access via custom domain or `r2.dev` subdomain | developers.cloudflare.com/r2 (A-01/A-02 in pre-staging audit) | 2026-11-11 |
| Card required for $0 operation | **Yes** — a payment method must be on file to enable R2 at all | developers.cloudflare.com/r2/get-started | 2026-11-11 |

**Zero-cost safety conclusion (BLOCKER):** R2's free tier is genuinely $0 *within* its allowances, but **enabling R2 requires a payment method on file and an R2 subscription checkout**, and usage is uncapped (overage billed). This directly conflicts with the binding owner decision: *"no payment method or billing activation solely to bypass a Free Tier restriction"* and *"if a service cannot be used without a payment commitment or potential unavoidable charge, mark it as conditional or unavailable."* **R2 is therefore CONDITIONAL, not approved, under the $0 rule.** It may only be used if the owner explicitly authorises adding a card and accepts the uncapped-overage risk, with a spend alert and a hard operational cap on upload volume.

**Zero-cost alternative (RECOMMENDATION):** Scenario B — keep `DEFAULT_FILE_STORAGE_BACKEND=django.core.files.storage.FileSystemStorage`, do not set any `AWS_*` variable, and **do not enable uploads for staging testers**. This is the only fully $0-compliant media posture. Note the honest limitation: this is an **operational restriction**, not an enforced code flag — the upload endpoints still accept writes to the backend's ephemeral disk, and any uploaded bytes are lost on restart/spin-down and are not publicly served in production (`settings.DEBUG=False` disables `static()`). A true disable requires an owner-authorised code change (a feature flag or removing the upload route), which is out of scope for this documentation revision. **Do not** fall back to the ephemeral filesystem as if it were durable media.

**Candidate (UNVERIFIED):** Neon Object Storage — 5 GB/project, S3-compatible, included in Neon Free, no card. It is a plausible zero-cost S3-compatible target, but it is recently introduced, counts against the same 5 GB transfer allowance, and its compatibility with `django-storages` 1.14 (signed URLs, `endpoint_url`, region) is **unverified**. Treat as a candidate for an owner-approved technical spike, not as an approved target. If verified, it would satisfy the no-card rule and replace R2 in Scenario A.

### 2.5 Vercel (Hobby) — frontend alternative (not eligible)

| Item | Value | Source | Checked |
|---|---|---|---|
| Cost | $0 (Hobby) | vercel.com/docs/plans/hobby | 2026-11-11 |
| Commercial use | **Hobby is restricted to non-commercial personal use only**; all commercial usage requires Pro or Enterprise | vercel.com/docs/limits/fair-use-guidelines | 2026-11-11 |
| Hobby included | 100 GB fast data transfer; 10 GB fast origin transfer; 1M function invocations; 4 CPU-hrs active | vercel.com/docs/plans/hobby | 2026-11-11 |
| Enforcement | Vercel may suspend or terminate Hobby accounts it considers commercial, with or without notice | vercel.com/legal/terms §4 | 2026-11-11 |
| Additional | Hobby content may be used for AI model training; paid plans exclude this | vercel.com/legal/terms | 2026-11-11 |

**Conclusion:** JAM is a commercial marketplace (it processes and advertises the sale of products/services). Vercel Hobby is **not eligible**. Marked **BLOCKER** for any "free Vercel" suggestion. Do not recommend.

### 2.6 Cloudflare Workers / Pages (free) — frontend alternative (CONDITIONAL)

| Item | Value | Source | Checked |
|---|---|---|---|
| Cost | $0 (Workers Free) | developers.cloudflare.com (Workers plans) | 2026-11-11 |
| Limits | 100,000 requests/day; 10 ms CPU per request; no credit card required for Free | developers.cloudflare.com (Workers plans) | 2026-11-11 |
| Next.js compatibility | Requires an adapter (e.g. OpenNext) and code/config changes; not a drop-in for this App Router app; runtime semantics differ from Node | (inferred from platform docs) | 2026-11-11 |

**Conclusion:** Genuinely $0 and card-free, but adopting it requires code changes that are **not authorised** in this revision and would alter the security model (same-origin proxy, `API_INTERNAL_URL`). Marked **CONDITIONAL / DEFERRED**. If the owner later wants a Cloudflare-based frontend, it must be a scoped, reviewed code change — not a documentation tweak.

### 2.7 Cloudflare Tunnel (Scenario C only)

| Item | Value | Source | Checked |
|---|---|---|---|
| Quick tunnels (`trycloudflare.com`) | Free, no account, no domain, no card; URL changes on every restart | developers.cloudflare.com/cloudflare-one/connections/connect-networks/do-more-with-tunnels/trycloudflare | 2026-11-11 |
| Named tunnels | Require a Cloudflare account and a domain on Cloudflare DNS; no card for Free plan | developers.cloudflare.com/cloudflare-one | 2026-11-11 |

**Conclusion:** Acceptable as a **temporary** exposure mechanism for Scenario C (local staging) only. Quick tunnels are ephemeral and unsuitable for sharing with testers for more than a session.

---

## 3. Zero-cost scenario comparison (RECOMMENDATION)

| Scenario | Topology | $0-compliant? | Verdict |
|---|---|---|---|
| **A — Cloud staging with R2 media** | Render Free frontend (Web Service) + Render Free backend + Neon Free + Upstash Free + R2 | **No** (R2 requires a card and has uncapped overage) | CONDITIONAL / BLOCKED pending owner card authorisation |
| **B — Cloud staging, uploads disabled** | Same as A, `FileSystemStorage`, no `AWS_*`, uploads not exposed to testers | **Yes** | **RECOMMENDED default** |
| **C — Local staging + tunnel** | Docker Compose on owner machine + Neon/Upstash or local Postgres/Redis + quick tunnel | **Yes** | FALLBACK if cloud quotas exhausted or Render suspended |
| Rejected: Render Static Site frontend | Incompatible with this app (§4) | n/a | BLOCKED |
| Rejected: Vercel Hobby frontend | Commercial use prohibited | n/a | BLOCKED |
| Rejected: Render Free Postgres | Expires after 30 days | n/a | BLOCKED |
| Rejected: Render Free Key Value | 25 MB, non-persistent | n/a | BLOCKED (use Upstash) |

---

## 4. Why a Render Static Site cannot host this frontend (VERIFIED FACT)

`frontend/next.config.mjs` and the App Router source require a Node server. A static export (`output: 'export'`) is **not possible** without code changes:

1. `next.config.mjs` defines `rewrites()` (`/api/:path*` → `API_INTERNAL_URL`) — rewrites are **unsupported** with `output: 'export'`.
2. `frontend/app/api/[...path]/route.ts` is a catch-all route handler with `export const dynamic = "force-dynamic"` handling all HTTP methods — route handlers are not statically exportable.
3. `frontend/app/health/route.ts` is `force-dynamic`.
4. `frontend/app/page.tsx` is `force-dynamic`.
5. Four dynamic routes have no `generateStaticParams`: `app/m/[slug]`, `app/order/[id]`, `app/store/[id]`, `app/visit/[storeId]`.
6. `API_INTERNAL_URL` is read at server runtime by the proxy; a static build cannot hold a server-only secret/runtime value.
7. The same-origin `/api` proxy is the auth/security model: the browser never calls Django directly, so JWTs stay in the existing Bearer flow and no CORS/localhost-only changes are needed. Static export would force browser→Django cross-origin calls, conflicting with `DJANGO_ALLOWED_HOSTS`/`CORS` posture and the documented XSS/token model.

**Consequence:** the frontend must run as a **Render Free Web Service** (Docker/Node, `npm start` on `$PORT`), not a Render Static Site. This keeps it genuinely $0 (no card) but consumes shared instance hours and 5 GB bandwidth.

---

## 5. Port / bind resolution options (OWNER DECISION pending)

Backend `Dockerfile` CMD binds `0.0.0.0:8000` and `EXPOSE 8000`. Render injects `PORT` (default 10000) and routes to the port the service actually listens on.

| Option | Change | Cost | Risk |
|---|---|---|---|
| A — Dashboard env `PORT=8000` | None to repo | $0 | Relies on Render accepting an overridden `PORT` and detecting the listening port; unverified on Free. Documented workaround in prior audit (A-02). |
| B — Change Gunicorn bind to `${PORT:-8000}` in `Dockerfile` | One-line Dockerfile edit | $0 | Requires an owner-authorised code/Dockerfile change (out of scope for this docs revision); durable fix. |
| C — Frontend proxy unaffected | n/a | n/a | Frontend `next start` already honours `PORT`. |

**RECOMMENDATION:** Try Option A first during the authorised deploy stage; if Render health checks fail, escalate to Option B as a separately authorised change. Do not silently edit the Dockerfile in this revision.

---

## 6. Redis command-budget summary (VERIFIED FACT, local)

See §2.3. Additional application-side consumers:
- DRF throttling: ~2 commands per throttled request (cache get + set).
- JWT auth: 0 Redis commands.
- Entitlement/notification lookups: DB, not Redis.
- No Celery/beat; `notify_expiring_entitlements` is a manual management command.

**Rule for staging:** Render health check path = `/api/health/live/` only. `/api/health/ready/` is a manual smoke-test endpoint. No external uptime pinger.

---

## 7. Media posture summary (OWNER DECISION / BLOCKER)

- R2: CONDITIONAL (card required, uncapped overage). Blocked under the $0 rule unless owner authorises a card.
- Scenario B (uploads disabled operationally): RECOMMENDED default.
- Candidate: Neon Object Storage (5 GB, S3-compatible, no card) — UNVERIFIED compatibility; owner-approved spike only.
- Forbidden: reverting to ephemeral filesystem as if it were durable media (A-01).

---

## 8. What this document does not authorise

- No account creation, no bucket creation, no Render/Neon/Upstash/Cloudflare provisioning.
- No payment-method entry, no R2 checkout, no billing activation.
- No code, env, Dockerfile, Compose, Caddy, migration, or dependency changes.
- No git commit/push, no deployment, no migration execution.

Any of the above requires a separate, explicit owner authorisation beyond this documentation revision.