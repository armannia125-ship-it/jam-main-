# JAM — Zero-Cost Local Migration Runbook (Owner-Run)

**Document ID:** `JAM-ZERO-COST-LOCAL-MIGRATION-RUNBOOK-2026-11-11`
**Companion:** `JAM_ZERO_COST_STAGING_PROVIDER_VERIFICATION.md`, `JAM_PHASE_3_1_DEPLOYMENT_EXECUTION_PLAN.md` (Stage 3.2.3).
**Scope:** Documentation only. This runbook describes a procedure the **owner** may run later. It has not been executed. No migration has been applied.

---

## 0. Binding owner decisions (OWNER DECISION)

Migrations run from the owner's local dev environment against the Neon staging database. No provisioning, no commit/push, no deployment in this revision.

## 1. Non-negotiable safety rules

1. **Never run a migration against a database whose identity you have not verified in the same session.**
2. **Never use the pooled (`-pooler`) host for migrations** (Neon transaction pooling breaks session-level statements Django may use).
3. **Never run `flush`, `reset`, mass `UPDATE`/`DELETE`, or any data-destructive command.**
4. **Never edit, fake, or hand-write a down-migration** to make a failed migration pass. Forward-fix or restore from backup.
5. **Never paste secrets into chat, logs, commit messages, or this repository.**
6. **Always take a backup before migrating.**
7. **Always record the commit SHA, migration list, and timestamp** in the deployment record.
8. If any step fails or identity is ambiguous: **stop, do not retry blindly, restore from backup, investigate.**

---

## 2. Prerequisites

- Owner has provisioned the Neon Free project and staging database (Stage 3.2.1) — a separate authorisation.
- Owner's local Python environment can run Django with `config.settings` (PostgreSQL driver installed).
- The deployed image's commit SHA is known and matches the working tree being migrated.
- A temporary env file will be created **outside the repository** (e.g. `~/.jam-staging.env`) with `chmod 600`, and removed after.
- Shell history disabled for the session: `set +o history` and `export HISTFILE=/dev/null`.

---

## 3. Environment file template (placeholders — never commit)

Create `~/.jam-staging.env` (mode 600) with:

```
DJANGO_DEBUG=False
DJANGO_SECRET_KEY=<staging secret, >=50 chars>
OTPY_API_KEY=<provider key>
POSTGRES_HOST=<neon DIRECT host, no -pooler>
POSTGRES_PORT=5432
POSTGRES_DB=<staging db name>
POSTGRES_USER=<staging role>
POSTGRES_PASSWORD=<staging password>
POSTGRES_SSLMODE=require
REDIS_URL=rediss://:<password>@<upstash host>:6379
CACHE_REQUIRE_REDIS=True
DJANGO_ALLOWED_HOSTS=<staging hosts>
DJANGO_CSRF_TRUSTED_ORIGINS=https://<staging hosts>
DJANGO_TRUST_PROXY_SSL=True
ZARINPAL_SANDBOX=True
ZARINPAL_MERCHANT_ID=
DEFAULT_FILE_STORAGE_BACKEND=django.core.files.storage.FileSystemStorage
```

Load with `set -a; . ~/.jam-staging.env; set +a`. Verify with a **masked** check (print only whether each required var is non-empty, never its value):

```
for v in DJANGO_SECRET_KEY OTPY_API_KEY POSTGRES_HOST POSTGRES_DB POSTGRES_USER POSTGRES_PASSWORD REDIS_URL; do
  if [ -z "${!v}" ]; then echo "MISSING: $v"; else echo "OK: $v"; fi
done
```

`POSTGRES_SSLMODE` is not read by `config/settings.py` (no sslmode env exists) — it is documented for operator awareness; psycopg's default `prefer` negotiates TLS with Neon. If a stricter `require` is desired, that is a settings change requiring authorisation.

---

## 4. Pre-migration checks (all must pass)

Run from `backend/` with the env loaded:

1. `python manage.py check --settings=config.settings`
2. `python manage.py makemigrations --check --dry-run --settings=config.settings` — must report no changes.
3. `python manage.py migrate --plan --settings=config.settings` — review the list; confirm it matches the expected migrations for the commit SHA.
4. `python manage.py showmigrations --settings=config.settings` — record which are already applied.

Also verify the target is staging, not production, by checking the database name/user/host you expect. See §5.

---

## 5. Target identity verification (mandatory, in-session)

Run a read-only identity check against the database **before** any write:

```
python manage.py dbshell --settings=config.settings <<'SQL'
SELECT current_database() AS db,
       current_user AS usr,
       inet_server_addr() AS host,
       inet_server_port() AS port,
       version() AS pg_version;
SELECT count(*) AS auth_user_count FROM auth_user;
SQL
```

Confirm:
- `db` equals the staging database name you expect.
- `usr` equals the staging role.
- `host` is a Neon host (not localhost, not production).
- `pg_version` is PostgreSQL 14+ (Neon's current default).
- `auth_user_count` is consistent with a staging database (empty or known seed), not production data.

**Abort if any of these is ambiguous.** A wrong-target migration is the single most dangerous failure mode and is not recoverable by re-running.

Additionally, guard with an explicit assertion in a one-off Django shell (read-only):

```
python manage.py shell --settings=config.settings -c "
from django.db import connection
with connection.cursor() as c:
    c.execute('SELECT current_database()')
    name = c.fetchone()[0]
assert name == '<expected staging db name>', f'WRONG DB: {name}'
print('IDENTITY OK:', name)
"
```

---

## 6. Backup (mandatory, before migration)

Choose one or both:

**Option A — Neon branch (preferred, instant, zero data movement):**
- In the Neon console, create a branch from the current main branch named `pre-migrate-<YYYYMMDD-HHMM>-<short sha>`. This is a copy-on-write snapshot and is the fastest rollback path.

**Option B — `pg_dump` custom format (portable):**
```
pg_dump --format=custom --file="$HOME/jam-staging-pre-<shortsha>.dump" \
  --host="$POSTGRES_HOST" --port="$POSTGRES_PORT" \
  --username="$POSTGRES_USER" --dbname="$POSTGRES_DB" --no-owner --no-acl
```
- Store the dump outside the repo, mode 600.
- Verify it is non-empty: `ls -lh` and `pg_restore --list ... | head`.

**Restore test (optional but recommended):** restore the dump into a throwaway database and run `python manage.py check` against it. Do not restore into the staging database.

---

## 7. Execute the migration

Only after §§4–6 pass and the owner has explicitly authorised this step:

```
python manage.py migrate --noinput --settings=config.settings
```

- Capture the full output to a file outside the repo (e.g. `~/jam-migrate-<timestamp>.log`), mode 600.
- Do **not** use `--run-syncdb` or `--fake` / `--fake-initial`.
- If the command fails midway: **stop**. Do not re-run. Assess whether the migration is partially applied (Django records applied migrations per migration; a failure leaves earlier migrations applied and the failing one unrecorded, but DDL may be partially committed). Restore from the Neon branch (§6 Option A) or the dump (§6 Option B), then investigate.

---

## 8. Post-migration verification

1. `python manage.py showmigrations --settings=config.settings` — all expected migrations show `[X]`.
2. `python manage.py check --settings=config.settings` — no errors.
3. Spot-check row counts on key tables (read-only) and compare to pre-migration counts where the migration is data-preserving:
   - `auth_user`, `businesses_business`, `subscriptions_subscriptionproduct`, `subscriptions_subscriptionpurchase`, `payments_transaction`, `commerce_order`.
4. Verify the five seeded subscription products are intact (slugs, prices, durations) — **do not modify them**.
5. `python manage.py notify_expiring_entitlements --dry-run` if supported; otherwise skip (the command has no dry-run — do not run it against staging unless intended).
6. Hit `/api/health/ready/` once manually against the deployed backend (or via local tunnel) and confirm 200.

---

## 9. Record-keeping (deployment record)

Record, outside the repo:
- Commit SHA migrated.
- Full `showmigrations` output (or the list of newly applied migrations).
- Timestamp (UTC) and operator.
- Backup reference (Neon branch name or dump filename + checksum).
- Verification results (pass/fail per §8).

---

## 10. Recovery

| Scenario | Action |
|---|---|
| Migration fails midway | Stop; restore Neon branch or `pg_restore` the dump into a fresh database and re-point `POSTGRES_DB`; investigate the failure; do not re-run on the same DB |
| Wrong database targeted | **Stop immediately.** If writes occurred, restore that database from its own backup (if any) and notify the owner; this is a reportable incident |
| Post-migration verification fails | Do not deploy code that depends on the new schema; restore from backup; investigate |
| Need to undo a migration | Django migrations are **not** universally reversible. Use forward-fix migrations or restore from backup. Never hand-edit down-migrations or use `--fake` |
| `payments` 0004 (removes rows) involved | Treat as irreversible without a backup; restore from backup if needed |

---

## 11. Cleanup

After a successful migration and deployment:
1. Remove `~/.jam-staging.env` (or keep it mode 600 for future migrations, but never commit it).
2. Remove any dump files after confirming the deployment is stable (or retain one off-site backup for the staging DB's lifetime).
3. Disable shell history re-enablement is not needed; the session ends.

---

## 12. What this runbook does not authorise

No provisioning, no billing activation, no code/env/Dockerfile/migration-file changes, no git commit/push, no deployment. Those require separate explicit owner authorisation.