# Staging Deployment Preparation

Target architecture for a free-tier staging deployment:

| Component | Provider | Tier |
|---|---|---|
| Frontend (Next.js + API proxy) | Render | Free |
| Backend (Django + Gunicorn) | Render | Free |
| PostgreSQL | Neon | Free |
| Redis / Cache | Upstash | Free |
| Persistent Media | S3-compatible Object Storage | — |

**Important:** This batch prepares the local repository only. No external services are created or connected. No credentials are provisioned. No deployments are performed.

## 1. Required Services

* [ ] Render free web services — one per component
* [ ] Neon PostgreSQL free project
* [ ] Upstash Redis free database
* [ ] S3-compatible Object Storage bucket (credentials provisioned via platform secret management, not created by this batch)

## 2. Frontend Build Commands

```bash
cd frontend
npm ci --omit=dev
npm run build
npm start          # production server on port 3000
```

The Dockerfile (`frontend/Dockerfile`) installs dependencies from `package-lock.json`, builds production, and runs as a non-root user. Port 3000 is exposed and bound to `0.0.0.0`.

**No change required** — the existing Dockerfile is production-ready.

## 3. Backend Build Commands

```bash
cd backend
pip install -r requirements.lock.txt
python manage.py collectstatic --noinput
cd .. && docker compose up --build backend
```

The `backend/Dockerfile` uses `python:3.12-slim`, installs lockfile dependencies, collects static files at build time, and runs Gunicorn with 3 workers. Migrations are **not** executed during startup — they must be run separately.

Dependency set relevant to media storage:

| Component | Version |
|---|---|
| Python | 3.12 (`python:3.12-slim`) |
| Django | 5.2.18 |
| django-storages | 1.14.6 |
| boto3 | 1.35.28 |

The lock file (`requirements.lock.txt`) is authoritative for image builds. `requirements.txt` declares the range `django-storages[boto3]>=1.14.6,<2.0`; 1.14.3 was the first release with Django 5.0/Python 3.12 support, so earlier 1.14 releases are not an appropriate pin for this project.

## 4. Explicit Migration Command

Database migrations are never automatic. The execution method differs by environment and is documented in detail in `STAGING_OPERATIONS.md` §1.

### Local Docker Compose

```bash
docker compose exec backend python manage.py migrate --noinput
```

This command is safe and idempotent and targets the Compose database.

### Render Staging

Render **Free** web services do not support one-off jobs or shell access (SSH or Dashboard), so there is currently no verified free way to run `manage.py migrate` inside the Render service. Do not use the Compose command against Staging, and do not add migrations to the start command.

**This is a Batch 2 deployment blocker.** The owner must choose and authorize an execution channel before the first deploy; options and trade-offs are listed in `STAGING_OPERATIONS.md` §1B.

## 5. Static-File Strategy

Django's WhiteNoise static compression is already configured. Static collection is performed at Docker image build time (`collectstatic --noinput`). Static files are served from Django's `STATIC_ROOT`.

Existing WhiteNoise middleware is preserved. No changes are needed.

## 6. Media Storage Configuration

Media storage supports two modes controlled by the `DEFAULT_FILE_STORAGE_BACKEND` environment variable.

### Canonical environment variables

| Variable | Required (S3 mode) | Purpose |
|---|---|---|
| `DEFAULT_FILE_STORAGE_BACKEND` | Yes | Switch: `django.core.files.storage.FileSystemStorage` (default) or `storages.backends.s3boto3.S3Boto3Storage` |
| `AWS_STORAGE_BUCKET_NAME` | Yes | S3 bucket name |
| `AWS_ACCESS_KEY_ID` | Yes | S3 access key ID |
| `AWS_SECRET_ACCESS_KEY` | Yes | S3 secret access key |
| `AWS_S3_ENDPOINT_URL` | No | Custom S3-compatible endpoint URL (e.g., for non-AWS providers) |
| `AWS_S3_REGION_NAME` | No | S3 region |
| `AWS_S3_CUSTOM_DOMAIN` | No | Custom domain for media URLs (optional) |
| `AWS_DEFAULT_ACL` | No | Default ACL for uploaded objects (optional) |

### Default (local filesystem)

When `DEFAULT_FILE_STORAGE_BACKEND` is set to `django.core.files.storage.FileSystemStorage` (the default), Django's standard `FileSystemStorage` is used. The development workflow is unchanged. Local uploads work exactly as before. No S3 credentials are required.

### S3-compatible mode

Set in `.env`:
```
DEFAULT_FILE_STORAGE_BACKEND=storages.backends.s3boto3.S3Boto3Storage
AWS_STORAGE_BUCKET_NAME=<bucket-name>
AWS_ACCESS_KEY_ID=<access-key>
AWS_SECRET_ACCESS_KEY=<secret-key>
AWS_S3_ENDPOINT_URL=<endpoint-url>
AWS_S3_REGION_NAME=<region-name>
```

When `DEFAULT_FILE_STORAGE_BACKEND` points to a non-filesystem backend, all three S3 credentials (`AWS_STORAGE_BUCKET_NAME`, `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`) **must** be present. If any is missing, the application fails to start with a clear `ImproperlyConfigured` error.

When S3 mode is active, `django-storages` 1.14.6 uses `boto3`-backed S3 storage. The `media-proxy` API route (`frontend/app/api/.../route.ts`) continues to work because it reads URLs from `MEDIA_URL` which stays `/media/`.

Selecting the backend and initializing it is only **Level A** verification (no network request). A real upload/read/delete test is **Level B** and is deferred until the owner provisions the bucket, authorizes credentials, and provides an approved execution channel. Media delivery through the frontend/backend is **Level C** and is also deferred. See `STAGING_OPERATIONS.md` §6.

Do not hardcode a specific storage provider. The `AWS_S3_ENDPOINT_URL` variable allows any S3-compatible service.

## 7. Database Configuration (Neon Compatibility)

PostgreSQL connection is configured through environment variables:

```
POSTGRES_DB=<db-name>
POSTGRES_USER=<db-user>
POSTGRES_PASSWORD=<db-password>
POSTGRES_HOST=<neon-host>         # e.g., postgres.<project-slug>.neon.db.host.com
POSTGRES_PORT=5432
```

Django's `psycopg` driver is already compatible with Neon's PostgreSQL implementation. SSL support is built-in via `sslmode` parameter. The `DATABASES` dict accepts Neon's connection string format.

Expected Neon connection string format (redacted):
```
postgres://<user>:<password>@<host>:5432/<db-name>?sslmode=require
```

**SSL configuration:** Set `POSTGRES_HOST` to the Neon host directly (Neon requires SSL). Django will use SSL implicitly through the standard PostgreSQL driver connection string.

## 8. Redis Configuration (Upstash Compatibility)

Redis URL is configured through environment variables:

```
REDIS_URL=redis://:<tls-password>@<host>:<port>/<database-id>
```

Upstash supports TLS connections. If you use Upstash's TLS-enabled URL format, the standard `django-redis` cache backend works correctly.

When `REDIS_URL` is empty, Django falls back to `LocMemCache` for local development. A successful set/get against that fallback does **not** prove external Redis connectivity. In deployed environments (`DEBUG=false`), `CACHE_REQUIRE_REDIS` defaults to true: the readiness endpoint reports the cache as `unavailable` with HTTP 503 unless the configured backend is `django_redis.cache.RedisCache`, `REDIS_URL` is set, and a set/get round-trip succeeds. Set `CACHE_REQUIRE_REDIS=false` only to deliberately allow the in-memory fallback.

## 9. Health and Readiness Endpoints

The backend provides two health endpoints:

| Endpoint | Purpose | Authentication | Rate Limit |
|---|---|---|---|
| `GET /api/health/live/` | Process liveness check | None | None |
| `GET /api/health/ready/` | Dependency readiness (DB + cache) | None | None |

Readiness checks verify PostgreSQL connectivity and the configured cache. They do NOT require OTPy, ZarinPal, or Telegram Bot token. Database connection failures return `not_ready` with status 503. Cache failures — including a `LocMemCache` fallback when Redis is required, a missing `REDIS_URL`, or a failed set/get — return `not_ready` with the same status.

The readiness response contract is unchanged: `{"status": ..., "checks": {"database": ..., "cache": ...}}` with values `ok` or `unavailable`.

Health endpoints must never expose database credentials, Redis credentials, Redis URLs, stack traces, or sensitive internal information. They only report `ok` or `unavailable`.

## 10. Telegram Bot — Exclusion for Staging

The existing polling-based Telegram bot (`run_telegram_bot.py`) is fully present in the codebase but **must remain disabled** during staging startup:

* **Backend entrypoint:** `CMD` in `backend/Dockerfile` only starts Gunicorn. The bot command is available but not started.
* **Docker Compose:** No service runs `run_telegram_bot`.
* **Render deployment:** No Docker start script triggers the bot.

Existing bot functionality (commands, models, services) are preserved. The only change is that the polling process is not started as part of normal startup. Admin can start it manually with `TELEGRAM_BOT_TOKEN` set only on an environment with an approved shell; Render Free has none.

Do NOT create a webhook. Do NOT contact Telegram.

## 11. Notification Scheduling Limitation

The five-day expiration notification command exists:

```bash
docker compose exec backend python manage.py notify_expiring_entitlements
```

It is idempotent and requires no Celery or external scheduler. It can be run manually.

For automated scheduling, options include:
- A daily cron job running the above command (recommended)
- A scheduler service added to Compose

This wiring is documented here; implement the scheduler after Batch 2 infrastructure provisioning.

## 12. Safe Staging Setup Sequence

1. Provision secrets via approved secret management channels (never commit to Git)
2. Create Neon PostgreSQL project and database
3. Create Upstash Redis database
4. Provision S3-compatible Object Storage bucket
5. Set Render environment variables
6. Apply S3 credentials via Render secret management
7. Deploy backend with Render Docker service — **blocked** until an owner-approved migration channel exists (see §4)
8. Deploy frontend with Render Docker service
9. Run migrations explicitly through the owner-approved channel (not the Compose command; see `STAGING_OPERATIONS.md` §1B)
10. Create first admin through an owner-approved channel: `python manage.py make_admin --phone <phone>`
11. Start notification scheduling through an owner-approved channel (Render Free has no cron jobs)
12. Verify with smoke tests

## 13. Known Limitations

* Render Free web services support no one-off jobs and no SSH/Dashboard shell → migration, admin promotion, and manual bot start have no verified Free execution path
* Render Free services spin down after 15 minutes idle → cold starts expected
* Render ephemeral filesystem → media must use object storage, NOT local filesystem
* Neon free tier has 1 GB storage limit → no large media uploads
* Upstash free tier Redis expires → cache data lost on restart
* No public user registration system exists
* Payment gateway remains unconfigured until Batch 2
* CORS restricted to localhost origin in current codebase
* Telegram bot uses polling (requires long-lived connections)
