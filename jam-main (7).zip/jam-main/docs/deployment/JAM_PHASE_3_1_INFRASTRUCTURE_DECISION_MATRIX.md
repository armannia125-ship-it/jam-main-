# JAM — Phase 3.1 Infrastructure Decision Matrix (Zero-Cost Revision)

**Document ID:** `JAM-PHASE-3.1-DECISION-MATRIX-ZERO-COST-2026-11-11`
**Supersedes (in part):** previous Phase 3.1 decision matrix (paid-minimum / $7 Scenario B). That recommendation is **withdrawn** under the binding owner zero-cost decision. Historical text is retained only as superseded context; do not follow it.
**Companion:** `JAM_ZERO_COST_STAGING_PROVIDER_VERIFICATION.md`, `JAM_PHASE_3_1_RECOMMENDED_STAGING_ARCHITECTURE.md`, `JAM_PHASE_3_1_DEPLOYMENT_EXECUTION_PLAN.md`, `JAM_ZERO_COST_LOCAL_MIGRATION_RUNBOOK.md`.
**Scope:** Documentation only. No provisioning, billing, code, or deployment.

---

## 0. Binding owner decisions (OWNER DECISION)

1. Cloud staging on Free Tiers only; **$0 budget**; no paid upgrades.
2. No payment method or billing activation solely to bypass a Free Tier restriction.
3. Cloudflare R2 for media **only if** usable without charges.
4. Database migrations run from the owner's local dev environment.
5. No provisioning, no git commit/push, no deployment in this revision.
6. Frontend must be a genuinely zero-cost hosting option; if a free option breaks required product functionality it is not acceptable.

All conclusions below are filtered through these six decisions. Where a conclusion conflicts with them, the decision wins and the item is marked **BLOCKER** or **CONDITIONAL**.

---

## 1. Verified baseline (VERIFIED FACT)

- Repository HEAD at revision start: `fdb1add6cf56b852e07aa804a19c3bb7736fac18`, branch `main`.
- Working tree: 64 dirty entries (50 modified tracked + deletions + untracked docs/migrations). **No file in this revision may be altered except the six documents listed in §10.**
- Backend: 236 tests OK (skipped 17, all PostgreSQL-only concurrency); Django checks and migration drift clean; `makemigrations --check` clean.
- Frontend: `tsc --noEmit` exit 0; `npm run lint` exit 0 (11 pre-existing warnings); production build not re-run in this batch.
- Compose base + prod config validation: exit 0.
- External Staging services, Docker image builds, and live provider tests: **not** verified.

---

## 2. Decision register (OD-01 … OD-15, revised)

| ID | Decision area | Prior position | Zero-cost position | Status |
|---|---|---|---|---|
| OD-01 | Hosting budget | $7/mo minimum acceptable | **$0 only.** No paid plan, no card for overage bypass | OWNER DECISION (supersedes) |
| OD-02 | Backend host | Render Free web service | Render Free web service (unchanged) | APPROVED |
| OD-03 | Frontend host | Render Static Site (assumed) | **Render Free Web Service (Docker/Node)** — static site is incompatible (§4 of provider verification) | RECOMMENDATION (changed) |
| OD-04 | Database | Neon Free | Neon Free (unchanged) | APPROVED |
| OD-05 | Cache | Upstash Free | Upstash Free (unchanged) | APPROVED |
| OD-06 | Media | R2 if approved | **R2 CONDITIONAL** (card required + uncapped overage); Scenario B (uploads disabled) is the $0 default | BLOCKER unless owner authorises card |
| OD-07 | Migrations | Operator-run on Render (blocked) | **Owner runs locally** against Neon direct endpoint (runbook) | APPROVED (owner decision) |
| OD-08 | Admin promotion | `make_admin` on Render (blocked) | Owner runs `make_admin --phone` locally against Neon | APPROVED |
| OD-09 | Telegram bot | Disabled | Disabled (unchanged) | APPROVED |
| OD-10 | Zarinpal | Unconfigured (sandbox) | Unconfigured (sandbox) until explicitly authorised; `ZARINPAL_SANDBOX=True` explicit | APPROVED |
| OD-11 | Health probe | `/ready/` | **`/live/` only** (Redis quota) | RECOMMENDATION (changed) |
| OD-12 | Port binding | Set `PORT=8000` | Try dashboard override first; durable fix needs authorised Dockerfile change | CONDITIONAL |
| OD-13 | Git snapshot | Assume all 50 modified files | **Do not assume** — enumerate and review before any commit (§7) | RECOMMENDATION |
| OD-14 | Cost scenario | Scenario B ($7) | Scenario B (zero-cost, uploads disabled) | RECOMMENDATION (changed) |
| OD-15 | Production readiness claim | Not production ready | Not production ready (unchanged; zero-cost staging is not production) | VERIFIED FACT |

---

## 3. Scenario comparison (zero-cost)

| Scenario | Topology | $0-compliant | Notes |
|---|---|---|---|
| **A — Cloud staging with R2 media** | Render Free frontend (Web Service) + Render Free backend + Neon Free + Upstash Free + R2 | **No** (R2 requires a card and has uncapped overage) | CONDITIONAL; only if owner explicitly authorises a card + spend alert |
| **B — Cloud staging, uploads disabled** | Same as A, `FileSystemStorage`, no `AWS_*`, uploads not exposed to testers | **Yes** | **RECOMMENDED default** |
| **C — Local staging + tunnel** | Docker Compose on owner machine + Neon/Upstash (or local) + quick tunnel | **Yes** | FALLBACK if cloud quotas exhausted or Render suspended |
| Rejected: Render Static Site frontend | Incompatible with this app (provider verification §4) | n/a | BLOCKED |
| Rejected: Vercel Hobby frontend | Commercial use prohibited (JAM is a marketplace) | n/a | BLOCKED |
| Rejected: Render Free Postgres | Expires 30 days after creation | n/a | BLOCKED |
| Rejected: Render Free Key Value | 25 MB, non-persistent | n/a | BLOCKED (use Upstash) |

---

## 4. Provider decision summary (OWNER DECISION / RECOMMENDATION)

| Provider | Role | $0-safe? | Card? | Verdict |
|---|---|---|---|---|
| Render (Hobby + Free compute) | Frontend + backend compute | Yes, if no card on file (overage suspends) | No | APPROVED, with quota monitoring |
| Neon (Free) | PostgreSQL | Yes (hard caps, suspension) | No | APPROVED |
| Upstash (Free) | Redis | Yes (command errors on exceed) | No | APPROVED, with conservative 300k target |
| Cloudflare R2 | Media | Only within free tier; uncapped overage | **Yes (required)** | CONDITIONAL / BLOCKER under $0 rule |
| Vercel (Hobby) | Frontend alt. | $0 but ToS prohibits commercial use | No | BLOCKED |
| Cloudflare Workers/Pages (Free) | Frontend alt. | Yes | No | CONDITIONAL (code changes required) |
| Cloudflare Tunnel (quick) | Scenario C exposure | Yes | No | APPROVED for temporary use |

---

## 5. Carried-over pre-staging findings (A-01 … A-24) — disposition

Disposition under the zero-cost revision. Codes: **KEEP** = unchanged; **REVISED** = position changed by this revision; **BLOCKED** = cannot be resolved without a protected action or owner decision; **DEFERRED** = out of scope.

| ID | Finding | Disposition |
|---|---|---|
| A-01 | Uploaded media unreachable in filesystem mode on Render | REVISED — Scenario B makes this a documented limitation, not a defect; uploads not exposed to testers; no durable media in staging |
| A-02 | Backend binds 8000, not Render `$PORT` | REVISED — see OD-12; dashboard override first, authorised Dockerfile change if needed |
| A-03 | No Render Free path for migrations/admin promotion | REVISED — resolved by owner decision OD-07/OD-08 (local execution); Render Free path remains unavailable and must not be attempted |
| A-04 | Readiness probe burns Redis quota | REVISED — OD-11: `/live/` only |
| A-05 | Two free services can exceed 750 instance hours | KEEP — monitor; do not add keep-alive pingers |
| A-06 | JWT in `localStorage` (XSS-readable) | KEEP — accepted for staging; documented risk |
| A-07 | No server-side logout/revocation | KEEP — accepted for staging |
| A-08 | Admin UI served to unauthenticated users; APIs protected | KEEP |
| A-09 | Production host/CSRF values are placeholders | KEEP — must be set before deploy (env config, not code) |
| A-10 | App-level SSL redirect off; proxy trust off by default | KEEP — set `DJANGO_TRUST_PROXY_SSL=True` |
| A-11 | HSTS disabled by default | KEEP — enable after HTTPS verification |
| A-12 | S3 signed URLs break PWA offline image caching | KEEP — moot under Scenario B; revisit if R2 approved |
| A-13 | No application-level upload size limit | KEEP — required before any public uploads (Scenario B avoids exposure) |
| A-14 | No CI/CD or `render.yaml` | KEEP — manual runbook |
| A-15 | Expiry notifications have no scheduler | KEEP — manual command |
| A-16 | Telegram bot has no worker topology | KEEP — disabled |
| A-17 | Zarinpal callback must target backend | KEEP |
| A-18 | No error tracking or uptime alerting | KEEP |
| A-19 | `CONN_MAX_AGE=60` with pooled Neon | KEEP — use pooled URL at runtime, direct for migrations |
| A-20 | Duplicate API proxy mechanisms | KEEP — low priority |
| A-21 | Forwarded headers copied from client by Next proxy | KEEP — validate during staging |
| A-22 | Build images not digest-pinned | KEEP |
| A-23 | Free Postgres unsuitable | KEEP — use Neon |
| A-24 | No database backup job | KEEP — rely on Neon restore window (6 h / 1 GB) |

---

## 6. New zero-cost-specific blockers (B-07 … B-12)

| ID | Blocker | Severity | Owner action required |
|---|---|---|---|
| B-07 | R2 requires a payment method and has uncapped overage | High (media) | Explicit authorisation to add a card + spend alert, or accept Scenario B |
| B-08 | 5 GB/month outbound bandwidth shared across both services + assets | High (availability) | Monitor; reduce payload (image sizes, no large exports); no keep-alive pingers |
| B-09 | Frontend static-site incompatibility (resolved by using a Web Service) | Resolved | None — documented |
| B-10 | Two Free web services + 750 shared instance hours | Medium | Monitor first month; accept cold starts |
| B-11 | No enforced "uploads disabled" flag (operational restriction only) | Medium | Owner-authorised code change if a hard disable is required |
| B-12 | Neon 5 GB transfer shared with Object Storage | Medium | If R2 approved later, account for transfer |

---

## 7. Git snapshot procedure (documentation only — no execution)

The working tree is dirty with 64 entries. **Do not assume all 50 modified tracked files belong to a deployable snapshot.** Before any future commit:

1. Run `git status --short` and `git diff --stat`; save output to a review file outside the repo.
2. Classify each changed path into: (a) intended for this staging snapshot, (b) unrelated local work, (c) generated/scratch, (d) unknown — requires owner decision.
3. Confirm no secrets, `.env`, `node_modules`, build artifacts, or test databases are staged.
4. Run `git diff --check` on the intended set.
5. Stage only the classified-intended paths explicitly by name; never `git add -A` on a dirty tree.
6. Commit with a scoped message referencing the staging snapshot; push only after owner authorisation.
7. Record the resulting commit SHA in the deployment record and use that exact SHA for the Render deploy.

**This revision does not stage or commit anything.**

---

## 8. Cost table (zero-cost)

| Resource | Allowance | Overage without card | Overage with card |
|---|---|---|---|
| Render instance hours | 750/workspace/mo | Suspend all Free web services until next month | n/a (hours are free, not billable) |
| Render outbound bandwidth | 5 GB/workspace/mo | Suspend all Free services until next month | $0.15/GB |
| Render build minutes | 500/workspace/mo | New builds paused until next month | n/a |
| Neon compute | 100 CU-h/project/mo | Compute suspended | n/a (Free has no paid overage; upgrade required) |
| Neon storage | 1 GB/project | Writes blocked | n/a |
| Neon transfer | 5 GB/project/mo | (suspension of compute on exceed) | n/a |
| Upstash commands | 500k/mo | Command errors | n/a |
| Upstash data | 256 MB | Command errors | n/a |
| R2 storage/ops | 10 GB-mo / 1M A / 10M B | n/a (card required to enable) | Billed at published rates |

**Hard rule:** No payment method is added to Render, Neon, Upstash, or Cloudflare in this revision. Render/Neon/Upstash need none. R2 cannot be enabled without one → Scenario B.

---

## 9. What remains open (owner decisions)

- Refunds/cancellation policy beyond no-refund (AGENTS.md §4).
- Production scheduler ownership (notifications).
- JWT revocation/logout and `localStorage` migration.
- Settlement payout provider and reconciliation.
- Final Staging execution channel for migrations/admin promotion (resolved in principle: local; channel details in runbook).
- Whether to authorise a card for R2 (B-07).
- Whether to authorise the Dockerfile port change (OD-12 Option B).
- Whether to authorise an "uploads disabled" code flag (B-11).

---

## 10. Files in this revision

Created:
- `docs/deployment/JAM_ZERO_COST_STAGING_PROVIDER_VERIFICATION.md`
- `docs/deployment/JAM_ZERO_COST_LOCAL_MIGRATION_RUNBOOK.md`
- `docs/audits/JAM_PHASE_3_1_ZERO_COST_REVISION_REPORT.md`

Updated:
- `docs/deployment/JAM_PHASE_3_1_INFRASTRUCTURE_DECISION_MATRIX.md` (this file)
- `docs/deployment/JAM_PHASE_3_1_RECOMMENDED_STAGING_ARCHITECTURE.md`
- `docs/deployment/JAM_PHASE_3_1_DEPLOYMENT_EXECUTION_PLAN.md`

No other file is touched.
---

## 11. Architecture comparison addendum (2026-11-11)

Added by `JAM_PHASE_3_1_ARCHITECTURE_COMPARISON.md`. These items surface new owner decisions; they do not override the rows in §2.

| ID | Decision area | Options | Recommendation | Blocks next phase? |
|---|---|---|---|---|
| OD-16 | Frontend host: Render Free Web Service (baseline) vs Netlify Free (SSR adapter) | Render Free (2 providers total, no credit budget) vs Netlify Free (300 credits/mo, better Next.js DX) | Keep Render for the pilot; evaluate Netlify as a swap if Render Free proves inadequate | No |
| OD-17 | Database: Neon Free (baseline) vs Supabase Free | Neon (better restore/pause/compatibility) vs Supabase (1-week pause, no backups, IPv6 caveat) | Neon | No |
| OD-18 | Media: disabled uploads (baseline) vs Supabase Storage (1 GB, 50 MB max file, S3-compatible, $0) vs R2 (card required) | Disabled vs Supabase Storage vs R2 (conditional) | Disabled unless uploads must be demonstrated in the pilot; then Supabase Storage | No |
| OD-19 | Confirm geographic/account availability of all candidate providers from Iran before provisioning | Proceed vs defer | Complete `JAM_PHASE_3_1_PROVIDER_ACCESS_PREFLIGHT.md` first | **Yes** |

No rows in §2 were changed. Historical conclusions are preserved.
