# JAM — Phase 3.1 Provider Access Preflight (Iran)

**Document ID:** `JAM-PHASE-3.1-PROVIDER-ACCESS-PREFLIGHT-2026-11-11`
**Companion:** `JAM_PHASE_3_1_ARCHITECTURE_COMPARISON.md`, `JAM_PHASE_3_1_NETLIFY_SUPABASE_COMPATIBILITY_AUDIT.md`, `JAM_PHASE_3_1_ARCHITECTURE_COMPARISON_REPORT.md`.
**Scope:** Documentation and research only. No account creation, no VPN/circumvention, no provisioning.

---

## 1. Purpose

The owner operates from Iran. Provider availability there is a material, potentially blocking risk that is separate from a provider's published Free Tier. This document records what is officially documented, what is not, and what the owner must verify before selecting a provider. It does **not** recommend circumvention.

## 2. Classification scheme

Each provider is classified as one of:

- **Officially supported** — provider explicitly states service availability in Iran.
- **Explicitly restricted** — provider terms/policy explicitly prohibit or block Iranian users.
- **Not explicitly documented** — no explicit statement found; availability is unclear.
- **Operationally unverified** — cannot be confirmed from documentation alone; requires an owner-side test.

## 3. Findings (checked 2026-11-11)

### 3.1 Netlify

- **Classification: Not explicitly documented / Operationally unverified.**
- Searched: Netlify Terms of Use, Self-Serve Subscription Agreement, acceptable use policy. No explicit Iran/Sanctions clause was found in the snippets reviewed. Netlify's terms require valid account information and compliance with applicable law; they reserve the right to terminate accounts.
- **Evidence gap:** No official Netlify page was found stating whether Iranian residents may create or use accounts. The absence of an explicit ban is not proof of support.
- **Owner preflight:** attempt account creation from the owner's normal environment without VPN or false information; record the outcome. If blocked, document the block and do not attempt circumvention.

### 3.2 Supabase

- **Classification: Not explicitly documented / Operationally unverified.**
- Searched: Supabase Terms of Service, Acceptable Use Policy, regions, billing FAQ. No explicit Iran ban was found in the snippets reviewed. The AUP prohibits automated/bulk registration and using services to bypass geoip restrictions. A community thread exists asking whether an individual developer based in Iran may use Supabase for a small commercial project; no official answer was found in the search results.
- Supabase is a US-incorporated company; US sanctions law may apply regardless of published terms. This is a legal question, not a documentation question.
- **Owner preflight:** verify account creation and project creation from the owner's normal environment; consult legal counsel if commercial use is intended. Do not use VPN or false residency.

### 3.3 Render

- **Classification: Not explicitly documented / Operationally unverified.**
- Searched: Render docs (free tier, pricing, terms). No explicit Iran restriction was found in the snippets reviewed. Render is US-incorporated.
- Render requires a payment method only for paid overage; Free tier needs no card, which removes one potential block (card acceptance). Account creation may still be blocked by sanctions screening.
- **Owner preflight:** attempt account creation from the owner's normal environment; record outcome.

### 3.4 Neon

- **Classification: Not explicitly documented / Operationally unverified.**
- Searched: Neon docs and pricing. No explicit Iran restriction was found. Neon is US-incorporated (Databricks).
- **Owner preflight:** attempt account creation and project creation; record outcome.

### 3.5 Upstash

- **Classification: Not explicitly documented / Operationally unverified.**
- Searched: Upstash docs and pricing. No explicit Iran restriction was found. Upstash is US-incorporated.
- Upstash Free requires no card, removing one potential block.
- **Owner preflight:** attempt account creation; record outcome.

### 3.6 Cloudflare (R2)

- **Classification: Not explicitly documented / Operationally unverified, with an additional practical block.**
- Searched: Cloudflare billing policy, R2 get-started, terms. No explicit Iran ban was found in the snippets reviewed, but R2 requires a payment method on file (checkout) and Cloudflare accepts Visa/Mastercard/Amex/Discover/PayPal/Apple Pay/Google Pay/Stripe Link/UnionPay. Iranian-issued cards are not in that list, and PayPal/Apple Pay/Google Pay availability in Iran is limited. This is a **practical block** independent of any terms clause.
- Combined with the uncapped-overage billing risk, R2 remains non-compliant with the strict $0 rule (see comparison doc §6 and decision matrix OD-06).

## 4. What this means for the comparison

Geographic availability is **unverified for every provider**. It is not a differentiator between architectures A/B/C on the evidence available. It is a **blocking preflight item** for all of them: if any chosen provider cannot be used from Iran, that architecture is unavailable regardless of its technical merits.

Because no provider is confirmed available, the comparison recommendation (in the comparison report) is conditional on the owner completing this preflight. The preflight must be completed **before** any provisioning, and no circumvention (VPN, false billing info, false residency) is recommended.

## 5. Owner-side verification steps (no circumvention)

1. From the owner's normal, unmodified network and environment (no VPN, no proxy), attempt to create an account on each candidate provider (Netlify, Supabase, Render, Neon, Upstash; Cloudflare only if R2 is being reconsidered).
2. Record: whether signup succeeded, whether email verification succeeded, whether dashboard access works, whether a free project/database can be created, and any error message (without secrets).
3. If a provider blocks signup, record the block and mark that provider unavailable for this project; do not attempt workarounds.
4. If all candidate providers are blocked, the only remaining $0 path is Scenario C (local staging with a tunnel) or a non-cloud local-only setup; escalate to the owner.
5. Re-run this preflight whenever a provider's terms or the owner's location changes.

## 6. What this document does not authorise

No account creation, provisioning, billing, payment-method entry, deployment, migration, or code change. Documentation and research only.