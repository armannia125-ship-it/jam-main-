# Staging Operations

How to operate the staging deployment after Batch 1 preparation.

## 1. Running Migrations

Migrations are **never** run automatically: the backend Dockerfile neither runs
`migrate` at build time nor includes it in `CMD`. They must be executed
explicitly against the Staging database through an approved execution channel.

### A. Local Docker Compose

```bash
docker compose exec backend python manage.py migrate --noinput
```

This connects to the Compose `db` service defined by `POSTGRES_DB`,
`POSTGRES_USER`, `POSTGRES_HOST=db`, and `POSTGRES_PASSWORD`. It is safe and
idempotent and must not be pointed at the Staging database.

Inspect migration state before and after:

```bash
docker compose exec backend python manage.py showmigrations
docker compose exec backend python manage.py migrate --plan
```

The command is safe to retry: already-applied migrations are recorded and
skipped. A migration that failed partway may leave partial schema changes if
that migration was not atomic; inspect the state before rerunning.

### B. Render Staging — no verified Free-plan execution method

**Verified platform limitation (checked 2026-11-10):**

* Render Free instances are available only for Static Site, Web Service,
  Postgres, and Key Value services.
* Render documents that Free web services do **not** support:
  * running one-off jobs,
  * shell access via SSH or the Render Dashboard.
* The Render Dashboard therefore does **not** provide a "Run console" or
  one-off command for the Free backend service. The procedure previously
  documented in this file assumed that capability and was incorrect.

Sources (Render documentation, accessed 2026-11-10):

* <https://render.com/docs/free> — Free instance limitations
* <https://render.com/docs/ssh> — shell access support by service type
* <https://render.com/docs/one-off-jobs> — one-off jobs use a base service's
  build and environment

**Consequence:** there is currently **no verified, free-of-charge way to run
`python manage.py migrate` inside a Render Free backend service**. No speculative
workaround is implemented in this repository.

Available options and trade-offs:

| Option | Trade-off |
|---|---|
| Temporarily move the backend to a paid instance type and use a Render one-off job or paid shell | Not free; requires owner authorization and billing; no new service is added; the job must target one base service and run once |
| Run the migration from an operator workstation against Neon using the exact deployed commit, lock file, and container image | Not executed by Render; requires owner-authorized TLS access to the Staging database; a version mismatch would corrupt schema expectations, so the image digest must match the deploy |
| Add a separate cron job or background worker | Paid on Render; introduces a new deployment component; out of scope for this batch |
| Run `migrate` from the web-service start command | Rejected: runs on every restart, can overlap with other starts, hides failures, and conflicts with the no-automatic-migration rule |

Regardless of the option chosen, the operator must:

1. Confirm the target is the Staging database (not the local Compose database)
   and take a database export/snapshot first, if the provider supports it.
2. Inspect state: `python manage.py showmigrations` and
   `python manage.py migrate --plan`.
3. Run `python manage.py migrate --noinput` **once**, from **one** process, and
   wait for it to exit.
4. Re-run `showmigrations` to confirm the expected migrations are applied.
5. If it fails, stop; do not run a second migration concurrently. Read the
   failure, inspect `showmigrations`, and correct the cause before retrying.
   Retrying is safe for migrations that were never applied; a partially applied
   non-atomic migration may require manual repair.

**Status: Batch 2 deployment blocker.** The owner must choose and authorize an
execution channel before the first Staging deploy. Do not deploy the backend
assuming its schema exists.

## 2. Collecting Static Files

### Local Docker Compose

```bash
docker compose exec backend python manage.py collectstatic --noinput
```

This must be run after any static file changes and after the first build. It collects all
files from `STATICFILES_DIRS` into `STATIC_ROOT` (`backend/staticfiles`).

### Render Staging

Static files are collected at **Docker image build time** (see the backend
Dockerfile: `RUN python manage.py collectstatic --noinput`). This happens during
the build stage, not at runtime.

If static files change after deployment, redeploy the backend service — the new
image will include the updated static files. No manual `collectstatic` is needed
in the running Render service.

Render Free web services do not support one-off commands or shell access
(see §1B). Redeploying the service is therefore the only supported way to
update static files on Free compute; the build step regenerates them. A manual
`collectstatic` requires an approved execution channel and is unnecessary when
redeploying.

## 3. Promoting the First Admin

### Important

`make_admin` **promotes an existing registered user only**. It does **not** create a
new user, set a password, or accept any registration input. There is no public
admin-registration endpoint. The first admin must be an existing user.

### Safe sequence

1. Register an ordinary user using the existing supported registration workflow
   (the OTP-based signup flow in the frontend).
2. Verify the user exists and is eligible (active, not already an admin).
3. Run the promotion command.
4. Verify the resulting server-side admin role via `GET /api/auth/me/`.

### Local Docker Compose

```bash
docker compose exec backend python manage.py make_admin --phone +989xxxxxxxxx
```

### Render Staging

`make_admin` requires a shell or one-off execution channel. Render Free web
services support neither (see §1B), so this operation has no verified Free-plan
execution path. It is part of the same Batch 2 deployment blocker as migrations:
the owner must authorize a channel before the first admin can be promoted.

The command reads the same environment variables as the running service and
must target the Staging database. It:

* Promotes an existing registered user only — never creates a new account

* Refuses inactive users
* Refuses to demote the last active admin
* Writes an `AdminAction` audit row (actor, action, target, timestamp, safe metadata)
* Is idempotent — repeated runs on the same user are harmless
* Never accepts or sets a password (users log in with the existing OTP flow)

## 4. Inspecting Logs Safely

### Local Docker Compose

Container logs are accessible via standard Docker log commands:

```bash
docker compose logs backend    # Backend stdout/stderr
docker compose logs frontend   # Next.js output
docker compose logs redis      # Redis operations (no secrets)
docker compose logs db         # PostgreSQL health logs
```

### Render Staging

Render provides built-in log aggregation accessible through the Render dashboard
or the Render CLI. No Docker Compose commands are available in Render.

```bash
# Via the Render dashboard:
#   Navigate to the service -> Logs tab
#   Filter by: service (backend/frontend), time range, log level

# Via the Render CLI (if installed):
render logs --service <service-name> --tail 50
```

Do NOT expose `DJANGO_SECRET_KEY`, `OTPY_API_KEY`, `ZARINPAL_MERCHANT_ID`, or
other secret values in logs. Render logs may be accessible to anyone with
dashboard access — ensure secret values are never logged.

Gunicorn logs request tracebacks to stderr (see `LOGGING` in `settings.py`).
The `django.request` logger captures unhandled request errors at ERROR level.

## 5. Diagnosing Database and Redis Connection Issues

> **Note:** `python manage.py check --deploy` performs Django's built-in system
> checks. It does **not** prove that PostgreSQL or Redis are actually reachable.
> Use the checks below for real connectivity verification.

### Execution channels

* **Local Docker Compose:** the `manage.py shell` checks below can be run with
  `docker compose exec backend ...`.
* **Render Free:** no shell and no one-off command is available (see §1B). The
  only externally callable check is the readiness endpoint over HTTPS:
  `GET https://<backend-service>.onrender.com/api/health/ready/`.
* **Any paid Render plan or operator workstation:** the application-level shell
  checks are usable only after the owner authorizes that channel.

### PostgreSQL — Application-level check

Uses Django's configured database connection and executes a harmless `SELECT 1`.
It does **not** print credentials, the connection URL, or stack traces.

```bash
# Local Docker Compose
docker compose exec backend python manage.py shell -c "
from django.db import connection
with connection.cursor() as cursor:
    cursor.execute('SELECT 1')
    print('PostgreSQL OK:', cursor.fetchone()[0])
"
```

Expected output: `PostgreSQL OK: 1`

On Render Free, use the readiness endpoint (its `database` field is backed by
the same `SELECT 1`):

```bash
curl -fsS https://<backend-service>.onrender.com/api/health/ready/
```

A `database: "ok"` result proves the running Staging service reached PostgreSQL.
It does not prove migration state (see §1) or that a specific Neon project is in
use; inspect the configured environment variables in the Render dashboard for
that.

If the database check fails, check:
- `POSTGRES_HOST` resolves to the Neon host
- `POSTGRES_USER` and `POSTGRES_PASSWORD` are correct
- Neon's firewall allows the Render service's egress IP
- The database is not in paused/suspended state

### Redis checks — three distinct checks

#### A. Local Compose Redis container (local only)

```bash
docker compose exec redis redis-cli ping
# Expected: PONG
```

**Proves only** that the Compose `redis` container is running and answering. It
says nothing about the application's configured Redis or Upstash.

#### B. Configured cache backend (application-level)

This check inspects the actual `CACHES` backend and refuses to treat
`LocMemCache` as external Redis. It never prints the Redis URL or credentials.

```bash
# Local Docker Compose, or an owner-authorized shell
# (not available on Render Free — see §1B)
docker compose exec backend python manage.py shell -c "
from django.conf import settings
from config.health import cache_status

backend = settings.CACHES.get('default', {}).get('BACKEND', '')
print('Cache backend:', backend)
if backend != 'django_redis.cache.RedisCache':
    raise SystemExit('FAIL: cache is not Redis-backed; this is not external Redis connectivity')
if not settings.REDIS_URL:
    raise SystemExit('FAIL: REDIS_URL is not set')
if cache_status() != 'ok':
    raise SystemExit('FAIL: cache set/get failed; Redis is unreachable or misconfigured')
print('Redis OK: configured Redis backend passed set/get')
"
```

On Render Free, call the readiness endpoint instead:

```bash
curl -fsS https://<backend-service>.onrender.com/api/health/ready/
```

When the service runs with `DJANGO_DEBUG=false` (the Staging default), the
default `CACHE_REQUIRE_REDIS=true` applies. Readiness then reports
`cache: "ok"` **only if** the configured backend is
`django_redis.cache.RedisCache`, `REDIS_URL` is set, and a set/get round-trip
succeeded. A `LocMemCache` fallback is reported as
`cache: "unavailable"` with HTTP 503. The response shape is unchanged.

What this proves: the URL configured in that service is reachable and usable.
It does not identify the provider; confirm the Render environment's `REDIS_URL`
points at the intended Upstash database without printing its value.

#### C. Local in-memory fallback (not external Redis)

When `REDIS_URL` is empty and `CACHE_REQUIRE_REDIS` is false (the normal local
development configuration), Django falls back to
`django.core.cache.backends.locmem.LocMemCache`. A `cache.set/get` in that mode
succeeds, but it proves **only local process memory**. It must never be reported
as Upstash connectivity.

`CACHE_REQUIRE_REDIS` defaults to `not DEBUG`: disabled for local development,
enabled for deployed environments. Setting it to `true` forces Redis-backend
requirements even in a debug configuration.

### Redis state matrix

| State | `CACHES` backend | `CACHE_REQUIRE_REDIS` | Readiness `cache` | Meaning |
|-------|-----------------|----------------------|-------------------|---------|
| Redis configured and reachable | `django_redis.cache.RedisCache` | any | `ok` | Configured Redis set/get succeeded |
| Redis configured but unreachable | `django_redis.cache.RedisCache` | any | `unavailable` | Redis down, TLS/auth failure, or readback mismatch |
| Redis backend but no `REDIS_URL` | `django_redis.cache.RedisCache` | any | `unavailable` | Misconfigured; fails clearly |
| LocMem fallback, deployed | `LocMemCache` | `true` | `unavailable` | **Not** external Redis; readiness fails closed |
| LocMem fallback, local | `LocMemCache` | `false` | `ok` | Local process memory only; not external Redis |

### Health endpoint check

The readiness endpoint (`GET /api/health/ready/`) performs both checks (see §9 of
`STAGING_PREPARATION.md`). Its response contract is unchanged:

```json
{"status": "ready", "checks": {"database": "ok", "cache": "ok"}}
```

or `not_ready` with status 503 if either check fails. It does **not** require
OTPy, ZarinPal, or Telegram Bot token. It is safe to call repeatedly.

## 6. Verifying Media Storage

### A. Configuration-only verification (no external credentials required)

This check verifies that the S3 storage backend is selected and initializes
correctly. It does **not** make any network request.

```bash
# Local Docker Compose
docker compose exec backend python manage.py shell -c "
from django.conf import settings
print('Storage backend:', settings.STORAGES.get('default', {}).get('BACKEND', 'not configured'))
print('Bucket:', settings.S3_BUCKET_NAME or '(not set)')
print('Endpoint:', settings.S3_AWS_ENDPOINT_URL or '(not set)')
print('Region:', settings.S3_AWS_REGION_NAME or '(not set)')
print('S3 access key set:', bool(settings.S3_AWS_ACCESS_KEY_ID))
print('S3 secret key set:', bool(settings.S3_AWS_SECRET_ACCESS_KEY))
"
```

This check requires a shell. Render Free provides no shell or one-off job
(see §1B), so on Free compute it is **not executable**. The app's fail-closed
startup check is the Free-plan signal: if S3 mode is selected without complete
credentials, the service exits before serving traffic. A configuration report
can be produced only through an owner-authorized execution channel.

Expected output (filesystem mode):

```
Storage backend: django.core.files.storage.FileSystemStorage
Bucket: (not set)
Endpoint: (not set)
Region: (not set)
S3 access key set: False
S3 secret key set: False
```

Expected output (S3 mode with credentials):

```
Storage backend: storages.backends.s3boto3.S3Boto3Storage
Bucket: <bucket-name>
Endpoint: <endpoint-url>
Region: <region-name>
S3 access key set: True
S3 secret key set: True
```

If `DEFAULT_FILE_STORAGE_BACKEND` points to a non-filesystem backend but
`AWS_STORAGE_BUCKET_NAME`, `AWS_ACCESS_KEY_ID`, or `AWS_SECRET_ACCESS_KEY`
is missing, the application fails to start with an `ImproperlyConfigured`
error (see §6 of `STAGING_PREPARATION.md`).

### Filesystem mode (default, local only)

```bash
ls -la backend/media/
```

Images should be accessible under `MEDIA_URL /media/` through the Django
development server or production WSGI. This check is **local-only** and does
not apply to Render Staging.

### B. S3 integration (deferred — requires owner authorization)

This procedure must be executed **only after** the owner has provisioned the
S3-compatible bucket, explicitly authorized credential configuration, and
provided an approved execution channel. **Do not run it in Batch 1.2.** It makes
real API calls to an external storage endpoint. Render Free provides no shell or
one-off job (see §1B).

The procedure verifies:

1. Uploading a small temporary file through Django's configured storage backend.
2. Confirming that the object exists.
3. Reading it back through the same backend.
4. Comparing the exact contents.
5. Deleting only that exact temporary object.
6. Confirming that the object no longer exists.

```bash
# Run only after owner authorization, bucket provisioning, and an approved
# execution channel. Credentials come from the environment — never arguments.
python manage.py shell -c "
import uuid
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage

# Unique, namespaced key. Never reuse or overwrite an existing object.
test_key = f'jam-staging-verify/{uuid.uuid4().hex}.txt'
payload = b'JAM staging verification - safe to delete'
saved_name = None

try:
    if default_storage.exists(test_key):
        raise RuntimeError('Refusing to overwrite an existing object')

    # 1. Upload through Django's configured storage backend.
    saved_name = default_storage.save(test_key, ContentFile(payload))

    # 2. Confirm the object exists.
    if not default_storage.exists(saved_name):
        raise RuntimeError('Object not found after upload')

    # 3. Read it back and compare the exact bytes.
    with default_storage.open(saved_name, 'rb') as handle:
        if handle.read() != payload:
            raise RuntimeError('Content mismatch after readback')

    print('S3 integration verification PASSED')
finally:
    # 4. Cleanup is attempted even if an upload, read, or assertion failed.
    #    Only the UUID-named objects under jam-staging-verify/ are touched.
    for name in {saved_name, test_key}:
        if name and default_storage.exists(name):
            default_storage.delete(name)
    leftovers = [n for n in {saved_name, test_key} if n and default_storage.exists(n)]
    if leftovers:
        raise RuntimeError('Temporary verification object still exists: ' + ', '.join(leftovers))
"
```

**Safety requirements:**

- Credentials are read from the environment or Django's configured storage
  backend — **never** placed in command arguments, documentation, logs, or
  source code.
- Never print secret values.
- Use a unique UUID key under `jam-staging-verify/`.
- Never overwrite or delete user media.
- Use the application's configured `default_storage`, not a separate boto3
  client; the purpose is to verify Django storage integration.
- Cleanup runs in `finally`, so a failed assertion or read still attempts to
  delete the temporary object.
- This procedure must **not** be run in Batch 1.2.

### C. Media delivery (deferred)

This verifies that an uploaded file is actually reachable through the
application's real frontend/backend media delivery path. It is not proven by a
successful S3 upload.

```bash
# Test that the frontend API proxy forwards media requests to the backend.
curl -I http://localhost:3000/api/media-proxy/<path>
```

The API proxy at `frontend/app/api/[...path]/route.ts` handles proxy requests
when `API_INTERNAL_URL` is configured. This check is local-only until Staging
media delivery is authorized and configured.

### Verification levels

| Level | Check | Proves |
|-------|-------|--------|
| A | Configuration-only | Backend selected and settings initialized; no network request |
| B | S3 integration | Upload, existence, readback, exact-content comparison, and delete through the configured Django backend |
| C | Media delivery | Media URLs are reachable through the real frontend/backend delivery path |

Levels A, B, and C are independent. Level A does not prove credentials work;
Level B does not prove files are served to users; a successful `list_objects`
call proves none of upload, retrieval, or delivery. Batch 1.2 claims only what
it ran locally: Level A in filesystem mode and fail-closed startup behavior.
Levels B and C have **not** passed and are deferred.

## 7. Restarting Services Safely

### Local Docker Compose

```bash
# Graceful restart — running processes finish current requests first
docker compose restart backend
docker compose restart frontend

# Full restart — stop and start all services
docker compose down
docker compose up --build
```

After restart, run migrations if not automatic:
```bash
docker compose exec backend python manage.py migrate --noinput
```

### Render Staging

Render manages service restarts differently. There is no `docker compose restart`
equivalent. Use one of these approaches:

**Redeploy (recommended):**
- In the Render dashboard, navigate to the service, click "Deploy", and select
  "Deploy latest commit" or "Deploy latest image".
- This creates a new instance with the latest image and environment variables.
- The old instance is drained gracefully before being terminated.

**Manual restart:**
- In the Render dashboard, navigate to the service, click "Restart", and select
  "Restart service" or "Restart instance".
- This restarts the current instance without redeploying.
- Use only for troubleshooting; the instance retains its previous state.

**Important:**
- Migrations are **not** run automatically on restart (the Dockerfile CMD no
  longer includes `migrate`).
- If you redeploy with a new database schema, run migrations first through an
  owner-approved channel (see §1B).
- Render free services spin down after 15 minutes of inactivity. A restart or
  redeploy will bring the service back online with a cold start.

### Render service health checks

Render automatically monitors each web service. If the service fails its health
check, Render restarts the instance. The backend service's health check uses
the readiness endpoint (`GET /api/health/ready/`), which verifies PostgreSQL
and cache connectivity.

The frontend service's health check is configured in the Dockerfile or
`render.yaml` (if present). A simple HTTP check on port 3000 is sufficient.

### Render service logs

Render provides built-in log aggregation. Access logs through:
- The Render dashboard: navigate to the service, click the "Logs" tab
- The Render CLI: `render logs --service <service-name> --tail 50`

## 8. Avoiding Concurrent Migration Issues

Render Free is limited to one instance per web service, but a migration must
still be treated as a single-operator operation. For any approved channel:

1. Do not run `migrate` from the entrypoint CMD or start command.
2. Use exactly one process and wait for it to exit before starting anything else.
3. Do not run a migration while another deploy, job, or operator is migrating.
4. Inspect with `python manage.py showmigrations` and
   `python manage.py migrate --plan` before applying.
5. If an execution channel cannot guarantee one-at-a-time execution, do not use
   it for migrations. The owner must select a channel that does (see §1B).

## 9. Keeping Telegram Bot Disabled

The bot command is available in the codebase but **intentionally excluded**
from all startup paths. It must not run during normal Staging operation.

### Where the bot is NOT started

- **Backend Dockerfile CMD:** Only starts Gunicorn. No `run_telegram_bot`.
- **Docker Compose:** No service runs `run_telegram_bot`.
- **Render deployment:** No Docker start script or entrypoint triggers the bot.
- **Default environment:** `TELEGRAM_BOT_TOKEN` is empty by default.

### How to start the bot (manual only)

The bot can be started manually when explicitly authorized. It requires
`TELEGRAM_BOT_TOKEN` and `TELEGRAM_BOT_USERNAME` environment variables.

**Local Docker Compose:**
```bash
docker compose exec backend python manage.py run_telegram_bot
```

**Render Staging:**
Not available on Render Free: there is no shell or one-off job (see §1B). Do not
replace the disabled startup path with a web-service start command. Any manual
start would require an owner-approved paid execution channel and explicit
authorization.

Start only when explicitly authorized. Do not start it as part of normal
Staging operation.

### Prohibited actions

- Do NOT configure Telegram webhooks.
- Do NOT send real Telegram messages.
- Do NOT contact Telegram API endpoints.
- Do NOT create webhook registrations.

## 10. Avoiding Concurrent Migration Pitfalls

* Run migration on a single backend instance at a time
* Verify with `python manage.py showmigrations` before and after
* Never run multiple `manage.py migrate` processes against the same database simultaneously
* If using Docker Swarm/Kubernetes, use pod disruption budgets and drain nodes before upgrades

## 11. Environment Variable Reference

### Canonical Object Storage variables

| Variable | Required (S3 mode) | Purpose |
|---|---|---|
| `DEFAULT_FILE_STORAGE_BACKEND` | Yes | Switch: `django.core.files.storage.FileSystemStorage` (default) or `storages.backends.s3boto3.S3Boto3Storage` |
| `AWS_STORAGE_BUCKET_NAME` | Yes | S3 bucket name |
| `AWS_ACCESS_KEY_ID` | Yes | S3 access key ID |
| `AWS_SECRET_ACCESS_KEY` | Yes | S3 secret access key |
| `AWS_S3_ENDPOINT_URL` | No | Custom S3-compatible endpoint URL (e.g., for non-AWS providers) |
| `AWS_S3_REGION_NAME` | No | S3 region |
| `AWS_S3_CUSTOM_DOMAIN` | No | Custom domain for media URLs (optional) |
| `AWS_DEFAULT_ACL` | No | Default ACL for uploaded objects (optional) |

### Full variable reference

| Variable | Required | Purpose |
|---|---|---|
| DJANGO_DEBUG | Optional | `true`/`false`; defaults `false` |
| DJANGO_SECRET_KEY | Required when DEBUG=false | Must be a strong random value |
| OTPY_API_KEY | Optional in DEBUG; required in production | OTP provider key |
| DJANGO_ALLOWED_HOSTS | Optional | Comma-separated host list |
| DJANGO_CSRF_TRUSTED_ORIGINS | Optional | HTTPS origins for CSRF |
| PUBLIC_FRONTEND_URL | Required for QR codes | Absolute public frontend origin (e.g. `https://frontend.example`), used for server-generated menu/QR links. Never derived from request headers; the QR endpoint fails closed (503) when it is missing or invalid. |
| DEFAULT_FILE_STORAGE_BACKEND | Optional | Switch storage backend (filesystem default) |
| AWS_STORAGE_BUCKET_NAME | Optional (S3 mode) | Bucket name |
| AWS_ACCESS_KEY_ID | Optional (S3 mode) | Access key |
| AWS_SECRET_ACCESS_KEY | Optional (S3 mode) | Secret key |
| AWS_S3_ENDPOINT_URL | Optional (S3 mode) | Custom endpoint URL |
| AWS_S3_REGION_NAME | Optional (S3 mode) | S3 region |
| REDIS_URL | Required in deployed environments | Redis cache URL; when empty, local `LocMemCache` fallback is used |
| CACHE_REQUIRE_REDIS | Optional | Force Redis-backed readiness; defaults to `true` when `DEBUG` is false, `false` when `DEBUG` is true |
| POSTGRES_DB | Required | Database name |
| POSTGRES_USER | Required | Database user |
| POSTGRES_PASSWORD | Required | Database password |
| POSTGRES_HOST | Required | Database host |
| POSTGRES_PORT | Optional | Database port (5432 default) |
| ZARINPAL_MERCHANT_ID | Optional | Payment gateway merchant ID |
| ZARINPAL_CALLBACK_URL | Optional | Payment callback URL |
| TELEGRAM_BOT_TOKEN | Optional | Bot token (for manual start only) |
| TELEGRAM_BOT_USERNAME | Optional | Bot username |
| COMMERCE_ALLOW_SIMULATED_PAYMENTS | Optional | Simulated payments enable flag |
| COMMERCE_ORDER_ONLINE_PAYMENTS_ENABLED | Optional | Online order payments flag |