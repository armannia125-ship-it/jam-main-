# JAM — Phase 3.1 Deployment Execution Plan (Zero-Cost)

**Document ID:** `JAM-PHASE-3.1-EXECUTION-PLAN-ZERO-COST-2026-11-11`
**Companion:** `JAM_ZERO_COST_STAGING_PROVIDER_VERIFICATION.md`, `JAM_PHASE_3_1_INFRASTRUCTURE_DECISION_MATRIX.md`, `JAM_PHASE_3_1_RECOMMENDED_STAGING_ARCHITECTURE.md`, `JAM_ZERO_COST_LOCAL_MIGRATION_RUNBOOK.md`.
**Scope:** Documentation only. No provisioning, billing, code, or deployment. Every stage below is a **plan**; none has been executed.

---

## 0. Binding owner decisions (OWNER DECISION)

$0 budget; no payment method/billing activation to bypass a Free Tier; R2 only if usable without charges; migrations from owner's local dev; no provisioning/commit/push/deployment in this revision; frontend must be a genuinely zero-cost option.

## 1. Guiding rules

1. **No automatic migration at container startup.** Render Free has no shell/one-off jobs; startup migration is an unreviewed destructive path and is forbidden.
2. **No payment method is added** to Render, Neon, Upstash, or Cloudflare in this revision.
3. **Render health check path = `/api/health/live/` only.**
4. **Telegram bot stays disabled.**
5. **Zarinpal stays unconfigured** (`ZARINPAL_SANDBOX=True`, empty merchant ID) until explicitly authorised.
6. **No production-readiness claim** may be made from a successful staging boot.
7. **Every stage ends at a gate** that requires explicit owner authorisation before the next stage.

---

## 2. Stage map

| Stage | Name | Output | Gate |
|---|---|---|---|
| 3.2.0 | Pre-flight (local) | Verified local test/build baseline + owner decisions recorded | G0 |
| 3.2.1 | Account & service creation (owner) | Render/Neon/Upstash services exist; no card added | G1 |
| 3.2.2 | Environment configuration | Env vars set in Render dashboards | G2 |
| 3.2.3 | Database migration (owner, local) | Neon schema at target revision | G3 |
| 3.2.4 | Admin promotion (owner, local) | First admin user exists | G4 |
| 3.2.5 | Deploy backend | Backend live on Render Free | G5 |
| 3.2.6 | Deploy frontend | Frontend live on Render Free | G6 |
| 3.3 | Smoke testing | Verified staging behaviour | G7 |
| 3.4 | Quota & cost checkpoint (monthly) | Usage within allowances | G8 |

---

## 3. Stage 3.2.0 — Pre-flight (local) (OWNER DECISION)

**Actions (local, no external mutation):**
1. Re-run the verified baseline: `python manage.py check --settings=config.test_settings`; `python manage.py test --settings=config.test_settings`; `python manage.py makemigrations --check --dry-run --settings=config.test_settings`.
2. Frontend: `npx tsc --noEmit`; `npm run lint`; (optionally) `npm run build`.
3. Confirm `git status --short` and record the dirty-tree classification (decision matrix §7).
4. Confirm owner decisions in §0 are still in force; record any change in the deployment record.
5. Confirm `NEXT_PUBLIC_DEMO_MODE=False` will be set (production must not fall back to demo stores).

**Gate G0:** Owner confirms baseline is green and the dirty-tree classification is acceptable. **No external action before G0.**

---

## 4. Stage 3.2.1 — Account & service creation (owner) (PROTECTED)

**Owner-only actions (not performed in this revision):**
1. Create a Render Hobby workspace (no payment method).
2. Create a Render Free Web Service for the backend (Docker, `backend/Dockerfile`).
3. Create a Render Free Web Service for the frontend (Docker, `frontend/Dockerfile`).
4. Create a Neon Free project (no credit card) and a dedicated staging database + role.
5. Create an Upstash Free Redis database (no credit card); copy the `rediss://` URL.
6. **Do not** create an R2 bucket or enable R2 (Scenario B default). If the owner wants R2, that is a separate authorisation (B-07) and requires adding a card.
7. **Do not** add a payment method to Render, Neon, or Upstash.

**Verification after creation:**
- Render: workspace shows Hobby plan, no card on file, 750 instance hours remaining.
- Neon: project on Free plan, 1 GB storage, scale-to-zero enabled.
- Upstash: database on Free plan, 256 MB / 500k commands.

**Gate G1:** Owner confirms services exist and no card was added.

---

## 5. Stage 3.2.2 — Environment configuration (PROTECTED)

Set the variables in §5 of the architecture doc in the Render dashboards (backend + frontend). Critical:
- `PORT` handling per §6 of the architecture doc (Option A first).
- Health check path: `/api/health/live/` for the backend; a shallow path for the frontend.
- `ZARINPAL_SANDBOX=True` explicitly.
- `NEXT_PUBLIC_DEMO_MODE=False`.

**Secrets handling:** enter values only in the Render dashboard; never in repo, never in logs, never in commit messages. Rotate any value that is ever printed.

**Gate G2:** Owner confirms all variables set and no secret appears in any repo file.

---

## 6. Stage 3.2.3 — Database migration (owner, local) (PROTECTED)

**Full procedure:** `JAM_ZERO_COST_LOCAL_MIGRATION_RUNBOOK.md`. Summary:
1. Verify target identity (database name, user, host, version) before any write.
2. Create a Neon branch backup (or `pg_dump` custom format to a local file outside the repo).
3. Run `python manage.py migrate --noinput` against the **direct** (non-pooled) Neon host, with `DJANGO_SETTINGS_MODULE=config.settings` and the staging env loaded from a temporary, `chmod 600` file.
4. Verify with `showmigrations` (all applied) and `check`.
5. Record commit SHA, migration list, and timestamp in the deployment record.

**Hard rules:**
- Never run migrations against a host that is not confirmed as the staging database.
- Never use the pooled (`-pooler`) host for migrations.
- Never run `flush`, `reset`, or any mass delete/update.
- Never edit or fake migrations to make them pass.

**Gate G3:** Owner confirms migration applied and verified; backup retained.

---

## 7. Stage 3.2.4 — Admin promotion (owner, local) (PROTECTED)

1. Ensure the first admin user already exists as an active user (phone signup or seed). `make_admin` promotes an existing active user only.
2. Run `python manage.py make_admin --phone +989xxxxxxxxx` against the staging database (direct host, same env file as §6).
3. Verify via `GET /api/auth/me/` after login that `role=admin`.
4. Record the promoted phone (masked) and timestamp in the deployment record.

**Gate G4:** Owner confirms admin access works and audit row exists.

---

## 8. Stage 3.2.5 — Deploy backend (PROTECTED)

1. Trigger a manual deploy of the backend service from the recorded commit SHA.
2. Watch build logs: `collectstatic` succeeds; image builds; Gunicorn starts on the bound port.
3. Confirm Render health check on `/api/health/live/` returns 200.
4. Confirm `/api/health/ready/` returns 200 (manual, one call).
5. Check logs for: no `ImproperlyConfigured`, no migration errors (migrations were pre-applied), no secret leakage.

**If the port binding fails:** escalate to OD-12 Option B (authorised Dockerfile change) — do not improvise.

**Gate G5:** Owner confirms backend live and healthy.

---

## 9. Stage 3.2.6 — Deploy frontend (PROTECTED)

1. Trigger a manual deploy of the frontend service from the same commit SHA.
2. Confirm build succeeds (`npm run build` inside the image).
3. Confirm the service starts on `$PORT` and Render health check passes.
4. Confirm `NEXT_PUBLIC_DEMO_MODE=False` is in effect (no demo stores appear).

**Gate G6:** Owner confirms frontend live.

---

## 10. Stage 3.3 — Smoke testing (PROTECTED)

Manual checks (no automated external test infra exists):
1. Storefront loads; a real public menu loads via `/api/...` proxy (requires a current MENU entitlement).
2. Login via OTP (real provider) — verify OTP delivery works in staging.
3. Admin panel loads for the promoted admin; non-admin gets 403/404 on admin APIs.
4. Subscription catalog loads; a **sandbox** Zarinpal flow completes end-to-end (no real money) and verification promotes state only after server-side verify.
5. Health: `/api/health/live/` 200; `/api/health/ready/` 200.
6. Confirm no `/media/` uploads are promised to testers (Scenario B).
7. Confirm Telegram bot is not running and no webhook is registered.
8. Confirm cold-start behaviour is observed and documented (one backend + one frontend cold start).

**Gate G7:** Owner confirms smoke tests pass or documents failures.

---

## 11. Stage 3.4 — Quota & cost checkpoint (monthly)

Run at the end of each staging month (or sooner if usage spikes):
1. Render dashboard: instance hours used (target < 700), bandwidth used (target < 4.5 GB), build minutes used (target < 450).
2. Neon console: CU-hours used (target < 90), storage (target < 0.9 GB), transfer (target < 4.5 GB).
3. Upstash console: commands used (target < 300,000), data size (target < 200 MB).
4. Confirm no payment method was added; confirm no invoice/charge exists.
5. Confirm R2 still disabled (Scenario B) unless explicitly authorised.
6. Record the checkpoint in the deployment record.

**Gate G8:** Owner confirms usage within allowances and $0 maintained.

---

## 12. Rollback

- Render: rollback to the two most recent previous deploys (supported on Free). A failed health check keeps the previous deploy live.
- Neon: restore from the 6-hour / 1 GB change-history window or a pre-migration branch. **Django migrations are not universally reversible** — forward-fix or branch restore; never `migrate --fake` or hand-edited down-migrations.
- Upstash: no restore; cache is ephemeral.
- If a rollback is needed during a migration window: stop (do not run more commands), restore the Neon branch, redeploy the previous image SHA, and record the incident.

---

## 13. What this plan does not authorise

No provisioning, account creation, billing activation, code/env/Dockerfile/Compose/Caddy/migration/dependency changes, git commit/push, or deployment. Those require separate explicit owner authorisation per stage gate.