# JAM — Phase 3.1 Netlify + Supabase Compatibility Audit

**Document ID:** `JAM-PHASE-3.1-NETLIFY-SUPABASE-COMPATIBILITY-AUDIT-2026-11-11`
**Companion:** `JAM_PHASE_3_1_ARCHITECTURE_COMPARISON.md`, `JAM_PHASE_3_1_PROVIDER_ACCESS_PREFLIGHT.md`, `JAM_PHASE_3_1_ARCHITECTURE_COMPARISON_REPORT.md`, and the existing Phase 3.1 zero-cost set.
**Scope:** Documentation and research only. No code, config, provisioning, migration, or deployment.

---

## 1. Purpose and method

This audit answers one question: **can the current JAM codebase run on Netlify (frontend) + Supabase (PostgreSQL + Storage) without code changes, and what would have to change?** It is based on:

- Direct inspection of the repository (Next.js config, App Router handlers, Django settings, storage, Dockerfiles, migrations).
- Official Netlify and Supabase documentation/pricing, checked 2026-11-11.

Every claim is labelled **VERIFIED FACT** (official doc or code), **ENGINEERING ANALYSIS** (inference), or **UNVERIFIED** (could not confirm).

---

## 2. JAM repository findings (VERIFIED FACT)

### 2.1 Frontend (`frontend/`)

- `next.config.mjs`:
  - `skipTrailingSlashRedirect: true`.
  - `images.remotePatterns`: only `http/https` on `localhost`.
  - `rewrites()`: `/api/:path*` → `${API_INTERNAL_URL}/api/:path*` (server-side, runtime env).
- `app/api/[...path]/route.ts`: catch-all route handler, `dynamic = "force-dynamic"`, handles GET/POST/PUT/PATCH/DELETE/HEAD, proxies to `${API_INTERNAL_URL}` with trailing slash restored; forwards `authorization`, `content-type`, `cookie`, `x-forwarded-*`; sets `Cache-Control: no-store` for API, `public, max-age=86400` for media proxy.
- `app/health/route.ts`: `force-dynamic`, returns JSON.
- `app/page.tsx`: `force-dynamic`.
- Dynamic routes without `generateStaticParams`: `app/m/[slug]`, `app/order/[id]`, `app/store/[id]`, `app/visit/[storeId]`.
- `lib/api.ts` (auth): JWT in `localStorage`, single-flight refresh, 401 retry, calls same-origin `/api`.
- `lib/public-menu.ts` `mediaSrc()`: rewrites any URL containing `/media/` to `/api/media-proxy/...`.
- `NEXT_PUBLIC_DEMO_MODE` gates demo data; production must be `False`.
- `API_INTERNAL_URL` is server-only (read at runtime by the proxy and `mediaSrc`-adjacent code).
- No `middleware.ts` exists in the repository (no Next.js Middleware file).
- No Server Actions detected in the inspected files (client components dominate; 26 of 35 pages are `"use client"`).

### 2.2 Backend (`backend/`)

- Django 5.2, DRF, SimpleJWT. `DATABASES` uses `psycopg` PostgreSQL; `CONN_MAX_AGE=60`; no `sslmode`/`OPTIONS`/`connect_timeout` set (relies on libpq defaults).
- `REDIS_URL` optional; `CACHE_REQUIRE_REDIS` defaults to `not DEBUG`; when set, uses `django_redis` with `DefaultClient`.
- `DEFAULT_FILE_STORAGE_BACKEND` defaults to `FileSystemStorage`; S3 mode requires all three AWS credentials or startup fails closed; S3 options live under `OPTIONS` (django-storages 1.14).
- `CORS_ALLOW_ALL_ORIGINS = DEBUG`; `CORS_ALLOWED_ORIGINS = ["http://localhost:3000"]`; `CSRF_TRUSTED_ORIGINS` from env.
- `ZARINPAL_SANDBOX = os.getenv("ZARINPAL_SANDBOX", str(DEBUG)).lower() == "true"` (defaults to DEBUG).
- `config/urls.py`: media served via `static()` only when `DEBUG=True`; `/api/health/live/` and `/api/health/ready/` (ready runs `SELECT 1` + cache set/get).
- Dockerfile: binds `0.0.0.0:8000`; `EXPOSE 8000`; non-root user; `collectstatic` at build with dummy secrets.
- `commerce/migrations/0004` deletes two models (`ClubMembership`, `ClubMembershipEvent`) — a destructive, non-reversible migration.

---

## 3. Netlify compatibility (VERIFIED FACT + ENGINEERING ANALYSIS)

### 3.1 Free plan and cost model

- Free plan: **300 credits/month**, hard limit, no auto-recharge, no card required (Netlify pricing/docs, checked 2026-11-11).
- Credit costs: production deploy 15 credits; compute 10 credits/GB-hour; bandwidth 20 credits/GB; web requests 2 credits/10,000; forms free; preview/branch deploys free.
- Free plan permits commercial projects (Netlify blog, "Introducing Netlify's Free plan", checked 2026-11-11).
- When credits are exhausted on Free, the site is suspended for the remainder of the month (no billing, no card). This satisfies the strict $0 rule **provided no payment method is added and auto-recharge stays off**.
- 300 credits ≈ 15 GB bandwidth if spent entirely on bandwidth, or 30 GB-hour of compute, or 20 production deploys, or 1.5M web requests — in practice a mix. A staging pilot with infrequent deploys and low traffic fits; a busy pilot does not.

### 3.2 Next.js App Router support

Netlify's current adapter (OpenNext-based, auto-applied, do not pin) supports (official docs, checked 2026-11-11):
- App Router, SSR, ISR, PPR, RSC, Server Actions, response streaming, `next/after`.
- Middleware (implemented via Edge Functions; Node.js Middleware has limitations).
- Route Handlers (full support).
- Redirects and rewrites (full support).
- Image optimization via Netlify Image CDN.
- i18n, skew protection, draft mode.

The adapter provisions a serverless function for SSR/ISR/PPR/route handlers/server actions, and an Edge Function for middleware; configures Full Route Cache and Data Cache.

### 3.3 Item-by-item JAM compatibility

| JAM feature | Netlify (current adapter) | Classification |
|---|---|---|
| `rewrites()` in `next.config.mjs` (`/api/:path*`) | Full support | Compatible with configuration only |
| Catch-all route handler `app/api/[...path]/route.ts` (`force-dynamic`, all methods) | Route Handlers fully supported; provisions serverless function | Compatible without changes |
| `app/health/route.ts` (`force-dynamic`) | Route Handler supported | Compatible without changes |
| `app/page.tsx` (`force-dynamic`) | SSR supported | Compatible without changes |
| Dynamic routes without `generateStaticParams` (`/m/[slug]`, `/order/[id]`, `/store/[id]`, `/visit/[storeId]`) | SSR supported (no static params needed) | Compatible without changes |
| Runtime `API_INTERNAL_URL` (server-only) | Env vars read at runtime for SSR/adapter functions | Compatible without changes, **if** frontend is deployed as a server-rendered Netlify site (not a static export) |
| Same-origin `/api` proxy + JWT Bearer in `localStorage` | Preserved (browser→Netlify same origin; serverless function→Django) | Compatible without changes |
| `images.remotePatterns` (localhost only) | Netlify Image CDN; remote patterns must include the production media host or images 404 | Requires configuration change (`remotePatterns` for the media host) — or accept unoptimised images |
| `skipTrailingSlashRedirect` | Supported | Compatible without changes |
| Next.js Middleware | No `middleware.ts` in repo | Not applicable |
| Server Actions | None detected in inspected code | Not applicable |
| `NEXT_PUBLIC_DEMO_MODE` | Build/runtime env | Compatible with configuration |

**Key point:** every item that made a Render Static Site impossible (rewrites, dynamic route handlers, force-dynamic pages, dynamic routes without params, runtime env) is supported by Netlify's current adapter. Netlify is therefore a credible frontend host for JAM; Render Static Site is not.

### 3.4 Caveats

- Netlify env vars for an SSR site are read at runtime by the serverless function, but `NEXT_PUBLIC_*` are inlined at build time. `API_INTERNAL_URL` must remain server-only (it already is).
- The duplicate proxy mechanisms (`rewrites()` plus the catch-all route handler) both exist; on Netlify both are supported, but the catch-all is the one that restores trailing slashes and handles media. Keep both; do not remove either without testing.
- Netlify functions have a default memory of 1024 MB and compute is billed per GB-hour; a slow proxy that holds connections counts against the 300-credit budget.
- Netlify does not provide a persistent filesystem or a long-running process; the frontend must not rely on local disk (it does not).
- Netlify's free plan is 1 team owner; no multi-seat collaboration on Free.

---

## 4. Supabase compatibility (VERIFIED FACT + ENGINEERING ANALYSIS)

### 4.1 Free plan database

- **2 active Free projects** per account (across all organisations where you are owner/admin).
- **500 MB database size** (Postgres data size, not disk); fixed **2 GB disk**; read-only mode at 95% disk / 500 MB data; if disk fills, Postgres shuts down until upgrade to Pro.
- **Nano compute**: shared CPU, up to 0.5 GB RAM, 500 MB recommended max DB size.
- **Connection limits (Nano)**: 60 direct (Postgres) connections, 200 pooler clients, default pool size 15.
- **5 GB egress** and 5 GB cached egress per month.
- **Free projects pause after 1 week of inactivity**; unpausing restores (data retained, no charge while paused).
- **No automated backups on Free** (Pro gets daily backups retained 7 days). Free has no PITR.
- PostgreSQL version: Supabase runs a recent PostgreSQL (15+). Extensions available (pgvector, PostGIS, TimescaleDB, etc.).
- **No credit card required** on Free; no overage billing on Free — limits are enforced by read-only/pause/shutdown, not by charges. This satisfies the strict $0 rule **if** usage stays within limits and the project is not upgraded.

### 4.2 Django / psycopg compatibility

JAM's `DATABASES` config: engine `django.db.backends.postgresql`, `CONN_MAX_AGE=60`, no `sslmode`/`OPTIONS`. Assessment:
- **SSL**: Supabase requires TLS. psycopg default `sslmode=prefer` negotiates TLS, so the connection succeeds without a settings change. A stricter `require` would need a settings change (not authorised here).
- **Connection pooling**: Supabase offers Supavisor in **transaction mode** (shared pooler, port 6543) and **session mode** (dedicated pooler, port 5432). JAM uses `select_for_update`, `transaction.atomic`, and per-request writes. Transaction-mode pooling returns connections to the pool after each transaction, which is compatible with Django's request-scoped transactions **provided** the app does not rely on session-level state (`SET`, advisory locks, temp tables, SQL-level `PREPARE`). JAM does not use those in the inspected code, so transaction pooling is **compatible in principle** — but this is ENGINEERING ANALYSIS, not verified against the full codebase; verify before relying on it.
- **Direct connections are IPv6-only** on Supabase Free (engineering analysis from Supabase docs/community). Render's outbound is IPv4. If the Django backend runs on Render and connects to Supabase, **use the pooler (IPv4)**, not the direct host, for runtime. This is a material constraint.
- **Migrations require session semantics**. JAM's runbook mandates the direct host for migrations. With Supabase, the direct host is IPv6-only; if the owner's local environment is IPv4-only, use the **Session-mode pooler** (Supavisor, port 5432) for migrations, which preserves session-level features. This must be verified before use (UNVERIFIED).
- **CONN_MAX_AGE=60**: with transaction pooling, persistent connections are acceptable as long as each request's transactions commit/rollback before the connection is returned. Django does this. Keep 60 or lower it; do not raise it.
- **Max 60 direct connections on Nano** is not a binding constraint if the pooler is used (200 clients).
- **Scale-to-zero / pause**: Supabase Free pauses after 1 week inactivity; the first request after unpause is slow. JAM's Render backend cold-starts in ~1 min anyway; combined latency is acceptable for staging.

### 4.3 Storage

- Free tier: **1 GB storage**, **50 MB max file size** (via multipart; single upload limit 50 MB on Free), 5 GB egress (shared with DB? Storage egress counts separately? Supabase pricing: storage egress is part of the 5 GB egress on Free; cached egress 5 GB).
- S3-compatible via the Supabase Storage S3 protocol (AWS Signature V4). Requires enabling S3 connection in the dashboard and generating access keys. S3 compatibility is described as GA for the common endpoints.
- django-storages integration: use `storages.backends.s3boto3.S3Boto3Storage` with `endpoint_url=https://<project>.supabase.co/storage/v1/s3`, `region_name=<region>`, `addressing_style=path` (Supabase does not support virtual-hosted style), and `querystring_auth` set according to bucket privacy (False for public buckets, True for private). Third-party Django+Supabase integration write-ups confirm this pattern (engineering analysis, not official Django docs).
- **Max file size 50 MB on Free**: JAM has no application-level upload size limit (A-13). A tester could attempt a >50 MB upload and receive a 413/400 from Supabase. This must be documented; a hard limit requires a code change (authorised separately).
- **No payment method required on Free**; overage on Free is prevented by hard caps (read-only / upload rejection / pause), not by billing. This satisfies the strict $0 rule **if** the project stays on Free and is not upgraded.
- **Caveat**: Supabase Storage buckets can be public or private with RLS policies on `storage.objects`. JAM's media model is public (product images). A public bucket with `querystring_auth=False` and a custom domain (or the Supabase CDN URL) works; private buckets require signed URLs, which conflict with the PWA offline image cache (A-12).

### 4.4 Migration feasibility (Supabase)

- Direct host is IPv6-only → use Session-mode pooler (port 5432) for migrations if the owner's local environment is IPv4-only (UNVERIFIED; must be confirmed).
- `pg_dump`/`pg_restore` feasible against the session pooler or direct host (session-mode supports `SET`/`pg_dump`).
- Backup: Free has no automated backups. Take a manual `pg_dump` custom-format dump before migrating (as in the existing runbook). Neon branches are not available on Supabase Free.
- Identity verification: same procedure as the existing runbook (query `current_database()`, `current_user`, `inet_server_addr()`, version; assert expected DB name).
- Supabase Free pause after 1 week inactivity means a staging DB left idle pauses; unpause before migrating.
- **Destructive migration warning preserved**: `commerce/migrations/0004` deletes `ClubMembership` and `ClubMembershipEvent`. Django migrations are not universally reversible; forward-fix or restore from dump.

### 4.5 Summary of Supabase fit

| Dimension | Supabase Free | JAM requirement | Fit |
|---|---|---|---|
| Database size | 500 MB (read-only beyond) | Small staging dataset | OK, with monitoring |
| Compute | Nano (shared, 0.5 GB RAM) | Low staging traffic | OK |
| Connections | 60 direct / 200 pooler | Django + migrations | OK if pooler used |
| Egress | 5 GB/month | Low staging traffic | OK, monitor |
| Storage | 1 GB, 50 MB max file | Public product images, no upload cap | OK for staging if uploads disabled or capped |
| Backups | None on Free | Staging recoverability | Weak — manual dumps only |
| Pause | 1 week inactivity | Staging may idle | Acceptable; unpause before use |
| Card required | No | Strict $0 | OK |
| Overage billing | None on Free (hard caps) | Strict $0 | OK |

---

## 5. What this audit does not claim

- It does not verify Supabase or Netlify availability from Iran (see `JAM_PHASE_3_1_PROVIDER_ACCESS_PREFLIGHT.md`).
- It does not verify the IPv6/IPv4 behaviour or the session-pooler-for-migrations path against a live Supabase project (UNVERIFIED).
- It does not authorise provisioning, code changes, migration execution, or deployment.
- It does not claim Supabase Storage is a drop-in replacement for R2; the addressing-style and RLS requirements differ.