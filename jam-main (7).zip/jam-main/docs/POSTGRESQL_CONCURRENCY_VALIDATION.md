# JAM — PostgreSQL Concurrency and Transaction Integrity

Date: 2026-11-08
Database: PostgreSQL 18.4 (Postgres.app), isolated cluster in `/tmp`, port 55432, trust auth on loopback only.
Test database: Django-created `test_jam_concurrency`; no existing development/production database was used.
Driver: `psycopg` via Django; real threads and separate connections.

## 1. Result

| Run | Result |
|---|---|
| Concurrency module only | 10 tests, OK |
| Full backend suite on PostgreSQL | 151 tests, OK |
| Full backend suite on SQLite | 151 tests, OK (10 PostgreSQL-only skipped) |

The concurrency tests are `backend/commerce/test_concurrency.py`; they are skipped automatically when the database vendor is not PostgreSQL.

## 2. Races found and fixed

### 2.1 Duplicate order on concurrent idempotent submission

**Before:** `create_order` used `select_for_update()` on a filtered idempotency key. When no row existed, the lock protected nothing; concurrent requests could both pass the check and attempt inserts. A partial unique constraint existed as backstop, but the resulting `IntegrityError` was not handled and surfaced as a 500.

**Fix:** inserts run in a savepoint; `IntegrityError` is caught, and the existing order for the same business/customer/key is returned with `created=False`.

**Test:** 8 threads, same customer/key → all return one order PK, exactly one `Order`, one item.

### 2.2 Cross-customer idempotency collision

**Before:** the unique constraint and lookup were scoped to `(business, idempotency_key)`. A second customer reusing a key could receive the first customer's order payload.

**Fix:** scope changed to `(business, customer, idempotency_key)` with migration `commerce/0003`; service lookup filters by customer as well.

**Test:** 6 threads, two customers sharing a key → 2 orders, one per customer, neither leaks.

### 2.3 Concurrent purchase-code issuance exceeded the daily limit

**Before:** concurrent issuance for the same customer could all count the same “issued today” value, create multiple active codes, and exceed `CLUB_PURCHASE_CODE_DAILY_LIMIT`.

**Fix:** lock the customer row (`select_for_update`) before the limit check and code replacement inside the transaction. This serializes issuance per customer across stores.

**Test:** 8 concurrent issues with limit 5 → 5 successes, 3 `daily_limit_reached`, 5 code rows, exactly 1 active (`issued`) code.

**Residual:** “one active code” is enforced by service locking, not a database partial unique constraint. A future direct ORM/admin write could still create two active codes.

### 2.4 Concurrent visit recording

`get_or_create` could race on the unique `(business, customer, visited_on)` constraint. Fixed by catching `IntegrityError` and returning the existing visit.

**Test:** 8 threads → one row, exactly one `created=True`.

## 3. Other verified behavior

### Status transitions

- 8 concurrent `accepted` transitions on one order → exactly one `changed=True`, one accepted status event, final status `accepted`.
- Concurrent `accepted` versus `done` → exactly one valid transition; the other is rejected as `invalid_transition`. No double status event.
- Invalid transitions are rejected under row lock; no partial writes.

### Payment confirmation

- 8 concurrent `mark_order_paid` calls on one online order → exactly one `changed=True`, one settlement entry, no commission entry before completion, final `paid`.
- `mark_order_paid` locks the order and shorts-circuit on already-paid.

### Purchase codes

- 8 concurrent confirmations of one code → one purchase, one code status `confirmed`, all callers receive the same purchase.
- Expired code → `code_expired`, no purchase.
- Revoked code → `code_revoked`, no purchase.

## 4. Constraint review

| Model | Constraint | Assessment |
|---|---|---|
| `Order` | partial unique `(business, customer, idempotency_key)` if key non-empty | Correct after fix |
| `OrderItem` | quantity validators 1–99; FK product `SET_NULL` | Service validates product availability and store ownership |
| `InPersonPurchase` | one confirmed purchase per `(business, customer, purchase_date)` | Correct; partial on `status=confirmed` |
| `PurchaseCode` | unique `code_hash` | Correct; raw code never stored |
| `ClubVisit` | unique `(business, customer, visited_on)` | Correct |
| `Transaction` | partial unique non-empty `authority` | Added; prevents one provider authority on two transactions |
| `SettlementEntry` | one-to-one order | Prevents duplicate settlement rows per order |

Decimal money fields are integer Toman columns; commission uses `Decimal` with half-up rounding. Delivery is excluded from commission basis by construction and tests.

## 5. Remaining risks / not covered

- No concurrent test for a real provider callback (no provider credentials; order payment is not implemented).
- No test for concurrent refunds against provider settlement because no payout provider exists.
- No database-level constraint enforcing allowed order status transitions; service lock + transition table is authoritative. Direct SQL/admin edits can violate it.
- No unique constraint for “one active purchase code per customer/store”; service serialization covers API paths only.
- No load/soak test (only short contention bursts of 2–8 threads).
- PostgreSQL was a temporary local cluster; production version/configuration may differ.

## 6. Reproduction

```bash
# Temporary isolated cluster (not project infrastructure)
export PATH="/Applications/Postgres.app/Contents/Versions/latest/bin:$PATH"
initdb -D /tmp/jam-pg-test -A trust -U postgres
pg_ctl -D /tmp/jam-pg-test -o "-p 55432 -c listen_addresses=127.0.0.1" -l /tmp/jam-pg-test.log start

cd backend
PGTEST_PORT=55432 python3 manage.py test commerce.test_concurrency --settings=config.concurrency_settings
PGTEST_PORT=55432 python3 manage.py test --settings=config.concurrency_settings
```

`config/concurrency_settings.py` is a temporary audit settings module and is intended to be removed after validation. The cluster and test database are temporary and were not used by the application.
