# JAM Life Frontend Implementation Spec

## 1. Proposed Frontend Architecture

### Directory Structure
```
frontend/
├── app/
│   ├── layout.tsx          # Root layout with fonts, dir=rtl, theme
│   ├── page.tsx            # Entry point → JamShell + VIEWS
│   ├── globals.css         # Tailwind v4 + design tokens
│   ├── hooks/              # Custom React hooks
│   ├── features/           # Feature-specific code (cart, search, etc.)
│   └── api/                # API route proxies or mock data
├── components/
│   ├── ui/                 # Shadcn-inspired UI primitives (button, card, etc.)
│   ├── jam/                # Shell slots (header, main, footer, bnav, fcart, toasts)
│   ├── shared/             # Shared non-UI components (forms, tables, etc.)
│   └── features/           # Feature-specific composites (ProductCard, StoreCard, etc.)
├── lib/
│   ├── types.ts            # GlobalState, Cart, Product, Store, DiscountCode types
│   ├── utils.ts            # `cn` class utility (clsx + tailwind-merge)
│   ├── api/                # API service modules (fetch → Django backend)
│   ├── store/              # State management (localStorage persistence, DEF, parseJLData13)
│   └── routing/            # Hash-route → Next.js path mapping
├── public/
│   ├── fonts/              # Vazirmatn 400/600/800 TTF files
│   └── media/              # WebP product placeholders
└── types/
    └── next.d.ts
```

### State Management
- **LocalStorage-persisted**: `GlobalState` interface from `lib/types.ts`
- **DEF()**: Default state matching original `00-data-boundary-v13.js` / `01-app-core.ts`
- **parseJLData13()**: Safe JSON.parse with fallback, mirrors legacy behavior
- **S export**: Mutable global state reference, initialized from localStorage on mount
- **saveState()**: Persist to `localStorage.setItem(STORE_KEY, JSON.stringify(S))`
- **Session**: `theme: "light" | "dark"` with `[data-theme="dark"]` toggle
- **No Redux/Zustand**: State lives in `S` object + localStorage; components read via `S` context or selector hooks

### API Service Layer
- **Base URL**: `http://backend:8000/api/` (Docker internal) or `http://localhost:8000/api/` (dev)
- **Proxy**: Next.js `next.config.ts` `async headers()` or `rewrites` for `/api/*` → backend
- **Auth**: JWT `Authorization: Bearer {token}` from localStorage or session
- **Public endpoints**: No auth header for `/api/public/menu/` and `/api/qr-code/`
- **Error handling**: Map DRF errors to UI notices/toasts
- **Timeouts**: Reasonable fetch timeouts, retry logic for transient errors

### Form Validation Strategy
- **React Hook Form** or simple onSubmit validation (keep dependencies minimal)
- **Schema**: Minimal validation, rely on backend for full validation
- **Fields**: `input`/`select`/`textarea` components with `onFocus`/`onBlur` states
- **Error display**: `err-msg` pattern: `font-size: 14px; color: var(--red); display: flex; gap: 6px; align-items: center`
- **Loading state**: `btn-disabled` during fetch, `progress` animation for async ops

### Tailwind CSS v4 Architecture
- **`tailwind.config.ts`**: Minimal config, extend design tokens
- **`globals.css`**: CSS variables from jam-life.html design tokens + `@tailwind base; @tailwind components; @tailwind utilities`
- **Theme extension**: Custom colors, radii, shadows, breakpoints matching audit
- **Responsive**: Custom breakpoints at 1180px, 1080px, 760px (non-default, not standard Tailwind)
- **Dark mode**: `class` strategy or `media` based on `[data-theme="dark"]`
- **Component libraries**: `lucide-react` for SVGs, `class-variance-authority` for variant components, `radix-ui` for primitive primitives

## 2. Route and Page Mapping

### Route Table (hash-based → Next.js path mapping)

| Hash Route | Next.js Path | Component | Auth Required |
|-----------|-------------|-----------|--------------|
| `#/` | `/` | Home (VIEWS.home()) | No |
| `#/store/:slug` | `/store/[slug]` | Store page | No (public) |
| `#/cart` | `/cart` | Cart page | No |
| `#/checkout` | `/checkout` | Checkout page | Yes (JWT) |
| `#/order/:id` | `/order/[id]` | Order tracking | No |
| `#/business` | `/business` | Business landing | No |
| `#/panel/:sid` | `/panel/[sid]` | Panel/dashboard | Yes (JWT) |
| `#/dm/*` | `/digital-menu/*` | Digital menu (QR) | No (public) |
| `#/search` | `/search` | Search page | No |
| `#/promo/*` | `/promo/*` | Promo views | No |
| `#/game/*` | `/game/*` | Game views | No |

### Page Components

#### `app/layout.tsx`
- `lang="fa"`, `dir="rtl"`, `data-theme="light"`
- Preload Vazirmatn fonts (400/600/800)
- `suppressHydrationWarning`
- Noscript warning
- No LEGACY_STYLES import (using Tailwind + CSS vars)

#### `app/page.tsx`
- `"use client"`
- `useEffect`: load token from localStorage, set `isAuth` state
- SSR placeholder: `<div dangerouslySetInnerHTML={{__html: VIEWS.home(false)}} />` until `isMounted`
- Then: `<div dangerouslySetInnerHTML={{__html: VIEWS.home(isAuth)}} />`
- Imports `VIEWS` from `@/lib/legacy/01-app-core`

#### `components/jam/jam-shell.tsx`
- **ShellSlots**: Memoized header/main/footer/bnav/fcart/layer/toasts
- Exact DOM structure matching jam-html reference:
  - `<a className="sr" href="#app">` skip link
  - `<header className="hdr" id="hdr">` sticky z-index 40 backdrop-filter
  - `<main id="app">` tabIndex=-1
  - `<footer className="ftr" id="ftr">` margin-top 24px
  - `<nav className="bnav" id="bnav">` fixed bottom z-index 50 (hidden >760px)
  - `<div className="fcart" id="fcart">` fixed bottom safe-area
  - `<div id="layer">` high z-index container
  - `<div className="toasts" id="toasts">` bottom center z-index 120
- `JamShell()`: `useEffect` → `initializeRuntime()` (no classic script injection)

#### Feature Pages (to implement)

**Home** (`features/home.tsx` or `app/home/page.tsx`):
- Home top: greeting + promo controls
- Promos grid (1.35fr 1fr 1fr, gap 16px, gradients p1/p2/p3)
- Categories grid (7-col > 4-col > 1-col responsive)
- Grid stores (auto-fill minmax 260px)

**Store** (`features/store/[slug].tsx`):
- Store hero (210px, border-radius 0 0 24 24, hero em 96px drop-shadow)
- Store head (margin -64px position relative z-index 2)
- Store card (logo 84x84, title, description, stats grid 4-col, items grid 2-col)
- Items grid (product cards, cursor pointer hover border/shadow)
- Side cart (sticky, cart box with rows, summary, progress, empty state)

**Cart** (`features/cart/[...path].tsx`):
- Cart head (h3, summary row, progress bar, empty state)
- Cart list (max-height min(46vh,420px) overflow auto, c-rows)
- Each row: thumb 48x48, name, price, stepper (34px height), remove
- Cart sum (border-top dashed, total green)
- Floating cart bar (.fcart) mobile

**Checkout** (`features/checkout/[...path].tsx`):
- Page title + crumbs
- Co-layout (1fr 380px gap 24px)
- Steps (co-step h2 with dot n, opt-grid options with radio, form-grid)
- Option grid: display flex gap 12px padding border radius, hover state, on state
- Form grid 2-col, full-width fields
- Address list with addr-opt selected state
- Code row (input dir ltr text-right uppercase)
- Summary store section

**Order Tracking** (`features/order-tracking/[id].tsx`):
- Track hero (padding 24px grid 1fr auto gap 16px h1 22px)
- Big status (72x72 border-radius 20 grid place-center)
- Timeline (flex, tl with dot b svg, done/cur classes)
- KV details (dt dd grid), pickup code
- Order rows (grid auto 1fr auto gap 16px padding border-bottom)

**Business** (`features/business/[...path].tsx`):
- Biz hero (56px 0 40px grid 1.1fr 1fr gap 48px, h1 40px em color brand, p.lead, ctas trust feat-grid plans steps)
- Phone mockup (290x580 border-radius 44 background 0E1418 box-shadow inset)
- Float card (position-absolute gap 10px align-center 14px)
- Feat grid (3-col gap 16px padding 22px, .t 46x46, h3 16px, p 14px line-height 1.8)
- Steps (4-col grid gap 16px counter-reset s, step .n 34x34, h4 15px, p 14px)
- Plans (3-col gap 16px, plan padding 24px flex-col gap 14px, .pop border/box-shadow, .ribbon)
- Faq details (border-bottom 1px solid var line, summary with ic rotate open)
- Cta-band (gradient 135deg 12353F 2C7A8C color white padding 32px gap 20px)
- .cta-band h2 22px, p 14.5px opacity .85, .btn-primary

**Panel** (`features/panel/[...path].tsx`):
- Panel (grid 248px 1fr gap 24px padding-top 24px, p-side sticky top var header-h 16px padding 12px)
- P-store (flex gap 10px padding 8 8 14 border-bottom var line margin-bottom 8, .lg 42x42, select)
- P-nav (flex flex-col gap 2px, a 42px 12px 600 14 color ink-2 transition, on bg brand-soft color brand, .cnt)
- Sub-card (margin-top 12px padding 14 border-radius 12 surface-2 border line, 14px)
- P-main h1 22px font-weight 800 letter -(.3px, .p-sub 2px 0 0 color ink-2 14px
- P-top (flex justify-between align-end gap 16px margin-bottom 20px flex-wrap wrap)
- KPIs (grid 4-col gap 16px padding 18px, .k 14 color ink-2 display flex align-between justify-space-between, .k .t 34x34 grid place-center, .v 24 font-weight 800 8px margin letter -.4px, .d 14 flex align-center gap 4px, up color brand, down color red)
- Chart (flex align-items-flex-end gap 12px 200px height 200px padding-top 12px, bar flex 1 display flex flex-col align-center gap 8 100% height justify-content flex-end, i display block 100% max-width 44 border-radius 8 8 4 4 background brand-soft transition height .4s, today i brand, span 14 color ink-3, em 14 style normal 600 color ink-2)
- Two-col (grid 1.5fr 1fr gap 16 margin-top 16, tbl 100% border-collapse 14px, th 14 color ink-3 font-weight 600 padding 10 16 border-bottom line background surface-2, td 12 16 border-bottom vertical-middle, tr:last-child td border-bottom 0, tr.na td opacity .6, tbl-wrap overflow-x auto)
- Price-in (130x38 border-radius 10 border 1px solid line-2 background surface padding 0 10 font-weight 700 outline-none font-variant-numeric tabular-nums, focus border brand-400 box-shadow 0 0 0 3px brand-soft)
- O-card (16 18 display grid 1fr auto gap 12 16 margin-bottom 12, new border brand-400 box-shadow 0 0 0 3px brand-soft)
- O-items 14 color ink-2 line-height 1.8, o-actions flex gap 8 flex-wrap align-center grid-column 1/-1 padding-top 12 border-top dashed var line-2)
- Tpls (grid 3-col gap 12px, tpl border 2px solid line border-radius 14 padding 10 cursor-pointer transition .15s text-start background surface, on border brand, .pv 92px border-radius 9 margin-bottom 8 overflow-hidden flex-col gap 5 padding 9px, .pv i display block 8px border-radius 4, tpl b 14px, swatches flex gap 10px flex-wrap wrap, sw 36x36 border-radius 10 border 3px solid surface box-shadow 0 0 0 1px line-2 cursor-pointer, on box-shadow 0 0 0 2px ink, qr-box flex gap 20 align-center flex-wrap wrap, qr 172x172 background #fff padding 12 border-radius 14 border 1px solid line qr svg 100% 100%, link-box flex align-center gap 8 background surface-3 border-radius 10 padding 4 4 4 12 direction ltr, link-box code 14px Menlo Consolas monospace 14px overflow hidden text-overflow ellipsis white-space nowrap padding-left 8px, tg-chat 180 180 gradient 180deg DDE9DA C9DDC4 border-radius 14 padding 16 flex-col gap 8 min-height 340px 14px, dark gradient 180deg 1E2A22 17211B, .msg max-width 82% padding 8 12 border-radius 14 line-height 1.7 box-shadow 0 1 1 rgba 0 0 0 .08 background #fff color 14202B align-self flex-start border-bottom-left-radius 4px, me align-self flex-end background E3F7D0 border-bottom-left-radius 14 border-bottom-right-radius 4px, msg .kb grid 1fr 1fr gap 5px margin-top 8px, msg .kb span 11 1 rgba 36 112 214 .1 color 2470D6 text-align center 6px 600 14px font-size, msg time display 14 color 8A949E text-align left margin-top 2px)

**Digital Menu** (`features/digital-menu/[...path].tsx`):
- DM (--acc 08805A max-width 560px margin 0 auto min-height 100vh background var dm-bg #fff color var dm-ink 14202B 14.5px)
- DM-hero (28 20 20 text-center background var dm-hero linear 180deg color-mix in srgb acc 14% #fff #fff)
- DM-logo 76x76 border-radius 22 margin 0 auto 10px grid place-center 40px background #fff box-shadow 0 6px 20px rgba 0 0 0 .08
- DM-hero h1 22px font-weight 800, p 14px opacity .75
- DM-meta (flex justify-center gap 8 margin-top 12 flex-wrap wrap, span inline-flex gap 5 align-center 14px padding 5 10 border-radius 8 background color-mix in srgb acc 10% transparent color acc font-weight 600)
- DM-tabs (sticky top 0 z-index 5 display flex gap 6 overflow-x auto padding 10 16 background var dm-bg #fff border-bottom 1px solid color-mix in srgb currentColor 10% transparent scrollbar-width none, a 7 14 700 14px opacity .7, on background acc color #fff opacity 1)
- DM-sec (18 16 4px scroll-margin-top 60px, h2 16px margin 0 0 10px font-weight 800 display flex align-center gap 10px, h2::after content "" flex 1 height 1px background currentColor opacity .12)
- DM-it (flex gap 12 padding 12 0 border-bottom 1 dashed color-mix in srgb currentColor 14% transparent, last-child border-bottom 0, .th 64x64 border-radius 14 grid place-center 32px flex none background color-mix in srgb acc 9% transparent, .nm font-weight 700, .ds 12.8px opacity .7 line-height 1.65 margin-top 2px, .pr font-weight 800 color acc white-space nowrap margin-inline-start auto text-align left, .pr s 14px opacity .55 color var dm-ink 14202B font-weight 500, .na opacity .45)
- DM-foot (24 16 100px text-align center 14px opacity .6)
- DM-order (fixed bottom 16px left 50% transform translateX(-50%) width min(528px calc(100% - 32px)) z-index 10, a display flex 52px border-radius 14 background acc color #fff font-weight 700 align-items-center justify-center gap 8 box-shadow 0 10px 24px rgba 0 0 0 .18)
- DM t-dark, dm t-classic variants

**Search** (`features/search/[...path].tsx`):
- S-layout (grid 260 1fr gap 24 margin-top 16 align-start)
- Filters (18px position sticky top var header-h 16px, h4 14 color ink-2 margin 0 0 10px, f-group 14 0 border-bottom line display flex flex-col gap 10, last-child border-bottom 0 padding-bottom 0 first-child padding-top 0, radio-row flex align-center gap 10 14px cursor-pointer input accent-color brand 17 17, res-head flex justify-between align-center gap 12 margin-bottom 14 flex-wrap wrap, hl background color-mix in srgb star 30% transparent color inherit border-radius 3px padding 0 1px, suggest 420px max-width calc(100vw - 32) position absolute top 100% 8px inset-inline 0 background surface border 1px solid line border-radius 14 box-shadow shadow-3 padding 8px z-index 60 max-height 420px overflow-auto, .g 14 color ink-3 600 padding 8 10 4px, a flex gap 10 align-center padding 8 10 14px font-size 14, hover kb-on background surface-3, a .th 36x36 border-radius 9 19px flex-center 19px font-size, small display block 14px color ink-3)

**Footer** (`app/footer.tsx` or `components/footer.tsx`):
- Footer ftr border-top 1px var line background var surface padding 40 0 32 margin-top 24px, ftr-grid grid 1.6fr 1fr 1fr 1fr gap 32px, h4 14 margin 0 0 12px, ul none padding 0 margin 0 display flex flex-col gap 8 14px color ink-2, ul a:hover color brand, ftr-bottom margin-top 28px padding-top 20px 1 border-top line font 14 color ink-3 display flex justify-between gap 12px flex-wrap wrap, bnav none fixed bottom 0 inset-inline 0 z-index 50 background color-mix in srgb surface 94% transparent backdrop-filter blur(14px) -webkit-backdrop-filter blur(14px) border-top 1px var line padding-bottom env(safe-area-inset-bottom), bnav-in grid 4-col 1fr height 64px, a flex flex-col align-center justify-center gap 3 14px font-weight 600 color ink-3 position-relative, on color brand, on::before content "" absolute top 0 28px 3px border-radius 0 0 3 3 background brand, .badge-dot top 6px inset-inline-end calc(50% - 22px)

## 3. Component Structure

### Shared UI Components (from current `frontend/components/ui/`)

#### `Button` (`components/ui/button.tsx`)
- `cva`-based variants: default/destructive/outline/secondary/ghost/link
- Sizes: default/xs/sm/lg/icon/icon-xs/icon-sm/icon-lg
- `asChild` prop for Slot.Root
- Tailwind v4 compatible with `tw:` prefixed utility strings
- `data-slot="button"`, `data-variant`, `data-size`

#### `Card` (`components/ui/card.tsx`)
- Card, CardHeader, CardTitle, CardDescription, CardAction, CardContent, CardFooter
- `tw:@container/card-header` for container queries
- Specific slot classNames for Tailwind v4

#### `Alert` (`components/ui/alert.tsx`)
- Variants: default/destructive
- AlertTitle, AlertDescription
- `role="alert"`, `data-slot="alert"`

#### `Input` (to create)
- Based on `.input` styles: 100% width, 46px height, border-radius 12, border 1px var(--line-2), background var(--surface), padding 0 14px, font 14.5px, transition .15s
- Focus: border var(--brand-400) box-shadow 0 0 0 4 var(--brand-soft)
- Error: border var(--red) box-shadow 0 0 0 4 var(--red-soft)
- `input-ltr` class for dir ltr text-align right
- `textarea` variant: min-height 84px, resize vertical, line-height 1.6, padding 12 14

#### `Select` (to create)
- Based on `.select` styles same as input height/border/radius
- Custom component wrapping native `<select>` or using radix-ui

#### `Chip` (to create)
- `.chip` styles: 38px height padding 0 14 border-radius 10 surface display inline-flex align-center gap 7 14px font-weight 600 color ink-2 white-space nowrap transition .15s flex-none
- Hover: border var(--ink-3) color var(--ink)
- `.chip.on`: background var(--ink) border var(--ink) color var(--surface)
- `.pill` styles: inline-flex gap 5 26px padding 0 9 border-radius 8 font 14 600 white-space nowrap
- `.pill.green`, `.pill.red`, `.pill.amber`, `.pill.blue`, `.pill.violet`, `.pill.gray`
- `.seg` styles: inline-flex padding 4 border-radius 13 background surface-3 gap 4
- `.seg button`: 38px height 16px padding 0 8 700 14 color ink-2 display flex align-center gap 8 transition .15s
- `.seg button.on`: background surface color ink box-shadow shadow-2, .ic color brand

### Feature-Specific Composites

#### `ProductCard` (`components/features/product-card.tsx`)
- Wraps `.p-card` styles
- Props: `product: Product`, `onAddToCart?: (pid: string) => void`, `light?: boolean`
- Thumb: `.p-thumb` 1.35/1 aspect border-radius 12 grid place-center 46px position-relative overflow-hidden
- Name: `.p-name` 14.5px font-weight 700 line-height 1.5
- Store: `.p-store` 14px color ink-3 flex align-center gap 4px
- Price: `.price` flex flex-col line-height 1.3, s 14 color ink-3, b 15 font-weight 800, b small 14 font-weight 500 color ink-2 margin-inline-start 3px
- Foot: `.p-foot` flex align-items-flex-end justify-space-between gap 8 margin-top auto
- Add button: `.add` 40x40 border-radius 12 background var(--brand-soft) color var(--brand) transition .15s hover background var(--brand) color #fff flex-none
- Stepper: `.stepper` 40px height 12 border-radius background var(--brand) color #fff flex-none, button 36x40 grid place-center color #fff hover rgba(0,0,0 .1), b 22 min-width center 14.5px
- Light stepper variant: `.stepper.light` surface border line-2 color ink, button color brand hover brand-soft

#### `StoreCard` (`components/features/store-card.tsx`)
- `.store-card` surface border var r-lg overflow hidden transition .2s hover box-shadow var shadow-2 transform translateY(-2px) border-color var line-2
- Cover: relative height 128px grid place-center overflow-hidden, .em 54px drop-shadow 0 6 10 rgba 0 0 0 .15 translateY(4px), ::before radial-gradient, .pat opacity .18 radial-gradient currentColor 1.2px transparent 1.2px background-size 14 14, .closed-veil absolute inset 0 background rgba 20 32 43 .52 grid place-center color fff font-weight 700 14px text-align center line-height 1.5 backdrop-filter grayscale(1)
- Fav: absolute top 10 inset-inline-start 10 36x36 border-radius 10 rgba 255 255 255 .92 grid place-center 56616D z-index 2 transition .15s hover scale(1.06), .on color var red .on svg fill currentColor
- Disc: absolute top 10 inset-inline-end 10, .disc-badge red 800 14px padding 3 8 border-radius 7 inline-flex gap 4 align-center
- Body: padding 0 16 16 relative, .s-logo 56x56 border-radius 14 surface border 1 display grid place-center 28px margin-top -28px position relative box-shadow var shadow-2, .sc-title flex align-center justify-between gap 8 margin-top 10, .sc-title h3 16 font-weight 800 0 0 letter -.2px, .rate inline-flex gap 4 700 14px, .rate svg 15 15 fill var star stroke var star, .rate span 14 color ink-3 500 14px, .sc-sub 14 color ink-2 margin-top 2px, .sc-meta flex flex-wrap gap 6 margin-top 12 padding-top 12 border-top dashed var line-2, .meta inline-flex gap 5 14 color ink-2 background surface-2 padding 4 8 border-radius 7, .meta .ic 14 14, .meta.free color brand background brand-soft font-weight 600

#### `CartItem` (`components/features/cart-item.tsx`)
- `.c-row` flex gap 12 align-center padding 12 0 border-bottom var line, last-child border-bottom 0, .th 48x48 border-radius 10 grid place-center 24px font-size flex-none, .nm 14 font-weight 700 line-height 1.45, .pr 14 color ink-2, .stepper 34 height, .stepper button 30x34, .cart-sum padding 14 18 border-top var line background surface-2, .sum-row flex justify-space-between 14 color ink-2 padding 3 0, .sum-row.total color ink font-weight 800 15.5 padding-top 10 margin-top 6 border-top dashed var line-2, .sum-row.green color var brand, .progress 6px height border-radius 6 surface-3 overflow hidden margin-top 8, .progress i display block height 100% background var brand border-radius 6 transition width .3s, .empty padding 36 20 text-align center color ink-2, .e-ic 64x64 border-radius 18 surface-3 grid place-center margin 0 auto 14 color ink-3, .e-ic svg 30x30, b display block color ink 15.5 margin-bottom 4px

#### `SearchInput` (`components/features/search-input.tsx`)
- `.search` position relative flex 1 max-width 520 min-width 200px, `.s-ic absolute inset-inline-start 14 top 12 color ink-3 pointer-events-none`, `.kbd absolute inset-inline-end 10 top 10 14px color ink-3 border 1px solid line-2 border-radius 6 padding 1 6 background surface`
- Input: 100% width 44px border-radius 12 border transparent background surface-3 padding 0 44 0 40px outline-none transition .15s 14.5px, placeholder color ink-3, focus: background surface border var(--brand-400) box-shadow 0 0 0 4 var(--brand-soft)

#### `SidebarNav` (`components/features/sidebar-nav.tsx`)
- `.s-layout` grid 260 1fr gap 24 margin-top 16 align-start, `.filters` 18px position sticky top calc var header-h 16px, `.f-group` 14 0 border-bottom line display flex flex-col gap 10, last-child border-bottom 0 padding-bottom 0 first-child padding-top 0, `.radio-row` flex align-center gap 10 14px font 14 cursor-pointer, `.accent-color brand 17 17`, `.suggest` 420px max-width calc(100vw - 32) position absolute top 100% 8 inset-inline 0 background surface border 1 line border-radius 14 box-shadow shadow-3 padding 8px z-index 60 max-height 420px overflow-auto, `.g 14 ink-3 600 padding 8 10 4px`, `a flex gap 10 align-center padding 8 10 14px 14px font-size 14, hover kb-on background surface-3, a .th 36 36 border-radius 9 19px flex-center 19px font-size, small display block 14 color ink-3`

#### `BottomNav` (`components/features/bottom-nav.tsx`)
- `.bnav` none fixed bottom 0 inset-inline 0 z-index 50 background color-mix in srgb surface 94% transparent backdrop-filter blur(14px) -webkit-backdrop-filter blur(14px) border-top 1px var line padding-bottom env(safe-area-inset-bottom), `.bnav-in` grid 4-col 1fr height 64px, `a flex flex-col align-center justify-center gap 3 14px font-weight 600 color ink-3 position-relative, .on color brand, .on::before content "" absolute top 0 28px 3px border-radius 0 0 3 3 background brand, .badge-dot top 6px inset-inline-end calc(50% - 22px)`

#### `PromoCard` (`components/features/promo-card.tsx`)
- `.promo` relative overflow-hidden border-radius var r-lg padding 22 min-height 168px flex flex-col justify-space-between color #fff isolation isolate transition .2s hover transform translateY(-2px), `.p1` linear 135deg 3A93A6 0 225F6E 100%, `.p2` linear 135deg F08C2A 0 C85A12 100%, `.p3` linear 135deg 3D4BD8 0 2A2F8F 100%
- H3 19px line-height 1.45 font-weight 800 max-width 300px, p 6 0 14 14px opacity .88 max-width 300px, .cta inline-flex align-center gap 6 700 14px background rgba 255 255 255 .18 padding 7 12 border-radius 9 align-self flex-start margin-top 14 backdrop-filter blur 4px, .deco absolute inset-inline-end -30 bottom -40 190x190 border-radius 50 background rgba 255 255 255 .1 z-index -1, .deco::after content "" absolute inset 34px border-radius 50 background rgba 255 255 255 .08, .big-ic absolute inset-inline-end 22 top 20 52x52 border-radius 14 background rgba 255 255 255 .16 grid place-center, .big-ic svg 28 28

#### `CategoryTile` (`components/features/category-tile.tsx`)
- `.cat` flex flex-col align-items-center gap 10 padding 16 8 border-radius var r-lg surface border line transition .18s text-center, hover border var brand-400 transform translateY(-2px) box-shadow var shadow-2, `.t` 52x52 border-radius 14 grid place-center, `.t svg` 26 26, `b 14 font-weight 700 line-height 1.4`, `small 14 color ink-3 margin-top -8px`
- 4-col at <760px, 7-col desktop, 8px gap, 12px 4px padding, 44x44 .t, 14px b, hide small

#### `Drawer` (based on `.drawer` styles)
- Fixed top 0 bottom 0 left 0 min(420px, 100vw) surface z-index 90 transform translateX(-102%) .28s cubic-bezier .2 .8 .2 1 flex flex-col box-shadow shadow-3, `.show` transform none
- Overlay `.overlay` fixed inset 0 rgba 10 16 22 .48 z-index 80 opacity 0 transition .22s backdrop-filter blur 2px, `.show` opacity 1
- Modal `.modal` fixed inset 0 z-index 90 grid place-center padding 24 pointer-events none, pointer-auto surface 20px border-radius 20 max-height calc(100vh - 48px) overflow auto box-shadow shadow-3 transform translateY 14px scale .98 opacity 0 .22s cubic-bezier .2 .8 .2 1, `.wide` 520px max, `.show` transform none opacity 1
- `.m-head` flex align-center justify-between padding 18 20 border-bottom 1 line sticky top 0 background surface z-index 2, `.m-head h3` 17 font-weight 800, `.m-body` 20px padding, `.m-foot` 16 20 border-top 1 line sticky bottom 0 background surface

#### `Toast` (based on `.toast` styles)
- Fixed bottom 24px left 50% transform translateX(-50%) z-index 120 flex-col gap 8 align-center pointer-events-none max-content max-width calc(100vw - 24px), background 14202B color #fff 12 16 border-radius 12 14px font 14 600 display flex gap 10 align-center box-shadow shadow-3 animation tin .25s ease-out, dark 2A3136, `.ic` 2px margin-top 2 18 18 color 4ADE9F, `.err .ic` FF8A8A, `button 7EE2B8 700 margin-inline-start 6 white-space nowrap`, `tin` from opacity 0 transform translateY(10px)

## 4. UI-to-API Mapping

### UI-Only Interactions (no backend call needed)
- **Nav link hover/active states**: Pure CSS, no API call
- **Promo/category hover transforms**: Pure CSS
- **Cart localStorage operations**: Add/remove items, qty changes — managed in frontend `S.cart`
- **Bottom nav on/off**: Toggle class, no API
- **Theme toggle** (light/dark): Set `[data-theme]` and persist to localStorage
- **Toast notifications**: Show transient messages, no backend required
- **Drawer/modal open/close**: UI state only

### Frontend-Managed State
- **`S` global state** in localStorage: Stores, products, cart, user, addresses, toasts, modals
- **Hash routing**: `route()` / `go(hash)` functions navigate URL without API calls
- **Seller preview**: `SellerMenuPreviewView` reads owner's menu data via API
- **QR code generation**: `QrCodeView` generates QR for public menu URL

### Backend-Persisted Operations
- **Menu CRUD**: `POST/GET/PUT/DELETE /api/menus/` — requires JWT + active subscription
- **Category CRUD**: `POST/GET/PUT/DELETE /api/categories/` — requires JWT + active subscription
- **Product CRUD**: `POST/GET/PUT/DELETE /api/products/` — requires JWT + active subscription
- **Business CRUD**: `POST/GET/PUT/DELETE /api/businesses/` — requires JWT, owner scoping
- **Order tracking**: Read-only status queries, possibly `GET /api/orders/:id/`
- **Subscription management**: No endpoints currently visible, but `_business_has_active_subscription()` checked in views
- **Payment processing**: ZarinPal callback `POST /api/payments/zarinpal/callback/`
- **User auth**: JWT obtain via `accounts` app, token refresh via simplejwt

### API Endpoint Mapping Table

| Feature | UI Element | API Endpoint | Method | Auth | Notes |
|---------|-----------|-------------|--------|------|-------|
| Menu browse | `.public-menu` | `GET /api/public/menu/<slug>/` | GET | None | Public, no auth |
| QR code | `.dm-order .qr` | `GET /api/qr-code/<slug>/` | GET | None | Generates PNG base64 |
| Menu manage | Panel .p-nav/.p-store | `GET/POST /api/menus/` | GET/POST | JWT | Requires active subscription |
| Category manage | Panel .p-nav/.sub-card | `GET/POST /api/categories/` | GET/POST | JWT | Requires active subscription |
| Product manage | Panel .two-col/.o-card | `GET/POST /api/products/` | GET/POST | JWT | Requires active subscription |
| Business manage | Panel header | `GET/POST /api/businesses/` | GET/POST | JWT | Owner-scoped |
| Cart ops | Cart .c-row .stepper | (frontend localStorage) | — | N/A | Frontend-managed |
| Order track | Order .tl .b .kv dd | `GET /api/orders/:id/` (assumed) | GET | JWT | Status only |
| Payment | ZarinPal callback | `POST /api/payments/zarinpal/callback/` | POST | None (callback) | Gateway webhook |
| User auth | Login form | `/api/auth/` (assumed from accounts) | POST | None | OTP/JWT flow |

## 5. TypeScript Data Contracts

### Core Types (`lib/types.ts` - already exists, extend as needed)

```typescript
// Already defined: CartItem, Cart, Store, Product, GlobalState, DEF(), DiscountCode
// Extend with:
// - Login/Auth response types
// - API response interfaces
// - Form types
```

### API Response Interfaces (to add)

```typescript
// Public menu response
interface PublicMenu {
  title: string;
  slug: string;
  business: { name: string; slug: string; description: string; logo: string | null };
  categories: Array<{ id: number; name: string; sort_order: number; products: PublicProduct[] }>;
}

// Product (public, for digital menu)
interface PublicProduct {
  id: string;
  name: string;
  description: string;
  price_toman: number;
  is_available: boolean;
  image: string | null;
}

// Order summary
interface OrderKV {
  dt: string; // color ink-3
  dd: string; // font-weight 600 text-align left
}

// Pickup code span
interface PickupCodeSpan {
  width: number; // 48
  height: number; // 58
  font_size: number; // 26
  font_weight: number; // 800
  border: true;
}
```

### Form Types
```typescript
interface CheckoutForm {
  step: "opt" | "addr" | "code" | "summary";
  selectedOption?: number;
  addressId?: string;
  discountCode?: string;
  // ... other form state
}
```

## 6. State Management Requirements

### Primary State Source: `localStorage` + `S` object

```
STORE_KEY = "jam.state.v1" (from 01-app-core.ts)
```

### Initialization Sequence
1. Module evaluates: `if (window) { try { raw = localStorage.getItem(STORE_KEY); if (raw) S = parseJLData13(raw); else S = DEF(); } catch { S = DEF(); } } else { S = DEF(); }`
2. `parseJLData13()`: Safe JSON.parse, fallback to DEF(), ensure nested objects initialized
3. Components mount, read `S` via export `{ S }` from `@/lib/legacy/01-app-core`
4. State changes: Direct mutation of `S` property + `saveState()` call
5. On navigate: Re-parse localStorage, restore state

### Selectors (to create)
- `useCart()` → `S.cart`, `S.cart.items`, `S.cart.total`, `S.cart.subtotal`, `S.cart.discount`, `cartCount()`, `cartLines()`, `cartTotals()`
- `useStores()` → `S.stores`
- `useProducts()` → `S.products`
- `useUser()` → `S.user`, `S.addrs`, `S.addrId`
- `useTheme()` → `S.theme`, `[data-theme="dark"]` toggle
- `useFavorites()` → `S.favs`

### Persistence
- `saveState()`: `localStorage.setItem(STORE_KEY, JSON.stringify(S))`
- Called after any `S` mutation
- Wrapped in try/catch, errors logged to console
- Quota exceeded gracefully handled (try/catch in saveState)

### Async State (development fixtures)
- If backend not available: `Promise.resolve(STORES || [])` from `01-app-core.ts`
- `stores()`, `store(id)`, `products(sid)`, `product(pid)` functions already promise-resolved
- Use these for development until backend is connected

## 7. Tailwind CSS Implementation Requirements

### `tailwind.config.ts`
```typescript
import { type Config } from "tailwindcss";

export default {
  content: [
    "./app/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      // Colors from jam-life.html design tokens
      colors: {
        brand: "#08805A",
        "brand-600": "#066B4B",
        "brand-400": "#12A574",
        "brand-soft": "#E7F5EF",
        "brand-ink": "#04402D",
        ink: "#14202B",
        "ink-2": "#56616D",
        "ink-3": "#8A949E",
        bg: "#F4F6F7",
        surface: "#FFFFFF",
        "surface-2": "#F7F8F9",
        "surface-3": "#EEF1F3",
        line: "#E4E8EB",
        "line-2": "#D5DBE0",
        amber: "#B76E00",
        "amber-soft": "#FFF4E0",
        star: "#F5A524",
        red: "#D93B3B",
        "red-soft": "#FDECEC",
        blue: "#2470D6",
        "blue-soft": "#E8F1FD",
        violet: "#6D4DD6",
        "violet-soft": "#F0ECFD",
        // Shadow tokens
        shadow: {
          1: "0 1px 2px rgba(16,24,32,.05)",
          2: "0 1px 2px rgba(16,24,32,.05),0 6px 18px rgba(16,24,32,.06)",
          3: "0 12px 40px rgba(16,24,32,.16)",
        },
        // Radius tokens
        radius: {
          sm: "8px",
          DEFAULT: "12px",
          lg: "16px",
        },
        // Breakpoints (custom, non-default)
        // Tailwind v4 uses screen names; extend as needed
        screens: {
          xs: "360px",
          sm: "760px",
          md: "1080px",
          lg: "1180px",
          xl: "1440px",
        },
      },
    },
  },
} satisfies Config;
```

### `globals.css`
```css
@tailwind base;
@tailwind components;
@tailwind utilities;

/* CSS custom properties from jam-life.html */
:root {
  --brand: #08805A;
  --brand-600: #066B4B;
  --brand-400: #12A574;
  --brand-soft: #E7F5EF;
  --brand-ink: #04402D;
  --ink: #14202B;
  --ink-2: #56616D;
  --ink-3: #8A949E;
  --bg: #F4F6F7;
  --surface: #FFFFFF;
  --surface-2: #F7F8F9;
  --surface-3: #EEF1F3;
  --line: #E4E8EB;
  --line-2: #D5DBE0;
  --amber: #B76E00;
  --amber-soft: #FFF4E0;
  --star: #F5A524;
  --red: #D93B3B;
  --red-soft: #FDECEC;
  --blue: #2470D6;
  --blue-soft: #E8F1FD;
  --violet: #6D4DD6;
  --violet-soft: #F0ECFD;
  --shadow-1: 0 1px 2px rgba(16,24,32,.05);
  --shadow-2: 0 1px 2px rgba(16,24,32,.05),0 6px 18px rgba(16,24,32,.06);
  --shadow-3: 0 12px 40px rgba(16,24,32,.16);
  --r-sm: 8px;
  --r: 12px;
  --r-lg: 16px;
  --header-h: 68px;
  --font: "Vazirmatn","Vazir","IRANSans","Noto Sans Arabic","Segoe UI",Tahoma,system-ui,sans-serif;
}

/* Dark theme */
[data-theme="dark"] {
  --brand: #14A873;
  --brand-600: #0F8E61;
  --brand-400: #3CCB95;
  --brand-soft: rgba(20,168,115,.14);
  --brand-ink: #9BE7C8;
  --ink: #F1F4F6;
  --ink-2: rgba(241,244,246,.68);
  --ink-3: rgba(241,244,246,.45);
  --bg: #0F1214;
  --surface: #181C1F;
  --surface-2: #1E2326;
  --surface-3: #262C30;
  --line: rgba(255,255,255,.09);
  --line-2: rgba(255,255,255,.16);
  --amber: #F2B04F;
  --amber-soft: rgba(242,176,79,.13);
  --red: #F07070;
  --red-soft: rgba(240,112,112,.13);
  --blue: #6EA8F5;
  --blue-soft: rgba(110,168,245,.13);
  --violet: #A78BFA;
  --violet-soft: rgba(167,139,250,.14);
  --shadow-1: none;
  --shadow-2: 0 0 0 1px rgba(255,255,255,.04);
  --shadow-3: 0 12px 40px rgba(0,0,0,.5);
}

/* Global resets */
*{box-sizing:border-box};html{-webkit-text-size-adjust:100%;scroll-behavior:smooth};body{margin:0;font-family:var(--font);font-size:16px;line-height:1.65;color:var(--ink);background:var(--bg);-webkit-font-smoothing:antialiased;font-feature-settings:"ss01"};button,input,select,textarea{font:inherit;color:inherit};button{cursor:pointer;background:none;border:0;padding:0};a{color:inherit;text-decoration:none};img,svg{display:block}:focus-visible{outline:2px solid var(--brand-400);outline-offset:2px;border-radius:6px};.ic{width:20px;height:20px;flex:none;stroke:currentColor;fill:none;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}.ic.sm{width:16px;height:16px}.ic.lg{width:24px;height:24px}.ic.xl{width:28px;height:28px}.flip{transform:scaleX(-1)}.sr{position:absolute!important;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}.container{max-width:1200px;margin:0 auto;padding:0 24px}.muted{color:var(--ink-2)} .faint{color:var(--ink-3)} .tnum{font-variant-numeric:tabular-nums}.row{display:flex;align-items:center;gap:8px}.grow{flex:1;min-width:0}.ellipsis{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.hide{display:none!important}

/* Focus utility */
@layer utilities {
  .focus-visible:ring-2 .focus-visible:ring-brand-400 .focus-visible:ring-offset-2 .focus-visible:ring-brand-400/50 {
    /* Tailwind v4 already handles focus-visible */
  }
}
```

### Component Styling Pattern
- **Small, purposeful authored CSS** only when needed for complex effects (gradients, backgrounds, `color-mix()`, `filter`, `backdrop-filter`)
- **Tailwind utilities** for layout, spacing, typography, borders, shadows
- **`twMerge`** via `cn()` utility for class concatenation
- **`class-variance-authority`** for variant components (Button, Card, Alert)
- **Responsive** using Tailwind `sm/md/lg/xl` or custom media queries matching jam-life.html breakpoints (1180px, 1080px, 760px)

### Avoid
- ❌ Importing legacy CSS files from `jam-life-next/` or `frontend/public/legacy/css/`
- ❌ Copying CSS wholesale into `globals.css`
- ❌ Using CSS selectors as substitute for React components + Tailwind
- ❌ Duplicated styling definitions (use theme tokens)
- ❌ Arbitrary values when reusable design tokens available
- ❌ Second styling framework (Tailwind v4 only)

## 8. Authentication Integration Requirements

### JWT Token Management
- **Storage**: `localStorage.getItem("token")` or sessionStorage
- **Header**: `Authorization: Bearer {token}` on all API calls
- **Refresh**: `rest_framework_simplejwt` auto-refresh via interceptor or manual refresh
- **Token expiry**: 30min access, 7day refresh

### Auth-Protected Routes
- **Panel/dashboard**: `/panel/[sid]` — requires valid JWT
- **Checkout**: `/checkout` — requires valid JWT
- **API calls**: `/api/menus/`, `/api/products/`, `/api/businesses/` — JWT header

### Public Routes (no auth)
- **Home**: `/` — no auth required
- **Store**: `/store/[slug]` — no auth required
- **Cart**: `/cart` — no auth required (localStorage state)
- **Digital menu**: `/digital-menu/*` — no auth required
- **Order tracking**: `/order/:id` — no auth required (read-only)

### Auth State in UI
- `isAuth` state from `localStorage token` presence
- `VIEWS.home(isAuth)` — different UI when authenticated
- `S.user` from global state: `{ name: string; phone: string }`
- `S.addrs` / `S.addrId` for address selection in checkout
- `[data-theme="dark"]` toggle independent of auth

### Login/Logout Flow (to implement)
1. User submits credentials/OTP → `POST /api/auth/token/` (or similar)
2. Receive JWT → store in `localStorage.setItem("token", token)`
3. Reload page → `useEffect` reads token → sets `isAuth` state
4. `Page` component renders `VIEWS.home(isAuth)` or `VIEWS.home(false)`
5. Logout: `localStorage.removeItem("token")` → reload

### API Service Wrapper (to create)
```typescript
// lib/api.ts
const API_BASE = "http://localhost:8000/api/";

export async function apiFetch(path: string, init: RequestInit = {}) {
  const token = typeof window !== "undefined" ? localStorage.getItem("token") : null;
  const headers = {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...init.headers,
  };
  const response = await fetch(`${API_BASE}${path}`, { ...init, headers });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.detail || `HTTP ${response.status}`);
  }
  return response.json();
}
```

## 9. Testing and Acceptance Criteria

### Type Checking
- `pnpm run typecheck` or `tsc --noEmit` must pass
- All components typed with `React.ComponentProps` or explicit interfaces
- No `any` types unless genuinely unavoidable (documented)
- Types align with `lib/types.ts` and API response interfaces

### Production Build
- `pnpm run build` must succeed
- `pnpm run start` must serve the app
- No build-time errors, missing dependencies, or circular imports

### Visual Acceptance
- **Breakpoints**: 1440px desktop, 1024px laptop, 768px tablet, 390px mobile, 360px small mobile
- **Comparison**: Screenshots vs `jam-life.html` reference at each breakpoint
- **Layout**: Overall structure, header, main content, sidebar/panel, footer match reference
- **Typography**: Font family (Vazirmatn), sizes, weights, line-height, letter-spacing match
- **Colors**: Brand green `#08805A`, full palette matches reference design tokens
- **Spacing**: Container 1200px, padding 24px gutters, component margins/paddings match
- **Cards**: Border-radius 8/12/16px, shadows, hover states match
- **Responsive**: Layout transforms at 1180px, 1080px, 760px match reference behaviors
- **RTL**: `dir="rtl"` on `<html>`, right-to-left text flow, natural grid reorder

### Interactive States
- **Hover**: All interactive elements (buttons, links, cards, chips) have hover styles
- **Focus**: `focus-visible` outlines match `outline: 2px solid var(--brand-400); outline-offset: 2px`
- **Active**: Button `transform: translateY(1px)` on press
- **Disabled**: `opacity: .45; pointer-events: none`
- **Selected/Active**: `.active` class styles for nav links, chips, segments
- **Empty states**: Cart empty, search results, tables with no data

### Error States
- **404 pages**: Fallback when resources not found
- **API errors**: Displayed as toast notices or inline error messages
- **Form validation**: Error messages next to fields, `err-msg` pattern

### Known Test Files (existing)
- `frontend/test/render-output.test.ts` → checks `<main>` present
- `frontend/test/domain-contracts.test.ts` → type contract validation
- `frontend/test/integration-contracts.test.ts` → contract coherence
- `frontend/test/cart.test.ts` → cart domain contracts

### Run Tests
```bash
pnpm test          # vitest run
pnpm test:watch    # vitest watch
```

### Acceptance Criteria Checklist
- [ ] TypeScript `typecheck` passes
- [ ] Production `build` succeeds
- [ ] App renders at `http://localhost:3000` through Docker
- [ ] Homepage matches reference layout
- [ ] Header matches (logo, search, nav, cart, rtl)
- [ ] All page views implemented (home, store, cart, checkout, order-tracking, business, panel, digital-menu, search, footer, bottom-nav)
- [ ] RTL layout works with `dir="rtl"`
- [ ] Responsive at 1440/1024/768/390/360px
- [ ] Tailwind CSS v4 (not v3)
- [ ] No dependency on legacy CSS files
- [ ] Global state persists in localStorage
- [ ] API services integrate with Django backend (mock fixtures when unavailable)
- [ ] All `focus-visible` styles present
- [ ] All `44px` minimum touch targets
- [ ] Animation timings match (bump .4s, progress .3s, tin .25s, transitions .2s/.28s/.15s)
- [ ] Design tokens extracted from reference (colors, radii, shadows, breakpoints)

## 10. Known Limitations and Unresolved Questions

### Backend Integration Gaps
1. **Cart API**: No backend cart endpoints found. Cart state managed purely via localStorage in current implementation. Decision needed: implement backend cart or keep frontend-only.
2. **Order placement**: No `POST /api/orders/` endpoint identified. Order tracking is read-only.
3. **Authentication flow**: No `login/` or `otp/` endpoints visible in reviewed backend files. Assuming `accounts` app provides this.
4. **Payment integration**: ZarinPal gateway configured but full flow not inspected.
5. **Search API**: No dedicated backend search endpoint. Client-side filtering only.

### Design Tokens
- **`color-mix()` function**: Used extensively in jam-life.html for dark/light variants. Tailwind v4 may need custom utilities or CSS vars for equivalent.
- **`@font-face` with data URI**: Exact font rendering may vary across OS. Preference: use preloaded TTF files from `public/fonts/`.
- **Custom breakpoints**: 1180px, 1080px, 760px are not Tailwind default. Will need custom screen names or media queries.

### Runtime Behavior
- **Hash routing**: `window.location.hash` driven `route()` / `go()` functions. Next.js App Router may need accommodation (dynamic routes vs hash).
- **LocalStorage persistence**: `jam.state.v1` key. Assumes browser localStorage available.
- ** no SSR support** for VIEWS HTML strings during initial mount (SSR-safe placeholder then client hydration).

### Dependencies
- Current deps: `class-variance-authority`, `clsx`, `lucide-react`, `next@15`, `radix-ui`, `react@19`, `react-dom@19`, `tailwind-merge`, `tailwindcss@4`
- May need to add: `react-hook-form` (if implementing forms), `zod` (validation), `@hookform/resolvers` (if using RHF)

### Docker Integration
- Frontend runs on `localhost:3000` (Next.dev) or through nginx/reverse-proxy in Docker
- API proxy: `/api/*` → `backend:8000` (docker-compose) or `localhost:8000` (dev)
- CORS configured for `http://localhost:3000`
- Media/WebP assets need to be served or mocked

### Unimplemented Pages (from reference)
- `#/promo/*` - promo views
- `#/game/*` - game views
- These may be lower priority if scope is core UI features