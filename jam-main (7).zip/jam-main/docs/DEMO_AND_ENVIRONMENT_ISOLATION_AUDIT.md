# JAM — Demo and Environment Isolation Audit

Date: 2026-11-08
Scope: frontend demo catalog, local browser state, production fallback paths, simulated payment and test-only configuration.

## 1. Demo-mode control

`frontend/lib/demo.ts` is the single gate:

- `NEXT_PUBLIC_DEMO_MODE=true` → demo mode enabled.
- `=false` → disabled.
- Unset → enabled only when `NODE_ENV !== "production"`.

Production builds therefore default to **real backend data**, and demo stores require an explicit build-time flag.

Gated routes/screens:

| Path | Demo behavior | Production behavior |
|---|---|---|
| `/` | `HomePage` demo stores | `RealHomePage` fetched from backend |
| `/search` | demo search | `RealCatalogSearch` calls `/api/commerce/public/stores/` |
| `/store/[id]` | demo store page | returns 404; real stores use `/m/[slug]` |
| `/m/[slug]` | demo menu by slug | real backend menu only; unknown/demo slugs 404 |
| `/checkout` | local demo order | API quote/order checkout |
| `/orders`, `/order/[id]` | local demo history | server orders/tracking |

Verified on the production build:

- `/m/nakhl` → 404, `/store/s1` → 404.
- `/` contains the seeded backend store and no demo store names.
- `/m/smoke-menu` server-renders backend product names and Toman prices.

## 2. Classification of remaining demo/mock state

| Occurrence | Classification | Notes |
|---|---|---|
| `lib/data.ts` `STORES`, product media, sample prices | Development-only content | Imported for demo screens and visual helpers; production catalog does not render it |
| Demo addresses in `lib/state.tsx` | Development-only | `addrs` initial value is empty unless demo mode |
| Demo cart/orders in `jam.state.v1` | Development-only / accidental residue | Production `load()` discards non-`api:` carts. Demo orders can remain in localStorage but production `/orders` and `/order/[id]` do not read them |
| `jam.apiStores.v1` backend snapshots | Production-safe cache | Contains real public API data; used only to keep API carts working across reloads |
| `NEXT_PUBLIC_DEMO_MODE` fallback | Explicit gate | Defaults off in production |
| ZarinPal sandbox | Environment control | Now defaults to `not DEBUG`; `.env.example` sets false |
| `COMMERCE_ALLOW_SIMULATED_PAYMENTS` | Test/development only | Defaults to `DEBUG`; seller-only endpoint |
| `COMMERCE_ORDER_ONLINE_PAYMENTS_ENABLED` | Production gate | Defaults false; online orders return 503 |
| `config/test_settings.py`, `config/smoke_settings.py` | Test-only | Must not be used in deployment; smoke settings are temporary and deleted |
| Static category labels (e.g. «سوپرمارکت») in home navigation | Production-safe static content | Labels, not demo store records |
| Legacy `cart` app | Dead/obsolete for customer flow | Client-supplied prices; not used by real checkout |

No hardcoded revenue, fake settlement or fake membership data is displayed by production menu/catalog/checkout screens. Panel screens read backend commerce endpoints.

## 3. Production failure behavior

Tested with a second production Next server on port 3101 pointed at a dead backend (`API_INTERNAL_URL=http://127.0.0.1:8999`):

- `/` returned HTTP 200 with the explicit error state «دریافت فهرست فروشگاه‌ها ناموفق بود».
- No demo store names (`نخل`, etc.) appeared.
- `/api/commerce/public/stores` through the proxy returned 502.
- The error text explicitly states that demo data is not substituted.

Code inspection confirms `RealHomePage` and `RealCatalogSearch` never import the demo store list for rendering and never fall back on API errors.

## 4. Browser/local storage isolation

- Production cart persists only `api:<id>` stores and sanitizes legacy demo carts on load.
- Backend store snapshots are written only by `registerStore` for API stores.
- Auth tokens are in a separate `jam.auth.v1` key and are never mixed with commerce state.
- Demo orders/addresses are not read by production order pages.
- No test user, test store, simulated payment flag or OTP bypass is reachable through production `config/settings.py` defaults.

## 5. Residual risks

| Severity | Risk | Recommendation |
|---|---|---|
| Medium | Demo orders remain in localStorage even though not rendered | Clear non-API `orders` in production on load for hygiene |
| Medium | `NEXT_PUBLIC_DEMO_MODE` is build-time; a production image accidentally built with `true` would expose demo routes | Add a CI/build assertion that production builds use `false` |
| Low | Static demo store registry still increases bundle/import surface | Consider code-splitting demo data if bundle size matters |
| Low | Prototype static category labels are not backend-driven | Acceptable; not commerce data |

## 6. Verification

- Production build (`NEXT_PUBLIC_DEMO_MODE` unset) served real data and 404 for demo routes.
- API-down production run: 200 error page, no demo data, proxy 502.
- PWA runtime matrix separately confirmed `/m/nakhl` is not cached.
- Full backend tests include the online-order 503 gate and simulation defaults.

**Status: production demo isolation is IMPLEMENTED and TESTED for catalog, menu, checkout and demo routes. Residual localStorage hygiene is documented, not blocking.**
