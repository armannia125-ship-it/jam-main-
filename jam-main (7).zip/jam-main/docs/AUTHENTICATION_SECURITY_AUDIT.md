# JAM — Authentication, Session and Authorization Security Audit

Date: 2026-11-08
Scope: `frontend/lib/api.ts`, `frontend/lib/auth.tsx`, `/login`, backend OTP/JWT endpoints, same-origin proxy, seller/customer authorization.

## 1. Result summary

| Area | Result |
|---|---|
| OTP verification | Implemented; provider verified server-side; attempts/challenge consumption enforced |
| JWT issuance | Implemented (access 30 min, refresh 7 days, rotation enabled) |
| Refresh endpoint | **Was missing; fixed** with `/api/auth/refresh/`; valid and invalid cases tested |
| Single-flight refresh | Verified at runtime against compiled client code |
| Token storage | `localStorage`; functional but XSS-exposed; documented limitation |
| Logout | Client-side session clear only; no server-side revocation |
| Object-level authorization | Backend enforced; seller/customer/unauthorized matrix tested |
| Public endpoints | Explicit `AllowAny` allowlist |
| Production cookies | Secure-by-default settings added; JWT still uses `Authorization`, not cookies |

No architecture rewrite was performed.

## 2. Token storage

- Access and refresh tokens are stored together in `localStorage` under `jam.auth.v1`.
- Auth state is synchronized via a `jam-auth` window event and the browser `storage` event (cross-tab).
- Tokens are never written to HTML, logs or API error messages.

Implications:

| Risk | Assessment |
|---|---|
| XSS | Any script executing on the origin can read both tokens. This is the main residual risk |
| CSRF | Low for API calls because the token is sent as an `Authorization` header, not an ambient cookie |
| Secure cookies / HttpOnly | Not used for JWTs; no migration was attempted because it would require backend cookie auth, CSRF handling and proxy changes |
| HTTPS | Required in production; secure cookie settings are not sufficient protection for localStorage tokens |
| Browser persistence | Tokens persist until logout or clearing site data |
| Cross-tab | `storage` listener syncs login/logout; refresh rotation is per tab but old refresh tokens remain valid (see below) |

**Status: documented limitation, not silently addressed.** Migration to HttpOnly secure cookies is recommended before handling high-value accounts, but is outside this phase.

## 3. Refresh lifecycle

### Bug found and fixed

The frontend called `POST /api/auth/refresh/`, but the backend URLconf exposed only `request-otp`, `verify-otp` and `signup`. The call returned 404, so any access-token expiry ended the session.

Fix: added `TokenRefreshView` at `api/auth/refresh/` and tests:

- valid refresh → 200 with new access/refresh, new access authorizes `/api/commerce/orders/mine/`;
- invalid refresh → 401.

### Single-flight runtime verification

`apiFetch` stores a module-level `refreshing` promise. Compiled `lib/api.ts` was exercised in Node with mocked storage/fetch:

- 3 concurrent requests with an expired access token → **1** refresh call, 6 resource calls (initial + one retry each), all retries succeeded with the rotated access token;
- failed refresh → session cleared, exactly one refresh attempt, no retry loop, final 401;
- anonymous 401 → no refresh attempt.

Result: **3/3 passed**.

### Residual behavior

- `ROTATE_REFRESH_TOKENS=True`, but `BLACKLIST_AFTER_ROTATION` is not enabled and the blacklist app is not installed. A rotated-away refresh token therefore remains cryptographically valid until its 7-day expiry.
- There is no server-side logout or token revocation endpoint. Logout clears local state; a copied refresh token remains usable.
- Cross-tab refresh is not coordinated; because old refresh tokens are not blacklisted, parallel tab refreshes do not invalidate each other.
- Expired access tokens on private pages produce the standard 401 flow; no protected data is rendered before `ready`.
- Backend refresh rotation is verified; browser multi-tab refresh was not executed as a full browser scenario.

**Owner decision:** enable `rest_framework_simplejwt.token_blacklist` + `BLACKLIST_AFTER_ROTATION` and add a logout/revocation endpoint if stolen-token revocation is required.

## 4. Authorization

Backend default permission is `IsAuthenticated`; public catalog/menu endpoints opt out explicitly with `AllowAny` + no authentication.

Seller routes use `owned_business(request, business_id)` → `get_object_or_404(Business, pk=..., owner=request.user)`, so another seller gets 404 rather than data.

Customer order detail allows only the order's customer or the business owner; all other users get 404.

Verified against the production smoke stack (`/api` through the Next proxy):

| Request | Expected | Observed |
|---|---|---|
| Unauthenticated `/api/commerce/orders/mine/` | 401 | 401 |
| Customer calls seller `/businesses/1/orders/` | 404 | 404 |
| Stranger calls seller `/businesses/1/orders/` | 404 | 404 |
| Owner calls seller `/businesses/1/orders/` | 200 | 200 |
| Stranger reads another customer's order | 404 | 404 |
| Customer reads own order | 200 | 200 |
| Public store directory/menu | 200 without auth | 200 |
| Online order from customer | 503 (feature gate) | 503 |

Seller revenue, metrics, settlement and purchase-list endpoints returned 200 only for the owner; the same routes were denied to the customer/stranger.

## 5. OTP and account handling

- OTP requests are throttled at 5/hour in production (`DevelopmentRateThrottle` bypasses only when `DEBUG=True`).
- Verification is performed by the OTPy provider, not by a client-supplied flag.
- Challenges are locked, active, unexpired and limited to 5 attempts; successful verification consumes the challenge.
- Unregistered identifiers return 404; inactive users return 403.
- Signup requires provider verification and relies on the unique phone constraint to handle concurrent signup.
- No phone numbers, OTP codes, API keys or tokens are logged. Provider diagnostics log only sanitized categories.
- Debug-mode OTP bypass is confined to the test/development settings, not production settings.

Residual: the OTP provider remains an external dependency; provider outage returns 502 and cannot be verified without credentials.

## 6. Error handling

- Unauthorized API requests return JSON `detail`/`code`, not stack traces.
- Proxy network failure returns 502 `api_unreachable` without exposing the internal URL.
- Offline private pages use the service worker offline page, not cached private HTML (see PWA audit).
- Token values are never included in errors or console output.

## 7. Findings and recommended follow-ups

| Severity | Finding | Recommendation |
|---|---|---|
| High | Tokens in `localStorage` are XSS-readable | Migrate to HttpOnly secure cookies with CSRF protection, or add a strict CSP and short access lifetime |
| High | No refresh-token revocation | Enable SimpleJWT blacklist and a logout endpoint |
| Medium | No explicit CSP/security headers in Next config | Add CSP, `X-Content-Type-Options`, `Referrer-Policy`, frame protections at the proxy/CDN |
| Medium | Cross-tab refresh coordination absent | Acceptable while rotation is not blacklisted; revisit after enabling blacklist |
| Low | Signup response omits the user object | Frontend synthesizes `{id:0}`; refresh from `/me` later or return the user |

## 8. Verification commands

```bash
cd backend
python3 manage.py test accounts --settings=config.test_settings   # 58 tests, OK
python3 manage.py test --settings=config.test_settings            # 151 tests, OK (10 skipped)
# Compiled-client single-flight harness (temporary, outside the repo): 3/3 passed
```

No credentials or token values were printed or committed.
