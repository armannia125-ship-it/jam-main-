# Deployment Foundation Final Report

**Date:** 2026-11-08
**Phase:** Deployment Foundation & Offline Commerce Pilot
**Outcome:** Foundation implemented and validated in an isolated environment. No production release was performed.

## 1. Executive summary

This phase converted the subscription path to one manual-payment plan with operator-issued, hash-only activation codes, disabled free trials and simulated subscription payments, added a TLS/reverse-proxy deployment shape, added Docker health checks, established lint/type/build gates, and executed a 23-check HTTPS pilot against an isolated PostgreSQL-backed stack.

Final evidence:

- **179 backend tests passed** (15 skipped on SQLite test settings).
- **15 PostgreSQL concurrency tests passed**.
- **23/23 HTTPS pilot checks passed**.
- **Frontend lint passed** with 0 errors and 11 warnings.
- **TypeScript and production build passed**.
- **Backend and frontend Docker images built**; all five Compose services became healthy.
- **Database-down readiness returned 503** and the container became unhealthy; recovery returned 200/healthy.
- **Local HTTPS, HTTP-to-HTTPS redirect, slashless POST, and bot issuance through the proxy were validated** with an internal certificate.

The system is suitable for a controlled owner-supervised pilot. Public launch remains gated on real domain/TLS, live Telegram/OTP validation, payment policy, access hardening, and owner decisions.

## 2. Architecture after this phase

### Subscription

```text
Customer panel
  -> POST /api/subscriptions/request
  -> owner pays externally
  -> operator confirms payment in admin
  -> trusted bot or admin issues one code
  -> customer redeems code in own panel
  -> active subscription with plan duration
```

There is exactly one publicly exposed plan, no free plan, no trial, and no online checkout. Activation codes are random, hashed at rest, single-use, customer-bound, expiring, revocable, and audited.

### Deployment

```text
Caddy :80/:443
  -> /admin, /static -> Django
  -> /media -> shared volume
  -> everything else -> Next.js
                         -> /api same-origin proxy -> Django
Django -> PostgreSQL + Redis
```

Backend and frontend are private Compose services. Caddy terminates TLS. Health checks verify dependencies, not just process liveness.

## 3. Deliverables

| Document | Contents |
|---|---|
| `DEPLOYMENT_FOUNDATION_BASELINE.md` | Starting point and baseline evidence |
| `MANUAL_SUBSCRIPTION_WORKFLOW.md` | End-to-end operational workflow |
| `SINGLE_SUBSCRIPTION_MODEL.md` | One-plan model, lifecycle, and limits |
| `MANUAL_ACTIVATION_SECURITY_AUDIT.md` | Threat model, controls, findings, residual risk |
| `TLS_AND_REVERSE_PROXY_VALIDATION.md` | Caddy/TLS/proxy validation and production steps |
| `DOCKER_BUILD_AND_HEALTHCHECK_REPORT.md` | Image/build/health evidence |
| `ESLINT_AND_CODE_QUALITY_REPORT.md` | Lint, typecheck, build results |
| `PRODUCTION_OPERATIONS_RUNBOOK.md` | Deploy, activate, recover, rotate secrets |
| `OFFLINE_COMMERCE_PILOT_REPORT.md` | 23-check pilot evidence and limitations |
| `FINAL_DEPLOYMENT_REGRESSION_REPORT.md` | Final pass/fail/not-tested ledger |
| `DEPLOYMENT_FOUNDATION_FINAL_REPORT.md` | This summary |

## 4. Key implementation decisions

1. **Canonical plan:** the oldest active positive-price/positive-duration `SubscriptionPlan` is the one exposed. Legacy plan rows are preserved, not deleted.
2. **No free trial:** legacy club trial code remains for historical rows but returns `403 trial_disabled`; simulated membership/subscription activation returns `409`.
3. **No online checkout:** the subscription checkout endpoint returns `410` permanently.
4. **Manual request is not payment:** a request is `pending`; only operator action sets `payment_confirmed`.
5. **Code issuance is server-to-server or admin-only:** the bot token is never a browser environment variable.
6. **Plaintext code is ephemeral:** only SHA-256 digest and a 4-character hint persist.
7. **Atomic redemption:** row locks plus customer/status/expiry/revocation checks; one winner under concurrency.
8. **Django is not exposed publicly:** Caddy sends API traffic through the Next.js proxy to preserve trailing-slash POST semantics.
9. **Health checks are dependency-aware and unthrottled:** readiness checks PostgreSQL and cache.
10. **No invented financial data:** the actual price, duration, bank/card instructions, and contact remain owner inputs.

## 5. Defects found during validation and fixed

| Defect | Fix |
|---|---|
| Redemption returned 500 when a confirming operator was set (`User.get_full_name` did not exist) | Serializer now builds a name from first/last name or falls back to email/phone; regression test added |
| Backend health checks exhausted the anonymous API throttle and marked the container unhealthy | Health views bypass throttles; 150-call regression test |
| Next.js proxy dropped `X-Bot-Token` and `X-Forwarded-Proto` | Forward bot and proxy headers server-to-server |
| Gunicorn hid request tracebacks | Added `django.request` console error logging |

These were caught by the integrated pilot, not only unit tests.

## 6. Verification ledger

### Implemented and tested

- Manual request, payment info, operator confirmation, bot issuance, customer redemption.
- One-plan exposure, no trial, no online checkout, no simulated subscription activation.
- Hash-only storage, one-time use, customer binding, revocation, expiry, audit.
- Concurrent redemption.
- Isolated Compose startup, health, database-outage behavior.
- Local HTTPS, redirect, proxy headers, Caddy config validation.
- ESLint, TypeScript, Next.js build, backend tests, PG concurrency tests.

### Failed checks resolved

None remain unresolved. Four defects found during validation were fixed and re-verified.

### Not tested

- Public ACME/TLS with a real domain.
- Live Telegram delivery.
- Real OTP delivery/login.
- Real manual bank payment and reconciliation.
- Full authenticated browser interaction.
- Production backup/restore and orchestrator behavior.
- Registry push, scan, sign, or deploy.

### Blocked / owner decisions

- Real plan and payment details.
- Renewal/refund/cancellation rules.
- Legacy club-membership treatment.
- Domain/TLS approval.
- Admin/bot access hardening and dual control.
- Non-Telegram code delivery.

## 7. Operational readiness

Use `PRODUCTION_OPERATIONS_RUNBOOK.md` for the release sequence. Do not treat the isolated test values as production values:

- The pilot plan (150,000 Toman / 30 days) was synthetic.
- The test users, businesses, Telegram links, and bot token were synthetic.
- Local TLS used an internal CA.
- No production `.env` or secret was created.

## 8. Final recommendation

**Proceed to a controlled pilot only.** The deployment foundation, single-plan model, manual activation boundary, and health/security controls are in place and verified. A public launch should wait for owner policy decisions, production domain/TLS validation, live Telegram/OTP verification, and access-control review.
