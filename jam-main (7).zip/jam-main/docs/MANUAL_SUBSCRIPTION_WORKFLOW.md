# Manual Subscription Workflow — Removed

**Status:** RETIRED

**Date:** 2026-11-10

The manual payment and activation-code workflow no longer exists. Do not create plans, confirm manual payments, issue activation codes, or redeem codes.

## Current subscription flow

1. The seller opens `/subscriptions` or `/panel/plan`.
2. The seller selects one of the five canonical `SubscriptionProduct` rows.
3. The server creates a `SubscriptionPurchase` with an authoritative price snapshot.
4. ZarinPal initiates payment. If the provider is unconfigured, the API returns `503 payment_provider_unconfigured` and creates nothing.
5. The server verifies the callback and marks the purchase `paid`.
6. `activate_entitlements_for_purchase()` creates the MENU and/or CLUB entitlements atomically.
7. Public menu, QR, directory, product editing, product limits, bot editing, and admin views read only current entitlements.

## Product mapping

| Product | MENU | CLUB |
|---|---:|---:|
| Basic | Yes | No |
| Professional | Yes | No |
| Premium | Yes | No |
| Gold | Yes | Yes |
| Seller Club | No | Yes |

## Removed endpoints and UI

- `/api/subscriptions/plans/`
- `/api/subscriptions/mine/`
- `/api/subscriptions/request/`
- `/api/subscriptions/payment-info/`
- `/api/subscriptions/redeem/`
- `/api/subscriptions/checkout/`
- `/api/bot/activation-codes/`
- `/api/commerce/businesses/<id>/club/trial/`
- `/api/commerce/businesses/<id>/club/deactivate/`
- `/api/commerce/businesses/<id>/invoices/<invoice_id>/simulate-payment/`

No manual payment instructions, activation codes, trials, or simulated subscription payments remain.
