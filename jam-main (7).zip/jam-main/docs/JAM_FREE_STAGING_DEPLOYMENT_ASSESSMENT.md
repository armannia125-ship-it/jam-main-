# JAM FREE STAGING DEPLOYMENT ASSESSMENT REPORT

**Repository:** `/Users/erfmollaey/projects/polaris-jam`
**Branch:** `main` (HEAD: `fdb1add`, clean working tree, up to date with `origin/main`)
**Assessment Date:** 2026-11-09
**Deployment Target:** Free-tier staging environment (Render + Neon PostgreSQL + Upstash Redis)

---

## 1. REPOSITORY SCOPE AND BASELINE

The JAM repository is a monorepo-style application consisting of a Next.js (React/TypeScript) frontend and a Django (Python) backend, integrated via a Next.js API proxy route. The backend provides user management, authentication, subscription entitlement enforcement, payment processing (ZarinPal), business/product catalogs, Telegram bot interaction, and expiring-entitlement notifications.

Baseline verification performed:
- Branch `main`, clean working tree, synchronized with `origin/main`.
- All canonical documentation and configuration files reviewed.
- Backend source modules, frontend source modules, Dockerfiles, compose files, and environment templates examined.
- Full secrets scan performed across tracked files; no secrets committed.

---

## 2. TARGET STACK OVERVIEW

The intended staging deployment target consists of:

| Component | Provider | Tier |
|---|---|---|
| Web Service (Next.js + API proxy) | Render | Free |
| Web Service (Django API) | Render | Free |
| PostgreSQL | Neon | Free |
| Redis / Cache | Upstash | Free |
| Media Storage | Local filesystem (current) | — |

---

## 3. RENDER FREE TIER ASSESSMENT

- Free web services spin down after 15 minutes of inactivity.
- Maximum of 750 free instance hours per month.
- Ephemeral filesystem: no persistent disks available on free tier.
- Resources: 0.1 CPU / 512 MB RAM.
- Disallowed on free tier: one-off jobs, SSH access, manual scaling.
- Free PostgreSQL expires 30 days after creation; storage limit 1 GB; no automated backups; no connection pooling.
- Free Key Value store is in-memory only; data is lost on restart.

**Assessment:** Free-tier web services will be restarted frequently, causing cold starts and intermittent downtime. The combination of ephemeral filesystem and in-memory Redis renders simple free-tier configurations insufficient for stateful deployments.

---

## 4. NEON POSTGRESQL FREE TIER ASSESSMENT

- Free allocation: 100 compute-unit-hours per project.
- Storage: 1 GB per project (20 GB total account allowance).
- Scale-to-zero after 5 minutes of inactivity.
- Egress limit: 5 GB per project per month.
- Connection pooling included (up to 10,000 pooled connections).
- No uptime SLA.
- Maximum 100 projects per account.

**Assessment:** Sufficient for initial staging workloads, subject to compute-hour consumption and idle suspension behavior.

---

## 5. UPSTASH REDIS FREE TIER ASSESSMENT

- Free allocation: 250 MB data size, 500,000 commands per month, 10 GB bandwidth.
- TLS supported; persistence enabled.
- Limits: 1 database maximum; unclaimed free databases deleted after 3 days.

**Assessment:** Adequate for cache-only usage, provided command volume and data size remain within free-tier bounds.

---

## 6. NEXT.JS FRONTEND DEPLOYMENT READINESS

- `frontend/next.config.mjs` does **not** currently set `output: 'standalone'`.
- Render native runtime requires either `output: 'standalone'` or a custom Docker image for proper deployment.
- `frontend/app/api/[...path]/route.ts` implements a same-origin API proxy that forwards authentication headers, cookies, and proxy headers, and handles trailing slash normalization.
- Frontend API base configuration is derived through environment-driven API URL.

**Finding:** Without `output: 'standalone'` or Docker-based deployment, Render native runtime deployment is not currently viable as-is.

---

## 7. DJANGO BACKEND DEPLOYMENT READINESS

- Backend served via Gunicorn (`config.wsgi:application`).
- Backend `Dockerfile` runs database migrations automatically on every start.
- Backend startup procedure currently includes migration execution, which may require careful handling on free-tier ephemeral storage.

**Finding:** Backend deployment pipeline is Docker-based and appears suitable, pending environment variable and secret management.

---

## 8. DATABASE AND ORM CONFIGURATION

- Primary datastore: PostgreSQL via Neon.
- Django ORM standard usage.
- Database connection settings to be supplied through environment variables.

**Assessment:** Database provider supports pooled connections via Neon, which should alleviate single-connection limits on the free tier.

---

## 9. CACHE AND SESSION MANAGEMENT

- Redis (Upstash) currently used for caching purposes.
- No Celery or Beat task queue present in the codebase.
- No distributed cache backend configured for multi-instance scenarios.

**Finding:** Cache-only Redis usage is acceptable for staging, but no background scheduling infrastructure exists.

---

## 10. MEDIA AND FILE STORAGE

- Media root configured to local filesystem path (`BASE_DIR / "media"`).
- Image fields used on `Business.logo` and `Product.image`.
- No cloud object storage integration configured.

**Finding:** Render free tier ephemeral filesystem makes local media storage unsuitable for persistent staging deployments; cloud object storage (e.g., S3-compatible) is required.

---

## 11. ENVIRONMENT AND CONFIGURATION MANAGEMENT

- Canonical environment variable template: `.env.example`.
- Local `.env` file present but git-ignored (confirmed via `git check-ignore`); not part of tracked repository.
- No secrets baked into tracked files; secret scan found no exposed credentials.
- Deployment environment variables must be provisioned through platform secret management.

**Finding:** Secret handling approach is clean at repository level; runtime secret provisioning remains a deployment step.

---

## 12. AUTHENTICATION AND AUTHORIZATION

- JWT-based authentication with token storage in browser localStorage.
- Documented limitation: localStorage-based JWT introduces security exposure and refresh complexity.
- Backend session management also present.
- Admin access created via management command (`make_admin`) that promotes an existing user; no public registration flow exists.

**Findings:**
- CORS is limited to `http://localhost:3000`.
- Public registration is not available through the application itself.
- Admin creation requires an existing user account.

---

## 13. API AND INTEGRATION ARCHITECTURE

- Next.js catch-all API route proxies requests to backend.
- Header forwarding includes authentication and proxy-related headers.
- Trailing-slash handling implemented.
- Third-party integrations: OTPy (`https://api.otpy.ir` hardcoded), ZarinPal gateway.

**Finding:** OTPy endpoint is hardcoded; ZarinPal fails safely with HTTP 503 when unconfigured.

---

## 14. SUBSCRIPTION AND ENTITLEMENTS

- Entitlement module enforces subscription rules.
- Basic tier: 80 units.
- Gold tier: MENU + CLUB entitlements.
- Entitlements evaluated during access control flows.

**Assessment:** Core logic present; requires runtime configuration and database state for staging validation.

---

## 15. PAYMENT GATEWAY INTEGRATION

- ZarinPal gateway module at `/backend/payments/gateways/zarinpal.py`.
- Purchases flow through `/backend/subscriptions/purchase_views.py`.
- Payments fail safely (503) when gateway is unconfigured; no transactions are created in that state.

**Finding:** Payment integration is not production-ready until gateway credentials and test-mode behavior are configured.

---

## 16. NOTIFICATION AND BACKGROUND JOB SYSTEM

- Expiring entitlement notifications implemented as an idempotent management command.
- No scheduler (Celery, cron, or equivalent) currently exists to trigger notifications automatically.

**Finding:** Notification delivery pipeline requires scheduling infrastructure or a manually invoked job strategy.

---

## 17. TELEGRAM BOT INTEGRATION

- Bot managed via management command (`/backend/bot/management/commands/run_telegram_bot.py`).
- Bot uses polling; requires `TELEGRAM_BOT_TOKEN` environment variable.
- No webhook implementation found.

**Finding:** Polling-based bot is functional for staging but consumes long-lived connections and lacks webhook-based scalability.

---

## 18. SECURITY AND COMPLIANCE OBSERVATIONS

- Django security defaults applied (CSRF, password hashing, sessions).
- CORS restricted to localhost origin.
- JWT in localStorage: known security limitation, flagged for remediation.
- Secret management relies on environment variables with no tracked secrets.
- No additional compliance scanning performed during this assessment.

---

## 19. INFRASTRUCTURE AS CODE AND DEPLOYMENT CONFIGURATION

- Multiple Docker Compose files present for local orchestration.
- Backend Dockerfile performs build steps including static collection and startup migrations.
- Caddy configuration files present for local reverse proxy scenarios.

**Finding:** Existing IaC is local-oriented; Render-specific deployment configuration (render.yaml or dashboard setup) may need to be introduced.

---

## 20. DEPLOYMENT READINESS SUMMARY AND RISK REGISTER

| Area | Status |
|---|---|
| Next.js standalone output / Docker | Blocker |
| Media storage persistence | Blocker |
| Notification scheduling | Gap |
| Telegram bot delivery | Acceptable (polling) |
| Payment readiness | Blocker for real transactions |
| Cache/background jobs | Acceptable (cache-only) |
| Secret handling | Acceptable |
| Auth/CORS hardening | Gap |

---

## FINAL ASSESSMENT SECTIONS

### A. OVERALL VERDICT

**READY WITH BLOCKERS**

The application codebase demonstrates a complete functional architecture for the intended staging deployment. However, free-tier constraints, missing deployment artifacts, and unresolved infrastructure gaps prevent an immediate move to production staging without preparatory work.

### B. RECOMMENDED ARCHITECTURE

1. Deploy frontend via Docker container on Render (recommended given missing standalone output).
2. Deploy Django backend via existing Docker configuration.
3. Provision Neon PostgreSQL free tier.
4. Provision Upstash Redis free tier.
5. Integrate cloud object storage for media persistence.
6. Introduce scheduled job mechanism for expiring entitlement notifications.
7. Configure payment gateway test credentials.
8. Expand CORS to staging domain(s).
9. Migrate Telegram bot to webhook delivery (or retain polling for staging).
10. Implement secure token storage strategy beyond localStorage.

### C. CRITICAL BLOCKERS

1. **High:** Next.js missing `output: 'standalone'` — Render native runtime requires standalone output or Docker.
2. **High:** Local media storage incompatible with Render ephemeral filesystem.
3. **High:** No scheduler exists for expiring entitlement notifications.
4. **Medium:** CORS restricted to `http://localhost:3000`.
5. **Medium:** Telegram bot uses polling rather than webhook.
6. **Medium:** Payment gateway unconfigured — staging cannot exercise real purchase flows.
7. **Low:** No public user registration flow available.

### D. REQUIRED OWNER DECISIONS

1. Render deployment method: Docker vs. native runtime.
2. Cloud object storage provider and credentials.
3. Background job queue implementation (Celery/RabbitMQ/others).
4. CORS origin list for staging domains.
5. Payment gateway credentials and test-mode configuration.
6. Telegram bot delivery method selection.
7. Notification scheduling approach.
8. JWT storage and refresh strategy.
9. Public registration flow design.
10. Multi-environment configuration strategy.

### E. NEXT AUTHORIZED STEP

1. Introduce Docker-based Render deployment configuration (render.yaml or equivalent).
2. Add `output: 'standalone'` to Next.js configuration **or** finalize Docker image strategy.
3. Provision staging infrastructure values through approved secret management channels.
4. Configure object storage and update media handling.
5. Implement notification scheduling mechanism.
6. Validate staging deployment with read-only smoke tests before proceeding.

---

*End of Report*
