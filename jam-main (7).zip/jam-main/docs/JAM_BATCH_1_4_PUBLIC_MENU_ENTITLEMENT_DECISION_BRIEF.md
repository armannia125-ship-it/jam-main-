# JAM Batch 1.4 — Public Menu Entitlement Decision Brief

**Status:** AUDIT COMPLETE — OWNER DECISION REQUIRED  
**Date:** 2026-11-10  
**Companion audit:** `JAM_BATCH_1_4_PUBLIC_MENU_ENTITLEMENT_AUDIT.md`

## 1. Problem statement

Batch 1.3 made menu edit and publish access dual-model: a valid new MENU entitlement **or** a valid legacy `Subscription` can manage menus. Batch 1.4 found that public read paths did not receive the same update. Public menu, QR, and store directory still filter only legacy `Subscription` rows.

The practical result is that a customer who buys Basic, Professional, Premium, or Gold through the new Zarinpal flow may successfully publish a menu but cannot share it publicly unless they also have an unexpired legacy `Subscription`.

## 2. Root cause

The new system added:

- `SubscriptionProduct`, `SubscriptionPurchase`, and `SubscriptionEntitlement`;
- `entitlements.menu_access()` for edit/publish;
- purchase verification and independent entitlement windows.

It did not add a query-level equivalent of `menu_access()` for public reads. The three public surfaces were left with their pre-migration legacy filters:

- `PublicMenuView`: legacy `Subscription` only.
- `QrCodeView`: legacy `Subscription` only.
- `public_store_directory()`: legacy `Subscription` only.

This is a boundary inconsistency, not a data loss. The menu remains stored and can become visible later if the policy is fixed.

## 3. Affected user journeys

1. New paying customer publishes a menu and receives a public slug, but `/m/<slug>` returns 404.
2. The same customer cannot obtain a working QR payload from `/api/qr/<slug>/`.
3. The customer's store does not appear in home/search directory results.
4. A legacy subscriber continues to work; mixed records can mask the bug.
5. A Seller Club-only customer appears in the club list but its storefront link points at a business slug rather than a menu slug.
6. Telegram bot product editing remains legacy-only, so new buyers cannot edit products through the bot.

## 4. Current behavior summary

- Edit/publish: dual-model (`menu_access`).
- Public URL: legacy-only.
- QR: legacy-only.
- Directory: legacy-only.
- Club directory: new CLUB or legacy `ClubMembership`.
- Bot editing: legacy-only.
- Caches: Next 60 seconds, service worker 24 hours.

## 5. Risk assessment

| Risk | Severity | Notes |
|---|---:|---|
| New paying customer cannot use core advertised feature | High | Directly affects Basic/Professional/Premium/Gold |
| Inconsistent enforcement across boundaries | High | Edit and public reads disagree |
| Stale visibility after expiry/revocation | Medium | 60s/24h cache windows |
| Public exposure of unpublished menu | Low currently | Filter requires `is_active=True` |
| Cross-business leak | Low currently | Normal purchase path is owner-scoped |
| Legacy behavior regression | Medium if Option A chosen | Legacy records must be preserved |
| Documentation overstates central enforcement | Medium | Master report says every boundary |

## 6. Options

### Option A — New entitlements become canonical for public visibility

Public reads use only current MENU entitlements. Legacy-only records stop granting public visibility.

- Pros: simpler long-term model; one authority.
- Cons: breaks existing legacy subscribers unless a separate grandfathering decision and data policy are approved; contradicts current legacy compatibility intent.
- Migration: none if simply stopping legacy reads, but owner must explicitly accept behavior change.
- Rollback: code revert.

### Option B — Dual compatibility (recommended if legacy continues)

Public reads use current MENU entitlement **or** current legacy `Subscription`.

- Pros: fixes new buyers without removing legacy subscribers; matches existing `menu_access()` rule.
- Cons: two authorities remain; precedence conflicts must be defined; indefinite compatibility complexity.
- Migration: none.
- Rollback: code revert.

### Option C — Centralized policy helper (architecture, not policy)

Create one reusable predicate/query used by edit, public menu, QR, and directory. It can implement Option A or B.

- Pros: removes duplicated filters; makes tests and future policy changes coherent.
- Cons: does not itself resolve owner policy.
- Migration: none.
- Rollback: code revert.

### Option D — Not recommended

Add a separate `publicly_visible` boolean or cache invalidation system before settling entitlement policy. This would add schema and operational complexity without resolving the authority question.

## 7. Recommendation

Recommend **Option C implementing Option B**, unless the owner explicitly chooses Option A. In other words:

- Use one centralized public-visibility predicate.
- Grant public URL, QR, and directory access when either a current MENU entitlement or a current legacy `Subscription` exists.
- Preserve legacy records and their current behavior.
- Do not change product prices, durations, product limits, or purchase flow.
- Do not migrate or delete legacy data.
- Keep unpublished menus inaccessible.
- Keep Seller Club independent of menu access.
- Treat cache/offline semantics as an explicit owner decision before implementation.

This recommendation preserves compatibility while fixing the new-buyer gap. It is still subject to owner approval.

## 8. Proposed implementation plan (not authorized)

### Stage B.1 — Policy helper

Files:

- `backend/subscriptions/entitlements.py` or a new `backend/businesses/visibility.py`
- Add a queryset/Q helper, e.g. `menu_access_q(prefix="business")`, returning the approved OR/AND policy.
- Keep `menu_access(business)` for object-level checks.

### Stage B.2 — Apply to public boundaries

Files:

- `backend/businesses/views.py`: `PublicMenuView`, `QrCodeView`
- `backend/commerce/services.py`: `public_store_directory()`
- Ensure `.distinct()` to avoid duplicate rows from joined entitlement/subscription rows.

### Stage B.3 — Tests

Files:

- `backend/subscriptions/tests.py` or a new `backend/subscriptions/test_entitlements_public_visibility.py`
- `backend/businesses/tests.py`
- `backend/commerce/tests.py`

Minimum tests:

- New active MENU + published => 200 public menu, 200 QR, directory includes.
- New expired MENU => 404/excluded.
- New revoked MENU => 404/excluded.
- Legacy active only => still visible.
- Both valid => visible.
- New active + legacy expired => visible under Option B.
- New expired + legacy active => visible under Option B; document precedence.
- Seller Club only => no menu URL/QR/directory; club directory unaffected.
- Multi-entitlement and multi-menu no 500.
- Unpublished menu remains 404 even with valid entitlement.

### Stage B.4 — Cache and documentation

- Decide whether 60-second and 24-hour stale visibility is acceptable.
- If immediate revocation is required, change Next fetch cache and service worker behavior in a separate reviewed change.
- Update `docs/SUBSCRIPTION_ARCHITECTURE.md`, `docs/LEGACY_COMPATIBILITY.md`, and `AGENTS.md` after policy approval.
- Remove or document the duplicate public menu route.

### Stage B.5 — Optional separate scope

- Telegram bot: use `menu_access()` per business instead of legacy-only global check.
- Frontend club link: resolve menu slug before linking, or remove menu link for Seller Club-only stores.
- Live panel QR: replace demo-only pseudo QR with backend `/api/qr/<slug>/` if product requires it.

## 9. Rollback

- No migration is required for Option B/C.
- Revert the code change if behavior is wrong.
- Existing records remain untouched.
- Cache may continue to show old menus for up to 60 seconds online and 24 hours offline after rollback; no data repair is needed.

## 10. Owner approval checklist

- [ ] Approve Option A, B, or C.
- [ ] Approve whether new active MENU alone grants public URL access.
- [ ] Approve whether the same rule grants QR access.
- [ ] Approve whether the same rule grants store directory access.
- [ ] Approve whether legacy active subscriptions continue to grant public visibility.
- [ ] Approve precedence when new and legacy records disagree.
- [ ] Approve immediate expiry/revocation semantics or accept cache/offline stale windows.
- [ ] Approve that unpublished menus remain inaccessible.
- [ ] Approve directory row semantics for multiple menus.
- [ ] Approve whether Seller Club-only stores should link to a menu.
- [ ] Approve whether Telegram bot editing is in scope.
- [ ] Approve Stage B implementation and its tests.
- [ ] Confirm no migration or data change is authorized unless explicitly added later.

## 11. Explicit non-decisions

This audit does not decide:

- Whether public visibility should equal edit access.
- Whether legacy records should be grandfathered indefinitely.
- Whether revoked new entitlements override active legacy records.
- Whether offline cache must enforce immediate revocation.
- Whether Seller Club should ever grant menu access.
- Whether product marketing copy is an owner-approved policy.

## 12. Final status

AUDIT COMPLETE — OWNER DECISION REQUIRED
