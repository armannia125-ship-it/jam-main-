# JAM Master Implementation Report

Date: 2026-11-09 · Branch: `main` (uncommitted working tree) · Scope: Admin Panel, Multi-Tier Subscriptions, Online Payment Infrastructure & Full Regression

---

## A. Executive summary

**Implemented**

1. **Multi-product subscription domain** — five owner-approved products seeded in the database (`SubscriptionProduct`), `SubscriptionPurchase` with price snapshots, `SubscriptionEntitlement` with independent menu/club windows, Gold creating two entitlements atomically and idempotently.
2. **Server-side entitlement enforcement** — centralized `subscriptions/entitlements.py` used at every boundary: Basic 80-product limit (enforced in the product API), unlimited for higher plans, menu publish gate, Seller Club visibility, purchase-code issuance.
3. **Admin role & RBAC** — `User.role` (`user`/`admin`) read only from the server; `IsAdmin` permission on every admin API; `make_admin` provisioning command (promote-existing-only, idempotent, last-admin protection, audited); audited promotion/demotion/revocation; six admin API endpoints with real data.
4. **Admin frontend** (`/admin`) — dashboard (real aggregates, legacy-labelled), users (search/detail/promote/demote), payments (authoritative status only, no manual confirmation), subscriptions (entitlements + product matrix + audited revoke), admins management, audit log — all in the existing JAM design language, Persian RTL.
5. **Zarinpal online payment infrastructure** — purchase initiation with server-authoritative prices, payment attempt + verification boundary, idempotent callback with transactional entitlement activation, safe 503 when unconfigured; legacy offline subscription flow retired from the active experience (410) without deleting any historical record; Telegram bot untouched.
6. **Five-day expiration notifications** — idempotent management command + user panel UI; deployment scheduling documented (no Celery exists in the project).
7. **Frontend integration** — public catalog (exact prices, Gold with two independent entitlements and **no** discount claim), checkout with honest unconfigured-provider state, user panel subscriptions page with notifications and renewal, header/subnav/admin links.

**Preserved**

* Existing OTPy login flow, JWT/session architecture, all models and historical data (legacy `Subscription`, `ActivationCode`, `ClubMembership`, manual `Transaction`s).
* Existing customer-order commerce (`commerce` app) untouched — no duplicate order/payment models.
* Telegram bot and unrelated bot commands; PWA behaviour; all previously working routes.

**Overall completion:** implementation and verification complete; live Zarinpal connection and production scheduling remain owner/credential-dependent (see H).

---

## B. Architecture changes

* **New domain models** (`subscriptions/models.py`): `SubscriptionProduct` (catalog, JSON features, max_products limit), `SubscriptionPurchase` (price snapshot, pending→paid/failed), `SubscriptionEntitlement` (type menu/club, window, unique `(purchase, type)`, revocation fields), `EntitlementNotification`. `accounts/models.py`: `User.role`, `AdminAction` audit model. `payments/models.py`: nullable `purchase` FK + `transaction_has_one_target` check.
* **Entitlement design**: access = current entitlement OR legacy equivalent; renewal stacks from `max(now, latest end)`; expiration lazily applied, `is_current` authoritative; user data never deleted on expiry.
* **Payment architecture**: `POST /api/subscriptions/purchases/` → purchase + `Transaction(initiated)` → provider request → callback → server-side verify → `Transaction(success)` + `purchase(paid)` → atomic activation. Idempotency at three levels (open-purchase reuse, `select_for_update` callback serialization, unique-constraint activation).
* **Admin/RBAC architecture**: see `docs/ADMIN_RBAC.md`.
* **Notification architecture**: `EntitlementNotification` + `notify_expiring_entitlements` command (see `docs/SUBSCRIPTION_NOTIFICATIONS.md`).

---

## C. Subscription matrix

| Product | Price (Toman) | Duration | Category | Product limit | Online orders | Seller Club | Analytics | Customization |
|---|---:|---:|---|---:|---|---|---|---|
| پایه (basic) | 200,000 | 30 days | menu | **80** | ✗ | ✗ | ✗ | ✗ |
| حرفه‌ای (professional) | 250,000 | 30 days | menu | unlimited | ✓ (existing commerce flow) | ✗ | ✓ | ✗ |
| ویژه (premium) | 350,000 | 30 days | menu | unlimited | ✓ | ✗ | ✓ advanced | ✓ |
| طلایی (gold) | 450,000 | 30 days ×2 | combo | unlimited | ✓ | ✓ (independent) | ✓ | ✓ |
| باشگاه فروشندگان (seller_club) | 350,000 | 30 days | club | n/a | n/a | ✓ (standalone) | club metrics | n/a |

* Money stored as **integer Toman** everywhere; single ×10 conversion at the Zarinpal boundary (tested).
* **Gold pricing inconsistency (documented, owner-notified):** Premium + Seller Club = 700,000, so 450,000 is not a 10% discount. The 450,000 price is authoritative; no discount percentage is advertised anywhere; component prices unchanged.
* No cancellation, no auto-renewal, no proration — five-day expiration notification only.

---

## D. Payment status

| Item | State |
|---|---|
| Purchase/payment/verification/activation infrastructure | **Implemented** |
| Mocked payment tests (verify success/failure/cancel/replay/concurrency) | **Implemented, passing** |
| Live Zarinpal request/verify | **NOT tested — no credentials authorized** (fails safely with 503 `payment_provider_unconfigured` until configured) |
| Sandbox validation | NOT performed (needs merchant sandbox account) |
| Refunds via provider | Out of scope by owner decision |
| Customer-order online payments | Separate flow, remains disabled (`COMMERCE_ORDER_ONLINE_PAYMENTS_ENABLED=false`) — intentionally untouched |

Tests requiring actual Zarinpal credentials: live request redirect, real callback authority, merchant-panel reconciliation.

---

## E. Admin security

* Role model: `User.role` (server-side only) + `IsAdmin` permission; client role never trusted (frontend resolves via `GET /api/auth/me/`).
* Initial provisioning: `make_admin --phone` — promotes existing users only, idempotent, refuses inactive users and last-admin demotion, no public registration endpoint, no credentials handled.
* Promotion/demotion through the API with self-demotion and last-admin protection (409s).
* Audit logging: `AdminAction` records promotion, demotion, entitlement revocation, purchase mark-failed (actor, action, target, timestamp, safe metadata). OTP values/passwords never logged or stored.
* Backend authorization verified by tests: every admin endpoint denies normal and anonymous users; ownership scoping (404 not 403) preserved on user-scoped endpoints.

---

## F. Migration report

* Existing schema audited (see baseline in the transcript of Phase 0); migrations are additive: `accounts/0003`, `subscriptions/0004–0006`, `payments/0003`.
* Historical financial/subscription/customer records preserved; nothing rewritten or deleted; `makemigrations --check` clean.
* Legacy Club memberships: **not** auto-converted (owner decision pending — see `docs/LEGACY_COMPATIBILITY.md` §4). Pending legacy subscriptions are never auto-activated. Existing activation codes remain redeemable.
* Reversibility: seed migration has `unseed`; schema migrations have standard reverses; verified in isolated test databases (SQLite + throwaway PostgreSQL containers).

---

## G. Test evidence

| Command | Environment | Result |
|---|---|---|
| `python manage.py test --settings=config.test_settings` | SQLite in-memory | **230 tests — OK (17 skipped)**; skipped = PostgreSQL-only concurrency tests. 0 failures. |
| `PGTEST_PORT=55432 … python manage.py test subscriptions.test_concurrency commerce.test_concurrency subscriptions.test_payment_concurrency --settings=config.concurrency_settings` | Isolated throwaway PostgreSQL 16 container | **17 tests — OK (0 skipped, 0 failed)** incl. concurrent duplicate-callback and unique-constraint activation tests |
| `python manage.py makemigrations --check --dry-run --settings=config.test_settings` | SQLite | No changes detected (no drift) |
| `python manage.py check` (+ `--deploy` review) | dev env | System check clean; deploy warnings are the pre-existing DEBUG/cookie notes |
| `npx tsc --noEmit` (frontend) | — | Pass |
| `npm run build` (frontend) | production build | Pass (all new routes compiled) |
| `npm run lint` (frontend) | flat config | **0 errors, 11 warnings — all pre-existing** (documented in ESLINT_AND_CODE_QUALITY_REPORT.md), none introduced by this work |
| Runtime browser verification | isolated dev stack (throwaway PG + backend + frontend) | Catalog prices exact; checkout honest 503 fail-safe; admin 403 → promoted → real dashboard; Gold's two entitlements in user panel; two independent 5-day notifications rendered; make_admin refused unknown user, promoted existing user, audit recorded |

New automated tests added: `subscriptions/test_purchases.py` (17), `subscriptions/test_notifications.py` (10), `subscriptions/test_legacy_compatibility.py` (7), `subscriptions/test_payment_concurrency.py` (2, PG), `accounts/test_admin_api.py` (16). No real provider request, real Telegram message, or real OTP message was sent at any point (debug OTP delivery is not implemented in this codebase; test users were created directly in the isolated dev database and one fixed `SignupView` crash on missing `code` field was applied — documented in §H as a bug fix).

---

## H. Remaining work

**BLOCKER** (before live selling)
1. Zarinpal merchant credentials + sandbox/live validation; first-transaction reconciliation (`EXTERNAL CREDENTIAL REQUIRED`).
2. Production scheduling of `notify_expiring_entitlements` (cron or compose service — exact config in `docs/SUBSCRIPTION_NOTIFICATIONS.md`) (`EXTERNAL`/deployment).

**OWNER DECISION REQUIRED**
3. Legacy `ClubMembership` → paid Seller Club conversion policy (current: conservative, none converted).
4. Pending legacy manual subscriptions: keep operator confirmation for historical rows or close them out.
5. Prior open decisions unchanged: refresh-token revocation/localStorage JWT (pre-existing audit findings), settlement payout provider.

**OPTIONAL IMPROVEMENT**
6. Pre-existing 11 frontend lint warnings (documented; not mass-fixed).
7. `bot/views.py::TelegramVerifyView` remains dead/buggy code from before this phase (references a non-existent field); untouched as out of scope.
8. Admin UI pagination beyond 200 rows (lists are capped server-side).

---

## I. Final readiness status

**COMPLETE — READY FOR CONTROLLED STAGING VALIDATION**

(Production readiness is explicitly NOT claimed: live payment verification, real OTP/Telegram delivery, and production scheduling remain external prerequisites.)

---

## J. Safety confirmation

- ✅ No production deployment occurred.
- ✅ No real payment was initiated (provider interaction only in mocked tests; unconfigured runtime fails safely with 503).
- ✅ No live Telegram message was sent; the bot was not modified.
- ✅ No real OTP was sent during testing (test users created directly in isolated databases; no OTP provider credentials used).
- ✅ No production database was modified (tests used in-memory SQLite and throwaway PostgreSQL containers, all removed afterwards).
- ✅ No Git commit/push/tag/release was performed.
- ✅ No destructive Docker or database operation was performed (only throwaway test containers, removed after use).
