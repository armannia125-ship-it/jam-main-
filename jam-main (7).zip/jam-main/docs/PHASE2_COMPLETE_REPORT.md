# JamPlay — Phase 2 Complete Report

Date: 2026-11-18
Scope: JamPlay Phase 2 (progression, missions, achievements, rewards integration, profile/statistics,
non-multiplayer social, frontend screens, tests, hardening).
Phase 1 was left intact and was not rewritten.

**Final status: `PHASE 2 COMPLETE`**

---

## 1. Executive summary

Phase 2 completed the remaining prototype product surface on top of the accepted Phase 1 implementation:

- Server-authoritative XP/levels with level-up gem rewards and a persisted level history.
- Daily and permanent missions driven exclusively by trusted server-side events.
- Achievements with one-time, idempotent payouts.
- Daily gift economy reusing the existing once-per-local-date rule.
- Extended profile and statistics plus a privacy-preserving trophy leaderboard.
- Real, non-real-time social features (friend search by display name, requests, accept/reject, remove,
  friendly challenge) using separate JAM accounts.
- Nine-screen Persian RTL frontend with loading, empty, error and retry states.
- PostgreSQL concurrency verification (previously skipped in Phase 1) and a CI workflow.

All game resources remain in the independent JamPlay wallet with append-only ledger entries. No multiplayer,
WebSocket, matchmaking, presence, player-to-player transfer, subscription benefit, Coin→Commerce redemption,
City Discovery or GPS feature was introduced.

Unresolved business rules (notably Coin→JAM discount redemption) are documented and intentionally not
implemented. Unreachable prototype content is catalogued as blocked rather than faked.

---

## 2. Prototype feature inventory

`PHASE2_FEATURE_INVENTORY.md` (repository root) contains the full per-feature classification:
feature, prototype screen/behavior, Phase 1 status, missing backend/frontend work, dependencies,
Phase 2 scope and acceptance criteria, classified as complete / required / excluded / blocked.

Classification summary:

| Class | Features |
|---|---|
| Already complete (Phase 1) | Arena and Siege play, deck/cards, base & buildings, builder jobs, chest lifecycle, leagues, trophy integration, game shell |
| Implemented in Phase 2 | XP/levels/level-up rewards/history, daily + permanent missions, achievement catalog & unlocks, daily gift, extended profile & stats, leaderboard, friends & friendly battles, display-name search/settings, all Phase 2 screens |
| Explicitly excluded | Multiplayer, matchmaking, WebSockets/Channels, presence, player transfers, real-money resources, subscription benefits/entitlements, City Discovery/GPS, coin→commerce redemption |
| Blocked (documented, not faked) | `jd1`/`jd5` city-discovery missions, `jm-first`/`jm-three`/`jm-order` (no order-bound game event), badges `first`/`city10`/`local`, `th4` achievement (no approved dark-elixir source) |

---

## 3. Implementation coverage

### 3.1 Progression

- XP curve: `xp_to_next(level) = 120 + (level - 1) * 90` (prototype formula, unchanged).
- `grant_xp()` is the only XP mutator: applies XP, advances levels, creates one `LevelRecord` per level
  (`unique(profile, level)`), pays `LEVEL_UP_GEMS = 8` per level via `grant_rewards(reason="level_up")`,
  and returns the level-up payload for UI presentation.
- Pre-existing Phase 1 XP is recorded as `baseline=True, reward_gems=0` to avoid an invented retroactive payout.
- `progress_payload()` exposes level, XP, XP to next level, curve, level history, daily gift state and
  mission/achievement counters.

### 3.2 Missions

- Daily: `jd2` win an arena/siege battle, `jd3` claim the daily gift, `jd4` finish a friendly battle.
- Permanent: `jm-battle` (10 battles), `jm-build` (upgrade a building), `jm-friendly` (1 friendly battle),
  `jm-siege` (win a siege).
- `MissionProgress` unique on `(profile, mission_id, period)`; `period` is the player-local date for daily
  missions and `"permanent"` otherwise, so daily reset happens through the period key rather than destructive
  updates.
- Progress is recomputed from `GameEvent` rows under `select_for_update()`; the client can only ask for its
  own mission list or claim by `mission_id`. Progress and reward amounts are never client-supplied.
- Claims are idempotent: a claimed mission returns a conflict and cannot pay twice.

### 3.3 Achievements

- `win3` (3 ranked wins, 100 coins + 10 gems), `league` (reach Silver), `th4` (Town Hall 4, catalogued but
  unreachable).
- `AchievementUnlock` is unique per `(profile, achievement_id)`; `evaluate_achievements()` is called after
  battle settlement and after progression events, and pays the reward once.
- Unlocks and their rewards are included in the settlement/profile payload so the UI can present them.

### 3.4 Rewards

- Mission/achievement/level-up payouts reuse `grant_rewards()` and the append-only `LedgerEntry` table with
  new reasons `mission_reward` and `achievement_reward`.
- Every payout runs inside the same transaction as the state transition; duplicate events or repeated claim
  requests cannot duplicate resources.
- Chests, battle rewards and building costs from Phase 1 are unchanged.

### 3.5 Profile and statistics

`GET /api/games/profile/` (and the `/play` profile screen) now reports: display name (editable), level, XP,
trophies, best trophies, league, arena wins/losses, siege stats, friendly battles played, battles played,
mission counts (available/claimed), achievements unlocked/total, and card/building progression summaries.
All values are read from persisted rows; no derived client state.

### 3.6 Social

- `GameFriend(requester, addressee, status, requested_by)` with a unique pair constraint and self-request
  rejected.
- Search by display name only (case-insensitive, minimum length, capped results, authenticated users only,
  no phone/email exposed).
- Accept/reject/remove restricted to the addressee/participants; foreign rows return 404.
- `challenge` starts a friendly arena battle against an accepted friend: `Battle.friendly=True`,
  `FRIENDLY_BATTLE_XP = 15`, no trophy change, no chest, excluded from ranked arena statistics.
- Leaderboard returns display name, level and trophies ordered by trophies; no private fields.

### 3.7 Event tracking

`GameEvent(profile, kind, reference, amount, metadata)` is append-only with `unique(profile, kind, reference)`.
Emitted from settlement/services for: battle finished, battle won/lost, trophy change, XP earned, card
upgraded, building completed, chest claimed, friendly battle, daily gift. `record_event()` uses
`get_or_create`, so replayed or retried operations never double-count progress.

---

## 4. Backend changes

### Models and migration

`backend/games/migrations/0003_phase2_progression_missions_social.py` (additive):

- `LevelRecord` — unique `(profile, level)`, `xp_total`, `reward_gems`, `baseline`.
- `GameEvent` — unique `(profile, kind, reference)`, indexed for mission recomputation.
- `MissionProgress` — unique `(profile, mission_id, period)`, progress and claim timestamp.
- `AchievementUnlock` — unique `(profile, achievement_id)`.
- `GameFriend` — unique `(requester, addressee)`, status and initiator.
- `Battle.friendly` boolean; `GameProfile.friendly_played` counter; new ledger reasons.

`makemigrations --check --dry-run` reports no drift.

### Services and rules

`backend/games/rules.py`: `LEVEL_UP_GEMS`, `DAILY_GIFT_GEMS`, `DAILY_MISSIONS`, `PERMANENT_MISSIONS`,
`ACHIEVEMENTS`, `FRIENDLY_BATTLE_XP`, search/leaderboard/name limits, `mission_definition()`,
`missions_for_event()`, `achievement_definition()`.

`backend/games/services.py`: `grant_xp`, `grant_rewards`, `record_event`, `evaluate_achievements`,
`progress_payload`, `missions_payload`, `claim_mission`, `achievements_payload`, `daily_gift_payload`,
`claim_daily_gift`, `friends_payload`, `search_players`, `send_friend_request`, `respond_friend_request`,
`remove_friend`, `friend_challenge`, `leaderboard_payload`, `update_display_name`; battle settlement extended
with the friendly branch, event emission, level-up and achievement payloads; building completion emits an
event.

### Endpoints (`/api/games/`, all authenticated, owner-scoped)

`PATCH profile/`, `GET progress/`, `GET missions/`, `POST missions/claim/`, `GET achievements/`,
`GET daily-gift/`, `POST daily-gift/claim/`, `GET leaderboard/`, `GET friends/`, `GET friends/search/`,
`POST friends/request/`, `POST friends/respond/`, `POST friends/remove/`, `POST friends/challenge/`.

---

## 5. Frontend changes

- `frontend/app/play/page.tsx`: nine tabs (`آوردگاه`, `مأموریت`, `پیشرفت`, `دوستان`, `پروفایل`, `کارت‌ها`,
  `دسته`, `صندوق‌ها`, `پایگاه`), Phase 2 data loading, mutations, result notices (level-up, achievement,
  friendly battle), display-name save, and horizontal-scrolling tab strip on narrow screens.
- `frontend/app/play/Phase2Screens.tsx`: Missions (daily/permanent progress, claim, claimed state),
  Progress (level card, XP curve, level history, daily gift, badges), Profile (player card, statistics,
  arena/siege numbers, name editing), Friends (search, requests, list, challenge, remove), LevelUpNotice.
- `frontend/app/play/progression.ts`: pure helpers (XP formatting, curve, percentages, Persian number
  formatting) unit tested with Node's native test runner.
- `frontend/app/play/types.ts`: Phase 2 payload types.
- `frontend/app/play/jamplay.css`: Phase 2 card/section styles, mission layout, search field, scrollable nav.
- Every Phase 2 screen has loading, empty, error + retry, and success states; Persian RTL throughout; no mock
  data.

---

## 6. Rules delivered (summary)

| Rule | Value |
|---|---|
| XP to next level | `120 + (level - 1) * 90` |
| Level-up reward | 8 gems per level, one `LevelRecord` per level |
| Daily gift | `150 + 40 × town_hall` coins + 3 gems, once per local date |
| Friendly battle | 15 XP, no trophies, no chest, not in ranked stats |
| Daily missions | `jd2`, `jd3`, `jd4`, reset by local date |
| Permanent missions | `jm-battle`, `jm-build`, `jm-friendly`, `jm-siege` |
| Achievements | `win3`, `league`, `th4` (catalogued/unreachable) |
| Mission/achievement payouts | ledger reasons `mission_reward` / `achievement_reward` |

---

## 7. Security and ownership

- Every Phase 2 endpoint requires JWT authentication; all querysets are filtered by `request.user`.
- Mission progress, achievement conditions, XP, rewards and level-ups are computed server-side; no endpoint
  accepts client progress or reward values.
- Foreign friend/battle rows return 404, not 403 (no existence leak).
- Friend search never exposes phone/email; leaderboard exposes display name/level/trophies only.
- Resource mutations are atomic and idempotent: unique constraints on events, unlocks, mission periods and
  level records, plus `select_for_update()` on claim/settlement paths.
- No changes to authentication, OTP, JWT storage, admin authorization or Commerce.

---

## 8. Testing and actual results

Commands run in this Phase 2 work (all local; the repository has no CI history — the workflow file was added
but has never executed remotely because nothing was pushed):

| Check | Command | Result |
|---|---|---|
| Backend full suite (SQLite) | `python3 manage.py test --settings=config.test_settings` | `Ran 301 tests`, `OK (skipped=20)` — skips are the PostgreSQL-only concurrency tests |
| Backend full suite (PostgreSQL) | `TEST_DB_ENGINE=postgres python3 manage.py test --settings=config.test_settings` | `Ran 301 tests`, `OK` (0 skipped) — concurrency tests executed |
| Migration drift | `makemigrations --check --dry-run --settings=config.test_settings` | clean, no migrations created |
| TypeScript | `npx tsc --noEmit` | exit 0 |
| Lint | `npm run lint` | 0 errors, 42 warnings (mostly `<img>` advisories; no new rules disabled) |
| Frontend unit tests | `npm test` | 9 pass, 0 fail |
| Production build | `npm run build` | success; `/play` compiled |
| Live API journey | temporary local Django on `127.0.0.1:8011` + temp SQLite | 16/16 checks passed |

Phase 2 backend tests: `backend/games/test_phase2.py` (progression, level records, missions, duplicate claims,
achievements, daily gift, friends, leaderboard privacy, friendly battle), plus a real PostgreSQL concurrency
test for battle settlement in `games/tests.py` and a concurrent mission-claim test.

End-to-end API journey covered: profile bootstrap, display names, mission catalog, progress, achievement
catalog, daily gift once, mission claim once and duplicate/incomplete rejection, arena XP + trophies,
`win3` unlock, permanent claim, siege mission, friend search/request/accept, friendly battle (15 XP, no trophy
change, no chest), leaderboard privacy, persistence and ledger balance integrity.

Frontend unit tests: `frontend/tests/progression.test.ts` (curve, formatting, percentages, level-up detection,
mission grouping).

---

## 9. Visual QA

Performed in headless Chrome against the production build with the live API:

- Mobile 390×844: all nine tabs reachable via horizontal nav scroll; missions list, claim flow and
  "دریافت شد" state; progress, profile, friends screens; friendly battle screen showing opponent identity,
  `چالش دوستانه: کاپ و صندوق ندارد؛ فقط ۱۵ تجربه.` and exit back to the lobby.
- Desktop 1440×900: nine-tab horizontal nav, mission rows, friends/search and leaderboard layouts.
- Verified no horizontal page overflow (`scrollWidth == clientWidth`), `dir="rtl"` on all content, and no
  console errors or page exceptions during the flows.

One real defect was found and fixed during QA: the desktop nav inherited `flex-direction: column` from the
Phase 1 media query, stretching a single tab across the header; the Phase 2 override now forces a row. The
friend search input also lost its field chrome because it reused the `.field` wrapper class; it now has a
dedicated `.p2-search` style.

---

## 10. Changed files

Backend:

- `backend/games/models.py`
- `backend/games/rules.py`
- `backend/games/services.py`
- `backend/games/views.py`
- `backend/games/urls.py`
- `backend/games/tests.py`
- `backend/games/test_phase2.py` (new)
- `backend/games/migrations/0003_phase2_progression_missions_social.py` (new)

Frontend:

- `frontend/app/play/page.tsx`
- `frontend/app/play/Phase2Screens.tsx` (new)
- `frontend/app/play/progression.ts` (new)
- `frontend/app/play/types.ts`
- `frontend/app/play/jamplay.css`
- `frontend/tests/progression.test.ts` (new)
- `frontend/package.json`, `frontend/tsconfig.json`

Project:

- `PHASE2_FEATURE_INVENTORY.md` (new)
- `PHASE2_COMPLETE_REPORT.md` (new)
- `docs/jam play/JAMPLAY_ARCHITECTURE.md` (Phase 2 delivered-implementation section)
- `.github/workflows/ci.yml` (new)

No commit, push, deploy, release or production data change was performed.

---

## 11. Remaining technical limitations

- The added CI workflow has not run on GitHub (nothing was pushed); local commands remain the verified source.
- Visual QA used a local production build and temporary servers, not Staging.
- Docker is unavailable in this environment, so Compose stacks and image builds were not re-verified.
- Local tooling ran Python 3.14 / Django 5.1.4 while the project targets Python 3.12 / Django 5.2.18;
  PostgreSQL behavior was verified locally, but not on the exact production image.
- Lint warnings (42) are pre-existing-style advisories; none were suppressed or disabled.

---

## 12. Unresolved business decisions (not implemented)

- **Coin→JAM discount redemption**: conversion rate, caps, eligible products, stacking and expiry are
  unapproved. No redemption code exists and Commerce was not modified. The required contract is documented in
  `docs/jam play/JAMPLAY_ARCHITECTURE.md`.
- **City Discovery / GPS gameplay**: excluded from Phase 2; blocks `jd1`, `jd5`, the `city10`/`local` badges
  and any location-based mission.
- **Order-bound game events**: no approved game event exists for JAM orders, so `jm-order` and the `first`
  badge remain blocked.
- **Town Hall 4 achievement (`th4`)**: catalogued but unreachable because no approved dark-elixir/reward source
  exists.

---

## 13. Final status

All in-scope Phase 2 features are implemented, tested, and verified end to end with real persisted data.
Blocked prototype items are explicitly isolated and documented rather than fabricated.

`PHASE 2 COMPLETE`
