# Docker Build and Healthcheck Report

**Date:** 2026-11-08
**Status:** Images build, Compose starts, all services healthy, and readiness correctly follows database availability.
**Scope:** Isolated local Compose project. No production deployment, registry push, or external traffic.

## 1. Images built

| Image | Size | Notes |
|---|---:|---|
| `polaris-jam-backend:latest` | 819 MB | Python 3.12 slim, Gunicorn, non-root `app` user |
| `polaris-jam-frontend:latest` | 1.73 GB | Next.js 15.5.29 standalone-style production start, non-root `appuser` |
| `caddy:2.9-alpine` | pulled | TLS/HTTP reverse proxy |
| `postgres:16-alpine` | pulled | Database |
| `redis:7-alpine` | pulled | Cache/queue dependency |

The frontend image is large because the production stage installs production dependencies separately and copies the built `.next` output. It is functional for the pilot; image-size optimization is not part of this phase.

Build commands used:

```bash
docker compose -f docker-compose.prod.yml build backend
docker compose -f docker-compose.prod.yml build frontend
```

Both completed successfully after the final code changes, including the proxy header fix, serializer fix, and health-throttle fix.

## 2. Compose configuration

- Production topology: `docker-compose.prod.yml`.
- Local development topology: `docker-compose.yml`.
- Production config validation: `docker compose -f docker-compose.prod.yml config --quiet` exits `0`.
- Caddy owns host ports `80` and `443`.
- Backend and frontend use `expose` only; they are not published directly.
- PostgreSQL password is fail-closed in production: `${POSTGRES_PASSWORD:?...}`.
- Services use `restart: unless-stopped`.
- Caddy, backend, frontend, PostgreSQL, and Redis all define health checks.
- `backend/.dockerignore` and `frontend/.dockerignore` limit build context and exclude local artifacts/secrets.

## 3. Health checks

| Service | Probe | Expected |
|---|---|---|
| Caddy | `http://127.0.0.1:2019/config/` | Admin API loaded a valid config |
| Backend | `http://127.0.0.1:8000/api/health/ready/` | Process, PostgreSQL, and cache ready |
| Frontend | `http://127.0.0.1:3000/health` | Next.js process serving |
| PostgreSQL | `pg_isready` | Database accepting connections |
| Redis | `redis-cli ping` | Cache responding |

The backend has separate:

- `/api/health/live/`: process liveness, no dependencies.
- `/api/health/ready/`: PostgreSQL `SELECT 1` and cache set/readback. Returns `503` when either dependency is unavailable.

Health views disable API throttling. This was a real fix: the default anonymous limit is 100/hour, while a 10-second probe generates 360 requests/hour. Without the fix, the backend became falsely `unhealthy` after roughly ten minutes even though the service was fine. A regression test now performs 150 consecutive readiness requests.

## 4. Full-stack status observed

At the end of the isolated run:

```text
SERVICE    STATUS
backend    Up (healthy)
caddy      Up (healthy)
db         Up (healthy)
frontend   Up (healthy)
redis      Up (healthy)
```

Observed while the database was stopped:

```text
GET /api/health/ready -> 503
{"status":"not_ready","checks":{"database":"unavailable","cache":"ok"}}

backend container health -> unhealthy
```

After restarting the database:

```text
GET /api/health/ready -> 200
{"status":"ready","checks":{"database":"ok","cache":"ok"}}

backend container health -> healthy
```

This confirms the readiness probe reflects dependencies rather than only proving that Gunicorn is running.

## 5. Startup and migration behavior

The backend command is:

```text
python manage.py migrate --noinput
gunicorn config.wsgi:application --bind 0.0.0.0:8000 --workers 3 --timeout 60
```

Migrations run automatically on container start. This is acceptable for the pilot; a production release process should decide whether migrations run in a dedicated one-shot job instead. The current command is intentionally simple and was verified to reach a healthy state.

The frontend starts with `next start` and serves `/health` without authentication.

## 6. Isolation and cleanup

The validation used:

- Compose project `jam-foundation-test`.
- Override file outside the repository for test-only environment/ports.
- A temporary local Caddy configuration for internal TLS and the pilot hostname.
- Synthetic users, a synthetic plan, and synthetic businesses.
- No production database, no real customer data, and no external payment or Telegram calls.

After the evidence above was captured, the isolated Compose project, its test volumes, and the separate PostgreSQL test cluster were torn down. Its temporary files were removed; the production-named images remain available locally for inspection. Nothing was deployed, committed, or pushed.

## 7. Not tested / limitations

- Public registry push, image signing, and vulnerability scanning were not performed.
- Public DNS/ACME certificate issuance was not tested.
- Production orchestrator behavior (Kubernetes, systemd, cloud load balancer) was not tested.
- Backup/restore of production volumes was not executed.
- Real frontend browser interaction against authenticated APIs was not automated; see `OFFLINE_COMMERCE_PILOT_REPORT.md`.
