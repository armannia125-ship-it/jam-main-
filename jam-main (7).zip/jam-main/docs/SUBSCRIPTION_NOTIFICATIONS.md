# Subscription Expiration Notifications

Status: **Implemented + tested.** Five-day expiration notification per owner decision (no cancellation, no auto-renewal).

## 1. Behaviour

When an active `SubscriptionEntitlement` has **≤ 5 days** remaining (and is not expired/revoked), a user-visible notification is created:

* which entitlement (menu / club), product, business;
* expiration date (`ends_at`, ISO in payload, Persian date in UI);
* remaining days;
* a renewal entry point (`/subscriptions/checkout?product=…`).

**Deduplication:** unique `(entitlement, kind)` constraint — repeated runs never duplicate for the same entitlement cycle. A renewal creates a *new* entitlement row, which legitimately notifies again. A Gold purchase therefore produces two independent notifications (menu + club lifecycles).

## 2. The job

`python manage.py notify_expiring_entitlements` (`subscriptions/management/commands/notify_expiring_entitlements.py`) calls `run_expiration_notifications()` — idempotent, timezone-aware (`django.utils.timezone`, project TZ `Asia/Tehran`), no notifications for expired/revoked entitlements, indexed queries (`ends_at`, business/type/status).

Programmatic entry point: `subscriptions.management.commands.notify_expiring_entitlements.run_expiration_notifications() -> (created, skipped)`.

## 3. Scheduling (deployment requirement)

The project has **no Celery/beat** (Redis is cache-only). Schedule the command externally — exact required configuration:

Option A — cron on the backend host (daily 09:00 Asia/Tehran):
```
0 9 * * * cd /srv/jam/backend && docker compose exec -T backend python manage.py notify_expiring_entitlements >> /var/log/jam-notify.log 2>&1
```

Option B — add a lightweight `scheduler` service to `docker-compose.prod.yml` running the same command in a loop (e.g. `sh -c 'while true; do python manage.py notify_expiring_entitlements; sleep 86400; done'`). Both are safe: the command is idempotent.

**This scheduling wiring is a remaining production deployment step** (documented; not executable without the production host).

## 4. API

* `GET /api/subscriptions/notifications/?unread=1` — the user's notifications (ownership-scoped).
* `POST /api/subscriptions/notifications/` — mark all read.

## 5. Tests

`subscriptions/test_notifications.py`: exactly 5 days → notifies once; >5 days → no; <5 days first run → notifies; expired/revoked → no; repeated runs → no duplicates; Gold → two independent notifications; ownership; timezone window edges (5d+1s outside, 4d23h inside).
