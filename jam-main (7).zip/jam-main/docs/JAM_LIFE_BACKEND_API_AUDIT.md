# JAM Life Backend API Audit

## 1. Django Architecture Overview

### Project Structure
- **Django version**: Current latest compatible with project dependencies
- **Settings**: `backend/config/settings.py`
- **URL routing**: `backend/config/urls.py`
- **Apps**: `accounts`, `businesses`, `subscriptions`, `payments`, `cart`, `bot`
- **Database**: PostgreSQL (default), configurable via env vars
- **Language**: `fa-ir` (Persian), `USE_I18N = True`, `USE_TZ = True`
- **Time zone**: `Asia/Tehran`
- **Static files**: Whitenoise `WhiteNoiseMiddleware`
- **CORS**: `CORS_ALLOW_ALL_ORIGINS = DEBUG`, `CORS_ALLOWED_ORIGINS = ["http://localhost:3000"]`
- **CSRF**: `CSRF_TRUSTED_ORIGINS` from env

### Installed Applications
```
django.contrib.admin, django.contrib.auth, django.contrib.contenttypes,
django.contrib.sessions, django.contrib.messages, django.contrib.staticfiles,
corsheaders, rest_framework, rest_framework_simplejwt,
accounts, businesses, subscriptions, payments, cart, bot
```

### Middleware Order
1. `CorsMiddleware`
2. `SecurityMiddleware`
3. `WhitenoiseMiddleware`
4. `SessionMiddleware`
5. `CommonMiddleware`
6. `CsrfViewMiddleware`
7. `AuthenticationMiddleware`
8. `MessageMiddleware`
9. `XFrameOptionsMiddleware`

### Database Configuration
- **Engine**: `django.db.backends.postgresql`
- **Name**: `jam` (env: `POSTGRES_DB`)
- **User**: `jam` (env: `POSTGRES_USER`)
- **Password**: `jam-local-password` (env: `POSTGRES_PASSWORD`)
- **Host**: `localhost` (env: `POSTGRES_HOST`)
- **Port**: `5432` (env: `POSTGRES_PORT`)
- **Conn max age**: 60

### Authentication
- **User model**: `AUTH_USER_MODEL = "accounts.User"`
- **JWT**: `rest_framework_simplejwt` with 30min access, 7day refresh
- **Throttle**: `anon: 100/hour`, `user: 1000/hour`, `otp: 5/hour`
- **CORS**: Allow all in debug, localhost:3000 in production

### Models (Key ones)

#### `businesses.models.Business`
- `id`, `name` (160), `slug` (180, unique), `description` (Text, blank), `created_at`
- `owner` (FK to accounts.User, CASCADE, related_name="businesses")

#### `businesses.models.Menu`
- `id`, `title` (160 default "منوی اصلی"), `slug` (180, unique), `is_active` (Boolean, True), `created_at`
- `business` (FK to Business, CASCADE, related_name="menus")

#### `businesses.models.Category`
- `id`, `name` (120), `sort_order` (PositiveInteger, default 0), `menu` (FK to Menu, CASCADE, related_name="categories")
- **Ordering**: `["sort_order", "id"]`

#### `businesses.models.Product`
- `id`, `name` (160), `description` (Text, blank), `price_toman` (PositiveBigInteger), `is_available` (Boolean, True), `sort_order` (PositiveInteger, default 0), `created_at`
- `category` (FK to Category, CASCADE, related_name="products")
- `image` (ImageField, blank, null)

#### `subscriptions.models.Subscription`
- `id`, `business` (FK to Business, CASCADE, related_name="subscriptions")
- `status` (Choices: ACTIVE, INACTIVE; default ACTIVE)
- `starts_at` (DateTime, nullable), `ends_at` (DateTime, nullable)
- **Active check**: `starts_at <= now < ends_at`

#### `payments.models.Transaction`
- `id`, `amount_toman` (PositiveBigInteger), `gateway` (Char 32 default "zarinpal"), `status` (Choices: initiated/success/failed, default initiated), `authority` (Char 100, blank), `ref_id` (Char 100, blank), `gateway_payload` (JSON, blank, default dict), `created_at`, `updated_at`
- `subscription` (FK to Subscription, CASCADE, related_name="transactions")

#### `accounts.models.User` (custom)
- `name`, `phone` (extended from default User)

## 2. Models and Relationships

```
Account (1) -- (*) Business
Business (1) -- (*) Menu
Menu (1) -- (*) Category
Category (1) -- (*) Product
Business (1) -- (*) Subscription
Subscription (1) -- (*) Transaction
User (1) -- (*) Transaction (via gateway)
```

### Key Relationships
- **Business → Menu**: One-to-many (CASCADE), filtered by owner in queries
- **Menu → Category**: One-to-many (CASCADE), filtered by business owner
- **Category → Product**: One-to-many (CASCADE), filtered by category.menu.business.owner
- **Business → Subscription**: One-to-one (active check required for operations)
- **User → Business**: One-to-many (owner), all business queries scoped to owner
- **Product → Image**: Optional image field

### Manager Methods (custom)
- `_business_has_active_subscription(business)`: Checks subscription ACTIVE status with date range
- All view querysets filter by `request.user` ownership except public endpoints

## 3. Complete Relevant API Inventory

### Public Endpoints (AllowAny, no auth)

#### `GET /api/public/menu/<slug>/`
- **View**: `PublicMenuView`
- **Serializer**: `PublicMenuSerializer`
- **Permission**: `AllowAny`, `authentication_classes []`
- **Response**: 
  ```json
  {
    "title": "string",
    "slug": "string",
    "business": {"name": "string", "slug": "string", "description": "string", "logo": "url"},
    "categories": [
      {"id": int, "name": "string", "sort_order": int, "products": [{"id": int, "name": "string", "price_toman": int, "is_available": bool, "image": "url"}]}
    ]
  }
  ```
- **Query**: Only active menus with active subscription + active business owner
- **Prefetch**: `categories__products` (filtered `is_available=True`)
- **Use case**: QR code digital menu display

#### `GET /api/qr-code/<slug>/`
- **View**: `QrCodeView`
- **Response**:
  ```json
  {
    "menuTitle": "string",
    "publicUrl": "http://domain/m/{slug}/",
    "qrCode": "data:image/png;base64,{base64}"
  }
  ```
- **Generates QR** for menu public URL using `qrcode` library
- **Same access control** as PublicMenuView

### Seller/Authenticated Endpoints (JWT required)

#### `GET/POST /api/businesses/`
- **View**: `BusinessViewSet` (ModelViewSet)
- **Serializer**: `BusinessSerializer`
- **Permission**: `IsAuthenticated`
- **Queryset**: `Business.objects.filter(owner=self.request.user)`
- **Create**: `perform_create` sets `owner=request.user`
- **Update/create restrictions**: Requires active subscription for certain operations

#### `GET/POST /api/menus/`
- **View**: `MenuViewSet` (ModelViewSet)
- **Serializer**: `MenuSerializer`
- **Permission**: `IsAuthenticated`
- **Queryset**: `Menu.objects.filter(business__owner=self.request.user).select_related("business")`
- **Create**: Validates active subscription, sets `is_active` based on subscription status
- **Update**: Permission denied if publishing without active subscription
  > `"برای انتشار منو باید اشتراک فعال داشته باشید."`

#### `GET/POST /api/categories/`
- **View**: `CategoryViewSet` (ModelViewSet)
- **Serializer**: `CategorySerializer`
- **Permission**: `IsAuthenticated`
- **Queryset**: `Category.objects.filter(menu__business__owner=self.request.user).select_related("menu")`
- **Create**: Permission denied without active subscription
  > `"برای افزودن دسته‌بندی باید اشتراک فعال داشته باشید."`

#### `GET/POST /api/products/`
- **View**: `ProductViewSet` (ModelViewSet)
- **Serializer**: `ProductSerializer`
- **Permission**: `IsAuthenticated`
- **Queryset**: `Product.objects.filter(category__menu__business__owner=self.request.user).select_related("category")`
- **Create/update**: Permission denied without active subscription
  > `"برای افزودن محصول باید اشتراک فعال داشته باشید."`

#### `GET /api/seller-menu-preview/<slug>/`
- **View**: `SellerMenuPreviewView`
- **Permission**: `IsAuthenticated` (implied by `request.user`)
- **Response**: `PublicMenuSerializer` data for owner's menu
- **Use case**: Private seller preview of their own menu

### Cart API (likely in `cart/ app)

Not fully documented in available views, but based on:
- `cart` app with models and serializers
- LocalStorage state management in frontend (`jam.state.v1`)
- Cart operations: add, remove, qty update, totals calculation

### Accounts API (likely)

- OTP-based authentication
- Profile management (name, phone)
- Address management

### Subscriptions API

- Plan management
- Activation code handling
- Status tracking

## 4. Authentication and Authorization

### JWT Authentication
- **Default**: `rest_framework_simplejwt.authentication.JWTAuthentication`
- **Header**: `Authorization: Bearer {token}`
- **Token lifecycle**: 30min access, 7day refresh, rotate refresh
- **Header types**: `Bearer`

### Permission Classes
- **Default DRF**: `IsAuthenticated` for most endpoints
- **Public endpoints**: `AllowAny` with empty authentication classes
- **Seller-scoped**: `request.user` ownership checked in `get_queryset`

### Authentication Flow
1. User obtains JWT token (via OTP or credentials)
2. Token sent in `Authorization: Bearer` header
3. Views filter queryset by `request.user`
4. Public endpoints bypass auth (for menu/QR display)
5. Failed auth → 401/403 response

### Role-Based Access
- **Customer**: Browse products, view menus, use QR codes
- **Seller/Business owner**: Full CRUD on their business/menu/products
- **Requires active subscription** for most seller operations

## 5. Request and Response Contracts

### PublicMenuView Response
```json
{
  "title": "string",
  "slug": "string",
  "business": {
    "name": "string",
    "slug": "string",
    "description": "string",
    "logo": "url"
  },
  "categories": [
    {
      "id": int,
      "name": "string",
      "sort_order": int,
      "products": [
        {
          "id": int,
          "name": "string",
          "description": "string",
          "price_toman": int,
          "is_available": bool,
          "image": "url"
        }
      ]
    }
  ]
}
```

### QrCodeView Response
```json
{
  "menuTitle": "string",
  "publicUrl": "http://localhost:8000/m/{slug}/",
  "qrCode": "data:image/png;base64,{base64_png}"
}
```

### Business CRUD Response (BusinessSerializer)
```json
{
  "id": int,
  "owner": int (user pk),
  "name": "string",
  "slug": "string",
  "description": "string",
  "logo": "url (or null)"
}
```

### Product Response (PublicProductSerializer)
```json
{
  "id": int,
  "name": "string",
  "description": "string",
  "price_toman": int,
  "sort_order": int,
  "image": "url"
}
```

### Error Responses
- **403 PermissionDenied**: `"برای انتشار منو باید اشتراک فعال داشته باشید."`
- **404 Not Found**: `"منو پیدا نشد."` or `"Menu not found or unpublished."`
- **400**: Validation errors from serializers

## 5. Error Handling

### HTTP Status Codes
- **200**: Successful GET, POST (confirmation)
- **201**: Created (POST with resource)
- **400**: Bad request, validation failures
- **401**: Authentication credentials missing/invalid
- **403**: Permission denied (subscription required, ownership mismatch)
- **404**: Resource not found
- **429**: Rate throttled (anon/user rates)

### Throttling
- **Anonymous**: `100/hour`
- **User**: `1000/hour`
- **OTP**: `5/hour`

### Error Format
DRF default format with `detail` key for most errors. Validation errors include field-specific error messages.

## 6. File Upload and Image Handling

### Product Image
- **Field**: `ImageField` in Product model
- **Required**: False, `allow_null=True`
- **Upload path**: Default (MEDIA_ROOT)
- **Validation**: Not explicitly defined in model; handled by DRF serializer

### Image URL
- Accessible via `product.image.url` if uploaded
- `PublicProductSerializer` includes `image` field
- Business logo similarly handled

### CORS for Media
- `STATIC_URL = "static/"`, `STATIC_ROOT = BASE_DIR / "staticfiles"`
- Media handling not explicitly configured in settings (would need `MEDIA_URL`/`MEDIA_ROOT`)

## 7. Missing or Incomplete API Capabilities

### Identified Gaps
1. **Cart API endpoints**: No dedicated ViewSets or API views found for cart operations in the backend. Cart state managed via localStorage in frontend (`jam.state.v1`). Need to verify if cart API exists in `cart/ app` or if it's purely frontend-managed.

2. **Order placement API**: No visible order creation endpoint. Order tracking exists as a view/page but no `POST /api/orders/` endpoint identified.

3. **User authentication API**: No `POST /api/auth/login/` or `POST /api/auth/otp/` found in businesses views. Relies on `rest_framework_simplejwt` with assumed OTP flow from `accounts` app.

4. **Payment completion webhook**: ZarinPal callback endpoint configured (`ZARINPAL_CALLBACK_URL`) but `payments/views.py` only shows `ZarinPalCallbackView` - need to verify if this is the complete flow.

5. **User address management**: `addrs` field in GlobalState but no corresponding API endpoints visible.

6. **Discount code validation**: `CODES` enum in frontend (`JAM10`, `PICKUP5`) but no backend validation endpoint found.

7. **Subscription management API**: No endpoints for plan purchase, renewal, or cancellation visible beyond subscription status checks in view `perform_create`.

8. **Search API**: No dedicated search endpoint. Frontend search is client-side (hash-based routing with query params).

9. **Pagination**: No explicit pagination configuration beyond default DRF throttle rates. Would need to verify page size for product lists, order histories.

10. **File upload validation**: No explicit image type/size validation in models or serializers beyond `ImageField(blank=True, allow_null=True)`.

## 8. Security and Integration Considerations

### CORS Configuration
- `CORS_ALLOW_ALL_ORIGINS = DEBUG` (open in dev, restricted in prod)
- `CORS_ALLOWED_ORIGINS = ["http://localhost:3000"]` (frontend dev server)
- Missing: Production domain origins would need addition

### CSRF
- `CSRF_TRUSTED_ORIGINS` from env var
- Default configured for localhost development

### JWT Security
- 30min access token lifetime
- 7day refresh token with rotation
- `AUTH_HEADER_TYPES: ("Bearer",)`

### Data Validation
- Model-level constraints: `unique=True` on slugs, `PositiveInteger`/`PositiveBigInteger` for prices
- Serializer-level: `read_only_fields` for `id`, `owner`, `created_at`
- Business ownership filtering in all view `get_queryset` methods

### Subscription Guard
- Critical business rule: Most seller operations (create menu, category, product) require `_business_has_active_subscription()`
- Permission denied with clear message if subscription inactive
- Prevents unauthorized modifications

### Rate Limiting
- Separate anon/user/otp thresholds
- Default DRF throttle classes configured

### HTTPS Recommendation
- `ZARINPAL_SANDBOX` default True for development
- Callback URL default `http://localhost:8000/api/payments/zarinpal/callback/`
- Production would need HTTPS and real merchant ID