# Deployment Foundation — Stage 0 Baseline

Date: 2026-11-08
Repository: `/Users/erfmollaey/projects/polaris-jam`
Branch: `main` at `5985bcd` (`frontend final refactor`)
Git tags: none
Working tree: dirty before this phase; **no existing work was discarded**

## 1. Canonical documentation read/verified

Read and cross-checked against source:

- `README.md`
- `docs/JAM_LIFE_BACKEND_API_AUDIT.md`
- `docs/JAM_LIFE_FRONTEND_*`, `docs/JAM_LIFE_UI_AUDIT.md`
- All nine previous production-readiness reports
- `.env.example`, Dockerfiles, all three Compose files
- Subscription, activation-code, bot, payment, business and commerce source

No `AGENTS.md`, `CLAUDE.md` or `CONTRIBUTING.md` exists inside this repository.

## 2. Git baseline

```text
branch: main
HEAD:   5985bcd frontend final refactor
tags:   none
modified: 44 files
untracked: 23 paths
```

Existing modifications include the prior phase's catalog/commerce integration, security settings, PWA changes and audit documents. They are preserved.

## 3. Initial command results (before changes)

| Check | Command | Result |
|---|---|---|
| Backend tests (SQLite) | `python3 manage.py test --settings=config.test_settings` | **151 tests, OK, 10 skipped** |
| Django checks | `python3 manage.py check --settings=config.test_settings` | **No issues** |
| Migration drift | `makemigrations --check --dry-run` | **No changes** |
| TypeScript | `npx tsc --noEmit` | **exit 0** |
| Production build | `npm run build` | **exit 0** |
| Compose parse | `docker compose -f docker-compose.prod.yml config` | **exit 0** |
| ESLint direct | `npx eslint .` | **exit 2 — no `eslint.config.*`** |
| ESLint script | `npm run lint` (`next lint`) | **exit 1 — interactive/deprecated Next lint path** |
| Docker daemon | `docker info` | **exit 1 — daemon unavailable** |
| PostgreSQL concurrency | isolated cluster not running at baseline | **not run in this stage; prior phase used a temporary cluster** |

Docker Compose parsing passing is not Docker runtime validation. No image build or container startup passed.

## 4. Actual subscription architecture found

There are two separate membership systems:

### A. `subscriptions` app — menu subscription

- `SubscriptionPlan`: name, description, duration_days, price_toman, is_active.
- `Subscription`: business, plan, pending/payment_confirmed/active/expired/cancelled, starts/ends, confirmed_by/at.
- `ActivationCode`: subscription-bound plaintext code, expiry, redeem metadata, Telegram delivery fields.
- `/api/subscriptions/plans/` exposes **all** active plans.
- `/api/subscriptions/redeem/` exists and checks business ownership.
- Django admin can confirm payment and issue/send codes.
- Menu publishing and public menu/QR access require a current active subscription.
- Checkout still uses legacy ZarinPal code. It is not the required manual workflow.

### B. `commerce` app — club membership

- `ClubMembership`: one per business, includes `TRIAL`, free trial timestamps, paid membership timestamps.
- `/api/commerce/businesses/<id>/club/trial/` starts a **free trial**.
- Simulated invoice payment can activate membership for 30 days and is exposed in the panel UI.
- Club invoices and monthly fee (`StoreConfig.monthly_fee_toman`) are a second paid offer.

### Conflict

The owner's decision is one plan, no free plan, no trial, and all payments manual. The club trial and simulated invoice activation directly contradict that decision. The canonical customer-facing subscription must therefore be the `subscriptions` plan, with the club treated as legacy/backward-compatible data rather than a second sellable plan. This is a **requires owner confirmation** item, but the safe implementation direction is explicit: disable trial and simulated subscription activation, expose only the canonical subscription offer, and preserve old rows.

## 5. Activation-code security findings

Verified in source:

- Codes are generated with `secrets.choice`, 16 characters, 32-symbol alphabet. Good entropy.
- **Plaintext codes are stored in the database** (`ActivationCode.code`). This violates the required hash-only storage.
- Code lookup is by plaintext; admin displays plaintext.
- Issuance is nominally idempotent but the `select_for_update()` runs without a surrounding transaction at call sites, so concurrent issuance is racy.
- Redemption locks the code row but **not the subscription row**; two different codes for the same confirmed subscription can race.
- No revocation field/operation.
- Expiry is fixed at 24 hours, not configurable.
- No audit event model.
- No bot HTTP/API boundary. The only issuance path is a Django admin action coupled to Telegram.
- `run_telegram_bot.py` imports `ActivationCode` from `bot.models` (it does not exist), so `/redeem` is broken.
- The bot has no server-to-server credential for code issuance.
- Customer binding is indirect via `subscription.business.owner`, which is valid but must be enforced atomically on redemption.
- There is no request/manual-payment endpoint; a pending subscription can currently only be created by the legacy online checkout.

## 6. Single-plan and free/trial findings

- Multiple active `SubscriptionPlan` rows are allowed and all are returned publicly.
- No customer-facing UI calls the `subscriptions` API; the panel plan page is wired only to the club system.
- `CLUB_TRIAL_DAYS=14` and `start_trial()` are active.
- `COMMERCE_ALLOW_SIMULATED_PAYMENTS` defaults to `DEBUG`; panel UI exposes a “پرداخت آزمایشی” button.
- No price/duration is established in documentation for the canonical plan. A plan row must exist in production; inventing a price is prohibited.
- No renewal rule is defined (extend from current expiry vs. start from payment date). Must be documented, not guessed.

## 7. Deployment findings

- No TLS reverse proxy exists.
- `docker-compose.prod.yml` publishes backend `8000` and frontend `3000` directly, with no proxy.
- Backend image runs as root.
- Backend and frontend have no HTTP health checks.
- Backend has no health endpoint.
- Compose has no restart policies.
- Database password falls back to a local default.
- Docker daemon unavailable; Podman and Docker Desktop are installed but no daemon is currently running.
- Local tools available: `openssl`, `mkcert`; no local `caddy` or `nginx` binary.

## 8. ESLint findings

- `frontend/package.json` has ESLint 9 and `eslint-plugin-react`, but no flat config and no `eslint-config-next`.
- Script still calls deprecated `next lint`, which prompts interactively with no config.
- Next 15.5.29 / React 19.3.1 are installed; the config must match these versions.

## 9. Scope decision for this phase

1. Use `subscriptions.SubscriptionPlan` / `Subscription` as the only customer-facing subscription.
2. Keep club tables and existing rows; disable trial and simulated subscription activation rather than deleting data.
3. Do not invent plan price/duration or bank details. They come from an existing active plan row and environment-supplied manual instructions.
4. Keep legacy ZarinPal code isolated and disabled for subscription purchase; no live calls.
5. Preserve design and existing panel shell; integrate activation into `/panel/plan`.
6. Document renewal as an unresolved business rule; implement no arbitrary extension rule.

## 10. Baseline conclusion

The application's core HTTP flows and tests were green before this phase. The blocking gaps are specifically the insecure/racy activation-code implementation, absent manual request/bot boundary/UI, contradictory trial/simulation behavior, missing TLS/health layer, and missing ESLint configuration. Implementation may proceed.
