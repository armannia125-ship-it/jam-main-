# Admin Role & RBAC

Status: **Implemented** — single authentication system, server-authoritative roles.

## 1. Role model

* `accounts.User.role` ∈ `user` | `admin` (app-level platform role, indexed).
* The role is **always read from the authenticated server-side user row** (`user.is_admin` property). A role supplied by any client payload is never trusted.
* DRF permission class `accounts.permissions.IsAdmin` guards every admin endpoint (403 with a Persian message otherwise).
* `is_staff`/`is_superuser` remain Django-admin concerns and are unchanged.

## 2. Authentication

One login system for everyone: the existing OTP flow (`otpy` provider, unchanged) issues JWTs; `POST /api/auth/verify-otp/` now includes `role` in the user payload and `GET /api/auth/me/` returns the authoritative role for the frontend. There is **no** separate admin login. The OTPy integration, providers, and dependencies are untouched.

## 3. Initial admin provisioning

```
python manage.py make_admin --phone +989xxxxxxxxx            # promote
python manage.py make_admin --phone +989xxxxxxxxx --demote   # demote
```

* Promotes an **existing registered user only** — never creates accounts, never touches passwords.
* Idempotent; refuses inactive users; refuses to demote the **last active admin**; audits every change (`AdminAction`).
* No public admin-registration endpoint exists.

## 4. Admin management rules (enforced server-side)

* Promotion/demotion: `POST /api/admin/users/<id>/role/promote|demote/`.
* Self-demotion is blocked (409); demoting the last active admin is blocked (409).
* Targets must exist; inactive users cannot be promoted.
* Every role change writes an `accounts.AdminAction` audit row (actor, action, target, timestamp, safe metadata — no secrets).

## 5. Admin API surface (all `IsAdmin`)

| Endpoint | Purpose |
|---|---|
| `GET /api/admin/overview/` | Real aggregate dashboard (users, active entitlements, legacy counts labelled میراث, pending vs confirmed payments, confirmed revenue in Toman, recent purchases/actions) |
| `GET /api/admin/users/?q=&limit=` | User list/search |
| `GET /api/admin/users/<id>/` | User detail: businesses, entitlements, purchases, payments (passwords/OTP never exposed) |
| `GET /api/admin/payments/?status=&q=&limit=` | Payment list from authoritative backend data — **no manual confirmation exists** |
| `GET /api/admin/subscriptions/?type=&status=&limit=` | Entitlements + product matrix + legacy count |
| `POST /api/admin/entitlements/<id>/revoke/` {reason} | Explicit, audited revocation of ONE entitlement |
| `POST /api/admin/purchases/<id>/mark-failed/` | Operational correction for abandoned pending purchases (audited; PAID purchases protected) |
| `GET /api/admin/audit/?action=&limit=` | Audit log |

## 6. Frontend

`/admin` (dashboard, users, payments, subscriptions, admins, audit) shares `components/features/admin-shell.tsx`, which resolves the role via `GET /api/auth/me/` and renders an honest permission-denied state for non-admins. Client checks are cosmetic; the backend enforces everything.

## 7. Test coverage

`accounts/test_admin_api.py`: provisioning (promote-only-existing, idempotency, last-admin protection, audit), RBAC denials (normal/anonymous on every endpoint, privilege-escalation attempts), real-data dashboard integrity, audited revocation, mark-failed guards.
