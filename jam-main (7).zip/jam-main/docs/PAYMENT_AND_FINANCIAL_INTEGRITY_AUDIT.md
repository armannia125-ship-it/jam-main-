# JAM — Payment and Financial Integrity Audit

Date: 2026-11-08
Scope: subscription/ZarinPal integration, commerce orders, commission, settlement, simulated payments.
Method: source inspection plus isolated automated tests. No real provider was contacted and no real money was moved.

## 1. Executive finding

Customer order payment is **not implemented**. The only provider-backed payment flow is the seller subscription checkout (ZarinPal). `commerce.Order` has payment state, commission and settlement records, but no order-bound `Transaction`, no initiation endpoint and no provider callback that can verify an order.

This is intentionally gated: `COMMERCE_ORDER_ONLINE_PAYMENTS_ENABLED` defaults to `false`; online order creation returns HTTP 503 `online_payment_unavailable`. Offline order checkout works and is clearly presented as pay-in-store/delivery.

**Status: order payment is BLOCKED by an unimplemented provider flow. Subscription payment verification is implemented and test-covered, but not live-tested.**

## 2. Payment initiation

| Check | Result | Evidence |
|---|---|---|
| Amount calculated server-side | Pass for subscriptions | `CheckoutView` uses `plan.price_toman`; client cannot submit an amount |
| Transaction bound to an order | Fail for orders | `payments.Transaction` has only `subscription` FK; no `order` FK |
| Payment request uniquely identifiable | Improved | `authority` is now unique when non-empty (`payments/migrations/0002`), so one provider authority cannot be attached to two transactions |
| Invalid/expired order can be paid | Not applicable | No order payment initiation exists |
| Repeated initiation prevented | Partial | Each checkout creates a new subscription + transaction; there is no checkout idempotency key. Repeated clicks create separate pending subscriptions, not duplicate charges for the same transaction |
| Provider credentials missing | Handled | Checkout returns 503 before creating a provider request if `ZARINPAL_MERCHANT_ID` is absent |

## 3. Payment verification

`payments/views.py::ZarinPalCallbackView`:

- Verification is server-side; the browser redirect is not trusted.
- The provider verification API is called with the stored `authority` and the server-stored amount (converted Toman → Rial).
- `Status` must be `OK` before verification.
- The transaction row is locked with `select_for_update`.
- Already-successful callbacks return HTTP 200 without repeating financial effects.
- Provider codes `100` and `101` are accepted; `101` covers an already-verified provider payment.
- Provider reference ID and sanitized payload are stored on success.
- A transport/provider failure returns 502 and leaves the transaction `initiated`, allowing a safe retry.
- A cancelled/failed redirect marks `failed`.
- Successful subscription payment only sets `PAYMENT_CONFIRMED`; it does **not** activate the subscription. Activation requires an administrative code, by design.

| Check | Result |
|---|---|
| Client can fake a successful redirect | No; only provider verification promotes state |
| Double verification creates duplicate effects | No; row lock + success short-circuit + provider idempotency code `101` |
| Provider unavailable | 502, retryable, no state promotion |
| Ambiguous response | Treated as failure/exception, no promotion |
| Failed/cancelled payment handled | Marks `failed`, no activation |

Live provider behavior and the actual merchant account were **not tested** because test credentials were not available. This remains an external prerequisite.

## 4. Order/payment consistency

- There is no code path that marks an order paid from a redirect or client field.
- `mark_order_paid` is only reachable through the seller-only simulation endpoint, and only when `COMMERCE_ALLOW_SIMULATED_PAYMENTS` is enabled.
- The simulation endpoint is disabled by default in production (`COMMERCE_ALLOW_SIMULATED_PAYMENTS` defaults to `DEBUG`).
- `mark_order_paid` locks the order, is idempotent, and only accepts online orders.
- A payment cannot currently be associated with an order because the model has no order relation.
- Order and payment updates are not combined in one transaction for orders because no payment flow exists.

**Conclusion:** an order cannot be marked paid without an explicit seller simulation; no provider-confirmed order payment exists.

## 5. Commission and settlement

Verified by `backend/commerce/tests.py::OrderFinanceTests` and the full suite:

- Commission basis is goods only; delivery is excluded (`commission_base_toman` = goods, not total).
- Commission rate is snapshotted at order creation and again locked when the order is completed/paid.
- Historical orders do not change when `StoreConfig.commission_rate` changes.
- Offline orders never create commission.
- Settlement requires provider verification of the settlement account and seller agreement acceptance before `ELIGIBLE`.
- No payout provider is connected; `SettlementView` returns `real_settlement_available: false`.
- A settlement is never marked paid by this system.
- Cancelled/rejected orders move settlement to `FAILED`; refunded orders create reversal records and move to `REVERSED`.
- Only a delivered, paid order can be manually reversed.

## 6. Simulated payments and production safety

- `COMMERCE_ALLOW_SIMULATED_PAYMENTS` defaults to `DEBUG`, so production is false unless explicitly enabled.
- ZarinPal sandbox now defaults to `not DEBUG`; production defaults to the live endpoint rather than silently using sandbox.
- `.env.example` sets simulated payments false and online order payments false.
- Both gates were verified in tests (online order gate 503) and by source inspection of the simulation endpoints.

## 7. Critical blockers / owner decisions

| Severity | Component | Blocker | Resolution |
|---|---|---|---|
| Critical | Customer order payment | No order-bound transaction, initiation or callback | Implement a separate order payment model/flow with server-side amount binding and verified callback, then enable `COMMERCE_ORDER_ONLINE_PAYMENTS_ENABLED` after review |
| High | Live provider verification | No ZarinPal merchant/test credentials were used | Owner must provide sandbox merchant credentials and approve a sandbox transaction test |
| High | Settlement payouts | No payout provider/reconciliation | Owner must choose a payout provider and reconciliation process |
| Medium | Subscription checkout idempotency | Repeated checkout creates multiple pending subscriptions | Add a checkout idempotency key if the business wants to prevent abandoned duplicate intents |
| Medium | Refund reconciliation | Reversals are internal records only | Define provider refund procedure and reconciliation |

## 8. Verification commands

```bash
cd backend
python3 manage.py test --settings=config.test_settings          # 151 tests, OK (10 PostgreSQL-only skipped)
PGTEST_PORT=55432 python3 manage.py test --settings=config.concurrency_settings  # 151 tests, OK
python3 manage.py makemigrations --check --dry-run --settings=config.test_settings  # No changes
```

No real provider call was made. No production secrets were read or written. No payment was simulated as a real success.
