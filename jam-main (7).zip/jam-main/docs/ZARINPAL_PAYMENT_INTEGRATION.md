# Zarinpal Payment Integration Guide

Status: **Infrastructure implemented; live connection NOT tested** (no merchant credentials authorized yet).

## 1. What exists

* Provider abstraction: `payments/gateways/base.py` (`PaymentGateway` ABC — amounts denominated in **integer Toman** at the domain level).
* Zarinpal adapter: `payments/gateways/zarinpal.py` (v4 JSON API). The **only** unit conversion (Toman → Rial, ×10) happens inside the adapter for `payment/request.json` and `payment/verify.json`, asserted by `payments/tests.py::test_toman_converted_to_rial`.
* Verification-only-trusts-provider: the callback never treats the request itself as proof of payment.

## 2. Configuration (env vars — names only; never commit values)

| Variable | Meaning | Safe default behaviour |
|---|---|---|
| `ZARINPAL_MERCHANT_ID` | Merchant GUID | **Empty = provider unconfigured** → purchase initiation returns `503 payment_provider_unconfigured` and creates nothing |
| `ZARINPAL_SANDBOX` | `true` → sandbox endpoints | Defaults to `not DEBUG` |
| `ZARINPAL_CALLBACK_URL` | Gateway callback URL | `http://localhost:8000/api/payments/zarinpal/callback/` |

Endpoints used (per the existing verified adapter): `{api_base}/payment/request.json`, `{api_base}/payment/verify.json`; success codes `100` (new) and `101` (already verified).

## 3. Purchase lifecycle (state machine)

```
SubscriptionPurchase: pending ──verify OK──▶ paid
                        │                      (entitlements activate atomically)
                        ├──Status=NOK──▶ failed
                        └──verify error─▶ stays pending (retry safe)
Transaction:           initiated ──▶ success | failed
```

* **Idempotency:** duplicate/concurrent callbacks are serialized with `select_for_update`; an already-`success` transaction short-circuits; the unique `(purchase, entitlement_type)` constraint prevents duplicate entitlements (proven by `subscriptions/test_payment_concurrency.py` on PostgreSQL).
* **Replayed callbacks** return 200 without side effects.
* **Provider transport failure** leaves the transaction `initiated` — the purchase can be retried; nothing is activated for unverified payments.

## 4. What is NOT done (requires owner/credentials)

* Live Zarinpal request/verify against a real merchant account (never tested; no credentials authorized).
* Sandbox account validation (callback shape, merchant panel behaviour).
* Refund flows through the provider (out of scope by owner decision).
* Customer **order** payments remain separate and disabled (`COMMERCE_ORDER_ONLINE_PAYMENTS_ENABLED=false`); the subscription-payment infrastructure intentionally does not touch that flow.

## 5. Enabling live payments (operational checklist)

1. Set `ZARINPAL_MERCHANT_ID` (and `ZARINPAL_CALLBACK_URL` to the public HTTPS callback) in the production environment.
2. Confirm sandbox behaviour with a test merchant first.
3. Verify the callback is reachable (Caddy routes `/api/` to backend).
4. Reconcile the first real transaction against the merchant panel before announcing the flow.
5. The app fails safely (503) when misconfigured — a payment can never silently succeed.
