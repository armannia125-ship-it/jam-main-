# JAM — Final Regression Report

Date: 2026-11-08
Repository: `/Users/erfmollaey/projects/polaris-jam`, branch `main`, commit `5985bcd` (no new commit made).
Environment: macOS, Python 3.14, Node 24, Chrome installed, Docker daemon unavailable, local PostgreSQL 18.4 available via a temporary isolated cluster.

## 1. Backend

| Check | Command | Result |
|---|---|---|
| Full backend suite (SQLite) | `python3 manage.py test --settings=config.test_settings` | **151 tests, OK, 10 skipped** (PostgreSQL-only) |
| Full backend suite (PostgreSQL) | `PGTEST_PORT=55432 python3 manage.py test --settings=config.concurrency_settings` | **151 tests, OK** |
| Concurrency module only | `python3 manage.py test commerce.test_concurrency --settings=config.concurrency_settings` | **10 tests, OK** |
| Accounts/OTP/refresh | `python3 manage.py test accounts --settings=config.test_settings` | **58 tests, OK** |
| System checks | `python3 manage.py check --settings=config.test_settings` | **No issues** |
| Migration drift | `python3 manage.py makemigrations --check --dry-run --settings=config.test_settings` | **No changes detected** |
| Production deploy checks | `python3 manage.py check --deploy` with production env | **4 warnings without TLS env; 1 optional HSTS-preload warning with TLS env; 0 errors** |

New backend coverage this phase:

- quote aggregation of duplicate product lines;
- customer-scoped idempotency (cross-customer key isolation);
- malicious client price ignored / server totals;
- online-order 503 gate;
- refresh token valid/invalid;
- 10 PostgreSQL concurrency tests;
- unique non-empty payment authority migration.

Test count progression: 132 baseline → 137 commerce/API → 139 (duplicate-line fix) → 149 (concurrency module) → 151 (refresh tests). The current total is 151 on both SQLite (10 skipped) and PostgreSQL (all executed).

## 2. Frontend

| Check | Command | Result |
|---|---|---|
| TypeScript | `npx tsc --noEmit` | **exit 0, no errors** |
| Production build | `npm run build` | **exit 0, build completed** |
| Lint | `npm run lint` | **Blocked** — no ESLint configuration; command prompts interactively and cannot run non-interactively |
| Component/unit tests | — | **None configured in the repository** |
| E2E framework | — | No project Playwright/Puppeteer dependency; temporary external harness used |

Build was run after all frontend source changes, including `sw.js` and the auth/refresh client route consumption. No design, CSS or layout changes were made.

## 3. End-to-end smoke (production build + isolated backend)

Stack: Django smoke settings on 8000 with a temporary SQLite DB, Next production server on 3100, `NEXT_PUBLIC_DEMO_MODE` unset/false.

| Step | Expected | Observed |
|---|---|---|
| Public home | Real seeded store, no demo | 200, «کافه آزمون», no demo stores |
| Public store directory | Backend JSON | 200, 1 store, 2 products, delivery 50000 |
| Public menu SSR | Backend names/prices | 200, product and 98,000/50,000 rendered |
| Demo `/m/nakhl` | 404 | 404 |
| Demo `/store/s1` | 404 | 404 |
| Quote | Server totals, duplicate lines merged | 200, one line qty 3, subtotal 294,000 |
| Offline order create | 201, server totals | 201, total 246,000 (price tampering ignored) |
| Idempotent replay | Same order, created=false | 200, same number |
| Same key, different customer | Separate order, no leak | 201, different order |
| Customer orders/mine | Own order only | 200 |
| Stranger reads customer order | Denied | 404 |
| Unauthenticated private API | Denied | 401 |
| Customer/stranger seller endpoint | Denied | 404 |
| Owner seller endpoint | Allowed | 200 |
| Seller status transitions | accepted → preparing → ready | 200 each; customer sees `ready` |
| Owner revenue/metrics/settlement/purchases | Allowed | 200 each |
| Online order | Feature-gated | 503 `online_payment_unavailable` |
| Invalid refresh | Rejected, route exists | 401 (previously 404) |
| API-down production home | Error state, no demo data | 200 error page, no demo store names, proxy 502 |

Not exercised: real browser checkout click-through with a logged-in customer, real seller panel UI actions, live OTP login, provider payment.

## 4. PWA runtime

Temporary Playwright 1.65.0 + installed Chrome, against the final production build:

- **22/22 matrix checks passed** (SW activation, public menu/API/media caching, offline menu, private API/panel/login offline behavior, demo 404 not cached, manifest/icons, cache cleanup, no private API cache).
- **3/3 persistence checks passed** (browser close/reopen offline, network recovery, first online visit).
- Live service-worker version bump and installation prompt were not tested.

See `PWA_RUNTIME_VALIDATION.md`.

## 5. Authorization and auth refresh

- Object-level authorization matrix passed via direct API requests (see smoke table).
- Compiled-client refresh harness: 3/3 passed (single-flight, failed refresh clears/no loop, anonymous no refresh).
- Backend refresh endpoint: valid 200 + usable access; invalid 401.
- Token storage remains localStorage; no browser multi-tab refresh test.

## 6. What failed or is blocked

| Item | Status | Reason |
|---|---|---|
| Live ZarinPal verification | **Blocked** | No merchant/test credentials; no real provider contact was authorized |
| Customer online order payment | **Blocked by design** | No order-bound provider flow; feature flag remains false |
| Docker build/up/health checks | **Blocked** | Docker daemon unavailable |
| ESLint | **Blocked** | No config; interactive prompt |
| Frontend unit/component tests | **Not available** | None configured |
| Full seller/customer UI click-through | **Not tested** | API and SSR smoke only; no stable authenticated browser fixture |
| Service-worker live update rollout | **Not tested** | Activation cleanup tested by reinstall |
| Load/soak PostgreSQL testing | **Not tested** | Short 2–8 thread contention bursts only |

## 7. Known warnings

- `manage.py check --deploy` without TLS flags reports HSTS/secure-cookie/SSL-redirect warnings. These are configuration expectations, not runtime failures; settings now support the required env and the warnings clear when TLS is enabled.
- `ZarinPal` sandbox now defaults to `not DEBUG`; production must set live credentials explicitly.
- Backend test output includes `InsecureKeyLengthWarning` when a short smoke/test secret is used; production requires a long secret.

## 8. Commands summary

```bash
cd backend
python3 manage.py test --settings=config.test_settings
PGTEST_PORT=55432 python3 manage.py test --settings=config.concurrency_settings
python3 manage.py makemigrations --check --dry-run --settings=config.test_settings
DJANGO_DEBUG=false DJANGO_SECRET_KEY='...' OTPY_API_KEY='...' \
  DJANGO_ALLOWED_HOSTS=example.com POSTGRES_PASSWORD=placeholder \
  python3 manage.py check --deploy --settings=config.settings

cd ../frontend
npx tsc --noEmit
npm run build
# temporary external harnesses: node /tmp/jam-pw/pwa.js; node /tmp/jam-pw/persist.js
```

No test result above is inferred from a previous run; all listed checks were executed in this phase. The Docker and live-payment limitations are explicitly not reported as passed.
