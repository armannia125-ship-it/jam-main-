# Single Subscription Model

**Status:** Implemented.
**Decision:** JAM sells one paid subscription plan. There is no free plan and no free trial. Payment is manual and activation is code-based.

## 1. Canonical model

The subscription domain is:

```text
SubscriptionPlan
  └── Subscription (one business, one plan, one lifecycle)
        └── ActivationCode (hash-only, single-use, customer-bound)
              └── ActivationCodeEvent (audit)
```

Relevant code:

- `backend/subscriptions/models.py`
- `backend/subscriptions/services.py`
- `backend/subscriptions/views.py`
- `backend/subscriptions/admin.py`
- `backend/subscriptions/urls.py`

## 2. One exposed plan

`canonical_plan()` returns the oldest row that is:

- `is_active = true`
- `price_toman > 0`
- `duration_days > 0`

The public endpoint `GET /api/subscriptions/plans/` returns either zero or one plan. It never returns a list of several sellable plans.

Database checks enforce:

- `price_toman > 0`
- `duration_days > 0`

There is deliberately no zero-price/free plan path. `GET /api/subscriptions/plans/` returns `[]` when no valid active plan exists, and a manual request receives `503 plan_not_configured`.

### Legacy duplicate rows

The schema can still contain legacy `SubscriptionPlan` rows. The service does not delete them; it exposes only the oldest valid active row. This preserves historical references while presenting one offer.

Operational rule: keep exactly one active plan. Deactivate legacy duplicates in admin after confirming existing subscriptions still reference the intended plan. Do not seed a price or duration from this document; the owner must maintain the real plan row.

## 3. Subscription lifecycle

```text
pending
  └── payment_confirmed   (operator verifies external payment)
        └── active        (customer redeems a valid code)
              └── expired (calculated from ends_at; status may remain active in storage)

cancelled is available in the model for administrative use.
```

Important properties:

- `pending` is a request, not proof of payment.
- `payment_confirmed` is an operator decision, not a gateway callback.
- `active` is set only by a successful redemption.
- `is_current` requires `status == active` and `starts_at <= now < ends_at`.
- `ends_at = starts_at + plan.duration_days` at redemption.
- The plan duration is snapshotted into the subscription period at activation; later plan edits do not rewrite existing periods.

## 4. One open request per business

`request_manual_subscription()` locks the business row and:

- rejects an existing current active subscription with `409 already_active`;
- returns an existing `pending` or `payment_confirmed` subscription idempotently;
- otherwise creates one `pending` subscription for the canonical plan.

This prevents double-click and concurrent requests from creating two open requests for the same business.

## 5. One code per payment

`ActivationCode.issue_for_subscription()` locks the subscription row and:

- requires `payment_confirmed`;
- revokes all prior unredeemed codes for that subscription;
- generates a cryptographically random 16-character code;
- stores only the SHA-256 hash and a four-character hint;
- returns the raw code once on the in-memory object;
- writes an `issued` audit event.

This means there is at most one valid unredeemed code per subscription at a time.

## 6. No trial and no simulated subscription payment

- `CLUB_TRIALS_ENABLED` defaults to `False`.
- `POST /api/commerce/businesses/<id>/club/trial` returns `403 trial_disabled`.
- Simulated invoice payment for membership or subscription invoices returns `409 manual_activation_required`.
- `POST /api/subscriptions/checkout/` returns `410 online_checkout_disabled`.
- The legacy ZarinPal callback remains isolated and is not part of this workflow.

## 7. Relationship to legacy club membership

`ClubMembership` is a legacy in-person club concept. It is not a second sellable online subscription.

Existing club rows are retained to avoid destructive migration. Trials are disabled and the simulated activation path is blocked. No new customer-facing club subscription path is defined in this phase.

The owner must decide how existing paid club memberships are honored. This document does not invent a migration or refund rule.

## 8. What “one plan” does and does not guarantee

Guaranteed:

- One plan is publicly exposed.
- No free plan can be exposed because of price/duration checks.
- No free trial can be started.
- No online checkout path exists.
- Activation is bound to one paid request and one customer.

Not guaranteed by a database singleton:

- Multiple legacy active `SubscriptionPlan` rows cannot coexist in admin without the oldest one winning. The schema does not have a single-row constraint. Staff procedure is required.
- A future owner may intentionally publish a different plan by deactivating the old one; existing subscriptions keep their historical plan reference.

## 9. Owner decisions

1. Final plan name, price, duration, and description (must be entered by the owner; no values are invented here).
2. Renewal rules, including early renewal and overlap.
3. Refund/cancellation policy.
4. Treatment of legacy club memberships.
5. Whether the plan will change over time and how existing subscribers are notified.
