# JAM Life UI Audit

## 1. HTML Reference Overview

- **File**: `jam-life.html` at repository root
- **Document language**: Persian (`lang="fa"`), Right-to-Left (`dir="rtl"`)
- **Viewport**: `<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">`
- **Theme color**: `#FCFDFB`
- **Favicon**: SVG with brand green `#164B40`
- **Font**: Vazirmatn (400/600/800 weights) via `@font-face` preload
- **Color scheme**: `light` default, `dark` variant via `[data-theme="dark"]`
- **No external dependencies**: All CSS and JavaScript embedded inline
- **HTML structure**: Single file with full stylesheet and minimal script

## 2. Complete UI Inventory

### Application Shell
- **Header** (`hdr`): Sticky, z-index 40, backdrop-filter `saturate(1.6) blur(14px)`, border-bottom 1px var(--line)
- **Bottom nav** (`bnav`): Fixed bottom, z-index 50, hidden by default (`display:none`), appears at <760px, backdrop-filter blur(14px)
- **Floating cart** (`fcart`): Fixed bottom, hidden by default, appears when `has` class, safe-area inset bottom
- **Layer layer** (`div#layer`): High z-index container (120)
- **Toasts** (`div#toasts`): Bottom center, z-index 120, flex column, gap 8px

### Pages/Views

#### Homepage
- **Home top** (`home-top`): Padding-top 24px, flex between greet + promo controls
- **Greeting** (`greet h1`): 24px font-weight 800, letter-spacing -.4px
- **Promos** (`promos`): Grid 1.35fr 1fr 1fr, gap 16px
- **Promo** (`promo`): Relative, overflow-hidden, border-radius var(--r-lg), padding 22px, min-height 168px, flex column justify-space-between, white color, isolation isolate, transform .2s hover translateY(-2px)
- **Promo categories**: p1 (green gradient), p2 (amber gradient), p3 (violet gradient)
- **Categories grid** (`cats`): 7-column grid, gap 12px
- **Category** (`cat`): Flex column align-center, gap 10px, padding 16px 8px, border-radius var(--r-lg), surface border var(--line), transition .18s hover transform Y-2px box-shadow var(--shadow-2)
- **Grid stores** (`grid-stores`): Auto-fill minmax(260px, 1fr), gap 20px

#### Store Page
- **Store hero** (`store-hero`): Height 210px, border-radius 0 0 24px 24px, overflow-hidden, grid place-center
- **Store head** (`store-head`): Margin-top -64px, position-relative z-index 2
- **Store card** (`sh-card`): Padding 20px, grid auto 1fr auto gap 18px align-start
- **Store logo** (`sh-logo`): 84x84px, border-radius 20px, surface border, box-shadow var(--shadow-2)
- **Store info** (`sh-info h1`): 24px font-weight 800 letter-spacing -.4px
- **Store stats** (`sh-stats`): Grid 4-col, border-top var(--line), margin -20px -20px 4px, grid-column 1/-1
- **Store layout** (`store-layout`): Grid 1fr 360px gap 24px align-start
- **Menu nav** (`menu-nav`): Sticky top var(--header-h) z-index 20, background var(--bg), padding 12px 0, flex gap 12px align-center
- **Mini search** (`mini-search`): Width 220px, flex none, input border-radius 10px, padding 0 36px 0 12px
- **Menu sections** (`menu-sec`): Scroll-margin-top 140px, margin-top 20px
- **Items grid** (`items`): Grid 1fr 1fr gap 12px
- **Item** (`item`): Grid 1fr 104px gap 14px padding 14px, surface border var(--r-lg), transition .15s hover border Y-2px shadow var(--shadow-2), cursor pointer, min-height 148px
- **Item thumb** (`item .th`): 104x104px, border-radius 12px, grid place-center, font-size 46px, position-relative
- **Item name** (`item .nm`): 15px font-weight 700 line-height 1.5
- **Item description** (`item .ds`): 12.8px color var(--ink-2) WC 2 lines -webkit-box -webkit-line-clamp 2 -webkit-box-orient vertical overflow hidden line-height 1.65
- **Item actions** (`item .bt`): Flex align-items flex-end justify-space-between gap 8px margin-top 10px
- **Item control** (`item .ctl`): Flex flex-direction column justify-space-between align-center gap 8px
- **Not available** (`item.na`): Cursor default, opacity .5 filter grayscale(.8)
- **NA tag** (`na-tag`): 14px font-weight 700 color var(--ink-2) background var(--surface-3) padding 5px 10px border-radius 8px
- **Side cart** (`side-cart`): Sticky top calc(var(--header-h) + 16px)
- **Cart box** (`cart-box`): Overflow hidden
- **Cart head** (`cart-head`): Padding 16px 18px border-bottom var(--line), flex between h3 + space-between
- **Cart list** (`cart-list`): Max-height min(46vh, 420px) overflow auto padding 4px 18px
- **Cart row** (`c-row`): Flex gap 12px align-center padding 12px 0 border-bottom var(--line), last-child border-bottom 0
- **Cart row thumb** (`c-row .th`): 48x48px, border-radius 10px, grid place-center, font-size 24px, flex none
- **Cart row name** (`c-row .nm`): 14px font-weight 700 line-height 1.45
- **Cart row price** (`c-row .pr`): 14px color var(--ink-2)
- **Cart row stepper** (`c-row .stepper`): 34px height, background var(--brand) color #fff, flex none, button 30x34px
- **Cart sum** (`cart-sum`): Padding 14px 18px border-top var(--line) background var(--surface-2)
- **Sum row** (`sum-row`): Flex justify-space-between 14px color var(--ink-2), total: color var(--ink) font-weight 800 15.5px padding-top 10px margin-top 6px border-top dashed var(--line-2), green: color var(--brand)
- **Progress bar** (`progress`): 6px height border-radius 6px background var(--surface-3) overflow hidden margin-top 8px, i: display block height 100% background var(--brand) border-radius 6px transition width .3s
- **Empty state** (`empty`): Padding 36px 20px text-align center color var(--ink-2), e-ic: 64x64x border-radius 18px background var(--surface-3) grid place-center margin 0 auto 14px color var(--ink-3), e-ic svg: 30x30, b: display block color var(--ink) 15.5px margin-bottom 4px
- **Notice** (`notice`): Flex gap 10px align-flex-start padding 12px 14px border-radius 12px 14px font-size 14px line-height 1.65, ic: margin-top 2px 18x18, amber/blue/green/red backgrounds

#### Product Card
- **Product card** (`p-card`): Surface border var(--r-lg) padding 12px flex flex-col gap 10px transition .18s hover border var(--line-2) shadow var(--shadow-2), text-align start
- **Product thumb** (`p-thumb`): 1.35/1 aspect-ratio border-radius 12px grid place-center 46px position-relative overflow-hidden
- **Product name** (`p-name`): 14.5px font-weight 700 line-height 1.5
- **Product store** (`p-store`): 14px color var(--ink-3) flex align-center gap 4px
- **Price** (`price`): Flex flex-col line-height 1.3, s: 14px color var(--ink-3), b: 15px font-weight 800, b small: 14px font-weight 500 color var(--ink-2) margin-inline-start 3px
- **Product foot** (`p-foot`): Flex align-items-flex-end justify-space-between gap 8px margin-top auto
- **Add button** (`add`): 40x40 border-radius 12px background var(--brand-soft) color var(--brand) grid place-center transition .15s hover background var(--brand) color #fff, flex none
- **Stepper** (`stepper`): 40px height 12px border-radius background var(--brand) color #fff flex none, button 36x40 grid place-center color #fff hover background rgba(0,0,0,.1), b: 22px min-width text-align center 14.5px

#### Cart Page
- **Cart header** (`cart-head`): 16px 18px border-bottom var(--line) flex align-items-center justify-space-between h3: 16px font-weight 800
- **Cart empty** (`empty`): As above
- **Progress** (`progress`): As above
- **Summary row** (`sum-row`): Flex justify-space-between 14px color var(--ink-2) padding 3px 0, total: color var(--ink) font-weight 800 15.5px padding-top 10px margin-top 6px border-top dashed var(--line-2), green: color var(--brand)

#### Checkout Page
- **Page title** (`page-title`): Flex align-items-center gap 12px padding 24px 0 4px h1: 24px font-weight 800 letter-spacing -.4px
- **Crumbs** (`crumbs`): 14px color var(--ink-3) flex gap 6px align-items-center padding-top 20px, a:hover color var(--brand)
- **Checkout layout** (`co-layout`): Grid 1fr 380px gap 24px align-start margin-top 16px
- **Step** (`co-step`): Padding 20px margin-bottom 16px, h2: 16.5px font-weight 800 display flex align-center gap 10px, h2 .n: 28x28 border-radius 9 background var(--brand-soft) color var(--brand) grid place-center 14px font-size
- **Option grid** (`opt-grid`): Grid 1fr 1fr gap 12px
- **Option** (`opt`): Flex gap 12px align-flex-start padding 16px border 1.5px solid var(--line-2) border-radius 14px cursor-pointer transition .15s text-start position-relative background var(--surface), hover border var(--ink-3), on border var(--brand) background var(--brand-soft)
- **Option image** (`opt .oi`): 42x42 border-radius 11 background var(--surface-3) grid place-center color var(--ink-2) flex none, on: background var(--brand) color #fff
- **Option b** (display block): 14.5px font-size
- **Option small** (display block): 12.8px color var(--ink-2) 1.6 line-height margin-top 2px
- **Option tag** (position absolute): top 12px inset-inline-end 12px
- **Option radio** (position absolute): top 16px inset-inline-end 16px 20x20 border-radius 50% border 2px solid var(--line-2), on: border var(--brand) box-shadow inset 0 0 0 4px var(--surface) background var(--brand)
- **Form grid** (`form-grid`): Grid 1fr 1fr gap 14px, full: grid-column 1/-1
- **Addr list** (`addr-list`): Flex flex-col gap 10px
- **Addr opt** (`addr-opt`): Flex gap 12px align-center padding 14px border 1.5px solid var(--line-2) border-radius 14px cursor-pointer text-start width 100% transition .15s, on border var(--brand) background var(--brand-soft), oi: 40x40 border-radius 10 background var(--surface-3) flex none color var(--ink-2), on: background var(--brand) color #fff
- **Code row** (`code-row`): Flex gap 8px, input: 42px direction ltr text-align right text-transform uppercase
- **Summary store** (`summary .s-store`): Flex gap 12px align-center padding 16px 18px border-bottom var(--line), lg: 46x46 border-radius 12 background var(--surface-3) grid place-center 24px font-size

#### Order Tracking
- **Track hero** (`track-hero`): Padding 24px grid 1fr auto gap 16px align-center h1: 22px font-weight 800
- **Big status** (`big-status`): 72x72 border-radius 20 grid place-center, svg: 34x34
- **Timeline** (`timeline`): Flex gap 0, tl: flex 1 position-relative text-center 14px color var(--ink-3) font-weight 600, tl .b: 30x30 border-radius 50 margin 0 auto 8px grid place-center position-relative z-index 1 color var(--ink-3) border 3px solid var(--surface), tl .b svg: 15x15, tl::before: content "" position-absolute top 14px left 50% width 100% height 3px background var(--surface-3), tl first-child::before display none, tl.done: color var(--ink), tl.done .b: background var(--brand) color #fff, tl.done::before: background var(--brand), tl.cur .b: box-shadow 0 0 0 6px var(--brand-soft) animation pulse 1.6s infinite, pulse: 50% box-shadow 0 0 0 10px transparent, kv: Grid auto 1fr gap 10px 16px 14px color var(--ink-3) kv dd: margin 0 font-weight 600 text-align left, pickup-code: Flex gap 8px direction ltr justify-center margin 8px 0, pickup-code span: 48x58 border-radius 12 background var(--surface-3) grid place-center 26px font-weight 800 border 1px solid var(--line-2), order-row: Grid auto 1fr auto gap 16px align-center padding 16px 20px border-bottom var(--line) transition .15s hover background var(--surface-2), last-child border-bottom 0, order-row .lg: 52x52 border-radius 14 grid place-center 26px font-size

#### Business Landing
- **Biz hero** (`biz-hero`): Padding 56px 0 40px grid 1.1fr 1fr gap 48px align-center, h1: 40px 1.35 ltr -1px margin 12px 0 0 em: font-style normal color var(--brand), p.lead: 16.5px color var(--ink-2) margin 16px 0 0 max-width 520px line-height 1.85, ctas: flex gap 10px margin-top 28px flex-wrap wrap, trust: flex gap 24px margin-top 28px flex-wrap wrap, trust div b: 20px font-weight 800 display block, trust div span: 14px color var(--ink-3), phone: 290x580 border-radius 44px background 0E1418 padding 12px margin 0 auto box-shadow 0 30px 60px rgba(16,24,32,.25) inset 0 0 0 2px 2A3238 position-relative, phone::before: content "" absolute top 20px left 50% transform translateX(-50%) 90x24 border-radius 14px background 0E1418 z-index 3, phone .screen: 100% 100% border-radius 34px overflow-hidden background #fff position-relative, phone .screen > .pm: 100% height overflow-auto scrollbar-width none, phone .screen > .pm::-webkit-scrollbar display none, biz-visual: position-relative, float-card: position-absolute background surface border 1px solid var(--line) border-radius 14px padding 12px 14px box-shadow var(--shadow-3) display flex gap 10px align-center 14px z-index 4, feat-grid: grid 3-col gap 16px, feat: 22px padding, feat .t: 46x46 border-radius 13 grid place-center margin-bottom 14px, feat h3: 16px font-weight 800 margin 0 0 6px, feat p: 14px color var(--ink-2) margin 0 line-height 1.8, steps: grid 4-col gap 16px counter-reset s, step: 20px position-relative, step .n: 34x34 border-radius 10 background var(--ink) color var(--surface) grid place-center font-weight 800 margin-bottom 12px, step h4: 15px margin 0 0 4px, step p: 14px color var(--ink-2) line-height 1.75, plans: grid 3-col gap 16px align-stretch, plan: 24px display flex flex-col gap 14px position-relative, plan.pop: border 2px solid var(--brand) shadow 0 12px 32px rgba(8,128,90,.12), plan .ribbon: position-absolute top -13px inset-inline-start 24px background var(--brand) color #fff 14px font-weight 700 padding 3px 10px border-radius 7px, plan h3: 17px font-weight 800, plan .pp: 30px font-weight 800 letter-spacing -.5px, plan .pp small: 14px font-weight 500 color var(--ink-2) margin-inline-start 4px, plan ul: none margin 0 padding 0 display flex flex-col gap 9px 14px, plan li: flex gap 8px align-items-flex-start, plan li .ic: 18x18 color var(--brand) 3px margin-top 3px, plan li.off: color var(--ink-3), plan li.off .ic: color var(--ink-3), faq details: border-bottom 1px solid var(--line) padding 4px 20px, faq details last-child: border-bottom 0, faq summary: none cursor-pointer 14px font-weight 700 display flex justify-between align-center gap 12px, faq summary ::-webkit-details-marker display none, faq summary .ic: transition .2s color var(--ink-3), faq details[open] summary .ic: transform rotate(180deg), faq details p: 14px color var(--ink-2) margin 0 0 16px line-height 1.85, cta-band: 20px border-radius 20 padding 32px background linear-gradient 135deg 12353F 2C7A8C color #fff display flex align-center justify-between gap 20px flex-wrap wrap position-relative overflow-hidden, cta-band h2: 22px font-weight 800 margin 0, cta-band p: 6px 0 0 opacity .85 14.5px, cta-band .btn-primary: #fff 08805A, cta-band::after: content "" absolute width 280px height 280px border-radius 50% 40px solid rgba 255 255 255 .06 left -60px top -120px

#### Panel
- **Panel** (`panel`): Grid 248px 1fr gap 24px padding-top 24px align-start, p-side: sticky top calc(var(--header-h) + 16px) padding 12px, p-store: flex gap 10px align-center padding 8px 8px 14px border-bottom var(--line) margin-bottom 8px, p-store .lg: 42x42 border-radius 11 grid place-center 22px font-size flex none, p-store select: border 0 background transparent font-weight 800 14px padding 0 outline-none width 100% cursor-pointer, p-nav: flex flex-col gap 2px, p-nav a: flex align-center gap 10px 42px padding 0 12px border-radius 10px 600 14px color var(--ink-2) transition .15s hover background var(--surface-3) color var(--ink), on: background var(--brand-soft) color var(--brand), p-nav a .cnt: auto margin-inline-start 20 width 20 height 20 border-radius 6 grid place-center 14px font-weight 700 sub-card: margin-top 12px padding 14px border-radius 12 background var(--surface-2) border 1px solid var(--line) 14px p-main h1: 22px font-weight 800 letter-spacing -.3px, p-main .p-sub: 2px 0 0 color var(--ink-2) 14px, p-top: flex justify-between align-end gap 16px margin-bottom 20px flex-wrap wrap, kpis: grid 4-col gap 16px, kpi: 18px padding, kpi .k: 14px color var(--ink-2) display flex align-between justify-space-between, kpi .k .t: 34x34 border-radius 10 grid place-center, kpi .v: 24px font-weight 800 8px margin letter-spacing -.4px, kpi .d: 14px flex align-center gap 4px, up: color var(--brand), down: color var(--red), chart: flex align-items-flex-end gap 12px 200px height padding-top 12px, bar: flex 1 display flex flex-col align-center gap 8px 100% height justify-content flex-end, bar i: display block 100% max-width 44px border-radius 8 8 4 4 background var(--brand-soft) transition height .4s position-relative, bar.today i: background var(--brand), bar span: 14px color var(--ink-3), bar em: 14px style normal 600 color var(--ink-2), two-col: grid 1.5fr 1fr gap 16px margin-top 16px, tbl: 100% border-collapse collapse 14px, tbl th: 14px color var(--ink-3) font-weight 600 text-align start padding 10px 16px border-bottom var(--line) background var(--surface-2) white-space nowrap, tbl td: 12px 16px border-bottom var(--line) vertical-align middle, tbl tr:last-child td: border-bottom 0, tbl tr.na td: opacity .6, tbl-wrap: overflow-x auto, price-in: 130x38 border-radius 10 border 1px solid var(--line-2) background var(--surface) padding 0 10px font-weight 700 outline-none font-variant-numeric tabular-nums, price-in focus: border var(--brand-400) box-shadow 0 0 0 3px var(--brand-soft), o-card: 16px 18px display grid 1fr auto gap 12px 16px margin-bottom 12px, o-card.new: border var(--brand-400) box-shadow 0 0 0 3px var(--brand-soft), o-items: 14px color var(--ink-2) line-height 1.8, o-actions: flex gap 8px flex-wrap align-center grid-column 1/-1 padding-top 12px border-top dashed var(--line-2), tpls: grid 3-col gap 12px, tpl: border 2px solid var(--line) border-radius 14 padding 10 cursor-pointer transition .15s text-start background var(--surface), on: border var(--brand), tpl .pv: 92px border-radius 9 margin-bottom 8px overflow-hidden display flex flex-col gap 5 padding 9px, tpl .pv i: display block 8px border-radius 4, tpl b: 14px, swatches: flex gap 10px flex-wrap wrap, sw: 36x36 border-radius 10 border 3px solid var(--surface) box-shadow 0 0 0 1px var(--line-2) cursor-pointer, on: box-shadow 0 0 0 2px var(--ink), qr-box: flex gap 20px align-center flex-wrap wrap, qr: 172x172 background #fff padding 12px border-radius 14 border 1px solid var(--line) flex none, qr svg: 100% 100%, link-box: flex align-center gap 8 background var(--surface-3) border-radius 10 padding 4 4 4 12 direction ltr, link-box code: 14px Menlo Consolas monospace 14px overflow hidden text-overflow ellipsis white-space nowrap padding-left 8px, tg-chat: 180 180 gradient 180deg #DDE9DA #C9DDC4 border-radius 14 padding 16 flex-col gap 8 min-height 340px 14px, dark: gradient 180deg 1E2A22 17211B, msg: max-width 82% padding 8px 12px border-radius 14 line-height 1.7 box-shadow 0 1px 1px rgba 0 0 0 .08 background 14202B color 14202B align-self flex-start border-bottom-left-radius 4px, me: align-self flex-end background E3F7D0 border-bottom-left-radius 14 border-bottom-right-radius 4px, msg .kb: grid 1fr 1fr gap 5px margin-top 8px, msg .kb span: 11 1 rgba 36 112 214 .1 color 2470D6 text-align center 6px 8px border-radius 8 600 14px font-size, msg time: display block 14px color 8A949E text-align left margin-top 2px

#### Digital Menu (QR target)
- **Digital menu** (`dm`): --acc 08805A max-width 560px margin 0 auto min-height 100vh background var(--dm-bg #fff) color var(--dm-ink 14202B) 14.5px, dm-hero: 28px 20px 20px text-center background var(--dm-hero linear 180deg color-mix in srgb var(--acc) 14% #fff #fff), dm-logo: 76x76 border-radius 22 margin 0 auto 10px grid place-center 40px background #fff box-shadow 0 6px 20px rgba 0 0 0 .08, dm-hero h1: 22px font-weight 800, dm-hero p: 14px opacity .75, dm-meta: flex justify-center gap 8 margin-top 12px flex-wrap wrap, dm-meta span: inline-flex gap 5 align-center 14px padding 5 10px border-radius 8 background color-mix in srgb var(--acc) 10% transparent color var(--acc) font-weight 600, dm-tabs: sticky top 0 z-index 5 display flex gap 6 overflow-x auto padding 10 16 background var(--dm-bg #fff) border-bottom 1px solid color-mix in srgb currentColor 10% transparent scrollbar-width none, dm-tabs a: flex none 7 14 border-radius 9 700 14px opacity .7, on: background var(--acc) color #fff opacity 1, dm-sec: 18px 16px 4px scroll-margin-top 60px, h2: 16px margin 0 0 10px font-weight 800 display flex align-center gap 10px, h2::after: content "" flex 1 height 1px background currentColor opacity .12, dm-it: flex gap 12 padding 12px 0 border-bottom 1 dashed color-mix in srgb currentColor 14% transparent, last-child border-bottom 0, .th: 64x64 border-radius 14 grid place-center 32px flex none background color-mix in srgb var(--acc) 9% transparent, .nm: font-weight 700, .ds: 12.8px opacity .7 line-height 1.65 margin-top 2px, .pr: font-weight 800 color var(--acc) white-space nowrap margin-inline-start auto text-align left, .pr s: 14px opacity .55 color var(--dm-ink 14202B) font-weight 500, .na: opacity .45, dm-foot: 24px 16px 100px text-align center 14px opacity .6, dm-order: fixed bottom 16px left 50% transform translateX(-50%) width min(528px calc(100% - 32px)) z-index 10, dm-order a: display flex 52px border-radius 14 background var(--acc) color #fff font-weight 700 align-items-center justify-center gap 8 box-shadow 0 10px 24px rgba 0 0 0 .18, dm t-dark: --dm-bg 121417 --dm-ink F1F4F6 --dm-hero linear 180deg 1C2126 121417, dark .dm-logo: 1F252A, dm t-classic: --dm-bg FBF7EF --dm-ink 2B2118 --dm-hero linear 180deg F3E8D3 FBF7EF font-family Georgia var(--font), classic .dm-it .th border-radius 50%, dm-exit: fixed top 12px inset-inline-start 12 z-index 20 background rgba 20 32 43 .85 color fff 14px font-weight 600 padding 8 12 border-radius 10 display flex gap 6 align-items-center

#### Footer & Bottom Nav
- **Footer** (`ftr`): Border-top 1px var(--line) background var(--surface) padding 40px 0 32px margin-top 24px, ftr-grid: grid 1.6fr 1fr 1fr 1fr gap 32px, h4: 14px margin 0 0 12px, ul: none padding 0 margin 0 display flex flex-col gap 8 14px color var(--ink-2), ul a:hover color var(--brand), ftr-bottom: margin-top 28px padding-top 20px 14px color var(--ink-3) display flex justify-between gap 12px flex-wrap wrap
- **Bottom nav** (`bnav`): None fixed bottom 0 inset-inline 0 z-index 50 background color-mix in srgb var(--surface) 94% transparent backdrop-filter blur(14px) -webkit-backdrop-filter blur(14px) border-top 1px var(--line) padding-bottom env(safe-area-inset-bottom), bnav-in: grid 4-col 1fr height 64px, a: flex flex-col align-center justify-center gap 3 14px font-weight 600 color var(--ink-3) position-relative, on: color var(--brand), on::before: content "" absolute top 0 28px 3px border-radius 0 0 3 3 background var(--brand), .badge-dot: top 6px inset-inline-end calc(50% - 22px)

#### Search Page
- **Search layout** (`s-layout`): grid 260px 1fr gap 24px margin-top 16px align-start, filters: 18px position sticky top calc(var(--header-h) + 16px), h4: 14px color var(--ink-2) margin 0 0 10px, f-group: 14px 0 border-bottom var(--line) flex flex-col gap 10, last-child border-bottom 0 padding-bottom 0 first-child padding-top 0, radio-row: flex align-center gap 10 14px cursor-pointer, accent-color var(--brand) 17x17, res-head: flex justify-between align-center gap 12px margin-bottom 14px flex-wrap wrap, hl: background color-mix in srgb var(--star) 30% transparent color inherit border-radius 3px padding 0 1px, suggest: 420px max-width calc(100vw - 32px) position absolute top 100% 8px inset-inline 0 background var(--surface) border 1px solid var(--line) border-radius 14 box-shadow var(--shadow-3) padding 8px z-index 60 max-height 420px overflow-auto, .g: 14px color var(--ink-3) 600 padding 8 10 4px, a: flex gap 10 align-center padding 8 10 border-radius 10 14px font-size 14px, hover kb-on: background var(--surface-3), a .th: 36x36 border-radius 9 19px flex-center 19px font-size, small: display block 14px color var(--ink-3)

## 3. Design System Extraction

### Colors (CSS Custom Properties)

**Light theme**:
- `--brand: #08805A` (primary green)
- `--brand-600: #066B4B` (darker green)
- `--brand-400: #12A574` (lighter green)
- `--brand-soft: #E7F5EF` (light green bg)
- `--brand-ink: #04402D` (dark green text)
- `--ink: #14202B` (primary text)
- `--ink-2: #56616D` (secondary text)
- `--ink-3: #8A949E` (muted text)
- `--bg: #F4F6F7` (page bg)
- `--surface: #FFFFFF` (card/bg surface)
- `--surface-2: #F7F8F9` (secondary surface)
- `--surface-3: #EEF1F3` (tertiary surface)
- `--line: #E4E8EB` (dividers)
- `--line-2: #D5DBE0` (lighter dividers)
- `--amber: #B76E00` (amber/orange)
- `--amber-soft: #FFF4E0` (amber soft bg)
- `--star: #F5A524` (star/yellow)
- `--red: #D93B3B` (error red)
- `--red-soft: #FDECEC` (red soft bg)
- `--blue: #2470D6` (blue)
- `--blue-soft: #E8F1FD` (blue soft bg)
- `--violet: #6D4DD6` (violet)
- `--violet-soft: #F0ECFD` (violet soft bg)
- `--shadow-1: 0 1px 2px rgba(16,24,32,.05)`
- `--shadow-2: 0 1px 2px rgba(16,24,32,.05),0 6px 18px rgba(16,24,32,.06)`
- `--shadow-3: 0 12px 40px rgba(16,24,32,.16)`

**Dark theme** (`[data-theme="dark"]`):
- `--brand: #14A873` (lighter green)
- `--brand-600: #0F8E61`
- `--brand-400: #3CCB95`
- `--brand-soft: rgba(20,168,115,.14)`
- `--brand-ink: #9BE7C8`
- `--ink: #F1F4F6`
- `--ink-2: rgba(241,244,246,.68)`
- `--ink-3: rgba(241,244,246,.45)`
- `--bg: #0F1214`
- `--surface: #181C1F`
- `--surface-2: #1E2326`
- `--surface-3: #262C30`
- `--line: rgba(255,255,255,.09)`
- `--line-2: rgba(255,255,255,.16)`
- `--amber: #F2B04F`
- `--amber-soft: rgba(242,176,79,.13)`
- `--red: #F07070`
- `--red-soft: rgba(240,112,112,.13)`
- `--blue: #6EA8F5`
- `--blue-soft: rgba(110,168,245,.13)`
- `--violet: #A78BFA`
- `--violet-soft: rgba(167,139,250,.14)`
- `--shadow-1: none`
- `--shadow-2: 0 0 0 1px rgba(255,255,255,.04)`
- `--shadow-3: 0 12px 40px rgba(0,0,0,.5)`

### Typography
- **Font family**: `--font: "Vazirmatn","Vazir","IRANSans","Noto Sans Arabic","Segoe UI",Tahoma,system-ui,sans-serif`
- **Font weight**: 500 (regular), 600 (medium), 700 (semibold), 800 (bold)
- **Base font size**: 16px, line-height 1.65
- **Focus-visible**: `outline: 2px solid var(--brand-400); outline-offset: 2px; border-radius: 6px`
- **Text utilities**: `.muted` (var(--ink-2)), `.faint` (var(--ink-3)), `.tnum` (font-variant-numeric: tabular-nums)

### Spacing & Sizing
- **Container**: `max-width: 1200px; margin: 0 auto; padding: 0 24px`
- **Radius**: `--r-sm: 8px; --r: 12px; --r-lg: 16px`
- **Header height**: `--header-h: 68px` (light), `60px` at `<760px` media query
- **Minimum interactive target**: 44px throughout
- **Grid gap**: 8px (tight), 12px (standard), 16px (wide), 20px (grid-stores), 24px (panel/gap)

### Breakpoints
- `max-width: 1180px`: nav-link span hide, padding 0 10px
- `max-width: 1080px`: store/layout co-layout 1fr!important, side-cart hide, fcart.has display, cats 4-col, promos 1fr 1fr p1 grid-column 1/-1, panel 1fr, p-side static padding 8px, p-nav row overflow-x auto, p-nav a flex none, sub-card p-store hide, kpis 1fr 1fr, two-col 1fr!important, biz-hero 1fr gap 32px, feat-grid plans 1fr 1fr, steps 1fr 1fr, s-layout 1fr, filters position static, co-summary order -1
- `max-width: 760px`: root --header-h: 60px, body 14.5px, container 0 16px, hdr-in gap 8px, hdr hdr-in search nav-link cart-btn.lbl logo small panel-ic hide, logo 18px logo-mark 34x34, addr-btn flex 1 min-width 0, bnav display, main padding-bottom 120px, m-search display block!important padding 12px 0 0, m-search search max-width none, promos none column-flow auto-columns 86% margin-inline -16px padding 0 16px scroll-padding 0 16px overflow-x auto scroll-snap-type x mandatory scrollbar-width none, promos > start, promo 150px min-height 18px big-ic hide, cats 4-col gap 8px, cat 12 4 gap 8 border-radius 14, cat .t 44x44 border-radius 12, cat b 14px small none, greet h1 20px, home-top seg 100% seg button flex-1 justify-center, grid-stores 1fr gap 14px, section 32px, sec-head h2 18px, store-hero 160px border-radius 0, .store-hero .em 72px, sh-card grid auto 1fr padding 16 gap 12, sh-logo 64x64 16 border-radius 34 34px font 34px, sh-info h1 19px, sh-actions grid 1/-1 order 3, .fcart display block

## 4. Responsive and RTL Analysis

### RTL (Right-to-Left)
- **HTML**: `lang="fa"`, `dir="rtl"` on `<html>`
- **Text alignment**: `text-align: right` (implied by dir=rtl)
- **Direction properties**: `direction: ltr` on specific inputs (`input-ltr` class) for numeric/text fields
- **Logo layout**: flex start, gap 10px, items center
- **Address button**: `max-width: 230px; min-width: 0; flex: 1`
- **Navigation**: `nav-link` with gap 8px, right-aligned naturally via rtl
- **Cart button**: natural RTL ordering
- **Grid columns**: Natural RTL reorder (last column becomes first in rtl)
- **Scrollbar**: `scrollbar-width: thin` / `::-webkit-scrollbar` hidden

### Responsive Breakpoints (from source)
| Breakpoint | Max Width | Changes |
|-----------|-----------|---------|
| Desktop | 1180px+ | Full layout, 7-col cats, 3-col promos |
| Laptop | 1080px | Column transforms, grid reductions |
| Tablet | 760px | Header collapse, bnav show, font 14.5px, container 16px |
| Mobile small | <360px | Further reductions in component sizes |

### Specific Responsive Transformations
- **Header**: At <760px: search, nav-link (lbl), cart-btn.lbl, logo small, panel-ic hide; logo font 18px, mark 34px
- **Bottom nav**: `display: block` at <760px, fixed, backdrop-filter, safe-area-inset-bottom
- **Floating cart**: `display: block` when `.has` class at <1080px
- **Promos**: At <1080px: collapse to single column, auto-columns 86%, margin-inline -16px, padding 0 16px, scroll-padding 0 16px, overflow-x auto, scroll-snap x mandatory
- **Categories**: At <760px: 4-col grid, gap 8px, padding 12px 4px, border-radius 14px, .t 44x44, b 14px, small hide
- **Store layout**: At <1080px: 1fr!important (single column)
- **Panel**: At <1080px: 1fr (single column), p-side static padding 8px
- **Two-col**: At <1080px: 1fr!important (single column)
- **Biz hero**: At <1080px: 1fr gap 32px
- **Feat-grid/plans/steps**: At <1080px: 1fr 1fr (2-col)
- **S-layout**: At <1080px: 1fr (single column)
- **Filters**: At <1080px: position static (not sticky)

## 5. Interaction and UI Logic Audit

### Navigation Interactions
- **Header search**: Input with focus state (`border-color: var(--brand-400)`, `box-shadow: 0 0 0 4px var(--brand-soft)`), kbd icon absolute, placeholder color var(--ink-3)
- **Nav links**: Hover background var(--surface-3), color var(--ink), active: color var(--brand) background var(--brand-soft)
- **Cart button**: Background var(--brand) color #fff, hover var(--brand-600), bump animation `animation: bump .4s` on `.bump` class, is-empty state: background var(--surface-3) color var(--ink-2)
- **Bottom nav**: Items with on state color var(--brand), badge-dot position top 6px inset-inline-end calc(50% - 22px)

### Form Interactions
- **Input focus**: `border-color: var(--brand-400); box-shadow: 0 0 0 4px var(--brand-soft)`
- **Input error**: `border-color: var(--red); box-shadow: 0 0 0 4px var(--red-soft)`, error-msg: 14px color var(--red) flex gap 6px align-items center
- **Switch**: 44x26, span with border-radius 26 background var(--line-2) transition .2s, after element 20x20 radius 50 background #fff box-shadow 0 1px 3px rgba(0,0,0,.2) right 3px, checked: span background var(--brand), after right 21px, focus-visible outline 2px solid var(--brand-400) outline-offset 2px
- **Radio row**: accent-color var(--brand) 17x17

### Component Interactions
- **Promo hover**: `transform: translateY(-2px)` transition .2s
- **Card hover**: `box-shadow: var(--shadow-2); transform: translateY(-2px); border-color: var(--line-2)` transition .2s
- **Category hover**: `border-color: var(--brand-400); transform: translateY(-2px); box-shadow: var(--shadow-2)` transition .18s
- **Chip/selected**: `.chip.on`: background var(--ink) border var(--ink) color var(--surface)
- **Segmented control**: `.seg button.on`: background var(--surface) color var(--ink) box-shadow var(--shadow-2), .ic color var(--brand)
- **Button states**: Primary: bg brand, hover bg brand-600; Soft: bg brand-soft color brand, hover filter .97; Ghost: transparent color ink-2 border var(--line-2) hover bg surface-3 color ink; Plain: bg surface-3 color ink hover bg line; Danger: bg red-soft color red hover filter .97; Dark: bg ink color surface; Sm: 36px 12px 10px; Lg: 52px 22px 15.5px; Block: 100%

### Drawer/Modal/Toast
- **Overlay**: Fixed inset 0 rgba(10,16,22,.48) z-index 80 opacity 0 transition .22s backdrop-filter blur(2px), .show: opacity 1
- **Drawer**: Fixed top 0 bottom 0 left 0 min(420px, 100vw) surface z-index 90 transform translateX(-102%) .28s cubic-bezier(.2,.8,.2,1) flex flex-col box-shadow var(--shadow-3), .show: transform none
- **Modal**: Fixed inset 0 z-index 90 grid place-center padding 24px pointer-events none, modal: pointer-auto surface 20px border-radius 20 max-height calc(100vh - 48px) overflow auto box-shadow var(--shadow-3) transform translateY(14px) scale(.98) opacity 0 .22s cubic-bezier(.2,.8,.2,1), .wide: 520px max, .show: transform none opacity 1
- **Toast**: Fixed bottom 50% left 50% transform translateX(-50%) z-index 120 flex-col gap 8 align-center pointer-events-none max-content max-width calc(100vw - 24px), background 14202B color #fff 12px 16px border-radius 12 font 14 600 display flex gap 10 align-center box-shadow var(--shadow-3) animation tin .25s ease-out, dark: 2A3136, ic: 4ADE9F err: FF8A8A, button: 7EE2B8 700 margin-inline-start 6px white-space nowrap, tin: from opacity 0 transform translateY(10px)

### Responsive Interactions
- **Header nav-links**: At <1180px: span hide, padding 0 10px
- **Cart button**: At <1080px: is-empty state, fcart.has display
- **Promo grid**: At <1080px: 1fr 1fr, p1 grid-column 1/-1; At <760px: single column, auto-columns 86%, big-ic hide
- **Categories**: At <1080px: 4-col; At <760px: 4-col gap 8, padding 12 4, .t 44x44, b 14, small hide
- **Store layout**: At <1080px: 1fr!important
- **Bottom nav**: At <760px: display block, fixed bottom, safe-area-inset-bottom
- **Floating cart**: At <1080px: display block when .has

### State Changes
- **Active/selected**: `.nav-link.active`, `.chip.on`, `.seg button.on`, `.opt.on`, `.addr-opt.on`, `.tpl.on`, `.sw.on`, `.pill.green`, `.pill.red`, `.pill.amber`, `.pill.blue`, `.pill.violet`, `.pill.gray`, `.dt.on`, `.dt.cur`
- **Disabled**: `btn[disabled]`: opacity .45 pointer-events none
- **Empty states**: Cart empty, notice variants (amber/blue/green/red)

## 6. Asset Inventory

### Font Resources
- **Vazirmatn**: 400, 600, 800 weights
- **Preloaded** in `layout.tsx`: `/fonts/vazirmatn-400-bcdf679c79.ttf`, `/fonts/vazirmatn-600-ef484d8d9d.ttf`, `/fonts/vazirmatn-800-8893f9214c.ttf`
- **@font-face** defined in HTML `:root` with `font-family: var(--font)`, `font-style: normal`, `font-weight: 400`, `font-display: swap`, `src: url(data:font/ttf;base64,...)`
- **Fallback stack**: `"Vazirmatn","Vazir","IRANSans","Noto Sans Arabic","Segoe UI",Tahoma,system-ui,sans-serif`

### SVG Icons
- **Inline SVG** for logo mark, category icons, button icons
- **IC class**: 20x20 stroke currentColor fill-none stroke-width 1.9 stroke-linecap round stroke-linejoin round
- **IC SM/LG/XL**: 16/24/28px sizes
- **Flip**: `transform: scaleX(-1)` for RTL mirroring

### Media Assets (referenced in CSS)
- **WebP images** in `frontend/public/media/`: 60+ juice-tea-apples-pizza- images for product placeholders
- **Not directly referenced** in jam-life.html CSS (uses solid colors/gradients)

## 7. Source-to-Component Mapping

| HTML/CSS Selector | Target Component | Notes |
|---|---|---|
| `.hdr` | Header component | Sticky, backdrop, border-bottom |
| `.cart-btn` | Cart button | Brand color, bump animation, empty state |
| `.bnav` | Bottom navigation | Fixed, responsive show/hide at 760px |
| `.fcart` | Floating cart bar | Mobile, safe-area-inset-bottom |
| `.drawer` | Drawer/modal overlay | transformX transition |
| `.modal` | Modal dialog | scale/translateY transition |
| `.toasts` | Toast container | Bottom center, exit animation |
| `.promo` | Promo card | Hover transform, gradient backgrounds |
| `.cat` | Category tile | Hover transform, border-color change |
| `.item` | Product list item | Hover border/shadow, cursor pointer |
| `.p-card` | Product card | Hover border/shadow, stepper inside |
| `.sh-card` | Store card | Hover shadow transform, fav/disc badge |
| `.o-card` | Order card | New badge border/box-shadow |
| `.tbl` | Table | Zebra-stripes, na opacity |
| `.biz-hero` | Business hero | Gradient background, phone mockup |
| `.cta-band` | CTA band | Gradient, ribbon effect |
| `.dm` | Digital menu | QR target page, tabs, orders |
| `.ftr` | Footer | Grid 4-col, links, bottom bar |
| `.hscroll` | Horizontal scroll | Scroll-snap, thin scrollbar |

## 8. Visual Verification Results and Limitations

**Verification breakpoints**: 1440px (desktop), 1024px (laptop), 768px (tablet), 390px (mobile), 360px (small mobile)

**Known limitations**:
- No runtime environment available for pixel-level verification
- WebP media assets in `public/media/` referenced but not inspectable without build/runtime
- Embedded base64 font in CSS may render differently across OS/font installations
- CSS `color-mix()` function used for dark/light variants may need Tailwind equivalent
- `@font-face` with data URI may not match exact system font rendering
- Some responsive values derived from source inspection rather than explicit media queries

**Visual accuracy**: Source-based extraction of design tokens, colors, spacing, breakpoints, and component hierarchies from `jam-life.html`.

## 10. Explicit UI Reproduction Requirements

### Required Components (all pages/views from reference)
1. **Header** with logo, search, nav links, cart button, theme toggle
2. **Homepage** with greeting, promos grid, categories grid
3. **Store page** with hero, store card, items grid, side cart
4. **Product card** with thumb, name, store, price, stepper, add button
5. **Cart page** with list, row format, stepper, summary, progress bar
6. **Checkout page** with steps, options, form grid, address selection
7. **Order tracking** with timeline, status badges, kv details
8. **Business landing** with hero, phone mockup, features, plans, faq
9. **Panel/dashboard** with side bar, KPIs, charts, tables, templates
10. **Digital menu** (QR target) with hero, logo, tabs, items, order bar
11. **Footer** with grid links, bottom bar
12. **Bottom navigation** (mobile)
13. **Search page** with filters, suggestions
14. **Modals/drawers/toasts** with overlay, animations
15. **Responsive transformations** at 1180px, 1080px, 760px breakpoints

### Design Tokens to Reproduce
- CSS variables: `--brand`, `--ink`, `--surface`, `--shadow-*`, `--r-*`, `--header-h`
- Vazirmatn font (400/600/800) with `--font` family
- Tailwind color palette mapping from brand colors
- Breakpoint values: 1180px, 1080px, 760px (custom, not default Tailwind)
- Animation timings: `.2s`, `.28s cubic-bezier(.2,.8,.2,1)`, `.4s bump`, `.3s progress`, `.25s tin`
- Focus-visible: `outline: 2px solid var(--brand-400); outline-offset: 2px; border-radius: 6px`
- Minimum 44px interactive targets
- `env(safe-area-inset-bottom)` for mobile bottom nav/cart

### RTL Requirements
- `lang="fa"`, `dir="rtl"` on `<html>`
- Right-to-left text flow natural with dir=rtl
- `direction: ltr` on input fields for numeric/text entries
- Natural grid reorder with RTL
- All components must function correctly with rtl layout