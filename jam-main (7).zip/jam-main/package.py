"""Package source only: python scripts/package.py."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[1]
output = root.parent / "jam-phase1.zip"
excluded = {"node_modules", ".next", "__pycache__", ".venv", "staticfiles", ".git"}
with ZipFile(output, "w", ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root)
        if not path.is_file() or any(part in excluded for part in relative.parts):
            continue
        if path.name == ".env" or path.suffix in {".pyc", ".tsbuildinfo"} or str(relative) == "frontend/public/sw.js":
            continue
        archive.write(path, Path("jam-phase1") / relative)
print(output)
