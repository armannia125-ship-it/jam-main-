"use client";

/* =========================================================
   جم لایف — باشگاه خرید حضوری (/club)
   فهرست فقط از API عمومی باشگاه خوانده می‌شود؛ فروشگاه بدون
   عضویت فعال نمایش داده نمی‌شود و اطلاعات خصوصی برنمی‌گردد.
   ========================================================= */

import Link from "next/link";
import { usePublicClubStores } from "@/lib/commerce";
import { RvHeading, RvNote } from "@/components/features/rv-parts";

export default function ClubPage() {
  const { data, loading, error, refresh } = usePublicClubStores();

  return (
    <div className="container rv">
      <RvHeading
        over="باشگاه خرید حضوری"
        title="فروشگاه‌های عضو باشگاه جم لایف"
        text="از فروشگاه عضو خرید کن، کدت را نشان بده و بعد از تأیید خرید، پاداش بگیر."
      />
      <RvNote>
        عضویت و کد خرید سمت سرور ثبت می‌شود. کد یک‌بارمصرف است و فقط پس از تأیید فروشنده خرید محسوب می‌شود.
      </RvNote>

      {loading ? <p className="rv-empty">در حال دریافت فروشگاه‌های باشگاه…</p> : null}
      {error ? (
        <section className="rv-card">
          <p className="c7-error" role="alert">{error}</p>
          <button type="button" className="btn btn-ghost" onClick={() => refresh()}>تلاش دوباره</button>
        </section>
      ) : null}

      <div className="c7-club-grid">
        {data.length ? (
          data.map((s) => (
            <article className="rv-card" key={s.id}>
              <span className="c7-tag">عضو باشگاه</span>
              <h2>{s.name}</h2>
              <p>{s.offer || "پیشنهادهای فعال و شرایط پاداش را پیش از خرید بررسی کن."}</p>
              <Link className="btn btn-primary" href={`/visit/${s.id}`}>
                خرید حضوری و دریافت کد
              </Link>
              <Link className="c7-text-link" href={`/m/${s.slug}`}>
                ویترین فروشگاه
              </Link>
            </article>
          ))
        ) : (
          !loading && !error ? (
            <section className="rv-card">
              <h2>هنوز عضوی فعال نشده است.</h2>
              <p>فروشگاه‌ها پس از پذیرش شرایط و فعال‌شدن عضویت در این فهرست نمایش داده می‌شوند.</p>
              <Link className="btn btn-ghost" href="/panel/plan">
                فعال‌سازی باشگاه فروشگاه من
              </Link>
            </section>
          ) : null
        )}
      </div>
    </div>
  );
}
