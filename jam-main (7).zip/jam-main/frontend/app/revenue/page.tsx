"use client";

/* =========================================================
   جم لایف — مرکز درآمد (/revenue)
   تعرفه، کمیسیون، صورتحساب، کمپین، تبلیغ و محدودهٔ شروع از API
   سرور خوانده می‌شوند. نرخ هر سفارش هنگام ثبت روی سرور ثابت
   می‌شود و ارسال مشمول کمیسیون نیست.
   ========================================================= */

import { Suspense, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { CATS, STATUS } from "@/lib/data";
import { fa } from "@/lib/format";
import { useJam } from "@/lib/state";
import { money, rateOf, useCommerce, useRevenue, useSellerOrders } from "@/lib/commerce";
import { RvHeading, RvNote, RvField } from "@/components/features/rv-parts";

function RevenueCenter() {
  const sp = useSearchParams();
  const router = useRouter();
  const { toast } = useJam();
  const { businesses, sid: defaultSid } = useCommerce();
  const querySid = Number(sp.get("sid"));
  const sid = businesses.some((b) => b.id === querySid) ? querySid : defaultSid;
  const revenue = useRevenue(sid);
  const orders = useSellerOrders(sid);
  const data = revenue.data;
  const config = data?.config;

  const [rate, setRate] = useState("");
  const [monthly, setMonthly] = useState("");
  const [area, setArea] = useState("");
  const [camForm, setCamForm] = useState({ title: "پاداش خرید بعدی", budget: "1000000", pct: "5", cap: "10000", min: "200000", days: "7", seller: "70", platform: "20", brand: "10" });
  const [camErr, setCamErr] = useState("");
  const [adForm, setAdForm] = useState({ title: "نمایش ویژه در خانه", budget: "500000", days: "7", placement: "home" });
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!config) return;
    setRate(String(rateOf(config.commission_rate)));
    setMonthly(String(config.monthly_fee_toman));
  }, [config]);

  useEffect(() => {
    if (data) setArea(data.launch.area);
  }, [data?.launch.area]);

  const summary = data?.summary;
  const invoices = data?.invoices || [];
  const campaigns = data?.campaigns || [];
  const ads = data?.ads || [];

  return (
    <div className="container rv">
      <RvHeading
        over="مرکز درآمد · دادهٔ سرور"
        title="مرکز درآمد جم لایف"
        text="اشتراک خدمات، کمیسیون پرداخت آنلاین و تبلیغات اختیاری. همهٔ ارقام از سرور خوانده می‌شوند و واریز واقعی در این نسخه وجود ندارد."
      />
      <RvNote>
        نرخ هر سفارش هنگام ثبت ثابت می‌شود. کمیسیون فقط از بهای کالا پس از تخفیف محاسبه می‌شود و هزینهٔ ارسال مشمول کمیسیون نیست.
      </RvNote>
      <nav className="rv-links">
        <Link href="/panel/plan">پلن و راه‌اندازی</Link>
        <Link href="/panel/agreement">پذیرش آنلاین</Link>
        <Link href="/panel/settlement">دفتر تسهیم</Link>
        <Link href="/business">صفحهٔ همکاری</Link>
      </nav>

      {revenue.loading ? <p className="rv-empty">در حال دریافت اطلاعات درآمد…</p> : null}
      {revenue.error ? (
        <section className="rv-card">
          <p className="c7-error" role="alert">{revenue.error}</p>
          <button type="button" className="btn btn-ghost" onClick={() => revenue.refresh()}>تلاش دوباره</button>
        </section>
      ) : null}

      {data && config ? (
        <>
          <section className="rv-card">
            <h2>تعرفهٔ فروشگاه</h2>
            <label className="rv-field">
              <span>فروشگاه</span>
              <select
                id="rv-store"
                value={sid ?? ""}
                onChange={(e) => router.replace(`/revenue?sid=${e.target.value}`)}
              >
                {businesses.map((s) => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </label>
            <form
              id="rv-config"
              onSubmit={async (e) => {
                e.preventDefault();
                const r = Number(en(rate));
                const m = Number(en(monthly));
                if (!Number.isFinite(r) || r < 0 || r > 30) return;
                setBusy(true);
                try {
                  await revenue.saveConfig({ commission_rate: r, monthly_fee_toman: m });
                  toast("تعرفه ذخیره شد؛ نرخ تازه فقط برای سفارش‌های بعدی اعمال می‌شود.");
                } catch (x) {
                  toast((x as Error).message, "err");
                } finally {
                  setBusy(false);
                }
              }}
            >
              <div className="rv-form">
                <RvField id="rate" label="نرخ کمیسیون آنلاین ٪ · فقط کالا" value={rate} onChange={setRate} extra={{ min: 0, max: 30, step: 0.5 }} />
                <RvField id="monthly" label="اشتراک ماهانه" value={monthly} onChange={setMonthly} extra={{ min: 0, max: 100000000, step: 1000 }} />
              </div>
              <button className="btn btn-primary" type="submit" disabled={busy}>
                {busy ? "در حال ذخیره…" : "ذخیرهٔ تعرفه"}
              </button>
            </form>
            <p className="rv-small">نرخ سفارش‌های قبلی تغییر نمی‌کند و تاریخچهٔ تغییر نرخ در سرور ثبت می‌شود.</p>
          </section>

          <section className="rv-card">
            <h2>کمیسیون و صورتحساب</h2>
            <div className="rv-grid">
              <div className="rv-card">
                <span>کمیسیون سفارش‌های تحویل‌شده</span>
                <strong>{money(summary?.commission_earned_toman || 0)}</strong>
              </div>
              <div className="rv-card">
                <span>صورتحساب‌های پرداخت‌شده · آزمایشی</span>
                <strong>{money(summary?.invoices_paid_toman || 0)}</strong>
              </div>
              <div className="rv-card">
                <span>سفارش واجد کمیسیون</span>
                <strong>{fa(summary?.commissionable_orders || 0)}</strong>
              </div>
              <div className="rv-card">
                <span>سهم واجد شرایط تسویه · واریزنشده</span>
                <strong>{money(summary?.settlement_eligible_toman || 0)}</strong>
              </div>
            </div>
          </section>

          <section className="rv-card">
            <h2>دفتر سفارش‌ها</h2>
            {orders.loading ? <p className="rv-empty">در حال دریافت سفارش‌ها…</p> : null}
            {orders.error ? <p className="c7-error" role="alert">{orders.error}</p> : null}
            {orders.orders.length ? (
              orders.orders.map((o) => (
                <div className="rv-line" key={o.number}>
                  <div>
                    <b dir="ltr">{o.number}</b>
                    <small>
                      {STATUS[o.status]?.short || o.status} · نرخ ثبت‌شده {o.commission_rate ? Number(o.commission_rate).toLocaleString("fa-IR") : "۰"}٪
                    </small>
                  </div>
                  <span>مبنای کالا {money(o.goods_total_toman)}</span>
                  <b>{money(o.commission_amount_toman || 0)}</b>
                  {o.status === "done" && o.payment_state === "paid" ? (
                    <button
                      type="button"
                      className="btn btn-ghost"
                      onClick={async () => {
                        if (!window.confirm("ثبت مرجوعی؟ رکورد مالی حفظ می‌شود و برگشت سهم‌ها ثبت خواهد شد.")) return;
                        try {
                          await orders.setStatus(o.number, "refunded");
                          await revenue.refresh();
                          toast("مرجوعی ثبت شد؛ سابقهٔ مالی حفظ شده است.");
                        } catch (x) {
                          toast((x as Error).message, "err");
                        }
                      }}
                    >
                      ثبت مرجوعی
                    </button>
                  ) : null}
                </div>
              ))
            ) : (
              !orders.loading ? <p className="rv-empty">سفارشی ثبت نشده است.</p> : null
            )}
          </section>

          <section className="rv-card">
            <h2>صورت‌حساب‌های راه‌اندازی و تبلیغات</h2>
            {invoices.length ? (
              invoices.map((i) => {
                const paid = i.status === "simulated_paid" || i.status === "paid";
                return (
                  <div className="rv-line" key={i.id}>
                    <div>
                      <b>{i.title}</b>
                      <small>
                        {paid
                          ? "پرداخت‌شده"
                          : i.status === "canceled"
                            ? "لغوشده"
                            : "پرداخت‌نشده"}
                      </small>
                    </div>
                    <b>{money(i.amount_toman)}</b>
                  </div>
                );
              })
            ) : (
              <p className="rv-empty">هنوز درخواستی ثبت نشده است.</p>
            )}
          </section>

          <section className="rv-card">
            <h2>کمپین‌ها و تعهد بودجه</h2>
            {campaigns.length ? (
              campaigns.map((cp) => {
                const activeNow = cp.is_active && (!cp.ends_at || new Date(cp.ends_at).getTime() > Date.now());
                const label = activeNow ? "فعال · آزمایشی" : cp.is_funded ? "تأمین‌شده · متوقف" : "پیش‌نویس · بدون تأمین بودجه";
                return (
                  <article className="rv-card" key={cp.id}>
                    <span className="rv-label">{label}</span>
                    <h3>{cp.title}</h3>
                    <p>{fa(cp.discount_pct)}٪ تا {money(cp.cap_toman)} · حداقل خرید {money(cp.min_purchase_toman)} · {fa(cp.days)} روز</p>
                    <p>بودجه {money(cp.budget_toman)}</p>
                    <p>فروشگاه {fa(cp.seller_share_pct)}٪ / جم لایف {fa(cp.platform_share_pct)}٪ / حامی {fa(cp.brand_share_pct)}٪</p>
                    <button
                      type="button"
                      className="btn btn-ghost"
                      onClick={async () => {
                        try {
                          await revenue.toggleCampaign(cp.id);
                          toast(cp.is_active ? "صدور کد متوقف شد." : "انتشار آزمایشی ثبت شد.");
                        } catch (x) {
                          toast((x as Error).message, "err");
                        }
                      }}
                    >
                      {cp.is_active ? "توقف صدور کد" : "تأیید تأمین و انتشار آزمایشی"}
                    </button>
                  </article>
                );
              })
            ) : (
              <p className="rv-empty">کمپینی ندارید. با یک بودجهٔ کوچک و سقف روشن شروع کنید.</p>
            )}
            <form
              id="rv-campaign"
              className="rv-card"
              onSubmit={async (e) => {
                e.preventDefault();
                setCamErr("");
                try {
                  await revenue.addCampaign({
                    title: camForm.title.trim(),
                    budget_toman: Number(en(camForm.budget)),
                    discount_pct: Number(en(camForm.pct)),
                    cap_toman: Number(en(camForm.cap)),
                    min_purchase_toman: Number(en(camForm.min)),
                    days: Number(en(camForm.days)),
                    seller_share_pct: Number(en(camForm.seller)),
                    platform_share_pct: Number(en(camForm.platform)),
                    brand_share_pct: Number(en(camForm.brand)),
                    service_fee_toman: 0,
                  });
                  toast("پیش‌نویس کمپین ذخیره شد؛ انتشار پس از تأیید تأمین بودجه است.");
                } catch (x) {
                  setCamErr((x as Error).message);
                }
              }}
            >
              <h3>کمپین خرید + بازی</h3>
              <p className="rv-small">همهٔ مبلغ‌ها تومان‌اند. سهم‌ها باید جمعاً ۱۰۰٪ باشند؛ بودجه ثبت حسابداری واقعی نیست.</p>
              <div className="rv-form">
                <RvField id="c-title" label="نام کمپین" type="text" value={camForm.title} onChange={(v) => setCamForm({ ...camForm, title: v })} extra={{ maxLength: 60 }} />
                <RvField id="c-budget" label="کل بودجهٔ تخفیف" value={camForm.budget} onChange={(v) => setCamForm({ ...camForm, budget: v })} extra={{ min: 1000, max: 1000000000, step: 1000 }} />
                <RvField id="c-pct" label="درصد تخفیف" value={camForm.pct} onChange={(v) => setCamForm({ ...camForm, pct: v })} extra={{ min: 5, max: 15, step: 5 }} />
                <RvField id="c-cap" label="سقف هر کد" value={camForm.cap} onChange={(v) => setCamForm({ ...camForm, cap: v })} extra={{ min: 1000, max: 90000, step: 1000 }} />
                <RvField id="c-min" label="حداقل خرید مبنا" value={camForm.min} onChange={(v) => setCamForm({ ...camForm, min: v })} extra={{ min: 1000, max: 1000000000, step: 1000 }} />
                <RvField id="c-days" label="اعتبار کمپین · روز" value={camForm.days} onChange={(v) => setCamForm({ ...camForm, days: v })} extra={{ min: 1, max: 90 }} />
                <RvField id="c-seller" label="سهم فروشگاه ٪" value={camForm.seller} onChange={(v) => setCamForm({ ...camForm, seller: v })} extra={{ min: 0, max: 100 }} />
                <RvField id="c-platform" label="سهم جم لایف ٪" value={camForm.platform} onChange={(v) => setCamForm({ ...camForm, platform: v })} extra={{ min: 0, max: 100 }} />
                <RvField id="c-brand" label="سهم حامی ٪" value={camForm.brand} onChange={(v) => setCamForm({ ...camForm, brand: v })} extra={{ min: 0, max: 100 }} />
              </div>
              <p className="rv-error" role="alert">{camErr}</p>
              <button className="btn btn-primary" type="submit">ذخیرهٔ پیش‌نویس کمپین</button>
            </form>
          </section>

          <section className="rv-card">
            <h2>تبلیغات اختیاری</h2>
            {ads.length ? (
              ads.map((ad) => (
                <div className="rv-line" key={ad.id}>
                  <div>
                    <b>{ad.title}</b>
                    <small>{ad.placement === "home" ? "صفحهٔ خانه" : "مأموریت"} · {fa(ad.days)} روز · {money(ad.budget_toman)}</small>
                  </div>
                  <span>{ad.is_active ? "فعال" : "متوقف"}</span>
                  <button type="button" className="btn btn-ghost" onClick={async () => {
                    try {
                      await revenue.toggleAd(ad.id);
                    } catch (x) {
                      toast((x as Error).message, "err");
                    }
                  }}>
                    {ad.is_active ? "توقف" : "فعال‌سازی"}
                  </button>
                </div>
              ))
            ) : (
              <p className="rv-empty">تبلیغی ثبت نشده است.</p>
            )}
            <form
              className="rv-card"
              onSubmit={async (e) => {
                e.preventDefault();
                try {
                  await revenue.addAd({
                    title: adForm.title.trim(),
                    budget_toman: Number(en(adForm.budget)),
                    days: Number(en(adForm.days)),
                    placement: adForm.placement,
                  });
                  toast("تبلیغ ثبت شد؛ پرداخت واقعی انجام نشده است.");
                } catch (x) {
                  toast((x as Error).message, "err");
                }
              }}
            >
              <h3>تبلیغ جدید</h3>
              <div className="rv-form">
                <RvField id="ad-title" label="عنوان" type="text" value={adForm.title} onChange={(v) => setAdForm({ ...adForm, title: v })} extra={{ maxLength: 80 }} />
                <RvField id="ad-budget" label="بودجه" value={adForm.budget} onChange={(v) => setAdForm({ ...adForm, budget: v })} extra={{ min: 1000, step: 1000 }} />
                <RvField id="ad-days" label="مدت · روز" value={adForm.days} onChange={(v) => setAdForm({ ...adForm, days: v })} extra={{ min: 1, max: 90 }} />
              </div>
              <button className="btn btn-ghost" type="submit">ثبت تبلیغ</button>
            </form>
          </section>

          <form
            id="rv-launch"
            className="rv-card"
            onSubmit={async (e) => {
              e.preventDefault();
              try {
                await revenue.saveLaunch(area, data.launch.category);
                toast("محدودهٔ شروع ذخیره شد.");
              } catch (x) {
                toast((x as Error).message, "err");
              }
            }}
          >
            <h2>محدودهٔ آزمایش اولیه</h2>
            <div className="rv-form">
              <RvField id="rv-area" label="نام محدودهٔ شروع" type="text" value={area} onChange={setArea} extra={{ maxLength: 80 }} />
              <label className="rv-field">
                <span>گروه شروع</span>
                <select
                  name="category"
                  value={data.launch.category}
                  onChange={async (e) => {
                    try {
                      await revenue.saveLaunch(data.launch.area, e.target.value);
                    } catch (x) {
                      toast((x as Error).message, "err");
                    }
                  }}
                >
                  {CATS.map((cat) => (
                    <option key={cat.id} value={cat.id}>{cat.name}</option>
                  ))}
                </select>
              </label>
            </div>
            <button type="submit" className="btn btn-ghost">ذخیرهٔ برنامهٔ شروع</button>
          </form>

          <section className="rv-card">
            <h2>تاریخچهٔ تغییر نرخ کمیسیون</h2>
            {data.commission_history.length ? (
              data.commission_history.map((h) => (
                <div className="rv-line" key={h.id}>
                  <div>
                    <b>{Number(h.rate).toLocaleString("fa-IR")}٪</b>
                    <small>{h.basis === "goods_only" ? "مبنای کالا" : h.basis} · {new Date(h.created_at).toLocaleString("fa-IR")}</small>
                  </div>
                  <span>{h.note || "—"}</span>
                </div>
              ))
            ) : (
              <p className="rv-empty">هنوز تغییری ثبت نشده است.</p>
            )}
          </section>

          <section className="rv-card">
            <h2>پیش از راه‌اندازی واقعی</h2>
            <p>
              قرارداد و نرخ توافقی، احراز هویت فروشنده، درگاه پرداخت، حسابداری سمت سرور، تأیید تحویل و مرجوعی، پیشگیری از
              چندحسابی و کنترل دسترسی. بودجهٔ حامی بدون قرارداد واقعی تأمین‌شده محسوب نمی‌شود. نرخ هر سفارش هنگام ثبت ذخیره
              می‌شود و تغییر نرخ، سفارش‌های قبلی را تغییر نمی‌دهد.
            </p>
          </section>
        </>
      ) : null}
    </div>
  );
}

function en(s: string) {
  return s.replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d))).replace(/,/g, "");
}

export default function RevenuePage() {
  return (
    <Suspense fallback={null}>
      <RevenueCenter />
    </Suspense>
  );
}
