import { notFound } from "next/navigation";
import { StorePage } from "@/components/features/store-page";
import { store } from "@/lib/data";
import { isDemoMode } from "@/lib/demo";

type PageProps = {
  params: Promise<{ id: string }>;
};

export default async function StoreDetailsPage({ params }: PageProps) {
  const { id } = await params;
  if (!isDemoMode()) {
    notFound();
  }
  const s = store(id);

  if (!s) {
    notFound();
  }

  return <StorePage storeId={s.id} />;
}
