import { SearchPage } from "@/components/features/search-page";
import { RealCatalogSearch } from "@/components/features/real-search";
import { isDemoMode } from "@/lib/demo";

export default function SearchRoute() {
  return isDemoMode() ? <SearchPage /> : <RealCatalogSearch />;
}
