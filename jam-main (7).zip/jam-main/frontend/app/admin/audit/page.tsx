"use client";
/* گزارش حسابرسی — اقدامات مدیریتی ثبت‌شدهٔ سرور با فیلتر نوع عمل؛
   فقط سوابق واقعی، بدون امکان ویرایش یا حذف. */

import { useCallback, useEffect, useState } from "react";
import AdminShell from "@/components/features/admin-shell";
import { ApiError, apiFetch } from "@/lib/api";
import { fa, fmtDate } from "@/lib/format";
import Ic from "@/components/icons";

type AuditRow = {
  id: number;
  actor: { id: number; name: string; phone: string | null } | null;
  action: string;
  target_type: string;
  target_id: number | string;
  metadata: unknown;
  created_at: string;
};

const ACTION_FILTERS: [string, string][] = [
  ["", "همه"],
  ["admin_promoted", "ارتقا به مدیر"],
  ["admin_demoted", "حذف نقش مدیر"],
  ["entitlement_revoked", "لغو اعتبار"],
  ["purchase_marked_failed", "ثبت خرید ناموفق"],
];

const ACTION_LABELS: Record<string, string> = {
  admin_promoted: "ارتقای کاربر به مدیر",
  admin_demoted: "حذف نقش مدیر",
  entitlement_revoked: "لغو اعتبار اشتراک",
  payment_inspected: "بازرسی پرداخت",
  purchase_marked_failed: "ثبت خرید ناموفق",
};

function fmtMeta(meta: unknown): string {
  if (meta === null || meta === undefined) return "—";
  try {
    return JSON.stringify(meta);
  } catch {
    return "—";
  }
}

function AuditInner() {
  const [rows, setRows] = useState<AuditRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [denied, setDenied] = useState(false);
  const [action, setAction] = useState("");

  const load = useCallback(async (actionFilter: string) => {
    setLoading(true);
    setError(null);
    setDenied(false);
    try {
      const search = new URLSearchParams();
      if (actionFilter) search.set("action", actionFilter);
      search.set("limit", "100");
      const res = await apiFetch<{ results: AuditRow[] }>(`/admin/audit/?${search.toString()}`);
      setRows(res.results || []);
    } catch (err) {
      if (err instanceof ApiError && err.status === 403) setDenied(true);
      else setError(err instanceof ApiError ? err.message : "دریافت گزارش حسابرسی ناموفق بود.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load("");
  }, [load]);

  if (denied) {
    return (
      <section className="rv-card">
        <span className="pill red">۴۰۳</span>
        <h2 style={{ marginTop: 12 }}>دسترسی مجاز نیست</h2>
        <p>سرور این درخواست مدیریتی را رد کرد.</p>
      </section>
    );
  }

  return (
    <section className="rv-card">
      <h2>گزارش حسابرسی</h2>
      <form
        className="rv-form"
        onSubmit={(e) => {
          e.preventDefault();
          load(action);
        }}
      >
        <label className="rv-field" htmlFor="admin-audit-action">
          <span>نوع عمل</span>
          <select id="admin-audit-action" value={action} onChange={(e) => setAction(e.target.value)}>
            {ACTION_FILTERS.map(([value, label]) => (
              <option key={value || "all"} value={value}>
                {label}
              </option>
            ))}
          </select>
        </label>
        <div style={{ display: "flex", alignItems: "end", gap: 8 }}>
          <button className="btn btn-primary" type="submit">
            <Ic n="search" c="sm" /> اعمال فیلتر
          </button>
          <button
            type="button"
            className="btn btn-ghost"
            onClick={() => {
              setAction("");
              load("");
            }}
          >
            همه
          </button>
        </div>
      </form>

      {loading ? <p className="rv-empty">در حال دریافت گزارش…</p> : null}
      {error ? (
        <p className="c7-error" role="alert">
          {error}
        </p>
      ) : null}

      {!loading && rows.length === 0 && !error ? (
        <p className="rv-empty">رکوردی مطابق فیلتر پیدا نشد.</p>
      ) : null}

      {rows.length > 0 ? (
        <div className="tbl-wrap">
          <table className="tbl">
            <thead>
              <tr>
                <th>شناسه</th>
                <th>عامل</th>
                <th>عمل</th>
                <th>هدف</th>
                <th>جزئیات</th>
                <th>تاریخ</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((a) => (
                <tr key={a.id}>
                  <td className="tnum">{fa(a.id)}</td>
                  <td>{a.actor?.name || "—"}</td>
                  <td>{ACTION_LABELS[a.action] || a.action}</td>
                  <td dir="ltr">
                    {a.target_type}:{a.target_id}
                  </td>
                  <td dir="ltr" style={{ maxWidth: 320, overflowWrap: "anywhere" }}>
                    {fmtMeta(a.metadata)}
                  </td>
                  <td>{fmtDate(a.created_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}
    </section>
  );
}

export default function AdminAuditPage() {
  return (
    <AdminShell>
      <AuditInner />
    </AdminShell>
  );
}
