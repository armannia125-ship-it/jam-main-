"use client";
/* مدیریت پرداخت‌ها — فیلتر وضعیت + جست‌وجو + جدول؛ مبالغ صحیح
   تومان‌اند و هیچ تأیید دستی پرداخت در این صفحه وجود ندارد. */

import { useCallback, useEffect, useState } from "react";
import AdminShell from "@/components/features/admin-shell";
import { ApiError, apiFetch } from "@/lib/api";
import { fa, fmtDate } from "@/lib/format";
import Ic from "@/components/icons";

type AdminPayment = {
  id: number;
  user: { id: number; name: string; phone: string | null } | null;
  target: string;
  product: string | null;
  amount_toman: number;
  gateway: string;
  status: string;
  ref_id: string | null;
  created_at: string;
};

const STATUS_FILTERS: [string, string][] = [
  ["", "همه"],
  ["initiated", "در انتظار"],
  ["success", "موفق"],
  ["failed", "ناموفق"],
];

const STATUS_LABELS: Record<string, string> = {
  initiated: "در انتظار",
  success: "موفق",
  failed: "ناموفق",
};

function statusPill(status: string) {
  if (status === "success") return "pill green";
  if (status === "failed") return "pill red";
  return "pill amber";
}

function PaymentsInner() {
  const [rows, setRows] = useState<AdminPayment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [denied, setDenied] = useState(false);
  const [status, setStatus] = useState("");
  const [q, setQ] = useState("");

  const load = useCallback(async (statusFilter: string, query: string) => {
    setLoading(true);
    setError(null);
    setDenied(false);
    try {
      const search = new URLSearchParams();
      if (statusFilter) search.set("status", statusFilter);
      if (query.trim()) search.set("q", query.trim());
      search.set("limit", "50");
      const res = await apiFetch<{ results: AdminPayment[] }>(`/admin/payments/?${search.toString()}`);
      setRows(res.results || []);
    } catch (err) {
      if (err instanceof ApiError && err.status === 403) setDenied(true);
      else setError(err instanceof ApiError ? err.message : "دریافت پرداخت‌ها ناموفق بود.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load("", "");
  }, [load]);

  if (denied) {
    return (
      <section className="rv-card">
        <span className="pill red">۴۰۳</span>
        <h2 style={{ marginTop: 12 }}>دسترسی مجاز نیست</h2>
        <p>سرور این درخواست مدیریتی را رد کرد.</p>
      </section>
    );
  }

  return (
    <>
      <section className="rv-card">
        <h2>پرداخت‌ها</h2>
        <p className="p-sub">
          وضعیت پرداخت فقط از سمت درگاه و سرور معتبر است؛ هیچ تأیید یا تغییر دستی پرداخت در این صفحه
          انجام نمی‌شود.
        </p>

        <form
          className="rv-form"
          onSubmit={(e) => {
            e.preventDefault();
            load(status, q);
          }}
        >
          <label className="rv-field" htmlFor="admin-pay-q">
            <span>جست‌وجو (شناسهٔ مرجع یا کدauthority)</span>
            <input
              id="admin-pay-q"
              type="search"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="مثلاً ref یا authority"
            />
          </label>
          <label className="rv-field" htmlFor="admin-pay-status">
            <span>وضعیت</span>
            <select id="admin-pay-status" value={status} onChange={(e) => setStatus(e.target.value)}>
              {STATUS_FILTERS.map(([value, label]) => (
                <option key={value || "all"} value={value}>
                  {label}
                </option>
              ))}
            </select>
          </label>
          <div style={{ display: "flex", alignItems: "end", gap: 8 }}>
            <button className="btn btn-primary" type="submit">
              <Ic n="search" c="sm" /> اعمال فیلتر
            </button>
            <button
              type="button"
              className="btn btn-ghost"
              onClick={() => {
                setStatus("");
                setQ("");
                load("", "");
              }}
            >
              حذف فیلترها
            </button>
          </div>
        </form>

        {loading ? <p className="rv-empty">در حال دریافت پرداخت‌ها…</p> : null}
        {error ? (
          <p className="c7-error" role="alert">
            {error}
          </p>
        ) : null}

        {!loading && rows.length === 0 && !error ? (
          <p className="rv-empty">پرداختی مطابق فیلترها پیدا نشد.</p>
        ) : null}

        {rows.length > 0 ? (
          <div className="tbl-wrap">
            <table className="tbl">
              <thead>
                <tr>
                  <th>شناسه</th>
                  <th>کاربر</th>
                  <th>مقصد</th>
                  <th>اشتراک</th>
                  <th>مبلغ (تومان)</th>
                  <th>درگاه</th>
                  <th>وضعیت</th>
                  <th>مرجع</th>
                  <th>تاریخ</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((t) => (
                  <tr key={t.id}>
                    <td className="tnum">{fa(t.id)}</td>
                    <td>{t.user?.name || "—"}</td>
                    <td dir="ltr">{t.target}</td>
                    <td>{t.product || "—"}</td>
                    <td className="tnum">{fa(t.amount_toman)}</td>
                    <td>{t.gateway}</td>
                    <td>
                      <span className={statusPill(t.status)}>{STATUS_LABELS[t.status] || t.status}</span>
                    </td>
                    <td dir="ltr">{t.ref_id || "—"}</td>
                    <td>{fmtDate(t.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : null}
      </section>
    </>
  );
}

export default function AdminPaymentsPage() {
  return (
    <AdminShell>
      <PaymentsInner />
    </AdminShell>
  );
}
