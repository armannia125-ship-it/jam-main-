"use client";
/* مدیریت مدیران — فهرست مدیران فعلی (فیلتر سمت کلاینت از فهرست
   کاربران) و ارتقای کاربر با جست‌وجو؛ خطای «آخرین مدیر» صادقانه از
   سرور نمایش داده می‌شود. */

import { useCallback, useEffect, useState } from "react";
import AdminShell from "@/components/features/admin-shell";
import { ApiError, apiFetch } from "@/lib/api";
import { fmtDate } from "@/lib/format";
import Ic from "@/components/icons";

type AdminUser = {
  id: number;
  name: string;
  phone: string | null;
  email: string | null;
  role: string;
  is_active: boolean;
  date_joined: string;
};

function AdminsInner() {
  const [rows, setRows] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [denied, setDenied] = useState(false);

  const [q, setQ] = useState("");
  const [searched, setSearched] = useState<AdminUser[] | null>(null);
  const [searchLoading, setSearchLoading] = useState(false);

  const [actionMsg, setActionMsg] = useState<string | null>(null);
  const [actionOk, setActionOk] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    setDenied(false);
    try {
      const res = await apiFetch<{ results: AdminUser[] }>("/admin/users/?limit=200");
      setRows(res.results || []);
    } catch (err) {
      if (err instanceof ApiError && err.status === 403) setDenied(true);
      else setError(err instanceof ApiError ? err.message : "دریافت فهرست کاربران ناموفق بود.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const admins = rows.filter((u) => u.role === "admin");

  const searchUsers = async (e: React.FormEvent) => {
    e.preventDefault();
    setSearchLoading(true);
    setSearched(null);
    setActionMsg(null);
    setActionOk(null);
    try {
      const search = new URLSearchParams();
      if (q.trim()) search.set("q", q.trim());
      search.set("limit", "50");
      const res = await apiFetch<{ results: AdminUser[] }>(`/admin/users/?${search.toString()}`);
      setSearched(res.results || []);
    } catch (err) {
      setActionMsg(err instanceof ApiError ? err.message : "جست‌وجوی کاربران ناموفق بود.");
    } finally {
      setSearchLoading(false);
    }
  };

  const changeRole = async (id: number, action: "promote" | "demote") => {
    const target = rows.find((r) => r.id === id) || searched?.find((r) => r.id === id);
    const ok = window.confirm(
      action === "promote"
        ? `نقش «${target?.name || id}» به مدیر ارتقا یابد؟`
        : `نقش مدیر «${target?.name || id}» حذف شود؟`,
    );
    if (!ok) return;
    setBusy(true);
    setActionMsg(null);
    setActionOk(null);
    try {
      const res = await apiFetch<{ detail: string }>(`/admin/users/${id}/role/${action}/`, {
        method: "POST",
        body: {},
      });
      setActionOk(res.detail || "تغییر نقش انجام شد.");
      setSearched(null);
      setQ("");
      await load();
    } catch (err) {
      setActionMsg(err instanceof ApiError ? err.message : "تغییر نقش ناموفق بود.");
    } finally {
      setBusy(false);
    }
  };

  if (denied) {
    return (
      <section className="rv-card">
        <span className="pill red">۴۰۳</span>
        <h2 style={{ marginTop: 12 }}>دسترسی مجاز نیست</h2>
        <p>سرور این درخواست مدیریتی را رد کرد.</p>
      </section>
    );
  }

  return (
    <>
      <section className="rv-card">
        <h2>مدیران فعلی</h2>
        {loading ? <p className="rv-empty">در حال دریافت فهرست مدیران…</p> : null}
        {error ? (
          <p className="c7-error" role="alert">
            {error}
          </p>
        ) : null}
        {!loading && admins.length === 0 && !error ? (
          <p className="rv-empty">مدیری یافت نشد.</p>
        ) : null}
        {admins.length > 0 ? (
          <div className="tbl-wrap">
            <table className="tbl">
              <thead>
                <tr>
                  <th>نام</th>
                  <th>شماره</th>
                  <th>وضعیت</th>
                  <th>عضویت</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {admins.map((u) => (
                  <tr key={u.id}>
                    <td>{u.name || "—"}</td>
                    <td dir="ltr" className="tnum">
                      {u.phone || "—"}
                    </td>
                    <td>
                      <span className={u.is_active ? "pill green" : "pill red"}>
                        {u.is_active ? "فعال" : "غیرفعال"}
                      </span>
                    </td>
                    <td>{fmtDate(u.date_joined)}</td>
                    <td>
                      <button
                        type="button"
                        className="btn btn-sm btn-danger"
                        disabled={busy}
                        onClick={() => changeRole(u.id, "demote")}
                      >
                        حذف نقش مدیر
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : null}
        <p className="c7-small">
          حذف نقش آخرین مدیر فعال از سمت سرور مسدود است؛ در این حالت پیام خطای سرور نمایش داده
          می‌شود.
        </p>
      </section>

      <section className="rv-card">
        <h2>ارتقای کاربر به مدیر</h2>
        <form className="rv-form" onSubmit={searchUsers}>
          <label className="rv-field" htmlFor="admin-promote-q">
            <span>جست‌وجوی کاربر (نام، شماره، ایمیل)</span>
            <input
              id="admin-promote-q"
              type="search"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="مثلاً ۰۹۱۲ یا نام"
            />
          </label>
          <div style={{ display: "flex", alignItems: "end", gap: 8 }}>
            <button className="btn btn-primary" type="submit">
              <Ic n="search" c="sm" /> جست‌وجو
            </button>
          </div>
        </form>

        {searchLoading ? <p className="rv-empty">در حال جست‌وجو…</p> : null}

        {searched ? (
          searched.filter((u) => u.role !== "admin").length === 0 ? (
            <p className="rv-empty">کاربر عادیِ مطابق جست‌وجو پیدا نشد.</p>
          ) : (
            <div className="tbl-wrap">
              <table className="tbl">
                <thead>
                  <tr>
                    <th>نام</th>
                    <th>شماره</th>
                    <th>نقش</th>
                    <th>وضعیت</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {searched
                    .filter((u) => u.role !== "admin")
                    .map((u) => (
                      <tr key={u.id}>
                        <td>{u.name || "—"}</td>
                        <td dir="ltr" className="tnum">
                          {u.phone || "—"}
                        </td>
                        <td>
                          <span className="pill gray">کاربر</span>
                        </td>
                        <td>
                          <span className={u.is_active ? "pill green" : "pill red"}>
                            {u.is_active ? "فعال" : "غیرفعال"}
                          </span>
                        </td>
                        <td>
                          <button
                            type="button"
                            className="btn btn-sm btn-primary"
                            disabled={busy || !u.is_active}
                            onClick={() => changeRole(u.id, "promote")}
                          >
                            ارتقا به مدیر
                          </button>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          )
        ) : null}

        {actionMsg ? (
          <p className="c7-error" role="alert">
            {actionMsg}
          </p>
        ) : null}
        {actionOk ? <p className="c7-small">{actionOk}</p> : null}
      </section>
    </>
  );
}

export default function AdminAdminsPage() {
  return (
    <AdminShell>
      <AdminsInner />
    </AdminShell>
  );
}
