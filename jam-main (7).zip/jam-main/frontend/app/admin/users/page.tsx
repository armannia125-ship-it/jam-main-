"use client";
/* مدیریت کاربران — جست‌وجو، جزئیات کاربر (کسب‌وکار، اعتبار، خرید،
   پرداخت) و ارتقا/تنزل نقش با تأیید و نمایش صادقانهٔ خطای سرور. */

import { useCallback, useEffect, useState } from "react";
import AdminShell from "@/components/features/admin-shell";
import { ApiError, apiFetch } from "@/lib/api";
import { fa, fmtDate } from "@/lib/format";
import { ENTITLEMENT_TYPE_LABELS } from "@/lib/subscriptions-api";
import Ic from "@/components/icons";

type AdminUser = {
  id: number;
  name: string;
  phone: string | null;
  email: string | null;
  role: string;
  is_active: boolean;
  date_joined: string;
};

type UserDetail = {
  user: AdminUser;
  businesses: { id: number; name: string; slug: string }[];
  entitlements: {
    id: number;
    business: string;
    type: string;
    product: string;
    status: string;
    starts_at: string | null;
    ends_at: string | null;
  }[];
  purchases: {
    id: number;
    product: string;
    price_toman: number;
    status: string;
    created_at: string;
    confirmed_at: string | null;
  }[];
  payments: {
    id: number;
    amount_toman: number;
    status: string;
    gateway: string;
    ref_id: string | null;
    created_at: string;
  }[];
};

const PAYMENT_STATUS_LABELS: Record<string, string> = {
  initiated: "در انتظار",
  success: "موفق",
  failed: "ناموفق",
};

function paymentPill(status: string) {
  if (status === "success") return "pill green";
  if (status === "failed") return "pill red";
  return "pill amber";
}

function UsersInner() {
  const [q, setQ] = useState("");
  const [rows, setRows] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [denied, setDenied] = useState(false);

  const [detail, setDetail] = useState<UserDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [roleError, setRoleError] = useState<string | null>(null);
  const [roleBusy, setRoleBusy] = useState(false);

  const load = useCallback(async (query: string) => {
    setLoading(true);
    setError(null);
    setDenied(false);
    try {
      const search = new URLSearchParams();
      if (query.trim()) search.set("q", query.trim());
      search.set("limit", "50");
      const res = await apiFetch<{ results: AdminUser[] }>(`/admin/users/?${search.toString()}`);
      setRows(res.results || []);
    } catch (err) {
      if (err instanceof ApiError && err.status === 403) setDenied(true);
      else setError(err instanceof ApiError ? err.message : "دریافت کاربران ناموفق بود.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load("");
  }, [load]);

  const openDetail = async (id: number) => {
    setDetailLoading(true);
    setRoleError(null);
    try {
      setDetail(await apiFetch<UserDetail>(`/admin/users/${id}/`));
    } catch (err) {
      setDetail(null);
      setError(err instanceof ApiError ? err.message : "دریافت جزئیات کاربر ناموفق بود.");
    } finally {
      setDetailLoading(false);
    }
  };

  const changeRole = async (id: number, action: "promote" | "demote") => {
    const target = detail?.user || rows.find((r) => r.id === id);
    const ok = window.confirm(
      action === "promote"
        ? `نقش «${target?.name || id}» به مدیر ارتقا یابد؟`
        : `نقش مدیر «${target?.name || id}» حذف شود؟`,
    );
    if (!ok) return;
    setRoleBusy(true);
    setRoleError(null);
    try {
      await apiFetch(`/admin/users/${id}/role/${action}/`, { method: "POST", body: {} });
      await load(q);
      if (detail && detail.user.id === id) await openDetail(id);
      setRoleError(null);
    } catch (err) {
      setRoleError(err instanceof ApiError ? err.message : "تغییر نقش ناموفق بود.");
    } finally {
      setRoleBusy(false);
    }
  };

  if (denied) {
    return (
      <section className="rv-card">
        <span className="pill red">۴۰۳</span>
        <h2 style={{ marginTop: 12 }}>دسترسی مجاز نیست</h2>
        <p>سرور این درخواست مدیریتی را رد کرد.</p>
      </section>
    );
  }

  return (
    <>
      <section className="rv-card">
        <h2>کاربران</h2>
        <form
          className="rv-form"
          onSubmit={(e) => {
            e.preventDefault();
            load(q);
          }}
        >
          <label className="rv-field" htmlFor="admin-user-q">
            <span>جست‌وجو (نام، شماره، ایمیل)</span>
            <input
              id="admin-user-q"
              type="search"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="مثلاً ۰۹۱۲ یا نام"
            />
          </label>
          <div style={{ display: "flex", alignItems: "end", gap: 8 }}>
            <button className="btn btn-primary" type="submit">
              <Ic n="search" c="sm" /> جست‌وجو
            </button>
            <button type="button" className="btn btn-ghost" onClick={() => { setQ(""); load(""); }}>
              همه
            </button>
          </div>
        </form>

        {loading ? <p className="rv-empty">در حال دریافت کاربران…</p> : null}
        {error ? (
          <p className="c7-error" role="alert">
            {error}
          </p>
        ) : null}

        {!loading && rows.length === 0 && !error ? (
          <p className="rv-empty">کاربری مطابق جست‌وجو پیدا نشد.</p>
        ) : null}

        {rows.length > 0 ? (
          <div className="tbl-wrap">
            <table className="tbl">
              <thead>
                <tr>
                  <th>نام</th>
                  <th>شماره</th>
                  <th>نقش</th>
                  <th>وضعیت</th>
                  <th>عضویت</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {rows.map((u) => (
                  <tr key={u.id}>
                    <td>{u.name || "—"}</td>
                    <td dir="ltr" className="tnum">
                      {u.phone || "—"}
                    </td>
                    <td>
                      <span className={u.role === "admin" ? "pill violet" : "pill gray"}>
                        {u.role === "admin" ? "مدیر" : "کاربر"}
                      </span>
                    </td>
                    <td>
                      <span className={u.is_active ? "pill green" : "pill red"}>
                        {u.is_active ? "فعال" : "غیرفعال"}
                      </span>
                    </td>
                    <td>{fmtDate(u.date_joined)}</td>
                    <td>
                      <button type="button" className="btn btn-sm btn-ghost" onClick={() => openDetail(u.id)}>
                        جزئیات
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : null}

        {roleError ? (
          <p className="c7-error" role="alert">
            {roleError}
          </p>
        ) : null}
      </section>

      {detailLoading ? <p className="rv-empty">در حال دریافت جزئیات…</p> : null}

      {detail && !detailLoading ? (
        <section className="rv-card">
          <div className="p-top">
            <div>
              <h2>جزئیات کاربر: {detail.user.name || detail.user.phone}</h2>
              <p className="p-sub">
                نقش: {detail.user.role === "admin" ? "مدیر" : "کاربر"} · شناسه: {fa(detail.user.id)}
              </p>
            </div>
            <div className="row">
              {detail.user.role === "admin" ? (
                <button
                  type="button"
                  className="btn btn-danger"
                  disabled={roleBusy}
                  onClick={() => changeRole(detail.user.id, "demote")}
                >
                  حذف نقش مدیر
                </button>
              ) : (
                <button
                  type="button"
                  className="btn btn-primary"
                  disabled={roleBusy || !detail.user.is_active}
                  onClick={() => changeRole(detail.user.id, "promote")}
                >
                  ارتقا به مدیر
                </button>
              )}
            </div>
          </div>

          <h3>کسب‌وکارها</h3>
          {detail.businesses.length === 0 ? <p className="rv-empty">کسب‌وکاری ثبت نشده است.</p> : null}
          {detail.businesses.map((b) => (
            <div className="rv-line" key={b.id}>
              <div>
                <b>{b.name}</b>
                <small>{b.slug}</small>
              </div>
            </div>
          ))}

          <h3>اعتبارهای اشتراک</h3>
          {detail.entitlements.length === 0 ? <p className="rv-empty">اعتباری ثبت نشده است.</p> : null}
          {detail.entitlements.length > 0 ? (
            <div className="tbl-wrap">
              <table className="tbl">
                <thead>
                  <tr>
                    <th>نوع</th>
                    <th>کسب‌وکار</th>
                    <th>اشتراک</th>
                    <th>وضعیت</th>
                    <th>پایان</th>
                  </tr>
                </thead>
                <tbody>
                  {detail.entitlements.map((e) => (
                    <tr key={e.id}>
                      <td>{ENTITLEMENT_TYPE_LABELS[e.type] || e.type}</td>
                      <td>{e.business}</td>
                      <td>{e.product}</td>
                      <td>{e.status === "active" ? "فعال" : e.status}</td>
                      <td>{e.ends_at ? fmtDate(e.ends_at) : "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : null}

          <h3>خریدها</h3>
          {detail.purchases.length === 0 ? <p className="rv-empty">خریدی ثبت نشده است.</p> : null}
          {detail.purchases.length > 0 ? (
            <div className="tbl-wrap">
              <table className="tbl">
                <thead>
                  <tr>
                    <th>شناسه</th>
                    <th>اشتراک</th>
                    <th>مبلغ (تومان)</th>
                    <th>وضعیت</th>
                    <th>تاریخ</th>
                  </tr>
                </thead>
                <tbody>
                  {detail.purchases.map((p) => (
                    <tr key={p.id}>
                      <td className="tnum">{fa(p.id)}</td>
                      <td>{p.product}</td>
                      <td className="tnum">{fa(p.price_toman)}</td>
                      <td>{p.status === "paid" ? "پرداخت‌شده" : p.status === "pending" ? "در انتظار پرداخت" : "ناموفق"}</td>
                      <td>{fmtDate(p.created_at)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : null}

          <h3>پرداخت‌ها</h3>
          {detail.payments.length === 0 ? <p className="rv-empty">پرداختی ثبت نشده است.</p> : null}
          {detail.payments.length > 0 ? (
            <div className="tbl-wrap">
              <table className="tbl">
                <thead>
                  <tr>
                    <th>شناسه</th>
                    <th>مبلغ (تومان)</th>
                    <th>وضعیت</th>
                    <th>درگاه</th>
                    <th>مرجع</th>
                    <th>تاریخ</th>
                  </tr>
                </thead>
                <tbody>
                  {detail.payments.map((t) => (
                    <tr key={t.id}>
                      <td className="tnum">{fa(t.id)}</td>
                      <td className="tnum">{fa(t.amount_toman)}</td>
                      <td>
                        <span className={paymentPill(t.status)}>
                          {PAYMENT_STATUS_LABELS[t.status] || t.status}
                        </span>
                      </td>
                      <td>{t.gateway}</td>
                      <td dir="ltr">{t.ref_id || "—"}</td>
                      <td>{fmtDate(t.created_at)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : null}
        </section>
      ) : null}
    </>
  );
}

export default function AdminUsersPage() {
  return (
    <AdminShell>
      <UsersInner />
    </AdminShell>
  );
}
