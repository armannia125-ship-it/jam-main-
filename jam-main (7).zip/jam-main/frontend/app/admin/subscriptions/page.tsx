"use client";
/* مدیریت اشتراک‌ها و اعتبارها — جدول اعتبارها با لغو (با دلیل)،
   ماتریس محصولات و نما /گزارش حسابرسی اخیر. هیچ فعال‌سازی دستی
   اعتبار در این صفحه وجود ندارد. */

import { useCallback, useEffect, useState } from "react";
import AdminShell from "@/components/features/admin-shell";
import { ApiError, apiFetch } from "@/lib/api";
import { fa, fmtDate } from "@/lib/format";
import { ENTITLEMENT_TYPE_LABELS } from "@/lib/subscriptions-api";
import Ic from "@/components/icons";

type AdminEntitlement = {
  id: number;
  user: { id: number; name: string; phone: string | null } | null;
  business: string;
  type: string;
  product: string;
  status: string;
  starts_at: string | null;
  ends_at: string | null;
  purchase: number | null;
};

type AdminProduct = {
  slug: string;
  name: string;
  price_toman: number;
  duration_days: number;
  category: string;
  is_active: boolean;
};

type AuditRow = {
  id: number;
  actor: { id: number; name: string } | null;
  action: string;
  target_type: string;
  target_id: number | string;
  metadata: unknown;
  created_at: string;
};

const ACTION_LABELS: Record<string, string> = {
  admin_promoted: "ارتقای کاربر به مدیر",
  admin_demoted: "حذف نقش مدیر",
  entitlement_revoked: "لغو اعتبار اشتراک",
  payment_inspected: "بازرسی پرداخت",
  purchase_marked_failed: "ثبت خرید ناموفق",
};

const STATUS_FILTERS: [string, string][] = [
  ["", "همه"],
  ["active", "فعال"],
  ["expired", "منقضی"],
  ["revoked", "لغوشده"],
];

function statusPill(status: string) {
  if (status === "active") return "pill green";
  if (status === "revoked") return "pill red";
  return "pill gray";
}

function statusLabel(status: string) {
  if (status === "active") return "فعال";
  if (status === "revoked") return "لغوشده";
  if (status === "expired") return "منقضی";
  return status;
}

function SubscriptionsInner() {
  const [rows, setRows] = useState<AdminEntitlement[]>([]);
  const [products, setProducts] = useState<AdminProduct[]>([]);
  const [audit, setAudit] = useState<AuditRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [denied, setDenied] = useState(false);
  const [type, setType] = useState("");
  const [status, setStatus] = useState("");
  const [actionMsg, setActionMsg] = useState<string | null>(null);
  const [revokeBusy, setRevokeBusy] = useState(false);

  const load = useCallback(async (typeFilter: string, statusFilter: string) => {
    setLoading(true);
    setError(null);
    setDenied(false);
    try {
      const search = new URLSearchParams();
      if (typeFilter) search.set("type", typeFilter);
      if (statusFilter) search.set("status", statusFilter);
      search.set("limit", "50");
      const [res, auditRes] = await Promise.all([
        apiFetch<{ results: AdminEntitlement[]; products: AdminProduct[] }>(
          `/admin/subscriptions/?${search.toString()}`,
        ),
        apiFetch<{ results: AuditRow[] }>("/admin/audit/?limit=10"),
      ]);
      setRows(res.results || []);
      setProducts(res.products || []);
      setAudit(auditRes.results || []);
    } catch (err) {
      if (err instanceof ApiError && err.status === 403) setDenied(true);
      else setError(err instanceof ApiError ? err.message : "دریافت اعتبارها ناموفق بود.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load("", "");
  }, [load]);

  const revoke = async (id: number) => {
    const reason = window.prompt("دلیل لغو این اعتبار را بنویسید (ثبت در حسابرسی می‌شود):");
    if (reason === null) return;
    if (!reason.trim()) {
      setActionMsg("ثبت دلیل برای لغو اعتبار الزامی است.");
      return;
    }
    setRevokeBusy(true);
    setActionMsg(null);
    try {
      await apiFetch(`/admin/entitlements/${id}/revoke/`, { method: "POST", body: { reason: reason.trim() } });
      await load(type, status);
    } catch (err) {
      setActionMsg(err instanceof ApiError ? err.message : "لغو اعتبار ناموفق بود.");
    } finally {
      setRevokeBusy(false);
    }
  };

  if (denied) {
    return (
      <section className="rv-card">
        <span className="pill red">۴۰۳</span>
        <h2 style={{ marginTop: 12 }}>دسترسی مجاز نیست</h2>
        <p>سرور این درخواست مدیریتی را رد کرد.</p>
      </section>
    );
  }

  return (
    <>
      <section className="rv-card">
        <h2>اعتبارهای اشتراک</h2>
        <form
          className="rv-form"
          onSubmit={(e) => {
            e.preventDefault();
            load(type, status);
          }}
        >
          <label className="rv-field" htmlFor="admin-ent-type">
            <span>نوع اعتبار</span>
            <select id="admin-ent-type" value={type} onChange={(e) => setType(e.target.value)}>
              <option value="">همه</option>
              <option value="menu">منوی دیجیتال</option>
              <option value="club">باشگاه فروشندگان</option>
            </select>
          </label>
          <label className="rv-field" htmlFor="admin-ent-status">
            <span>وضعیت</span>
            <select id="admin-ent-status" value={status} onChange={(e) => setStatus(e.target.value)}>
              {STATUS_FILTERS.map(([value, label]) => (
                <option key={value || "all"} value={value}>
                  {label}
                </option>
              ))}
            </select>
          </label>
          <div style={{ display: "flex", alignItems: "end", gap: 8 }}>
            <button className="btn btn-primary" type="submit">
              <Ic n="search" c="sm" /> اعمال فیلتر
            </button>
          </div>
        </form>

        {loading ? <p className="rv-empty">در حال دریافت اعتبارها…</p> : null}
        {error ? (
          <p className="c7-error" role="alert">
            {error}
          </p>
        ) : null}
        {actionMsg ? (
          <p className="c7-error" role="alert">
            {actionMsg}
          </p>
        ) : null}

        {!loading && rows.length === 0 && !error ? (
          <p className="rv-empty">اعتباری مطابق فیلترها پیدا نشد.</p>
        ) : null}

        {rows.length > 0 ? (
          <div className="tbl-wrap">
            <table className="tbl">
              <thead>
                <tr>
                  <th>شناسه</th>
                  <th>کاربر</th>
                  <th>کسب‌وکار</th>
                  <th>نوع</th>
                  <th>اشتراک</th>
                  <th>وضعیت</th>
                  <th>پایان</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {rows.map((e) => (
                  <tr key={e.id}>
                    <td className="tnum">{fa(e.id)}</td>
                    <td>{e.user?.name || "—"}</td>
                    <td>{e.business}</td>
                    <td>{ENTITLEMENT_TYPE_LABELS[e.type] || e.type}</td>
                    <td>{e.product}</td>
                    <td>
                      <span className={statusPill(e.status)}>{statusLabel(e.status)}</span>
                    </td>
                    <td>{e.ends_at ? fmtDate(e.ends_at) : "—"}</td>
                    <td>
                      {e.status === "active" ? (
                        <button
                          type="button"
                          className="btn btn-sm btn-danger"
                          disabled={revokeBusy}
                          onClick={() => revoke(e.id)}
                        >
                          لغو اعتبار
                        </button>
                      ) : null}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : null}
      </section>

      <section className="rv-card">
        <h2>ماتریس محصولات اشتراک</h2>
        {products.length > 0 ? (
          <div className="tbl-wrap">
            <table className="tbl">
              <thead>
                <tr>
                  <th>نام</th>
                  <th>شناسه</th>
                  <th>دسته</th>
                  <th>قیمت (تومان)</th>
                  <th>مدت (روز)</th>
                  <th>وضعیت</th>
                </tr>
              </thead>
              <tbody>
                {products.map((p) => (
                  <tr key={p.slug}>
                    <td>{p.name}</td>
                    <td dir="ltr">{p.slug}</td>
                    <td>{p.category === "menu" ? "منو" : p.category === "club" ? "باشگاه" : "ترکیبی"}</td>
                    <td className="tnum">{fa(p.price_toman)}</td>
                    <td className="tnum">{fa(p.duration_days)}</td>
                    <td>
                      <span className={p.is_active ? "pill green" : "pill gray"}>
                        {p.is_active ? "فعال در کاتالوگ" : "غیرفعال"}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="rv-empty">محصولی ثبت نشده است.</p>
        )}
      </section>

      <section className="rv-card">
        <h2>حسابرسی اخیر</h2>
        {audit.length === 0 ? (
          <p className="rv-empty">اقدام مدیریتی ثبت نشده است.</p>
        ) : null}
        {audit.map((a) => (
          <div className="rv-line" key={a.id}>
            <div>
              <b>{ACTION_LABELS[a.action] || a.action}</b>
              <small>
                {a.actor?.name || "—"} · {a.target_type}:{fa(String(a.target_id))} · {fmtDate(a.created_at)}
              </small>
            </div>
          </div>
        ))}
      </section>
    </>
  );
}

export default function AdminSubscriptionsPage() {
  return (
    <AdminShell>
      <SubscriptionsInner />
    </AdminShell>
  );
}
