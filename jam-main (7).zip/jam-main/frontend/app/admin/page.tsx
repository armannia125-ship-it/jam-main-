"use client";
/* داشبورد مدیریت — فقط اعداد واقعی API؛ درآمد تأییدشده جدا از
   پرداخت‌های در انتظار و عضویت‌های میراث با برچسب «میراث». */

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import AdminShell from "@/components/features/admin-shell";
import { ApiError, apiFetch } from "@/lib/api";
import { fa, fmtDate } from "@/lib/format";
import { PURCHASE_STATUS_LABELS, purchaseStatusPill } from "@/lib/subscriptions-api";
import Ic from "@/components/icons";

type AdminUserBrief = {
  id: number;
  name: string;
  phone: string | null;
  email: string | null;
  role: string;
  is_active: boolean;
  date_joined: string;
};

type Overview = {
  users_total: number;
  users_active: number;
  menu_entitlements_active: number;
  club_entitlements_active: number;
  subscriptions_expired: number;
  payments_pending: number;
  payments_confirmed: number;
  payments_failed: number;
  confirmed_revenue_toman: number;
  recent_purchases: {
    id: number;
    user: AdminUserBrief | null;
    business: string;
    product: string;
    price_toman: number;
    status: string;
    created_at: string;
  }[];
  recent_admin_actions: {
    id: number;
    actor: AdminUserBrief | null;
    action: string;
    target: string;
    created_at: string;
  }[];
};

const ACTION_LABELS: Record<string, string> = {
  admin_promoted: "ارتقای کاربر به مدیر",
  admin_demoted: "حذف نقش مدیر",
  entitlement_revoked: "لغو اعتبار اشتراک",
  payment_inspected: "بازرسی پرداخت",
  purchase_marked_failed: "ثبت خرید ناموفق",
};

function DashboardInner() {
  const [data, setData] = useState<Overview | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [denied, setDenied] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    setDenied(false);
    try {
      setData(await apiFetch<Overview>("/admin/overview/"));
    } catch (err) {
      if (err instanceof ApiError && err.status === 403) setDenied(true);
      else setError(err instanceof ApiError ? err.message : "دریافت آمار مدیریت ناموفق بود.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  if (denied) {
    return (
      <section className="rv-card">
        <span className="pill red">۴۰۳</span>
        <h2 style={{ marginTop: 12 }}>دسترسی مجاز نیست</h2>
        <p>این درخواست از سمت سرور رد شد؛ نقش شما در بررسی دوباره تأیید نشد.</p>
        <Link className="btn btn-ghost" href="/">
          بازگشت به صفحهٔ اصلی
        </Link>
      </section>
    );
  }

  if (loading) return <p className="rv-empty">در حال دریافت آمار…</p>;

  if (error) {
    return (
      <section className="rv-card">
        <p className="c7-error" role="alert">
          {error}
        </p>
        <button type="button" className="btn btn-ghost" onClick={() => load()}>
          تلاش دوباره
        </button>
      </section>
    );
  }

  if (!data) return null;

  const kpis: [string, string, number | string][] = [
    ["کاربران کل", "user", data.users_total],
    ["کاربران فعال", "user", data.users_active],
    ["اعتبار منوی فعال", "qr", data.menu_entitlements_active],
    ["اعتبار باشگاه فعال", "spark", data.club_entitlements_active],
    ["اعتبارهای منقضی", "clock", data.subscriptions_expired],
    ["پرداخت‌های در انتظار", "card", data.payments_pending],
    ["پرداخت‌های تأییدشده", "check", data.payments_confirmed],
    ["پرداخت‌های ناموفق", "x", data.payments_failed],
  ];

  return (
    <>
      <div className="kpis">
        <div className="card kpi" style={{ gridColumn: "span 2" }}>
          <div className="k">
            <span>درآمد تأییدشده (پرداخت‌های موفق درگاه)</span>
            <span className="t" style={{ background: "var(--brand-soft)", color: "var(--brand)" }}>
              <Ic n="cash" />
            </span>
          </div>
          <div className="v tnum">{fa(data.confirmed_revenue_toman)}</div>
          <div className="d">تومان · فقط پرداخت‌های تأییدشده</div>
        </div>
        <div className="card kpi">
          <div className="k">
            <span>پرداخت‌های در انتظار</span>
            <span className="t" style={{ background: "var(--amber-soft)", color: "var(--amber)" }}>
              <Ic n="clock" />
            </span>
          </div>
          <div className="v tnum">{fa(data.payments_pending)}</div>
          <div className="d">تعداد؛ جزو درآمد تأییدشده حساب نمی‌شود</div>
        </div>
        <div className="card kpi">
          <div className="k">
            <span>پرداخت‌های ناموفق</span>
            <span className="t" style={{ background: "var(--red-soft)", color: "var(--red)" }}>
              <Ic n="x" />
            </span>
          </div>
          <div className="v tnum">{fa(data.payments_failed)}</div>
          <div className="d">تعداد تراکنش ناموفق</div>
        </div>
      </div>

      <div className="kpis" style={{ marginTop: 16 }}>
        {kpis.map(([label, icon, value]) => (
          <div className="card kpi" key={label}>
            <div className="k">
              <span>{label}</span>
              <span className="t">
                <Ic n={icon} />
              </span>
            </div>
            <div className="v tnum">{fa(Number(value) || 0)}</div>
          </div>
        ))}
      </div>

      <section className="rv-card">
        <h2>خریدهای اخیر</h2>
        {data.recent_purchases.length === 0 ? (
          <p className="rv-empty">هنوز خریدی ثبت نشده است.</p>
        ) : null}
        {data.recent_purchases.length > 0 ? (
          <div className="tbl-wrap">
            <table className="tbl">
              <thead>
                <tr>
                  <th>شناسه</th>
                  <th>کاربر</th>
                  <th>کسب‌وکار</th>
                  <th>اشتراک</th>
                  <th>مبلغ (تومان)</th>
                  <th>وضعیت</th>
                  <th>تاریخ</th>
                </tr>
              </thead>
              <tbody>
                {data.recent_purchases.map((p) => (
                  <tr key={p.id}>
                    <td className="tnum">{fa(p.id)}</td>
                    <td>{p.user?.name || "—"}</td>
                    <td>{p.business}</td>
                    <td>{p.product}</td>
                    <td className="tnum">{fa(p.price_toman)}</td>
                    <td>
                      <span className={purchaseStatusPill(p.status)}>
                        {PURCHASE_STATUS_LABELS[p.status] || p.status}
                      </span>
                    </td>
                    <td>{fmtDate(p.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : null}
      </section>

      <section className="rv-card">
        <h2>اقدامات مدیریتی اخیر</h2>
        {data.recent_admin_actions.length === 0 ? (
          <p className="rv-empty">اقدام مدیریتی ثبت نشده است.</p>
        ) : null}
        {data.recent_admin_actions.map((a) => (
          <div className="rv-line" key={a.id}>
            <div>
              <b>{ACTION_LABELS[a.action] || a.action}</b>
              <small>
                {a.actor?.name || "—"} · {a.target} · {fmtDate(a.created_at)}
              </small>
            </div>
          </div>
        ))}
        <Link className="c7-text-link" href="/admin/audit">
          مشاهدهٔ کامل گزارش حسابرسی
        </Link>
      </section>
    </>
  );
}

export default function AdminDashboardPage() {
  return (
    <AdminShell>
      <DashboardInner />
    </AdminShell>
  );
}
