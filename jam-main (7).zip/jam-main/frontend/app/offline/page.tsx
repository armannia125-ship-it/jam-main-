import Link from "next/link";

export const metadata = { title: "آفلاین | جم لایف" };

/* صفحهٔ پشتیبان سرویس‌ورکر برای مسیرهایی که کش نشده‌اند */
export default function OfflinePage() {
  return (
    <div className="container" style={{ padding: "48px 0" }}>
      <div className="empty">
        <span className="e-ic" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className="ic">
            <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" opacity=".35" />
            <path d="M3 3l18 18" />
          </svg>
        </span>
        <b>اتصال اینترنت در دسترس نیست</b>
        <p>این صفحه ذخیره نشده است. منوهایی که قبلاً باز کرده باشید از حافظهٔ دستگاه قابل مشاهده‌اند.</p>
        <Link className="btn btn-soft" href="/">
          تلاش دوباره
        </Link>
      </div>
    </div>
  );
}
