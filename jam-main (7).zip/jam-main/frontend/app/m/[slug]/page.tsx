import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { DigitalMenuPage } from "@/components/features/digital-menu-page";
import { store } from "@/lib/data";
import { isDemoMode } from "@/lib/demo";
import { apiMenuToStore, fetchPublicMenu } from "@/lib/public-menu";

type PageProps = {
  params: Promise<{ slug: string }>;
};

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const menu = await fetchPublicMenu(slug);
  const name = menu?.business.name || (isDemoMode() ? store(slug)?.name : undefined);
  return { title: name ? `منوی ${name} | جم لایف` : "منوی دیجیتال | جم لایف" };
}

export default async function DigitalMenuPageRoute({ params }: PageProps) {
  const { slug } = await params;

  // منوی واقعی از API عمومی؛ دادهٔ کامل در همان پاسخ HTML کش می‌شود تا
  // نمایش آفلاین به واکشی سمت کلاینت وابسته نباشد.
  const realMenu = await fetchPublicMenu(slug);
  const s = realMenu ? apiMenuToStore(realMenu) : isDemoMode() ? store(slug) : undefined;

  if (!s) {
    notFound();
  }

  return <DigitalMenuPage storeId={s.id} initialStore={s} />;
}
