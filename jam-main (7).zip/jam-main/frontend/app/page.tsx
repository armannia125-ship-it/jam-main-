import { HomePage } from "@/components/features/home";
import { RealHomePage } from "@/components/features/real-catalog";
import { isDemoMode } from "@/lib/demo";

/* The production catalog is fetched from Django at request time. */
export const dynamic = "force-dynamic";

export default function Page() {
  return isDemoMode() ? <HomePage /> : <RealHomePage />;
}