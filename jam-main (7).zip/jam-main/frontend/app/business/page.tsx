import { BusinessPage } from "@/components/features/business-page";

export default function BusinessPageRoute() {
  return <BusinessPage />;
}
