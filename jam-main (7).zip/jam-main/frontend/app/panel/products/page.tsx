"use client";
/* محصولات و قیمت‌ها — مطابق مرجع (pProducts + productEditor)
   تغییر قیمت/موجودی/ویرایش فقط در وضعیت محلی همین صفحه (override map) نگه داشته می‌شود؛
   این نسخه نمایشی است و به بک‌اند وصل نیست. */

import { useMemo, useState } from "react";
import PanelShell, { PTop, EmptyBlock, ProductArt, usePanelSid } from "@/components/features/panel-page";
import { useJam } from "@/lib/state";
import { store as getStore, STORES, type Product, type Store } from "@/lib/data";
import { fa, enD } from "@/lib/format";
import Ic from "@/components/icons";

type Override = Partial<Pick<Product, "name" | "desc" | "price" | "old" | "sec" | "available">>;
type OvMap = Record<string, Override>;

const fmtPrice = (n: number) => fa(n).replace(/٬/g, ",");
const parsePrice = (v: string) => {
  const d = enD(v.trim()).replace(/[٬,]/g, "");
  return /^\d{1,10}$/.test(d) ? Number(d) : NaN;
};

function ProductEditorModal({
  p,
  s,
  onClose,
  onSave,
}: {
  p: Product;
  s: Store;
  onClose: () => void;
  onSave: (pid: string, data: Override) => void;
}) {
  const [name, setName] = useState(p.name);
  const [desc, setDesc] = useState(p.desc);
  const [price, setPrice] = useState(p.price ? String(p.price) : "");
  const [old, setOld] = useState(p.old ? String(p.old) : "");
  const [sec, setSec] = useState(p.sec);
  const [available, setAvailable] = useState(p.available);
  const [err, setErr] = useState("");

  const save = () => {
    const pr = parsePrice(price);
    const prOld = old.trim() ? parsePrice(old) : 0;
    if (!name.trim() || name.length > 120 || desc.length > 2000 || !Number.isSafeInteger(pr) || pr < 1 || pr > 1000000000 || !Number.isSafeInteger(prOld) || prOld > 1000000000) {
      setErr("نام تا ۱۲۰ نویسه، توضیح تا ۲۰۰۰ نویسه و قیمت صحیح بین ۱ و ۱٬۰۰۰٬۰۰۰٬۰۰۰ تومان وارد کنید؛ مبلغ منفی یا اعشاری پذیرفته نیست.");
      return;
    }
    onSave(p.id, { name: name.trim(), desc: desc.trim(), price: pr, old: prOld > pr ? prOld : 0, sec, available });
  };

  return (
    <>
      <div className="overlay show" onClick={onClose} />
      <div className="modal-wrap">
        <div className="modal show" role="dialog" aria-modal="true" aria-label="ویرایش محصول">
          <div className="m-head">
            <h2 style={{ margin: 0, fontSize: 17 }}>ویرایش محصول</h2>
            <button className="icon-btn" aria-label="بستن" onClick={onClose}>
              <Ic n="x" />
            </button>
          </div>
          <div className="m-body">
            <div className="form-grid">
              <div className="field full">
                <label htmlFor="pe-n">نام محصول</label>
                <input className="input" id="pe-n" value={name} onChange={(e) => setName(e.target.value)} autoFocus />
              </div>
              <div className="field full">
                <label htmlFor="pe-d">توضیحات</label>
                <textarea className="textarea" id="pe-d" value={desc} onChange={(e) => setDesc(e.target.value)} />
              </div>
              <div className="field">
                <label htmlFor="pe-p">قیمت (تومان)</label>
                <input
                  className="input input-ltr tnum"
                  id="pe-p"
                  inputMode="numeric"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                />
              </div>
              <div className="field">
                <label htmlFor="pe-o">
                  قیمت قبل از تخفیف <span className="faint">(اختیاری)</span>
                </label>
                <input
                  className="input input-ltr tnum"
                  id="pe-o"
                  inputMode="numeric"
                  value={old}
                  onChange={(e) => setOld(e.target.value)}
                />
              </div>
              <div className="field">
                <label htmlFor="pe-s">بخش منو</label>
                <select className="select" id="pe-s" value={sec} onChange={(e) => setSec(e.target.value)}>
                  {s.sections.map((x) => (
                    <option key={x} value={x}>
                      {x}
                    </option>
                  ))}
                </select>
              </div>
              <div className="field">
                <label>وضعیت</label>
                <label className="chk" style={{ height: 46 }}>
                  <span className="switch">
                    <input type="checkbox" checked={available} onChange={(e) => setAvailable(e.target.checked)} />
                    <span />
                  </span>
                  موجود است
                </label>
              </div>
              {err ? (
                <span className="err-msg full" id="pe-e" role="alert">
                  <Ic n="alert" c="sm" />
                  {err}
                </span>
              ) : null}
            </div>
          </div>
          <div className="m-foot">
            <button className="btn btn-primary grow" onClick={save}>
              ذخیره تغییرات
            </button>
            <button className="btn btn-ghost" onClick={onClose}>
              انصراف
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

function PanelProductsInner() {
  const { sid } = usePanelSid();
  const { toast } = useJam();
  const [sec, setSec] = useState("all");
  const [ovr, setOvr] = useState<OvMap>({});
  const [editing, setEditing] = useState<Product | null>(null);
  const s = getStore(String(sid ?? "")) || STORES[0];

  const merged = useMemo<Product[]>(
    () => s.products.map((p) => ({ ...p, ...(ovr[p.id] || {}) })),
    [s, ovr],
  );
  const ps = sec === "all" ? merged : merged.filter((p) => p.sec === sec);
  const na = merged.filter((p) => !p.available).length;

  const commitPrice = (p: Product, raw: string) => {
    const v = parsePrice(raw);
    if (!Number.isSafeInteger(v) || v < 1) return;
    if (v === p.price) return;
    setOvr((prev) => ({ ...prev, [p.id]: { ...prev[p.id], price: v } }));
    toast(`قیمت «${p.name}» به‌روز شد`);
  };

  return (
    <>
      <PTop
        title="محصولات و قیمت‌ها"
        sub={`${fa(merged.length)} محصول · ${fa(na)} ناموجود · تغییرات فوراً روی منوی عمومی اعمال می‌شود`}
        actions={
          <button className="btn btn-primary btn-sm" onClick={() => toast("در نسخهٔ نمایشی در دسترس نیست", "err")}>
            <Ic n="plus" c="sm" />
            افزودن محصول
          </button>
        }
      />

      <div className="card">
        <div style={{ padding: "14px 16px", display: "flex", gap: 10, flexWrap: "wrap", borderBottom: "1px solid var(--line)" }}>
          <div className="chips grow">
            {["all", ...s.sections].map((x) => (
              <button key={x} className={`chip${sec === x ? " on" : ""}`} onClick={() => setSec(x)} aria-pressed={sec === x}>
                {x === "all" ? "همه" : x}
              </button>
            ))}
          </div>
        </div>
        {ps.length ? (
          <div className="tbl-wrap">
            <div className="ux-table-scroll" tabIndex={0} role="region" aria-label="جدول؛ برای دیدن ستون‌ها به چپ و راست حرکت کنید">
            <table className="tbl resp">
              <thead>
                <tr>
                  <th></th>
                  <th>محصول</th>
                  <th>بخش</th>
                  <th>قیمت (تومان)</th>
                  <th>موجود</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {ps.map((p) => (
                  <tr key={p.id} className={p.available ? "" : "na"}>
                    <td className="c-thumb">
                      <span className={`tone tone-${s.tone}`} style={{ width: 44, height: 44, borderRadius: 11, display: "grid", placeItems: "center", fontSize: 22, overflow: "hidden" }}>
                        <ProductArt p={p} sid={String(sid ?? s.id)} />
                      </span>
                    </td>
                    <td className="c-name">
                      <b>{p.name}</b>
                      <div className="faint ellipsis" style={{ fontSize: 14, maxWidth: 280 }}>
                        {p.desc}
                      </div>
                    </td>
                    <td className="c-cat">
                      <span className="pill gray">{p.sec}</span>
                    </td>
                    <td className="c-price">
                      <label className="sr" htmlFor={`pr-${p.id}`}>
                        قیمت {p.name}
                      </label>
                      <input
                        className="price-in"
                        id={`pr-${p.id}`}
                        inputMode="numeric"
                        defaultValue={fmtPrice(p.price)}
                        key={`${p.id}-${p.price}`}
                        onBlur={(e) => commitPrice(p, e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") (e.target as HTMLInputElement).blur();
                        }}
                      />
                    </td>
                    <td className="c-av">
                      <label className="switch" title="موجودی">
                        <input
                          type="checkbox"
                          checked={p.available}
                          onChange={(e) => setOvr((prev) => ({ ...prev, [p.id]: { ...prev[p.id], available: e.target.checked } }))}
                          aria-label={`موجود بودن ${p.name}`}
                        />
                        <span />
                      </label>
                    </td>
                    <td className="c-act">
                      <button className="btn btn-plain btn-sm" onClick={() => setEditing(p)}>
                        <Ic n="edit" c="sm" />
                        ویرایش
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            </div>
          </div>
        ) : (
          <EmptyBlock icon="layers" title="محصولی پیدا نشد" />
        )}
      </div>

      {editing ? (
        <ProductEditorModal
          p={editing}
          s={s}
          onClose={() => setEditing(null)}
          onSave={(pid, data) => {
            setOvr((prev) => ({ ...prev, [pid]: { ...prev[pid], ...data } }));
            setEditing(null);
            toast("تغییرات ذخیره شد");
          }}
        />
      ) : null}
    </>
  );
}

export default function PanelProductsPage() {
  return (
    <PanelShell>
      <PanelProductsInner />
    </PanelShell>
  );
}
