"use client";
/* سفارش‌های فروشنده — از API سرور؛ تغییر وضعیت با کنترل‌های مجاز
   سمت سرور اعتبارسنجی می‌شود. پرداخت آزمایشی فقط با درخواست صریح. */

import { useState } from "react";
import PanelShell, { PTop, EmptyBlock, usePanelSid } from "@/components/features/panel-page";
import { STATUS } from "@/lib/data";
import { fa, faD, tomanT, ago } from "@/lib/format";
import { useSellerOrders, type OrderRow } from "@/lib/commerce";
import Ic from "@/components/icons";

const GROUPS: Record<string, string[]> = {
  new: ["placed"],
  active: ["accepted", "preparing", "ready", "sent"],
  done: ["done"],
  failed: ["rejected", "canceled", "refunded"],
};
const LABELS: Record<string, string> = { new: "جدید", active: "در جریان", done: "تکمیل‌شده", failed: "رد / لغو / مرجوع" };

const nextOf = (o: OrderRow) => {
  const flow = o.mode === "pickup" ? ["placed", "accepted", "preparing", "ready", "done"] : ["placed", "accepted", "preparing", "sent", "done"];
  const i = flow.indexOf(o.status);
  return i >= 0 && i < flow.length - 1 ? flow[i + 1] : undefined;
};
const nextLabel = (nx: string | undefined, o: OrderRow) => {
  if (nx === "accepted") return "تأیید سفارش";
  if (nx === "preparing") return "شروع آماده‌سازی";
  if (nx === "ready") return "آماده تحویل شد";
  if (nx === "sent") return "تحویل به پیک";
  if (nx === "done") return o.mode === "pickup" ? "تحویل به مشتری" : "تحویل شد";
  return "";
};

function PanelOrdersInner() {
  const { sid } = usePanelSid();
  const { orders, loading, error, refresh, setStatus, simulatePayment } = useSellerOrders(sid);
  const [f, setF] = useState("new");
  const [err, setErr] = useState("");

  const list = orders.filter((o) => (GROUPS[f] || []).includes(o.status));

  const run = async (fn: () => Promise<void>, message: string) => {
    setErr("");
    try {
      await fn();
    } catch (x) {
      setErr((x as Error).message || message);
    }
  };

  return (
    <>
      <PTop title="سفارش‌ها" sub="سفارش‌ها را تأیید کنید و وضعیت آماده‌سازی را به‌روز نگه دارید" />

      <div className="chips v11-order-tabs" style={{ marginBottom: 16 }}>
        {Object.keys(GROUPS).map((k) => {
          const n = orders.filter((o) => GROUPS[k].includes(o.status)).length;
          return (
            <button key={k} className={`chip${f === k ? " on" : ""}`} onClick={() => setF(k)} aria-pressed={f === k}>
              {LABELS[k]} <span className="tnum" style={{ opacity: 0.7 }}>{fa(n)}</span>
            </button>
          );
        })}
      </div>

      {loading ? <p className="rv-empty">در حال دریافت سفارش‌ها…</p> : null}
      {error ? <p className="c7-error" role="alert">{error}</p> : null}
      {err ? <p className="c7-error" role="alert">{err}</p> : null}
      {error ? (
        <button type="button" className="btn btn-ghost" onClick={() => refresh()}>تلاش دوباره</button>
      ) : null}

      {list.length ? (
        list.map((o) => {
          const nx = nextOf(o);
          const st = STATUS[o.status] || STATUS.placed;
          const nl = nextLabel(nx, o);
          const paid = o.payment_state === "paid";
          return (
            <div className={`card o-card${o.status === "placed" ? " new" : ""}`} key={o.number}>
              <div>
                <div className="row" style={{ flexWrap: "wrap", gap: 8 }}>
                  <b className="tnum">{o.number}</b>
                  <span className={`pill ${st.c}`}>
                    <span className="dot" />
                    {st.short}
                  </span>
                  <span className={`pill ${o.mode === "pickup" ? "green" : "violet"}`}>
                    <Ic n={o.mode === "pickup" ? "walk" : "truck"} c="sm" />
                    {o.mode === "pickup" ? "تحویل حضوری" : "ارسال"}
                  </span>
                  {paid ? (
                    <span className="pill gray">پرداخت ثبت‌شده</span>
                  ) : o.payment_method === "online" ? (
                    <span className="pill amber">در انتظار پرداخت</span>
                  ) : (
                    <span className="pill amber">پرداخت هنگام تحویل</span>
                  )}
                </div>
                <div className="o-items" style={{ marginTop: 8 }}>
                  {o.items.map((i) => (
                    <span key={i.id}>
                      <b className="tnum">{fa(i.quantity)}×</b> {i.name}
                    </span>
                  ))}
                </div>
                <div className="faint" style={{ fontSize: 14, marginTop: 4 }}>
                  {o.customer?.name || "مشتری"} ·{" "}
                  <span className="tnum" dir="ltr">{faD(o.customer?.phone || "")}</span> · {ago(new Date(o.created_at).getTime())}
                  {o.preferred_time ? ` · ${o.preferred_time}` : ""}
                  {o.mode === "delivery" && o.address_text ? ` · ${o.address_text}` : ""}
                </div>
                {o.note ? (
                  <div className="notice amber" style={{ marginTop: 8, padding: "8px 12px" }}>
                    <Ic n="info" c="sm" />
                    <span>{o.note}</span>
                  </div>
                ) : null}
              </div>
              <div style={{ textAlign: "left" }}>
                <div className="faint" style={{ fontSize: 14 }}>مبلغ</div>
                <b className="tnum" style={{ fontSize: 17 }}>{tomanT(o.total_toman)}</b>
              </div>
              {nx || o.status === "placed" || (o.payment_method === "online" && !paid) ? (
                <div className="o-actions">
                  {nl && nx ? (
                    <button className="btn btn-primary btn-sm" onClick={() => run(() => setStatus(o.number, nx), "تغییر وضعیت ناموفق بود.")}>
                      <Ic n={STATUS[nx]?.icon || "check"} c="sm" />
                      {nl}
                    </button>
                  ) : null}
                  {o.status === "placed" ? (
                    <button className="btn btn-danger btn-sm" onClick={() => run(() => setStatus(o.number, "rejected"), "رد سفارش ناموفق بود.")}>
                      رد سفارش
                    </button>
                  ) : null}
                  {o.payment_method === "online" && !paid && o.status !== "canceled" && o.status !== "rejected" ? (
                    <button className="btn btn-ghost btn-sm" onClick={() => run(() => simulatePayment(o.number), "ثبت پرداخت آزمایشی ناموفق بود.")}>
                      ثبت پرداخت آزمایشی
                    </button>
                  ) : null}
                  {o.customer?.phone ? (
                    <a href={`tel:${o.customer.phone}`} className="btn btn-ghost btn-sm">
                      <Ic n="phone" c="sm" />
                      تماس با مشتری
                    </a>
                  ) : null}
                </div>
              ) : null}
            </div>
          );
        })
      ) : (
        !loading ? (
          <div className="card">
            <EmptyBlock
              icon="list"
              title="سفارشی در این بخش نیست"
              desc={f === "new" ? "سفارش جدیدی از مشتری ثبت نشده است." : ""}
            />
          </div>
        ) : null
      )}
    </>
  );
}

export default function PanelOrdersPage() {
  return (
    <PanelShell>
      <PanelOrdersInner />
    </PanelShell>
  );
}
