"use client";

/* =========================================================
   جم لایف — تسهیم و حساب مقصد (/panel/settlement)
   دفتر تسویه از سرور خوانده می‌شود. کنترل ساختار شبا تنها
   اعتبارسنجی قالب و رقم کنترل است و تأیید مالکیت حساب یا
   واریز بانکی نیست.
   ========================================================= */

import { useEffect, useState } from "react";
import Link from "next/link";
import PanelShell, { usePanelSid } from "@/components/features/panel-page";
import { RvHeading, RvNote } from "@/components/features/rv-parts";
import { SETTLEMENT_STATE_LABELS, money, useSettlement } from "@/lib/commerce";
import Ic from "@/components/icons";

export default function PanelSettlementPage() {
  return (
    <PanelShell>
      <Settlement />
    </PanelShell>
  );
}

function Settlement() {
  const { sid } = usePanelSid();
  const { data, loading, error, refresh, saveOnboarding, reverseEntry } = useSettlement(sid);
  const [legalName, setLegalName] = useState("");
  const [iban, setIban] = useState("");
  const [err, setErr] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (data?.account) {
      setLegalName((v) => v || data.account!.legal_name);
      setIban((v) => v || data.account!.iban);
    }
  }, [data?.account]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    setNotice("");
    setBusy(true);
    try {
      await saveOnboarding(legalName, iban);
      setNotice("ساختار شبا معتبر است؛ مالکیت حساب و احراز هویت تأیید نشده‌اند.");
    } catch (x) {
      setErr((x as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const reverse = async (entryId: number, orderNumber: string) => {
    if (!window.confirm(`ثبت برگشت برای سفارش ${orderNumber}؟ سابقهٔ مالی حفظ می‌شود و هیچ واریز واقعی انجام نمی‌شود.`)) return;
    setErr("");
    try {
      await reverseEntry(entryId, "درخواست برگشت توسط فروشنده");
      setNotice("برگشت ثبت شد؛ سابقهٔ تسویه حفظ شده است.");
    } catch (x) {
      setErr((x as Error).message);
    }
  };

  return (
    <>
      <RvHeading
        over="تسهیم خرید آنلاین"
        title="سهم جم لایف و فروشنده، روشن و جدا"
        text="دفتر تسویه سمت سرور نگهداری می‌شود. تا اتصال ارائه‌دهندهٔ پرداخت، هیچ واریز واقعی انجام نمی‌شود."
      />
      <RvNote>
        هیچ واریز بانکی واقعی در این نسخه انجام نمی‌شود. وضعیت «واجد شرایط» فقط یک رکورد داخلی است و به معنی پرداخت نیست.
      </RvNote>
      <div className="c7-flow">
        <span>پرداخت آنلاین</span>
        <span>تأیید تحویل</span>
        <span>پذیرش شرایط</span>
        <span>اتصال ارائه‌دهنده</span>
      </div>

      {loading ? <p className="rv-empty">در حال دریافت اطلاعات تسویه…</p> : null}
      {error ? (
        <section className="rv-card">
          <p className="c7-error" role="alert">{error}</p>
          <button type="button" className="btn btn-ghost" onClick={() => refresh()}>تلاش دوباره</button>
        </section>
      ) : null}

      {data ? (
        <>
          <section className="rv-card">
            <h2>پذیرندگی و حساب مقصد فروشگاه</h2>
            <p>
              {data.seller_agreement_accepted ? "شرایط همکاری فروشنده پذیرفته شده است." : "ابتدا شرایط همکاری را بپذیر."}{" "}
              وضعیت ارائه‌دهنده:{" "}
              <b>{data.account?.provider_status === "verified" ? "تأییدشده توسط ارائه‌دهنده" : "اتصال واقعی برقرار نیست"}</b>
            </p>
            <form onSubmit={submit}>
              <div className="rv-form">
                <label className="rv-field" htmlFor="c7-legal">
                  <span>نام صاحب حساب / پذیرنده</span>
                  <input id="c7-legal" required minLength={3} maxLength={100} autoComplete="name" value={legalName} onChange={(e) => setLegalName(e.target.value)} />
                </label>
                <label className="rv-field" htmlFor="c7-iban">
                  <span>شماره شبا</span>
                  <input id="c7-iban" dir="ltr" placeholder="IR…" maxLength={32} required autoComplete="off" value={iban} onChange={(e) => setIban(e.target.value)} />
                </label>
              </div>
              <button className="btn btn-ghost" type="submit" disabled={busy}>
                {busy ? "در حال ذخیره…" : "ذخیره و بررسی ساختار شبا"}
              </button>
              <p className="c7-error" role="alert">{err}</p>
              {notice ? <p className="c7-small">{notice}</p> : null}
            </form>
            <p className="c7-small">بررسی شبا فقط ساختار و رقم کنترل را می‌سنجد؛ مالکیت حساب را ثابت نمی‌کند.</p>
            <Link className="c7-text-link" href="/panel/agreement">شرایط همکاری و سوابق پذیرش</Link>
          </section>

          <section className="rv-card">
            <h2>دفتر تسهیم سفارش‌ها</h2>
            <p>نرخ هر سفارش ثابت می‌ماند. ارسال در سهم فروشنده است ولی مشمول کمیسیون نیست.</p>
            {data.ledger.length ? (
              data.ledger.map((l) => (
                <article className="c7-ledger" key={l.id}>
                  <div className="rv-line">
                    <div>
                      <b dir="ltr">{l.order_number}</b>
                      <small>نرخ {Number(l.rate).toLocaleString("fa-IR")}٪</small>
                    </div>
                    <span className="c7-tag">{SETTLEMENT_STATE_LABELS[l.status]}</span>
                  </div>
                  <div className="c7-split">
                    <div>
                      <span>سهم جم لایف</span>
                      <strong>{money(l.commission_toman)}</strong>
                    </div>
                    <div>
                      <span>سهم فروشنده، با ارسال</span>
                      <strong>{money(l.net_payable_toman)}</strong>
                    </div>
                    <div>
                      <span>جمع وجه مشتری</span>
                      <strong>{money(l.gross_toman)}</strong>
                    </div>
                  </div>
                  <p className="c7-small">
                    مبنای کالا {money(l.goods_toman)} · ارسال {money(l.delivery_toman)}
                    {l.paid_at ? " · زمان پرداخت ثبت شده" : " · واریزی ثبت نشده"}
                  </p>
                  {l.reversals.length ? (
                    <p className="c7-small">
                      برگشت‌ها: {l.reversals.map((r) => `${money(r.amount_toman)} (${r.reason})`).join(" · ")}
                    </p>
                  ) : null}
                  {l.status === "eligible" ? (
                    <button type="button" className="btn btn-ghost" onClick={() => reverse(l.id, l.order_number)}>
                      ثبت برگشت / مرجوعی
                    </button>
                  ) : null}
                </article>
              ))
            ) : (
              <p className="rv-empty">پس از سفارش آنلاین و تأیید تحویل، سهم‌ها اینجا ثبت می‌شوند.</p>
            )}
          </section>

          <details className="rv-card">
            <summary>حدود این دفتر و الزامات نسخهٔ واقعی</summary>
            <p>
              تأیید پرداخت و وب‌هوک امضاشده، ثبت سهم‌ها و جلوگیری از تسویهٔ تکراری باید سمت سرور باشند. زمان‌بندی و امکان
              تسویهٔ پس از تحویل باید با سرویس پرداخت تأیید شود. پذیرش سایت، تضمین حذف مدارک حقوقی/بانکی نیست.
            </p>
            <p>
              <Ic n="info" c="sm" /> {data.detail}
            </p>
          </details>
        </>
      ) : null}
    </>
  );
}
