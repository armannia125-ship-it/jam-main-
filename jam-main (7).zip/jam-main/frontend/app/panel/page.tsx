"use client";
/* داشبورد پنل فروشنده — لایهٔ نهایی g10 مطابق DOM مرجع (panel-overview)
   شمارندهٔ سفارش‌ها از API فروشنده خوانده می‌شود. */

import Link from "next/link";
import PanelShell, { usePanelSid } from "@/components/features/panel-page";
import { STORES } from "@/lib/data";
import { useCommerce, useSellerOrders } from "@/lib/commerce";
import { fa } from "@/lib/format";
import Ic from "@/components/icons";

const ACTIVE = ["placed", "accepted", "preparing", "ready", "sent"];

function PanelOverviewInner() {
  const { sid } = usePanelSid();
  const { storeOf } = useCommerce();
  const { orders } = useSellerOrders(sid);
  const s = storeOf(sid) || STORES[0];
  const flowCnt = orders.filter((o) => ACTIVE.includes(o.status)).length;

  return (
    <>
      <header className="rv-heading g10-heading">
        <span>{s.name}</span>
        <h1 tabIndex={-1}>مدیریت فروشگاه، ساده و سریع.</h1>
        <p>سفارش را بررسی کن، منو را به‌روز کن و مسیر بعدی را انتخاب کن.</p>
      </header>

      <div className="g10-dashboard-primary">
        <Link href="/panel/orders">
          <span className="g10-icon">
            <Ic n="list" />
          </span>
          <div>
            <span>سفارش‌های در جریان</span>
            <strong>{fa(flowCnt)}</strong>
            <b>
              رفتن به سفارش‌ها <Ic n="chevL" c="sm" />
            </b>
          </div>
        </Link>
        <Link href="/panel/menu">
          <span className="g10-icon">
            <Ic n="qr" />
          </span>
          <div>
            <span>منو و قیمت‌ها</span>
            <strong className="g10-dashboard-title">منوی فروشگاهت را ویرایش کن</strong>
            <b>
              منو و محصولات <Ic n="chevL" c="sm" />
            </b>
          </div>
        </Link>
      </div>

      <section className="g10-tasks">
        <h2>می‌خواهی چه کاری انجام بدهی؟</h2>
        <div>
          <Link href="/panel/orders">
            <span className="g10-icon">
              <Ic n="qr" />
            </span>
            <div>
              <b>تأیید خرید حضوری</b>
              <span>اسکن یا ورود کد مشتری</span>
            </div>
            <Ic n="chevL" c="sm" />
          </Link>
          <Link href="/panel/products">
            <span className="g10-icon">
              <Ic n="layers" />
            </span>
            <div>
              <b>محصول و قیمت</b>
              <span>ویرایش، موجودی و قیمت‌ها</span>
            </div>
            <Ic n="chevL" c="sm" />
          </Link>
          <Link href="/panel/plan">
            <span className="g10-icon">
              <Ic n="card" />
            </span>
            <div>
              <b>اشتراک‌ها</b>
              <span>منو، باشگاه و طلایی</span>
            </div>
            <Ic n="chevL" c="sm" />
          </Link>
          <Link href="/panel/metrics">
            <span className="g10-icon">
              <Ic n="dash" />
            </span>
            <div>
              <b>گزارش باشگاه</b>
              <span>بازدید و خریدهای تأییدشده</span>
            </div>
            <Ic n="chevL" c="sm" />
          </Link>
        </div>
      </section>

      <section className="g10-service-status">
        <h2>خدمات این فروشگاه</h2>
        <Link href="/panel/menu">
          <span>منوی دیجیتال</span>
          <span className="g10-state">فعال نشده</span>
        </Link>
        <Link href="/panel/plan">
          <span>باشگاه و نمایش ویژه</span>
          <span className="g10-state">فعال نشده</span>
        </Link>
        <Link href="/panel/plan">
          <span>بستهٔ طلایی</span>
          <span className="g10-state">فعال نشده</span>
        </Link>
      </section>

      <Link className="g10-security-note" href="/panel/settings">
        <Ic n="shield" c="sm" />
        امنیت و حریم خصوصی این نسخه <Ic n="chevL" c="sm" />
      </Link>
    </>
  );
}

export default function PanelPage() {
  return (
    <PanelShell>
      <PanelOverviewInner />
    </PanelShell>
  );
}
