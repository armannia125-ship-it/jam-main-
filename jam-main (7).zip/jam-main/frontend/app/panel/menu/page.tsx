"use client";
/* منوی دیجیتال و QR — لایهٔ نهایی مطابق DOM مرجع (panel-menu)
   شامل بنر اشتراک منو، کارت قالب/رنگ، کارت QR و پیش‌نمایش کامل منو
   داخل قاب گوشی (dm-v4). کد QR از نقطهٔ پایانی فروشنده
   (/api/businesses/<id>/qr/) برای فروشگاه انتخاب‌شده دریافت می‌شود؛ منو از
   رابطهٔ Business↔Menu و نشانی عمومی از PUBLIC_FRONTEND_URL تعیین می‌شود. */

import { useMemo, useState, useEffect } from "react";
import React from "react";
import Link from "next/link";
import PanelShell, { PTop, ProductArt, usePanelSid } from "@/components/features/panel-page";
import { useJam } from "@/lib/state";
import { useCommerce } from "@/lib/commerce";
import { ApiError, apiFetch } from "@/lib/api";
import { isRetryableQrError } from "@/lib/qr-retry";
import { ACCENTS, discPct, hoursText, productPhoto, store as getStore, STORES, STORE_NAMES, storePhoto, type Product, type Store } from "@/lib/data";
import { fa, faD, norm } from "@/lib/format";
import Ic from "@/components/icons";

/* ---------- پیش‌نمایش کامل منو داخل قاب گوشی (dm-v4) ---------- */
function SignatureCard({ p, s }: { p: Product; s: Store }) {
  const photo = productPhoto(p, s.id);
  return (
    <article className="signature-card">
      <button type="button" className="signature-photo">
        {photo ? (
          <img className="media-photo" src={photo} alt="" loading="lazy" />
        ) : (
          <span className="product-symbol">
            <Ic n="pkg" />
          </span>
        )}
        <span>
          <Ic n="spark" c="sm" />
          انتخاب ویژه
        </span>
      </button>
      <div className="signature-body">
        <button type="button">
          <h3>{p.name}</h3>
          <span>{p.desc}</span>
        </button>
        <div className="signature-foot">
          <div>
            <b className="tnum">{fa(p.price)}</b>
            <small>تومان</small>
          </div>
          <span className="qc" data-pid={p.id}>
            <button type="button" className="add" aria-label={`افزودن ${p.name} به سبد`}>
              <Ic n="plus" />
            </button>
          </span>
        </div>
      </div>
    </article>
  );
}

function MenuItem({ p }: { p: Product }) {
  const pct = discPct(p);
  return (
    <article className={`item${p.available ? "" : " na"}`} id={`dm-product-${p.id}`}>
      <button type="button" className="item-open" aria-label={`جزئیات ${p.name}`}>
        <span className="item-photo">
          <ProductArt p={p} />
          {p.pop ? <span className="item-choice">پیشنهاد جم</span> : null}
        </span>
        <span className="item-info">
          <h3>{p.name}</h3>
          <span className="item-description">{p.desc}</span>
          {!p.available ? <span className="sold-label">فعلاً ناموجود</span> : null}
        </span>
      </button>
      <div className="item-purchase">
        <div className="item-price">
          {pct > 0 ? (
            <span className="item-old">
              <s>{fa(p.old)}</s>
              <span>{fa(pct)}٪</span>
            </span>
          ) : null}
          <span>
            <b className="tnum">{fa(p.price)}</b>
            <small>تومان</small>
          </span>
        </div>
        <span className="qc" data-pid={p.id}>
          {p.available ? (
            <button type="button" className="add" aria-label={`افزودن ${p.name} به سبد`}>
              <Ic n="plus" />
            </button>
          ) : (
            <span className="na-tag">ناموجود</span>
          )}
        </span>
      </div>
    </article>
  );
}

function PhonePreview({ s, tpl, acc }: { s: Store; tpl: string; acc: string }) {
  const monogram = STORE_NAMES[s.id] || s.name;
  const [mode, setMode] = useState<"delivery" | "pickup">("delivery");
  const [sec, setSec] = useState(0);
  const [q, setQ] = useState("");

  const availSecs = s.sections.filter((x) => s.products.some((p) => p.sec === x));
  const signatures = useMemo(() => {
    const pops = s.products.filter((p) => p.pop && p.available);
    const rest = s.products.filter((p) => !pops.includes(p));
    return [...pops, ...rest].slice(0, 3);
  }, [s]);
  const matched = q.trim() ? s.products.filter((p) => norm(p.name).includes(norm(q)) || norm(p.desc).includes(norm(q))) : s.products;
  const noResults = q.trim() && matched.length === 0;

  return (
    <div className="phone" style={{ transform: "scale(.92)", transformOrigin: "top center", marginTop: -8 }}>
      <div className="screen in-phone">
        <div className="pm">
          <div className={`dm t-${tpl} dm-v4`} style={{ "--acc": acc } as React.CSSProperties} data-dm-store={s.id}>
            <header className="dm-top">
              <span className="dm-home">
                <span>
                  جم<i />
                </span>
                <small>منوی دیجیتال</small>
              </span>
              <span className="dm-top-title">{s.name}</span>
              <span className="dm-top-actions">
                <a href={`tel:${s.phone}`} className="dm-contact" aria-label="تماس با مجموعه">
                  <Ic n="phone" />
                </a>
                <span className="dm-contact" aria-label="اشتراک‌گذاری منو">
                  <Ic n="share" />
                </span>
                <span className="dm-header-cart">
                  <Ic n="bag" />
                  <span>سبد خرید</span>
                </span>
              </span>
            </header>

            <section className="dm-cover">
              <img className="dm-cover-photo" src={storePhoto(s)} alt="" />
              <div className="dm-cover-shade" />
              <div className="dm-cover-content">
                <span className="dm-cover-tag">{s.tagline}</span>
                <h1>{monogram}</h1>
                <p>{s.desc}</p>
                <div className="dm-cover-details">
                  <span className="dm-open">
                    <i />
                    امکان پیش‌سفارش
                  </span>
                  <span>
                    <Ic n="star" c="sm" />
                    {fa(s.rating)}{" "}
                    <small>
                      ({fa(s.reviews)} نظر)
                    </small>
                  </span>
                </div>
              </div>
              <a href={`tel:${s.phone}`} className="dm-cover-contact">
                <Ic n="phone" c="sm" />
                تماس با {monogram}
              </a>
              <div className="dm-cover-index">
                <span>منوی آنلاین</span>
                <b>{fa(s.products.length)}</b>
                <span>انتخاب برای شما</span>
              </div>
            </section>

            <div className="dm-utility">
              <div className="dm-about">
                <span className="dm-logo">
                  <span className={`brand-monogram bm-${s.id}`}>{monogram}</span>
                </span>
                <span>
                  <b>{s.name}</b>
                  <small>
                    <Ic n="clock" c="sm" />
                    آماده‌سازی {fa(s.prep)} دقیقه <i>•</i> تحویل حضوری رایگان
                  </small>
                </span>
              </div>
              <div className="seg" role="tablist" aria-label="روش دریافت">
                <button type="button" role="tab" aria-selected={mode === "delivery"} className={mode === "delivery" ? "on" : ""} onClick={() => setMode("delivery")}>
                  <Ic n="truck" />
                  ارسال به محل
                </button>
                <button type="button" role="tab" aria-selected={mode === "pickup"} className={mode === "pickup" ? "on" : ""} onClick={() => setMode("pickup")}>
                  <Ic n="walk" />
                  تحویل حضوری
                </button>
              </div>
              <button type="button" className="dm-info-btn">
                <Ic n="info" c="sm" />
                درباره مجموعه
              </button>
            </div>

            <div className="dm-layout">
              <aside className="dm-sidebar">
                <span className="dm-nav-label">در منو بگردید</span>
                <nav className="dm-tabs">
                  {availSecs.map((x, i) => (
                    <a key={x} className={sec === i ? "on" : ""} onClick={() => setSec(i)}>
                      <span>{x}</span>
                      <small>{fa(s.products.filter((p) => p.sec === x).length)}</small>
                      <Ic n="chevL" c="sm" />
                    </a>
                  ))}
                </nav>
                <div className="dm-side-note">
                  <Ic n="shield" />
                  <b>با خیال راحت انتخاب کنید.</b>
                  <span>قیمت نهایی پیش از ثبت سفارش نمایش داده می‌شود.</span>
                </div>
                <div className="dm-hours">
                  <Ic n="clock" c="sm" />
                  <span>
                    ساعت پذیرش سفارش
                    <b>{hoursText(s)}</b>
                  </span>
                </div>
              </aside>
              <div className="dm-content">
                <div className="dm-editorial">
                  <div>
                    <span className="dm-overline">به سلیقه‌ی {monogram}</span>
                    <h2>از این‌ها شروع کنید.</h2>
                  </div>
                  <span className="dm-handpick">
                    <Ic n="spark" />
                    انتخاب‌های محبوب
                  </span>
                </div>
                <div className="dm-signatures">
                  {signatures.map((p) => (
                    <SignatureCard key={p.id} p={p} s={s} />
                  ))}
                </div>
                <div className="dm-search-row">
                  <h2>همه‌ی منو</h2>
                  <label className="dm-search">
                    <Ic n="search" c="sm" />
                    <input
                      type="search"
                      placeholder="جست‌وجو در منو و محصولات"
                      value={q}
                      onChange={(e) => setQ(e.target.value)}
                      aria-label="جست‌وجو در منو"
                      maxLength={200}
                    />
                  </label>
                </div>
                <div className="dm-menu-sections">
                  {availSecs.map((x, i) => {
                    const list = matched.filter((p) => p.sec === x);
                    return (
                      <section className="dm-sec" key={x} id={`dm-${i}`}>
                        <div className="dm-section-title">
                          <span className="dm-sec-number">{faD(String(i + 1).padStart(2, "0"))}</span>
                          <h2>{x}</h2>
                          <span>{fa(list.length)} انتخاب</span>
                        </div>
                        <div className="dm-items">
                          {list.map((p) => (
                            <MenuItem key={p.id} p={p} />
                          ))}
                        </div>
                      </section>
                    );
                  })}
                </div>
                <div className="dm-no-results" hidden={!noResults}>
                  <div className="empty">
                    <div className="e-ic">
                      <Ic n="search" />
                    </div>
                    <b>این طعم را پیدا نکردیم</b>
                    <div style={{ fontSize: 14 }}>نام دیگری را امتحان کنید.</div>
                  </div>
                </div>
              </div>
            </div>

            <footer className="dm-foot">
              <span className="dm-footer-word">{monogram}</span>
              <b>{s.name}</b>
              <p>{s.address}</p>
              <a href={`tel:${s.phone}`} dir="ltr">
                {faD(s.phone)}
              </a>
              <div className="dm-powered">
                ساخته‌شده برای یک تجربه بهتر، با <Link href="/">جم</Link>
              </div>
              <small>نسخه نمایشی؛ تصاویر و اطلاعات نمونه هستند.</small>
            </footer>
          </div>
        </div>
      </div>
    </div>
  );
}

type SellerQr = {
  menuTitle: string;
  menuSlug: string;
  publicUrl: string;
  qrCode: string;
};

type QrMenuOption = { slug: string; title: string };

type QrState =
  | { businessId: number | null; status: "idle" | "loading" }
  | { businessId: number; status: "ready"; data: SellerQr }
  | { businessId: number; status: "selection"; menus: QrMenuOption[]; message: string }
  | { businessId: number; status: "error"; message: string; code?: string; retryable: boolean };

/* انتخاب صریح منو برای هر کسب‌وکار جدا نگه داشته می‌شود تا انتخاب یک
   کسب‌وکار هرگز روی کسب‌وکار دیگر اعمال نشود. معتبر بودن انتخاب همیشه با
   پاسخ سرور (فهرست منوهای منتشرشدهٔ همان کسب‌وکار) بررسی می‌شود. */
const QR_MENU_KEY = "jam.qr.menu.v1";

function readStoredMenu(businessId: number): string | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(QR_MENU_KEY);
    if (!raw) return null;
    const map = JSON.parse(raw) as Record<string, unknown>;
    const value = map[String(businessId)];
    return typeof value === "string" && value ? value : null;
  } catch {
    return null;
  }
}

function writeStoredMenu(businessId: number, slug: string | null) {
  if (typeof window === "undefined") return;
  try {
    const raw = localStorage.getItem(QR_MENU_KEY);
    const map = raw ? (JSON.parse(raw) as Record<string, string>) : {};
    if (slug) map[String(businessId)] = slug;
    else delete map[String(businessId)];
    localStorage.setItem(QR_MENU_KEY, JSON.stringify(map));
  } catch {
    /* ذخیرهٔ محلی اختیاری است؛ نبودش انتخاب را خراب نمی‌کند. */
  }
}

function PanelMenuInner() {
  const { sid } = usePanelSid();
  const { toast } = useJam();
  const { business } = useCommerce();
  const [tpl, setTpl] = useState("modern");
  const [acc, setAcc] = useState(ACCENTS[0]);
  /* فروشگاه واقعی انتخاب‌شده از لایهٔ احراز هویت‌شدهٔ پنل. */
  const businessId = business(sid)?.id ?? null;
  /* فقط برای پیش‌نمایش بصری قالب؛ هرگز برای تعیین QR استفاده نمی‌شود. */
  const previewStore = getStore(String(sid ?? "")) || STORES[0];
  const [qr, setQr] = useState<QrState>({ businessId: null, status: "idle" });
  const [attempt, setAttempt] = useState(0);
  /* منوی انتخاب‌شده همراه با کسب‌وکاری که برایش انتخاب شده است. */
  const [selected, setSelected] = useState<{ businessId: number; slug: string } | null>(null);
  /* فهرست منوهای معتبر که سرور در پاسخ انتخاب‌لازم برگردانده است. */
  const [options, setOptions] = useState<{ businessId: number; menus: QrMenuOption[] } | null>(null);

  /* انتخاب فقط وقتی معتبر است که به همین کسب‌وکار تعلق داشته باشد. */
  const selectedSlug = selected && selected.businessId === businessId ? selected.slug : null;
  const menuOptions = options && options.businessId === businessId ? options.menus : [];

  const tpls: [string, string, string, string, string][] = [
    ["modern", "مدرن", "#fff", "#2C7A8C", "#E6EAED"],
    ["classic", "کلاسیک", "#FBF7EF", "#8A5A2B", "#E9DCC4"],
    ["dark", "تیره", "#121417", "#2C7A8C", "#2A3035"],
  ];

  useEffect(() => {
    if (!businessId) {
      setQr({ businessId: null, status: "idle" });
      return;
    }
    let active = true;
    setQr({ businessId, status: "loading" });
    const query = selectedSlug ? `?menu=${encodeURIComponent(selectedSlug)}` : "";
    apiFetch<SellerQr>(`/businesses/${businessId}/qr/${query}`)
      .then((data) => {
        if (active) setQr({ businessId, status: "ready", data });
      })
      .catch((err) => {
        if (!active) return;
        if (!(err instanceof ApiError)) {
          setQr({
            businessId,
            status: "error",
            message: "ساخت QR ناموفق بود؛ دوباره تلاش کنید.",
            retryable: true,
          });
          return;
        }
        const payload = err.data as { menus?: QrMenuOption[] } | null;
        const menus = Array.isArray(payload?.menus) ? payload.menus : [];
        if (err.code === "menu_selection_required" && menus.length) {
          setOptions({ businessId, menus });
          /* انتخاب قبلیِ همین کسب‌وکار فقط اگر در فهرست معتبر سرور باشد بازگردانده می‌شود. */
          const stored = selectedSlug ? null : readStoredMenu(businessId);
          if (stored && menus.some((menu) => menu.slug === stored)) {
            setSelected({ businessId, slug: stored });
            return;
          }
          setQr({ businessId, status: "selection", menus, message: err.message });
          return;
        }
        /* انتخاب ذخیره‌شده دیگر منتشرشده نیست: انتخاب و فهرست گزینه‌های
           قدیمی پاک می‌شوند و درخواست بدون پارامتر نامعتبر تکرار می‌شود تا
           وضعیت معتبر سرور جایگزین شود. */
        if (selectedSlug && err.code === "menu_not_published") {
          writeStoredMenu(businessId, null);
          setSelected(null);
          setOptions(null);
          return;
        }
        setQr({
          businessId,
          status: "error",
          message: err.message,
          code: err.code,
          retryable: isRetryableQrError(err.status, err.code),
        });
      });
    return () => {
      active = false;
    };
  }, [businessId, selectedSlug, attempt]);

  /* وضعیت نمایش همیشه متعلق به کسب‌وکار فعلی است؛ پاسخ دیرهنگام کسب‌وکار
     قبلی هرگز QR یا فهرست منوی قدیمی را نشان نمی‌دهد. */
  const view: QrState =
    qr.businessId === businessId
      ? qr
      : businessId == null
        ? { businessId: null, status: "idle" }
        : { businessId, status: "loading" };
  const ready = view.status === "ready" ? view.data : null;
  const url = ready ? ready.publicUrl : "";
  const pickerMenus = menuOptions.length ? menuOptions : view.status === "selection" ? view.menus : [];
  /* فقط وقتی فهرست معتبر داریم یا انتخاب در حال بررسی است، انتخابگر دیده می‌شود؛
     در حالت خطا انتخابگرِ قدیمی نمایش داده نمی‌شود. */
  const showPicker =
    pickerMenus.length > 1 &&
    (view.status === "ready" ||
      view.status === "selection" ||
      (view.status === "loading" && selectedSlug !== null));

  /* انتخاب صریح فروشنده؛ سرور همچنان مالکیت و انتشار منو را دوباره بررسی می‌کند. */
  const pickMenu = (slug: string) => {
    if (!businessId) return;
    writeStoredMenu(businessId, slug);
    setSelected({ businessId, slug });
    setQr({ businessId, status: "loading" });
    /* انتخاب دوبارهٔ همان منو هم باید دوباره بررسی شود؛ وگرنه منویی که پس از
       انتخاب از انتشار خارج شده، پنل را برای همیشه در حالت بارگذاری می‌گذارد. */
    setAttempt((n) => n + 1);
  };

  const downloadQr = () => {
    if (!ready) {
      toast("QR هنوز آماده نیست", "err");
      return;
    }
    const a = document.createElement("a");
    a.href = ready.qrCode;
    a.download = `qr-${ready.menuSlug}.png`;
    a.click();
  };

  const printQr = () => {
    if (!ready) {
      toast("QR هنوز آماده نیست", "err");
      return;
    }
    const opened = window.open("", "_blank", "width=520,height=680");
    if (!opened) {
      toast("مرورگر اجازهٔ باز کردن پنجرهٔ چاپ را نداد", "err");
      return;
    }
    const printWindow: Window = opened;
    const doc = printWindow.document;
    doc.title = "کارت QR منو";
    const style = doc.createElement("style");
    style.textContent =
      "body{font-family:Tahoma,sans-serif;text-align:center;padding:32px;direction:rtl}" +
      "h1{font-size:20px;margin:0 0 16px}img{width:320px;height:320px}" +
      "p{color:#555;font-size:13px;word-break:break-all}";
    doc.head.append(style);
    const title = doc.createElement("h1");
    title.textContent = ready.menuTitle;
    const img = doc.createElement("img");
    img.alt = "QR منوی دیجیتال";
    const link = doc.createElement("p");
    link.textContent = ready.publicUrl;
    doc.body.append(title, img, link);

    /* چاپ فقط پس از بارگیری و رمزگشایی تصویر باز می‌شود؛ افزودن img به DOM
       به معنی آماده بودن تصویر نیست. */
    let settled = false;
    let timer: ReturnType<typeof setTimeout> | null = null;
    const cleanup = () => {
      if (timer !== null) {
        clearTimeout(timer);
        timer = null;
      }
      img.removeEventListener("load", onLoad);
      img.removeEventListener("error", onError);
    };
    const openPrint = () => {
      if (settled) return;
      settled = true;
      cleanup();
      printWindow.focus();
      printWindow.print();
    };
    const failPrint = () => {
      if (settled) return;
      settled = true;
      cleanup();
      toast("تصویر QR بارگیری نشد؛ چاپ انجام نشد. دوباره تلاش کنید.", "err");
    };
    const onLoad = () => {
      if (typeof img.decode !== "function") {
        openPrint();
        return;
      }
      img.decode().then(openPrint, failPrint);
    };
    const onError = failPrint;
    img.addEventListener("load", onLoad);
    img.addEventListener("error", onError);
    /* اگر تصویر هرگز بارگیری نشود، پنجرهٔ چاپ بی‌نهایت منتظر نمی‌ماند. */
    timer = setTimeout(failPrint, 15000);
    img.src = ready.qrCode;
  };

  const copy = async () => {
    if (!url) {
      toast("لینک منو هنوز آماده نیست", "err");
      return;
    }
    try {
      await navigator.clipboard.writeText(url);
      toast("کپی شد");
    } catch {
      const t = document.createElement("textarea");
      t.value = url;
      document.body.append(t);
      t.select();
      document.execCommand("copy");
      t.remove();
      toast("کپی شد");
    }
  };

  return (
    <>
      <PTop
        title="منوی دیجیتال و QR"
        sub="قالب منو را انتخاب کنید، QR را دانلود و چاپ کنید"
        actions={
          ready ? (
            <a href={ready.publicUrl} target="_blank" rel="noreferrer" className="btn btn-ghost btn-sm">
              <Ic n="eye" c="sm" />
              باز کردن منو
            </a>
          ) : null
        }
      />

      <div className="m9-menu-banner">
        <div>
          <Ic n="qr" />
          <span>
            <b>اشتراک منوی دیجیتال</b>
            <small>فعال نشده · مستقل از باشگاه حضوری</small>
          </span>
        </div>
        <Link className="btn btn-ghost" href="/panel/plan">
          پلن‌ها و تمدید
        </Link>
      </div>

      <div className="two-col" style={{ marginTop: 0, gridTemplateColumns: "1fr 330px" }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div className="card pad">
            <b>قالب منو</b>
            <p className="muted" style={{ margin: "2px 0 14px", fontSize: 14 }}>
              با تغییر قالب، منوی عمومی و پیش‌نمایش فوراً به‌روز می‌شود.
            </p>
            <div className="tpls">
              {tpls.map(([k, l, bg, a, ln]) => (
                <button key={k} className={`tpl${tpl === k ? " on" : ""}`} onClick={() => setTpl(k)} aria-pressed={tpl === k}>
                  <div className="pv" style={{ background: bg, border: `1px solid ${ln}` }}>
                    <i style={{ width: "40%", background: a, margin: "0 auto 4px" }} />
                    <i style={{ background: ln }} />
                    <i style={{ background: ln, width: "80%" }} />
                    <i style={{ background: ln, width: "60%" }} />
                  </div>
                  <b>{l}</b>
                </button>
              ))}
            </div>
            <div style={{ marginTop: 18 }}>
              <b style={{ fontSize: 14 }}>رنگ اصلی</b>
              <div className="swatches" style={{ marginTop: 10 }}>
                {ACCENTS.map((c) => (
                  <button
                    key={c}
                    className={`sw${acc === c ? " on" : ""}`}
                    style={{ background: c }}
                    onClick={() => setAcc(c)}
                    aria-label={`رنگ ${c}`}
                    aria-pressed={acc === c}
                  />
                ))}
              </div>
            </div>
          </div>

          <div className="card pad">
            <b>لینک و QR اختصاصی</b>
            <p className="muted" style={{ margin: "2px 0 14px", fontSize: 14 }}>
              QR را روی میز، ویترین، بسته‌بندی یا کارت ویزیت قرار دهید.
            </p>
            {showPicker ? (
              <div style={{ marginBottom: 14 }}>
                <b style={{ fontSize: 14 }}>منوی QR</b>
                <p className="muted" style={{ margin: "2px 0 10px", fontSize: 13 }}>
                  این کسب‌وکار چند منوی منتشرشده دارد؛ QR هر منو فقط به همان منو اشاره می‌کند. منوی موردنظر را انتخاب کنید.
                </p>
                <div
                  className="row"
                  role="group"
                  aria-label="انتخاب منوی QR"
                  style={{ flexWrap: "wrap", gap: 8 }}
                >
                  {pickerMenus.map((menu) => {
                    const on = ready ? ready.menuSlug === menu.slug : selectedSlug === menu.slug;
                    return (
                      <button
                        key={menu.slug}
                        type="button"
                        className={`btn btn-sm ${on ? "btn-primary" : "btn-soft"}`}
                        aria-pressed={on}
                        onClick={() => pickMenu(menu.slug)}
                      >
                        {menu.title}
                      </button>
                    );
                  })}
                </div>
              </div>
            ) : null}
            <div className="qr-box">
              <div className="qr" title={ready ? "کد QR منوی شما" : "کد QR در دسترس نیست"}>
                {ready ? (
                  <img
                    src={ready.qrCode}
                    alt={`QR منوی ${ready.menuTitle}`}
                    style={{ width: "100%", height: "100%", display: "block" }}
                  />
                ) : (
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      height: "100%",
                      padding: 8,
                      textAlign: "center",
                      fontSize: 12,
                      color: "var(--muted)",
                    }}
                  >
                    {view.status === "loading" ? (
                      <span>{selectedSlug ? "در حال ساخت QR منوی انتخاب‌شده…" : "در حال ساخت QR…"}</span>
                    ) : null}
                    {view.status === "idle" ? (
                      <span>فروشگاهی برای ساخت QR انتخاب نشده است.</span>
                    ) : null}
                    {view.status === "selection" ? (
                      <span>منوی موردنظر را انتخاب کنید تا QR ساخته شود.</span>
                    ) : null}
                    {view.status === "error" ? <span>{view.message}</span> : null}
                  </div>
                )}
              </div>
              <div className="grow" style={{ display: "flex", flexDirection: "column", gap: 10, minWidth: 220 }}>
                <div className="link-box">
                  <code>{url || "—"}</code>
                  <button className="btn btn-sm btn-soft" onClick={copy}>
                    <Ic n="copy" c="sm" />
                    کپی
                  </button>
                </div>
                <div className="row" style={{ flexWrap: "wrap" }}>
                  <button className="btn btn-primary btn-sm" onClick={downloadQr}>
                    <Ic n="download" c="sm" />
                    دانلود QR (PNG)
                  </button>
                  <button className="btn btn-ghost btn-sm" onClick={printQr}>
                    <Ic n="printer" c="sm" />
                    چاپ کارت رومیزی
                  </button>
                  {view.status === "error" && view.retryable ? (
                    <button className="btn btn-soft btn-sm" onClick={() => setAttempt((n) => n + 1)}>
                      تلاش دوباره
                    </button>
                  ) : null}
                </div>
                {ready ? (
                  <p className="muted" style={{ margin: 0, fontSize: 13 }}>
                    QR منوی «<b>{ready.menuTitle}</b>» —{" "}
                    <span dir="ltr">{ready.menuSlug}</span>
                  </p>
                ) : null}
                <span className="hint">
                  QR از نشانی عمومی منو ساخته می‌شود و روی میز، ویترین یا بسته‌بندی قابل استفاده است. آمار اسکن واقعی متصل نیست.
                </span>
              </div>
            </div>
          </div>
        </div>
        <div>
          <PhonePreview s={previewStore} tpl={tpl} acc={acc} />
        </div>
      </div>
    </>
  );
}

export default function PanelMenuPage() {
  return (
    <PanelShell>
      <PanelMenuInner />
    </PanelShell>
  );
}
