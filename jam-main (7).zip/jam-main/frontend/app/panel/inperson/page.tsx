"use client";

/* =========================================================
   جم لایف — تأیید خرید حضوری فروشنده (/panel/inperson)
   اعتبارسنجی کد، تأیید صریح و لغو خرید همه سمت سرور انجام
   می‌شود. کد صادرشده به‌تنهایی فروش نیست.
   ========================================================= */

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useJam } from "@/lib/state";
import { statusLabel, useClub, useCommerce, useMetrics, useSellerPurchases } from "@/lib/commerce";
import PanelShell, { usePanelSid } from "@/components/features/panel-page";
import { RvNote } from "@/components/features/rv-parts";
import Ic from "@/components/icons";

type DetectedBarcode = { rawValue: string };
declare global {
  interface Window {
    BarcodeDetector?: new (opts?: { formats?: string[] }) => { detect: (v: HTMLVideoElement) => Promise<DetectedBarcode[]> };
  }
}

type Validated = { code: string; hint: string; expires: string; customer: string };

export default function PanelInpersonPage() {
  return (
    <PanelShell>
      <Inperson />
    </PanelShell>
  );
}

function Inperson() {
  const { sid } = usePanelSid();
  const { business, storeOf } = useCommerce();
  const { data: club, saveOffer } = useClub(sid);
  const seller = useSellerPurchases(sid);
  const { data: metrics, refresh: refreshMetrics } = useMetrics(sid);
  const { toast } = useJam();
  const [code, setCode] = useState("");
  const [err, setErr] = useState("");
  const [perk, setPerk] = useState("");
  const [camOpen, setCamOpen] = useState(false);
  const [pending, setPending] = useState<Validated | null>(null);
  const [camSupported, setCamSupported] = useState<boolean | null>(null);
  const [busy, setBusy] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const current = business(sid);
  const s = storeOf(sid);
  const confirmed = useMemo(
    () => seller.purchases.filter((p) => p.status === "confirmed"),
    [seller.purchases],
  );

  useEffect(() => {
    setPerk(club?.offer.text || "");
  }, [club?.offer.text]);

  useEffect(() => {
    setCamSupported(typeof window !== "undefined" && "BarcodeDetector" in window && !!navigator.mediaDevices?.getUserMedia);
    return () => stopCamera();
  }, []);

  const stopCamera = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = null;
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setCamOpen(false);
  };

  const startCamera = async () => {
    if (!window.BarcodeDetector || !navigator.mediaDevices?.getUserMedia) {
      toast("اسکن دوربین این مرورگر در دسترس نیست؛ کد را دستی وارد کن.", "err");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" }, audio: false });
      streamRef.current = stream;
      setCamOpen(true);
      const video = videoRef.current;
      if (!video) return;
      video.srcObject = stream;
      await video.play();
      const detector = new window.BarcodeDetector({ formats: ["qr_code"] });
      timerRef.current = setInterval(async () => {
        try {
          const [hit] = await detector.detect(video);
          if (hit?.rawValue) {
            setCode(hit.rawValue.trim().toUpperCase());
            stopCamera();
            toast("کد خوانده شد؛ بررسی و تأیید کن.");
          }
        } catch {
          /* فریم بعدی */
        }
      }, 500);
    } catch {
      stopCamera();
      toast("دسترسی دوربین فراهم نشد؛ از ورود دستی استفاده کن.", "err");
    }
  };

  const verify = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    setPending(null);
    setBusy(true);
    try {
      const res = await seller.validate(code.trim().toUpperCase());
      if (res.state === "already_confirmed") {
        setErr("این کد قبلاً تأیید شده است.");
        return;
      }
      setPending({ code: code.trim().toUpperCase(), hint: res.code_hint, expires: res.expires_at, customer: res.customer_label });
    } catch (x) {
      setErr((x as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const confirmPending = async () => {
    if (!pending) return;
    setErr("");
    setBusy(true);
    try {
      const res = await seller.confirm(pending.code);
      setCode("");
      setPending(null);
      await refreshMetrics();
      toast(
        res.already_confirmed
          ? "این خرید قبلاً ثبت شده بود؛ رکورد تکراری ساخته نشد."
          : "خرید حضوری ثبت شد؛ کمیسیون جدا صفر است.",
      );
    } catch (x) {
      setErr((x as Error).message);
      setPending(null);
    } finally {
      setBusy(false);
    }
  };

  const revoke = async (id: number) => {
    if (!window.confirm("لغو تأیید خرید حضوری؟ خرید از آمار حذف می‌شود. هیچ برداشت بانکی وجود ندارد.")) return;
    try {
      await seller.revoke(id);
      await refreshMetrics();
      toast("خرید حضوری لغو شد؛ هیچ برداشت بانکی وجود ندارد.");
    } catch (x) {
      setErr((x as Error).message);
    }
  };

  return (
    <>
      <div className="p-top">
        <div>
          <h1 tabIndex={-1}>باشگاه مشتریان حضوری</h1>
          <p className="p-sub">اسکن کن؛ خرید را تأیید کن. اعتبار کد و فروشگاه سمت سرور بررسی می‌شود.</p>
        </div>
        <div className="row">
          <span className="pill gray">{current?.name || s?.name}</span>
        </div>
      </div>
      <RvNote>
        کد یک‌بارمصرف است، اعتبار آن توسط سرور تعیین می‌شود و کد فروشگاه دیگر پذیرفته نمی‌شود. تأیید تکراری رکورد جدید نمی‌سازد.
      </RvNote>

      <div className="rv-grid c7-pos-metrics">
        <div className="rv-card">
          <span>بازدید صفحهٔ باشگاه</span>
          <strong>{(metrics?.visits ?? 0).toLocaleString("fa-IR")}</strong>
        </div>
        <div className="rv-card">
          <span>کدهای صادرشده، نه فروش</span>
          <strong>{(metrics?.codes_issued ?? 0).toLocaleString("fa-IR")}</strong>
        </div>
        <div className="rv-card">
          <span>خریدهای تأییدشده</span>
          <strong>{(metrics?.purchases_confirmed ?? confirmed.length).toLocaleString("fa-IR")}</strong>
        </div>
      </div>

      <section className="rv-card">
        <span className="c7-tag">
          {club ? statusLabel(club.membership.status, club.membership.is_active, club.membership.trial_used) : "—"}
        </span>
        <h2>ثبت کد مشتری</h2>
        <p>پس از دریافت پول خرید، کد را اسکن یا وارد کن؛ تأیید نهایی با خودت است.</p>
        <form id="c7-scan" onSubmit={verify}>
          <label className="rv-field" htmlFor="c7-scan-code">
            <span>کد مشتری</span>
            <input
              id="c7-scan-code"
              dir="ltr"
              autoComplete="off"
              autoCapitalize="characters"
              placeholder="JL…"
              maxLength={40}
              required
              value={code}
              onChange={(e) => setCode(e.target.value)}
            />
          </label>
          <div className="c7-actions">
            <button className="btn btn-primary" type="submit" disabled={busy}>
              بررسی کد
            </button>
            {camOpen ? (
              <button type="button" className="btn btn-ghost" onClick={stopCamera}>بستن دوربین</button>
            ) : (
              <button type="button" className="btn btn-ghost" onClick={startCamera}>اسکن با دوربین</button>
            )}
          </div>
          <p className="c7-error" role="alert">{err}</p>
          {seller.error ? <p className="c7-error" role="alert">{seller.error}</p> : null}
        </form>
        {pending ? (
          <div className="rv-card" role="alertdialog" aria-label="تأیید خرید حضوری" style={{ background: "#F3F8F2", marginTop: 16 }}>
            <b>خرید انجام شده است؟ کد <bdi dir="ltr">{pending.code}</bdi></b>
            <p className="c7-small">
              مشتری {pending.customer} · اعتبار تا {new Date(pending.expires).toLocaleTimeString("fa-IR")}. فقط بعد از دریافت پول تأیید کن.
            </p>
            <div className="c7-actions">
              <button type="button" className="btn btn-primary" onClick={confirmPending} disabled={busy}>
                بله، خرید انجام شد
              </button>
              <button type="button" className="btn btn-ghost" onClick={() => setPending(null)}>انصراف</button>
            </div>
          </div>
        ) : null}
        {camOpen ? (
          <div id="c7-camera">
            <video ref={videoRef} playsInline muted />
          </div>
        ) : null}
        <p className="c7-small">
          {camSupported === false
            ? "دوربین این مرورگر از تشخیص کد پشتیبانی نمی‌کند؛ ورود دستی همیشه در دسترس است."
            : "دوربین فقط در مرورگر و بستر پشتیبانی‌شده کار می‌کند؛ ورود دستی همیشه در دسترس است."}
        </p>
      </section>

      <section className="rv-card">
        <h2>نشانی صفحهٔ خرید حضوری</h2>
        <p>مشتری با باز کردن این نشانی، صفحهٔ خرید حضوری فروشگاه شما و کد خودش را می‌بیند.</p>
        <div className="link-box" dir="ltr">/visit/{sid}</div>
        <div className="c7-actions">
          <Link className="btn btn-ghost" href={`/visit/${sid ?? ""}`}>بازکردن صفحهٔ مشتری</Link>
        </div>
      </section>

      <form
        id="c7-perk"
        className="rv-card"
        onSubmit={async (e) => {
          e.preventDefault();
          try {
            if (!club?.membership.is_active) throw new Error("اشتراک فعال لازم است.");
            await saveOffer(perk.trim());
            toast("پیشنهاد فروشگاه ذخیره شد؛ کد مالی تازه صادر نشده است.");
          } catch (x) {
            toast((x as Error).message, "err");
          }
        }}
      >
        <h2>پیشنهاد ویژهٔ فروشگاه</h2>
        <label className="rv-field" htmlFor="c7-perk-input">
          <span>توضیح پیشنهاد با شرایط روشن</span>
          <input
            id="c7-perk-input"
            maxLength={150}
            required
            value={perk}
            onChange={(e) => setPerk(e.target.value)}
            placeholder="مثلاً هدیهٔ مشخص در خرید بعدی، با حداقل خرید معلوم"
          />
        </label>
        <button className="btn btn-ghost" type="submit">ذخیرهٔ پیشنهاد</button>
        <p className="c7-small">این متن کد تخفیف نمی‌سازد؛ برای تخفیف مالی، کمپین با سقف و بودجه در مرکز درآمد تنظیم کن.</p>
      </form>

      <section className="rv-card">
        <h2>خریدهای حضوری تأییدشده</h2>
        {seller.loading ? <p className="rv-empty">در حال دریافت…</p> : null}
        {confirmed.length ? (
          confirmed.map((t) => (
            <div className="rv-line" key={t.id}>
              <div>
                <b dir="ltr">کد …{t.code_hint}</b>
                <small>
                  {new Date(t.confirmed_at).toLocaleString("fa-IR", { dateStyle: "medium", timeStyle: "short" })} · کمیسیون صفر
                  {t.perk ? ` · پیشنهاد: ${t.perk}` : ""}
                </small>
              </div>
              <button type="button" className="btn btn-ghost" onClick={() => revoke(t.id)}>
                لغو / مرجوعی خرید
              </button>
            </div>
          ))
        ) : (
          <p>تعداد کد صادرشده را با خرید واقعی اشتباه نمی‌گیریم؛ خریدها بعد از تأیید اینجا می‌آیند.</p>
        )}
      </section>

      <p className="c7-small">
        <Ic n="info" c="sm" /> مسیر مشتری: <Link href={`/visit/${sid ?? ""}`}>/visit/{sid}</Link> — کد صادرشده فقط وقتی خرید است که همین‌جا تأیید شود.
      </p>
    </>
  );
}
