"use client";

/* =========================================================
   جم لایف — شرایط همکاری (/panel/agreement)
   پذیرش با نسخه و زمان روی سرور ثبت می‌شود و سوابق قبلی
   بازنویسی نمی‌شوند. پذیرش آنلاین احراز هویت حقوقی نیست.
   ========================================================= */

import { useEffect, useState } from "react";
import PanelShell, { usePanelSid } from "@/components/features/panel-page";
import { RvHeading, RvNote } from "@/components/features/rv-parts";
import { useAgreements, useCommerce } from "@/lib/commerce";

export default function PanelAgreementPage() {
  return (
    <PanelShell>
      <Agreement />
    </PanelShell>
  );
}

function Agreement() {
  const { sid } = usePanelSid();
  const { business } = useCommerce();
  const { current, acceptances, loading, error, accept, refresh } = useAgreements(sid, "seller");
  const [name, setName] = useState("");
  const [consent, setConsent] = useState(false);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (acceptances[0]?.accepted_name && !name) setName(acceptances[0].accepted_name);
  }, [acceptances, name]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    if (!consent) {
      setErr("پذیرش صریح شرایط لازم است.");
      return;
    }
    setBusy(true);
    try {
      await accept(name);
    } catch (x) {
      setErr((x as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <RvHeading
        over="همکاری آنلاین"
        title="شرایط روشن؛ پذیرش نسخه‌دار"
        text="پذیرش با نسخه و زمان روی سرور ثبت می‌شود. این پذیرش جای احراز هویت، مدارک قانونی یا تأیید بانکی را نمی‌گیرد."
      />
      <RvNote>
        این صفحه جایگزین امضای دستی نیست. تغییر شرایط، نسخهٔ تازه می‌سازد و سابقهٔ پذیرش قبلی حفظ می‌شود.
      </RvNote>

      {loading ? <p className="rv-empty">در حال دریافت شرایط…</p> : null}
      {error ? (
        <section className="rv-card">
          <p className="c7-error" role="alert">{error}</p>
          <button type="button" className="btn btn-ghost" onClick={() => refresh()}>تلاش دوباره</button>
        </section>
      ) : null}

      {current ? (
        <section className="rv-card">
          <h2>شرایط نسخهٔ {current.version}</h2>
          <p className="c7-terms">{current.body}</p>
          <form onSubmit={submit}>
            <label className="rv-field" htmlFor="c7-acc-name">
              <span>نام کامل پذیرنده</span>
              <input
                id="c7-acc-name"
                autoComplete="name"
                required
                minLength={3}
                maxLength={100}
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </label>
            <label className="c7-checkbox">
              <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} />
              <span>متن و شرایط را خوانده‌ام و با ثبت نام، نسخه و زمان پذیرش موافقم.</span>
            </label>
            <button className="btn btn-primary" type="submit" disabled={busy}>
              {busy ? "در حال ثبت…" : "ثبت پذیرش آنلاین"}
            </button>
            <p className="c7-error" role="alert">{err}</p>
            <p className="c7-small">پذیرش برای فروشگاه {business(sid)?.name || ""} ثبت می‌شود.</p>
          </form>
        </section>
      ) : null}

      <section className="rv-card">
        <h2>سوابق پذیرش</h2>
        {acceptances.length ? (
          acceptances.map((x) => (
            <details key={x.id}>
              <summary>
                {x.version_label} · {new Date(x.created_at).toLocaleString("fa-IR", { dateStyle: "medium", timeStyle: "short" })}
              </summary>
              <p>{x.accepted_name}</p>
              {x.rate_snapshot ? <p className="c7-small">نرخ ثبت‌شدهٔ زمان پذیرش: {x.rate_snapshot}٪</p> : null}
            </details>
          ))
        ) : (
          <p>هنوز شرایط پذیرفته نشده است.</p>
        )}
      </section>
    </>
  );
}
