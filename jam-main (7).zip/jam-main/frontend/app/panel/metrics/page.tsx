"use client";

/* =========================================================
   جم لایف — گزارش باشگاه (/panel/metrics)
   اعداد مستقیماً از سرور خوانده می‌شوند: بازدید، کد صادرشده،
   خرید تأییدشده و بازگشت مشتری. بازدید/اسکن فروش نیست.
   ========================================================= */

import PanelShell, { usePanelSid } from "@/components/features/panel-page";
import { RvHeading, RvNote } from "@/components/features/rv-parts";
import { useMetrics } from "@/lib/commerce";
import { fa } from "@/lib/format";

export default function PanelMetricsPage() {
  return (
    <PanelShell>
      <Metrics />
    </PanelShell>
  );
}

function Metrics() {
  const { sid } = usePanelSid();
  const { data, loading, error, refresh } = useMetrics(sid);

  return (
    <>
      <RvHeading
        over="گزارش سروری"
        title="نتیجهٔ باشگاه مشتریان"
        text="بازدید و اسکن را فروش حساب نمی‌کنیم. فقط خرید تأییدشده توسط فروشنده در شمارش می‌آید."
      />
      <RvNote>
        این گزارش فقط مربوط به فروشگاه انتخاب‌شده است و از سرور خوانده می‌شود. خرید لغوشده در تعداد خرید و بازگشت شمرده نمی‌شود.
      </RvNote>

      {loading ? <p className="rv-empty">در حال دریافت گزارش…</p> : null}
      {error ? (
        <section className="rv-card">
          <p className="c7-error" role="alert">{error}</p>
          <button type="button" className="btn btn-ghost" onClick={() => refresh()}>تلاش دوباره</button>
        </section>
      ) : null}

      {data ? (
        <>
          <div className="rv-grid">
            <div className="rv-card">
              <span>بازدید صفحهٔ باشگاه</span>
              <strong>{fa(data.visits)}</strong>
            </div>
            <div className="rv-card">
              <span>کد خرید صادرشده</span>
              <strong>{fa(data.codes_issued)}</strong>
            </div>
            <div className="rv-card">
              <span>خرید تأییدشده</span>
              <strong>{fa(data.purchases_confirmed)}</strong>
            </div>
          </div>
          <section className="rv-card">
            <h2>بازگشت مشتری</h2>
            <p>{fa(data.returning_customers)} مشتری با خرید تأییدشده در بیش از یک روز.</p>
            <p className="c7-small">
              {fa(data.unique_customers)} مشتری یکتای خریدار. بازدید بدون خرید و کد صادرشدهٔ بدون تأیید در این عددها نیست.
            </p>
          </section>
        </>
      ) : null}
    </>
  );
}
