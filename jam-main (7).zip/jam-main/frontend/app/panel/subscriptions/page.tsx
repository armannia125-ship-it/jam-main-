"use client";
/* =========================================================
   جم لایف — اشتراک‌های من (پنل کاربری)
   اعتبارهای فعال، سوابق خرید و اعلان‌های پایان اعتبار؛ همه از API
   واقعی خوانده می‌شود. هیچ رابط لغو اشتراک در این صفحه وجود ندارد.
   ========================================================= */

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import PanelShell, { EmptyBlock, PTop } from "@/components/features/panel-page";
import { ApiError, apiFetch } from "@/lib/api";
import { fa, fmtDate } from "@/lib/format";
import {
  ENTITLEMENT_TYPE_LABELS,
  PURCHASE_STATUS_LABELS,
  purchaseStatusPill,
  remainingDays,
  useSubProducts,
  type SubEntitlement,
  type SubNotification,
  type SubPurchaseRow,
  type SubPurchaseStatus,
} from "@/lib/subscriptions-api";
import Ic from "@/components/icons";

function PanelSubscriptionsInner() {
  const { products } = useSubProducts();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [purchases, setPurchases] = useState<SubPurchaseRow[]>([]);
  const [entitlements, setEntitlements] = useState<SubEntitlement[]>([]);
  const [notifications, setNotifications] = useState<SubNotification[]>([]);
  const [markingRead, setMarkingRead] = useState(false);

  const productName = useCallback(
    (slug: string) => products.find((p) => p.slug === slug)?.name || slug,
    [products],
  );

  const productSlugByName = useCallback(
    (name?: string) => (name ? products.find((p) => p.name === name)?.slug : undefined),
    [products],
  );

  const refresh = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [purchaseRes, notifRes] = await Promise.all([
        apiFetch<{ results: SubPurchaseRow[] }>("/subscriptions/purchases/"),
        apiFetch<{ results: SubNotification[] }>("/subscriptions/notifications/"),
      ]);
      setPurchases(purchaseRes.results || []);
      setNotifications(notifRes.results || []);

      /* اعتبارها از وضعیت تک‌تک خریدهای پرداخت‌شده خوانده می‌شود؛
         طلایی دو اعتبار مستقل می‌سازد و هر دو جداگانه نشان داده می‌شوند. */
      const paid = (purchaseRes.results || []).filter((p) => p.status === "paid");
      const statuses = await Promise.all(
        paid.map((p) =>
          apiFetch<SubPurchaseStatus>(`/subscriptions/purchases/${p.id}/`).catch(() => null),
        ),
      );
      setEntitlements(statuses.flatMap((s) => (s ? s.entitlements : [])));
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "دریافت اشتراک‌ها ناموفق بود.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const markAllRead = async () => {
    setMarkingRead(true);
    try {
      await apiFetch("/subscriptions/notifications/", { method: "POST", body: {} });
      await refresh();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "ثبت خواندن اعلان‌ها ناموفق بود.");
    } finally {
      setMarkingRead(false);
    }
  };

  const unread = notifications.filter((n) => !n.read_at);

  return (
    <>
      <PTop
        title="اشتراک‌ها"
        sub="اعتبارهای فعال، سوابق خرید و اعلان‌های پایان اعتبار کسب‌وکارهای شما."
        actions={
          <Link className="btn btn-primary" href="/subscriptions">
            <Ic n="card" c="sm" /> خرید یا تمدید اشتراک
          </Link>
        }
      />

      {error ? (
        <section className="rv-card">
          <p className="c7-error" role="alert">
            {error}
          </p>
          <button type="button" className="btn btn-ghost" onClick={() => refresh()}>
            تلاش دوباره
          </button>
        </section>
      ) : null}

      {loading ? <p className="rv-empty">در حال دریافت اشتراک‌های شما…</p> : null}

      {/* ---------- اعلان‌های پایان اعتبار ---------- */}
      {!loading && unread.length > 0 ? (
        <section className="rv-card">
          <h2>اعلان‌های پایان اعتبار</h2>
          {unread.map((n) => {
            const slug = productSlugByName(n.payload.product_name);
            return (
              <div className="notice amber" key={n.id} style={{ marginBottom: 10 }}>
                <Ic n="bell" c="ic" />
                <span>
                  <b>{n.payload.product_name || "اشتراک"}</b>
                  {n.payload.business_name ? ` برای «${n.payload.business_name}»` : ""} تا{" "}
                  <b>{n.payload.ends_at ? fmtDate(n.payload.ends_at) : "—"}</b> به پایان می‌رسد
                  {typeof n.payload.remaining_days === "number"
                    ? ` (${fa(n.payload.remaining_days)} روز باقی‌مانده)`
                    : ""}
                  .
                  <span style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 8 }}>
                    {slug ? (
                      <Link
                        className="btn btn-sm btn-primary"
                        href={`/subscriptions/checkout?product=${encodeURIComponent(slug)}`}
                      >
                        تمدید اشتراک
                      </Link>
                    ) : (
                      <Link className="btn btn-sm btn-soft" href="/subscriptions">
                        مشاهدهٔ کاتالوگ
                      </Link>
                    )}
                  </span>
                </span>
              </div>
            );
          })}
          <button
            type="button"
            className="btn btn-ghost btn-sm"
            disabled={markingRead}
            onClick={markAllRead}
          >
            {markingRead ? "در حال ثبت…" : "علامت‌گذاری به‌عنوان خوانده‌شده"}
          </button>
        </section>
      ) : null}

      {/* ---------- اعتبارهای فعال ---------- */}
      <section className="rv-card">
        <h2>اعتبارهای فعال</h2>
        {!loading && entitlements.length === 0 ? (
          <EmptyBlock
            icon="card"
            title="فعلاً اعتبار فعالی ندارید"
            desc="پس از خرید موفق اشتراک، اعتبارهای فعال در این بخش نمایش داده می‌شوند."
          >
            <Link className="btn btn-primary" href="/subscriptions">
              مشاهدهٔ کاتالوگ اشتراک‌ها
            </Link>
          </EmptyBlock>
        ) : null}
        {entitlements.map((e, i) => {
          const days = remainingDays(e.ends_at);
          return (
            <div className="rv-line" key={i}>
              <div>
                <b>{ENTITLEMENT_TYPE_LABELS[e.type] || e.type}</b>
                <small>
                  از {e.starts_at ? fmtDate(e.starts_at) : "—"} تا {e.ends_at ? fmtDate(e.ends_at) : "—"}
                  {days !== null ? ` · ${fa(days)} روز باقی‌مانده` : ""}
                </small>
              </div>
              <span className={days !== null && days > 0 ? "pill green" : "pill gray"}>
                {days !== null && days > 0 ? "فعال" : "پایان‌یافته"}
              </span>
            </div>
          );
        })}
        {entitlements.length > 0 ? (
          <p className="c7-small">
            اشتراک طلایی دو اعتبار مستقل می‌سازد (منو و باشگاه) که هرکدام تاریخ و وضعیت جدا دارند.
          </p>
        ) : null}
      </section>

      {/* ---------- سوابق خرید ---------- */}
      <section className="rv-card">
        <h2>سوابق خرید</h2>
        {!loading && purchases.length === 0 ? (
          <p className="rv-empty">هنوز خریدی ثبت نشده است.</p>
        ) : null}
        {purchases.length > 0 ? (
          <div className="tbl-wrap">
            <table className="tbl">
              <thead>
                <tr>
                  <th>اشتراک</th>
                  <th>کسب‌وکار</th>
                  <th>مبلغ (تومان)</th>
                  <th>وضعیت</th>
                  <th>تاریخ ثبت</th>
                  <th>تاریخ تأیید</th>
                </tr>
              </thead>
              <tbody>
                {purchases.map((p) => (
                  <tr key={p.id}>
                    <td>{productName(p.product)}</td>
                    <td>{p.business}</td>
                    <td className="tnum">{fa(p.price_toman)}</td>
                    <td>
                      <span className={purchaseStatusPill(p.status)}>
                        {PURCHASE_STATUS_LABELS[p.status] || p.status}
                      </span>
                    </td>
                    <td>{fmtDate(p.created_at)}</td>
                    <td>{p.confirmed_at ? fmtDate(p.confirmed_at) : "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : null}
        <p className="c7-small">
          خرید اشتراک فقط با پرداخت آنلاین انجام می‌شود؛ امکان لغو خرید پرداخت‌شده از طریق سایت وجود
          ندارد.
        </p>
      </section>
    </>
  );
}

export default function PanelSubscriptionsPage() {
  return (
    <PanelShell>
      <PanelSubscriptionsInner />
    </PanelShell>
  );
}
