"use client";
/* ربات تلگرام — لایهٔ نهایی مطابق DOM مرجع (panel-telegram):
   ربات از این نسخه حذف شده و مدیریت فقط داخل پنل سایت است. */

import Link from "next/link";
import PanelShell from "@/components/features/panel-page";
import Ic from "@/components/icons";

export default function PanelTelegramPage() {
  return (
    <PanelShell>
      <header className="rv-heading g10-heading">
        <span>مدیریت از سایت</span>
        <h1 tabIndex={-1}>مدیریت فروشگاه داخل همین پنل است.</h1>
        <p>ربات از این نسخه حذف شده است؛ محصول، قیمت، منو و سفارش‌ها را در سایت مدیریت کن.</p>
      </header>
      <Link className="btn btn-primary" href="/panel">
        رفتن به خانه پنل <Ic n="chevL" c="sm" />
      </Link>
    </PanelShell>
  );
}
