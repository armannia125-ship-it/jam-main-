"use client";
/* اشتراک فروشگاه — خرید آنلاین از کاتالوگ رسمی و نمایش اعتبارهای مستقل. */

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import PanelShell, { usePanelSid } from "@/components/features/panel-page";
import { ApiError, apiFetch } from "@/lib/api";
import { fa, fmtDate } from "@/lib/format";
import {
  ENTITLEMENT_TYPE_LABELS,
  PURCHASE_STATUS_LABELS,
  purchaseStatusPill,
  remainingDays,
  useSubProducts,
  type SubEntitlement,
  type SubPurchaseRow,
  type SubPurchaseStatus,
} from "@/lib/subscriptions-api";
import Ic from "@/components/icons";

const OFFER_NAV: [string, string, boolean][] = [
  ["اشتراک منو", "/panel/plan", true],
  ["منو", "/panel/menu", false],
  ["باشگاه", "/club", false],
];

function PanelPlanInner() {
  const { sid } = usePanelSid();
  const { products, loading: productsLoading, error: productsError, refresh: refreshProducts } =
    useSubProducts();
  const [purchases, setPurchases] = useState<SubPurchaseRow[]>([]);
  const [entitlements, setEntitlements] = useState<SubEntitlement[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const refresh = useCallback(async () => {
    if (!sid) {
      setLoading(false);
      return;
    }
    setLoading(true);
    setError("");
    try {
      const rows = await apiFetch<{ results: SubPurchaseRow[] }>("/subscriptions/purchases/");
      const mine = (rows.results || []).filter((row) => row.business_id === sid);
      setPurchases(mine);
      const paid = mine.filter((row) => row.status === "paid");
      const statuses = await Promise.all(
        paid.map((row) =>
          apiFetch<SubPurchaseStatus>(`/subscriptions/purchases/${row.id}/`).catch(() => null),
        ),
      );
      setEntitlements(statuses.flatMap((row) => (row ? row.entitlements : [])));
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "دریافت وضعیت اشتراک ناموفق بود.");
    } finally {
      setLoading(false);
    }
  }, [sid]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const current = useMemo(
    () => entitlements.filter((item) => remainingDays(item.ends_at) !== 0),
    [entitlements],
  );

  return (
    <>
      <header className="rv-heading">
        <span className="g12-seller-label">
          <Ic n="brief" c="sm" />
          اشتراک فروشگاه
        </span>
        <h1 tabIndex={-1}>اشتراک‌های رسمی جم لایف.</h1>
        <p>
          خرید فقط با پرداخت آنلاین انجام می‌شود. قیمت و مدت اعتبار از سرور خوانده می‌شود و
          اعتبارهای منو و باشگاه مستقل از هم فعال می‌شوند.
        </p>
      </header>

      <nav className="g10-offer-nav" aria-label="بخش‌های اشتراک">
        {OFFER_NAV.map(([label, href, cur]) => (
          <Link key={label} href={href} aria-current={cur ? "page" : undefined}>
            {label}
          </Link>
        ))}
      </nav>

      {error || productsError ? (
        <section className="rv-card">
          <p className="c7-error" role="alert">
            {error || productsError}
          </p>
          <button
            type="button"
            className="btn btn-ghost"
            onClick={() => {
              void refresh();
              void refreshProducts();
            }}
          >
            تلاش دوباره
          </button>
        </section>
      ) : null}

      <section className="rv-card">
        <h2>اعتبارهای فعال این فروشگاه</h2>
        {loading ? <p className="rv-empty">در حال دریافت وضعیت اعتبارها…</p> : null}
        {!loading && current.length === 0 ? (
          <p className="rv-empty">برای این فروشگاه اعتبار فعالی ثبت نشده است.</p>
        ) : null}
        {current.map((item, index) => {
          const days = remainingDays(item.ends_at);
          return (
            <div className="rv-line" key={`${item.type}-${index}`}>
              <div>
                <b>{ENTITLEMENT_TYPE_LABELS[item.type] || item.type}</b>
                <small>
                  تا {item.ends_at ? fmtDate(item.ends_at) : "—"}
                  {days !== null ? ` · ${fa(days)} روز باقی‌مانده` : ""}
                </small>
              </div>
              <span className="pill green">فعال</span>
            </div>
          );
        })}
      </section>

      <section className="rv-card">
        <h2>خرید یا تمدید</h2>
        {productsLoading ? <p className="rv-empty">در حال دریافت کاتالوگ…</p> : null}
        {!productsLoading && products.length === 0 ? (
          <p className="rv-empty">محصولی برای خرید ثبت نشده است.</p>
        ) : null}
        <div className="plans">
          {products.map((product) => (
            <article className="card plan" key={product.slug}>
              <div>
                <h3>{product.name}</h3>
                <div className="muted" style={{ fontSize: 14 }}>
                  {product.description}
                </div>
              </div>
              <div className="pp tnum">
                <bdi dir="ltr">{fa(product.price_toman)}</bdi>{" "}
                <small>تومان / {fa(product.duration_days)} روز</small>
              </div>
              <ul>
                {product.features.map((feature) => (
                  <li key={feature}>
                    <Ic n="check" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              <Link
                className="btn btn-primary btn-block"
                href={`/subscriptions/checkout?product=${encodeURIComponent(product.slug)}${
                  sid ? `&business=${sid}` : ""
                }`}
              >
                خرید با پرداخت آنلاین <Ic n="chevL" c="sm" />
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className="rv-card">
        <h2>سوابق خرید این فروشگاه</h2>
        {!loading && purchases.length === 0 ? (
          <p className="rv-empty">هنوز خریدی برای این فروشگاه ثبت نشده است.</p>
        ) : null}
        {purchases.map((row) => (
          <div className="rv-line" key={row.id}>
            <div>
              <b>{row.product}</b>
              <small>
                {PURCHASE_STATUS_LABELS[row.status] || row.status} · {fmtDate(row.created_at)}
              </small>
            </div>
            <span className={purchaseStatusPill(row.status)}>
              {PURCHASE_STATUS_LABELS[row.status] || row.status}
            </span>
          </div>
        ))}
      </section>

      <p className="g12-club-purpose">
        اشتراک طلایی دو اعتبار مستقل ۳۰ روزه می‌سازد (منو و باشگاه)؛ خرید باشگاه به‌تنهایی منوی
        دیجیتال نمی‌دهد. هیچ پرداخت دستی یا کد فعال‌سازی وجود ندارد.
      </p>
    </>
  );
}

export default function PanelPlanPage() {
  return (
    <PanelShell mainClass="m9-club-page g12-club-page">
      <PanelPlanInner />
    </PanelShell>
  );
}
