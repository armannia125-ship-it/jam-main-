"use client";
/* تنظیمات فروشگاه — مطابق مرجع (pSettings)
   فرم از فروشگاه انتخابی پنل پیش‌پر می‌شود؛ ذخیره فقط محلی و نمایشی است. */

import { useState } from "react";
import PanelShell, { PTop, usePanelSid } from "@/components/features/panel-page";
import { useJam } from "@/lib/state";
import { store as getStore, STORES, type Store } from "@/lib/data";
import Ic from "@/components/icons";

type Form = {
  name: string;
  tagline: string;
  desc: string;
  phone: string;
  address: string;
  h1o: string;
  h1c: string;
  h2o: string;
  h2c: string;
  minOrder: string;
  prep: string;
  pickup: boolean;
  delivery: boolean;
};

const snapshot = (s: Store): Form => ({
  name: s.name,
  tagline: s.tagline,
  desc: s.desc,
  phone: s.phone,
  address: s.address,
  h1o: s.hours[0]?.[0] || "",
  h1c: s.hours[0]?.[1] === "24:00" ? "23:59" : s.hours[0]?.[1] || "",
  h2o: s.hours[1]?.[0] || "",
  h2c: s.hours[1]?.[1] || "",
  minOrder: String(s.minOrder || 0),
  prep: String(s.prep || 0),
  pickup: s.pickup,
  delivery: s.delivery,
});

function SettingsForm({ s }: { s: Store }) {
  const { toast } = useJam();
  const [f, setF] = useState<Form>(() => snapshot(s));
  const set = <K extends keyof Form>(k: K, v: Form[K]) => setF((p) => ({ ...p, [k]: v }));

  return (
    <form
      className="card pad"
      noValidate
      onSubmit={(e) => {
        e.preventDefault();
        toast("تنظیمات فروشگاه ذخیره شد");
      }}
    >
      <div className="form-grid">
        <div className="field">
          <label htmlFor="st-n">نام فروشگاه</label>
          <input className="input" id="st-n" value={f.name} onChange={(e) => set("name", e.target.value)} required />
        </div>
        <div className="field">
          <label htmlFor="st-t">شعار / توضیح کوتاه</label>
          <input className="input" id="st-t" value={f.tagline} onChange={(e) => set("tagline", e.target.value)} />
        </div>
        <div className="field full">
          <label htmlFor="st-d">معرفی</label>
          <textarea className="textarea" id="st-d" value={f.desc} onChange={(e) => set("desc", e.target.value)} />
        </div>
        <div className="field">
          <label htmlFor="st-p">تلفن</label>
          <input className="input input-ltr" id="st-p" value={f.phone} onChange={(e) => set("phone", e.target.value)} />
        </div>
        <div className="field">
          <label htmlFor="st-a">آدرس</label>
          <input className="input" id="st-a" value={f.address} onChange={(e) => set("address", e.target.value)} />
        </div>
        <div className="field">
          <label htmlFor="st-h1">ساعت کاری (شیفت اول)</label>
          <div className="row">
            <input
              className="input input-ltr"
              type="time"
              aria-label="شروع"
              value={f.h1o}
              onChange={(e) => set("h1o", e.target.value)}
            />
            <span className="faint">تا</span>
            <input
              className="input input-ltr"
              type="time"
              aria-label="پایان"
              value={f.h1c}
              onChange={(e) => set("h1c", e.target.value)}
            />
          </div>
        </div>
        <div className="field">
          <label>
            شیفت دوم <span className="faint">(اختیاری)</span>
          </label>
          <div className="row">
            <input
              className="input input-ltr"
              type="time"
              aria-label="شروع"
              value={f.h2o}
              onChange={(e) => set("h2o", e.target.value)}
            />
            <span className="faint">تا</span>
            <input
              className="input input-ltr"
              type="time"
              aria-label="پایان"
              value={f.h2c}
              onChange={(e) => set("h2c", e.target.value)}
            />
          </div>
        </div>
        <div className="field">
          <label htmlFor="st-m">حداقل سفارش (تومان)</label>
          <input
            className="input input-ltr tnum"
            id="st-m"
            inputMode="numeric"
            value={f.minOrder}
            onChange={(e) => set("minOrder", e.target.value)}
          />
        </div>
        <div className="field">
          <label htmlFor="st-pr">زمان آماده‌سازی (دقیقه)</label>
          <input
            className="input input-ltr tnum"
            id="st-pr"
            inputMode="numeric"
            value={f.prep}
            onChange={(e) => set("prep", e.target.value)}
          />
        </div>
        <div className="field full" style={{ gap: 14, paddingTop: 6 }}>
          <label className="chk">
            <span className="switch">
              <input type="checkbox" checked={f.pickup} onChange={(e) => set("pickup", e.target.checked)} />
              <span />
            </span>
            تحویل حضوری فعال باشد
          </label>
          <label className="chk">
            <span className="switch">
              <input type="checkbox" checked={f.delivery} onChange={(e) => set("delivery", e.target.checked)} />
              <span />
            </span>
            ارسال به محل فعال باشد (پیک همکار / تاکسی ۱۸۱۶)
          </label>
        </div>
      </div>
      <div className="row" style={{ marginTop: 20, justifyContent: "flex-end", gap: 10 }}>
        <button type="button" className="btn btn-ghost" onClick={() => setF(snapshot(s))}>
          بازگردانی
        </button>
        <button className="btn btn-primary" type="submit">
          <Ic n="check" c="sm" />
          ذخیره تغییرات
        </button>
      </div>
    </form>
  );
}

function PanelSettingsInner() {
  const { sid } = usePanelSid();
  const s = getStore(String(sid ?? "")) || STORES[0];

  return (
    <>
      <PTop title="تنظیمات فروشگاه" sub="اطلاعاتی که مشتری در صفحه فروشگاه و منو می‌بیند" />
      <SettingsForm key={s.id} s={s} />
    </>
  );
}

export default function PanelSettingsPage() {
  return (
    <PanelShell>
      <PanelSettingsInner />
    </PanelShell>
  );
}
