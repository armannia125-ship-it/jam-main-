import type { Metadata } from "next";
import VisitClient from "@/components/features/visit-page";

export const metadata: Metadata = { title: "خرید حضوری در باشگاه | جم لایف" };

export default async function VisitPage({ params }: { params: Promise<{ storeId: string }> }) {
  const { storeId } = await params;
  return <VisitClient storeId={storeId} />;
}
