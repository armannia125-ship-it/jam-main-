"use client";

import { useState } from "react";
import Ic from "@/components/icons";
import {
  achievementPercent,
  levelPercent,
  levelUpText,
  missionActionLabel,
  missionPercent,
  missionState,
  rankLabel,
  relationLabel,
  rewardChips,
} from "./progression";
import type {
  Achievement,
  DailyGift,
  FriendItem,
  FriendsPayload,
  LeaderboardPayload,
  Mission,
  MissionsPayload,
  Profile,
  ProgressPayload,
} from "./types";

const fa = (value: number | string) => Number(value || 0).toLocaleString("fa-IR");

const MISSION_ICONS: Record<string, string> = {
  swords: "star",
  users: "user",
  gift: "pkg",
  pin: "pin",
  map: "pin",
  cards: "layers",
  hammer: "wrench",
  store: "store",
  flag: "list",
};

function missionIcon(name: string): string {
  return MISSION_ICONS[name] || "list";
}

function StateNote({
  loading,
  error,
  empty,
  emptyText,
  onRetry,
}: {
  loading?: boolean;
  error?: string | null;
  empty?: boolean;
  emptyText?: string;
  onRetry?: () => void;
}) {
  if (loading) {
    return (
      <div className="card center" style={{ padding: 24 }}>
        <Ic n="clock" c="lg" />
        <p>در حال بارگذاری…</p>
      </div>
    );
  }
  if (error) {
    return (
      <div className="card center" style={{ padding: 24 }}>
        <Ic n="alert" c="lg" />
        <p>{error}</p>
        {onRetry && (
          <button className="btn btn-primary" onClick={onRetry}>
            تلاش دوباره
          </button>
        )}
      </div>
    );
  }
  if (empty) {
    return (
      <div className="card center" style={{ padding: 24 }}>
        <Ic n="list" c="lg" />
        <p className="muted">{emptyText || "هنوز چیزی اینجا نیست."}</p>
      </div>
    );
  }
  return null;
}

function MissionRow({
  mission,
  busy,
  onClaim,
}: {
  mission: Mission;
  busy: boolean;
  onClaim: (key: string) => void;
}) {
  const state = missionState(mission);
  return (
    <article className="p2-mission">
      <span className="p2-mission-icon">
        <Ic n={missionIcon(mission.icon)} />
      </span>
      <div className="p2-mission-body">
        <b>{mission.title}</b>
        <small className="p2-rewards">
          {rewardChips(mission.rewards)
            .map((chip) => `${fa(chip.value)} ${chip.label}`)
            .join(" · ")}
        </small>
        <span
          className="bar"
          role="progressbar"
          aria-valuemin={0}
          aria-valuemax={mission.target}
          aria-valuenow={mission.progress}
        >
          <i style={{ width: `${missionPercent(mission)}%` }} />
        </span>
        <small className="p2-count">
          {fa(mission.progress)} از {fa(mission.target)}
        </small>
      </div>
      <button
        className={`btn ${state === "ready" ? "btn-primary" : "ghost"} sm`}
        disabled={state !== "ready" || busy}
        onClick={() => onClaim(mission.key)}
      >
        {busy && state === "ready" ? "…" : missionActionLabel(mission)}
      </button>
    </article>
  );
}

export function MissionsScreen({
  missions,
  loading,
  error,
  busy,
  onRetry,
  onClaim,
}: {
  missions: MissionsPayload | null;
  loading: boolean;
  error: string | null;
  busy: string | null;
  onRetry: () => void;
  onClaim: (key: string) => void;
}) {
  const note = (
    <StateNote
      loading={loading}
      error={error}
      empty={!loading && !error && !missions}
      emptyText="مأموریتی برای نمایش نیست."
      onRetry={onRetry}
    />
  );
  if (!missions || loading || error) {
    return (
      <>
        <div className="sec-h">
          <div>
            <h2>مأموریت‌ها</h2>
            <p>هر روز یک قدم جلوتر؛ هر پاداش یک‌بار.</p>
          </div>
        </div>
        {note}
      </>
    );
  }
  return (
    <>
      <div className="sec-h">
        <div>
          <h2>هر روز، یک قدم جلوتر</h2>
          <p>مأموریت‌های روزانه و مسیر پیشرفت؛ هر پاداش فقط یک‌بار قابل دریافت است.</p>
        </div>
        <span className="count muted">
          امروز {fa(missions.daily_claimed)} از {fa(missions.daily_total)}
        </span>
      </div>

      <section className="card">
        <div className="sec-h">
          <div>
            <h3>چالش‌های امروز</h3>
            <p>با تغییر روز، پیشرفت چالش‌های روزانه از نو شروع می‌شود.</p>
          </div>
        </div>
        {missions.daily.length === 0 ? (
          <p className="muted">چالشی برای امروز تعریف نشده است.</p>
        ) : (
          <div className="jg-mission-list">
            {missions.daily.map((mission) => (
              <MissionRow
                key={mission.key}
                mission={mission}
                busy={busy === mission.key}
                onClaim={onClaim}
              />
            ))}
          </div>
        )}
      </section>

      <section className="card" style={{ marginTop: 16 }}>
        <div className="sec-h">
          <div>
            <h3>مسیر پیشرفت</h3>
            <p>این مأموریت‌ها با عوض شدن روز پاک نمی‌شوند.</p>
          </div>
          <span className="count muted">
            {fa(missions.permanent_claimed)} از {fa(missions.permanent_total)}
          </span>
        </div>
        {missions.permanent.length === 0 ? (
          <p className="muted">مأموریت دائمی فعالی نیست.</p>
        ) : (
          <div className="jg-mission-list">
            {missions.permanent.map((mission) => (
              <MissionRow
                key={mission.key}
                mission={mission}
                busy={busy === mission.key}
                onClaim={onClaim}
              />
            ))}
          </div>
        )}
      </section>
    </>
  );
}

export function ProgressScreen({
  progress,
  achievements,
  loading,
  error,
  busy,
  onRetry,
  onClaimGift,
}: {
  progress: ProgressPayload | null;
  achievements: Achievement[];
  loading: boolean;
  error: string | null;
  busy: string | null;
  onRetry: () => void;
  onClaimGift: () => void;
}) {
  if (!progress || loading || error) {
    return (
      <>
        <div className="sec-h">
          <div>
            <h2>پیشرفت و نشان‌ها</h2>
            <p>سطح، تجربه و دستاوردهای تو.</p>
          </div>
        </div>
        <StateNote loading={loading} error={error} onRetry={onRetry} />
      </>
    );
  }
  const gift: DailyGift = progress.daily_gift;
  return (
    <>
      <div className="sec-h">
        <div>
          <h2>پیشرفت و نشان‌ها</h2>
          <p>سطح، تجربه و دستاوردهای تو؛ همه روی سرور ذخیره می‌شود.</p>
        </div>
        <span className="count muted">
          {fa(progress.achievements.unlocked)} از {fa(progress.achievements.total)} نشان
        </span>
      </div>

      <section className="card">
        <div className="sec-h">
          <div>
            <h3>سطح {fa(progress.level)}</h3>
            <p>
              {fa(progress.xp_in_level)} از {fa(progress.xp_need)} تجربه ·{" "}
              {fa(progress.xp_to_next)} تجربه تا سطح بعد
            </p>
          </div>
          <span className="pill">{fa(progress.next_level_gems)} الماس در هر سطح</span>
        </div>
        <span className="bar" style={{ display: "block", height: 10 }}>
          <i style={{ width: `${levelPercent({ xp_in_level: progress.xp_in_level, xp_need: progress.xp_need })}%` }} />
        </span>
        {progress.level_history.length > 0 && (
          <div className="p2-levels">
            {progress.level_history.slice(0, 6).map((item) => (
              <span key={item.level} className={item.gems > 0 ? "on" : ""}>
                سطح {fa(item.level)}
                <small>{item.gems > 0 ? `+${fa(item.gems)} الماس` : "پایه"}</small>
              </span>
            ))}
          </div>
        )}
      </section>

      <section className="card" style={{ marginTop: 16 }}>
        <div className="sec-h">
          <div>
            <h3>هدیهٔ روزانه</h3>
            <p>
              {fa(gift.coins)} سکه و {fa(gift.gems)} الماس؛ هر روز یک‌بار.
            </p>
          </div>
        </div>
        <button
          className={`btn ${gift.available ? "btn-primary" : "ghost"}`}
          disabled={!gift.available || busy === "daily-gift"}
          onClick={onClaimGift}
        >
          {gift.available
            ? busy === "daily-gift"
              ? "در حال دریافت…"
              : "دریافت هدیهٔ امروز"
            : "هدیهٔ امروز دریافت شد"}
        </button>
      </section>

      <section className="card" style={{ marginTop: 16 }}>
        <div className="sec-h">
          <div>
            <h3>نشان‌ها</h3>
            <p>هر نشان تازه، ۱۰ الماس هدیه دارد و خودکار ثبت می‌شود.</p>
          </div>
        </div>
        {achievements.length === 0 ? (
          <p className="muted">نشانی تعریف نشده است.</p>
        ) : (
          <div className="jg-badges">
            {achievements.map((achievement) => (
              <div key={achievement.key} className={achievement.unlocked ? "earned" : ""}>
                <Ic n={achievement.icon} />
                <b>{achievement.title}</b>
                <small>{achievement.description}</small>
                <span>
                  {achievement.unlocked
                    ? "به دست آمد"
                    : `${fa(achievement.progress)} از ${fa(achievement.target)}`}
                </span>
                {!achievement.unlocked && (
                  <span className="bar" style={{ display: "block", width: "100%" }}>
                    <i style={{ width: `${achievementPercent(achievement)}%` }} />
                  </span>
                )}
              </div>
            ))}
          </div>
        )}
      </section>
    </>
  );
}

export function ProfileScreen({
  profile,
  progress,
  loading,
  error,
  busy,
  onRetry,
  onRename,
}: {
  profile: Profile;
  progress: ProgressPayload | null;
  loading: boolean;
  error: string | null;
  busy: string | null;
  onRetry: () => void;
  onRename: (name: string) => void;
}) {
  const [name, setName] = useState(profile.display_name);
  const stats = progress?.stats;
  return (
    <>
      <div className="sec-h">
        <div>
          <h2>پروفایل جم‌پلی</h2>
          <p>آمار واقعی بازی، از جمله نبردها، مأموریت‌ها و نشان‌ها.</p>
        </div>
      </div>

      <section className="card">
        <div className="jg-profile">
          <img src="/jamplay/art-hero.webp" alt="" />
          <div style={{ flex: 1, minWidth: 0 }}>
            <h2>{profile.display_name}</h2>
            <p>
              سطح {fa(profile.level)} · {fa(profile.xp)} تجربه
            </p>
            <span className="bar" style={{ display: "block" }}>
              <i style={{ width: `${levelPercent(profile)}%` }} />
            </span>
          </div>
        </div>
        <label className="field" style={{ marginTop: 16 }}>
          <span>نام نمایشی (برای دوستان و جدول)</span>
          <input
            value={name}
            maxLength={20}
            onChange={(event) => setName(event.target.value)}
            placeholder="نام نمایشی تو"
          />
        </label>
        <button
          className="btn btn-primary"
          style={{ marginTop: 10 }}
          disabled={busy === "rename" || name.trim() === profile.display_name || name.trim().length < 2}
          onClick={() => onRename(name.trim())}
        >
          {busy === "rename" ? "در حال ذخیره…" : "ذخیرهٔ نام"}
        </button>
      </section>

      {loading && <StateNote loading />}
      {!loading && error && <StateNote error={error} onRetry={onRetry} />}

      {!loading && !error && stats && (
        <>
          <section className="card" style={{ marginTop: 16 }}>
            <div className="sec-h">
              <div>
                <h3>کارنامه</h3>
                <p>لیگ {stats.league.name} · بهترین {fa(stats.best_trophies)} کاپ</p>
              </div>
              <span className="pill">{fa(stats.trophies)} کاپ</span>
            </div>
            <div className="record">
              <div>
                <b>
                  {fa(stats.arena_wins)}<small>/{fa(stats.arena_played)}</small>
                </b>
                <span>برد آوردگاه</span>
              </div>
              <div>
                <b>
                  {fa(stats.siege_wins)}<small>/{fa(stats.siege_played)}</small>
                </b>
                <span>برد محاصره</span>
              </div>
              <div>
                <b>{fa(stats.arena_crowns)}</b>
                <span>تاج</span>
              </div>
              <div>
                <b>{fa(stats.friendly_played)}</b>
                <span>چالش دوستانه</span>
              </div>
            </div>
          </section>

          <section className="card" style={{ marginTop: 16 }}>
            <div className="sec-h">
              <div>
                <h3>خلاصهٔ پیشرفت</h3>
                <p>مأموریت و نشان‌های ثبت‌شده روی سرور.</p>
              </div>
            </div>
            {progress && (
              <div className="record">
                <div>
                  <b>
                    {fa(progress.missions.daily_claimed)}<small>/{fa(progress.missions.daily_total)}</small>
                  </b>
                  <span>چالش امروز</span>
                </div>
                <div>
                  <b>
                    {fa(progress.missions.permanent_claimed)}
                    <small>/{fa(progress.missions.permanent_total)}</small>
                  </b>
                  <span>مأموریت دائمی</span>
                </div>
                <div>
                  <b>
                    {fa(progress.achievements.unlocked)}<small>/{fa(progress.achievements.total)}</small>
                  </b>
                  <span>نشان</span>
                </div>
                <div>
                  <b>{fa(stats.total_wins)}</b>
                  <span>کل بردها</span>
                </div>
              </div>
            )}
          </section>
        </>
      )}
    </>
  );
}

export function FriendsScreen({
  friends,
  leaderboard,
  loading,
  error,
  busy,
  searchResults,
  searchError,
  searchLoading,
  onRetry,
  onSearch,
  onRequest,
  onRespond,
  onRemove,
  onChallenge,
}: {
  friends: FriendsPayload | null;
  leaderboard: LeaderboardPayload | null;
  loading: boolean;
  error: string | null;
  busy: string | null;
  searchResults: FriendItem[] | null;
  searchError: string | null;
  searchLoading: boolean;
  onRetry: () => void;
  onSearch: (query: string) => void;
  onRequest: (profileId: number) => void;
  onRespond: (profileId: number, accept: boolean) => void;
  onRemove: (profileId: number) => void;
  onChallenge: (profileId: number) => void;
}) {
  const [query, setQuery] = useState("");
  return (
    <>
      <div className="sec-h">
        <div>
          <h2>دوستان و جدول</h2>
          <p>چالش دوستانه کاپ را کم و زیاد نمی‌کند؛ نتیجه روی سرور محاسبه می‌شود.</p>
        </div>
      </div>

      <section className="card">
        <div className="sec-h">
          <div>
            <h3>یافتن بازیکن</h3>
            <p>فقط نام نمایشی جست‌وجو می‌شود؛ شمارهٔ تلفن یا ایمیل هرگز نمایش داده نمی‌شود.</p>
          </div>
        </div>
        <div className="p2-search">
          <input
            value={query}
            maxLength={20}
            placeholder="نام نمایشی بازیکن"
            aria-label="نام نمایشی بازیکن"
            onChange={(event) => setQuery(event.target.value)}
          />
          <button
            className="btn btn-primary"
            disabled={query.trim().length < 2 || searchLoading}
            onClick={() => onSearch(query.trim())}
          >
            {searchLoading ? "در حال جست‌وجو…" : "جست‌وجو"}
          </button>
        </div>
        {searchError && <p className="muted">{searchError}</p>}
        {searchResults && (
          <div className="jg-mission-list" style={{ marginTop: 12 }}>
            {searchResults.length === 0 ? (
              <p className="muted">بازیکنی با این نام پیدا نشد.</p>
            ) : (
              searchResults.map((item) => (
                <div key={item.profile_id} className="friend">
                  <span className="av">{item.display_name.slice(0, 1)}</span>
                  <div>
                    <b>{item.display_name}</b>
                    <small>
                      سطح {fa(item.level)} · {fa(item.trophies)} کاپ · {relationLabel(item.relation)}
                    </small>
                  </div>
                  {item.relation === "none" && (
                    <button
                      className="btn ghost sm"
                      disabled={busy === `request-${item.profile_id}`}
                      onClick={() => onRequest(item.profile_id)}
                    >
                      <Ic n="plus" /> درخواست
                    </button>
                  )}
                  {item.relation === "incoming" && (
                    <button
                      className="btn btn-primary sm"
                      disabled={busy === `respond-${item.profile_id}`}
                      onClick={() => onRespond(item.profile_id, true)}
                    >
                      پذیرش
                    </button>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </section>

      <StateNote loading={loading} error={error} onRetry={onRetry} />

      {!loading && !error && friends && (
        <>
          {friends.incoming.length > 0 && (
            <section className="card" style={{ marginTop: 16 }}>
              <div className="sec-h">
                <div>
                  <h3>درخواست‌های دریافتی</h3>
                </div>
              </div>
              {friends.incoming.map((item) => (
                <div key={item.profile_id} className="friend">
                  <span className="av">{item.display_name.slice(0, 1)}</span>
                  <div>
                    <b>{item.display_name}</b>
                    <small>سطح {fa(item.level)} · {fa(item.trophies)} کاپ</small>
                  </div>
                  <button
                    className="btn btn-primary sm"
                    disabled={busy === `respond-${item.profile_id}`}
                    onClick={() => onRespond(item.profile_id, true)}
                  >
                    پذیرش
                  </button>
                  <button
                    className="btn ghost sm"
                    disabled={busy === `respond-${item.profile_id}`}
                    onClick={() => onRespond(item.profile_id, false)}
                  >
                    رد
                  </button>
                </div>
              ))}
            </section>
          )}

          <section className="card" style={{ marginTop: 16 }}>
            <div className="sec-h">
              <div>
                <h3>دوستان من</h3>
                <p>{fa(friends.friends.length)} دوست تأییدشده</p>
              </div>
            </div>
            {friends.friends.length === 0 ? (
              <p className="muted">هنوز دوستی نداری؛ با جست‌وجوی نام نمایشی شروع کن.</p>
            ) : (
              friends.friends.map((item) => (
                <div key={item.profile_id} className="friend">
                  <span className="av on">{item.display_name.slice(0, 1)}</span>
                  <div>
                    <b>{item.display_name}</b>
                    <small>
                      سطح {fa(item.level)} · {fa(item.trophies)} کاپ · {item.league}
                    </small>
                  </div>
                  <button
                    className="btn ghost sm"
                    disabled={busy === `challenge-${item.profile_id}`}
                    onClick={() => onChallenge(item.profile_id)}
                  >
                    <Ic n="star" /> چالش
                  </button>
                  <button
                    className="btn ghost sm"
                    disabled={busy === `remove-${item.profile_id}`}
                    onClick={() => onRemove(item.profile_id)}
                    aria-label={`حذف ${item.display_name}`}
                  >
                    <Ic n="trash" />
                  </button>
                </div>
              ))
            )}
          </section>

          {friends.outgoing.length > 0 && (
            <section className="card" style={{ marginTop: 16 }}>
              <div className="sec-h">
                <div>
                  <h3>در انتظار پاسخ</h3>
                </div>
              </div>
              {friends.outgoing.map((item) => (
                <div key={item.profile_id} className="friend">
                  <span className="av">{item.display_name.slice(0, 1)}</span>
                  <div>
                    <b>{item.display_name}</b>
                    <small>{relationLabel(item.relation)}</small>
                  </div>
                  <button
                    className="btn ghost sm"
                    disabled={busy === `remove-${item.profile_id}`}
                    onClick={() => onRemove(item.profile_id)}
                  >
                    لغو
                  </button>
                </div>
              ))}
            </section>
          )}
        </>
      )}

      {!loading && !error && leaderboard && (
        <section className="card" style={{ marginTop: 16 }}>
          <div className="sec-h">
            <div>
              <h3>جدول کاپ</h3>
              <p>رتبه‌بندی واقعی بازیکنان بر اساس کاپ.</p>
            </div>
            <span className="pill">رتبهٔ تو: {rankLabel(leaderboard.me.rank)}</span>
          </div>
          {leaderboard.entries.length === 0 ? (
            <p className="muted">هنوز بازیکنی در جدول نیست.</p>
          ) : (
            <ol className="board">
              {leaderboard.entries.map((entry) => (
                <li key={`${entry.rank}-${entry.display_name}`} className={entry.is_me ? "me" : ""}>
                  <span className="rk">{rankLabel(entry.rank)}</span>
                  <span className="av">{entry.display_name.slice(0, 1)}</span>
                  <span className="bn">
                    <b>
                      {entry.display_name}
                      {entry.is_me ? " (تو)" : ""}
                    </b>
                    <small>سطح {fa(entry.level)}</small>
                  </span>
                  <strong>{fa(entry.trophies)} کاپ</strong>
                </li>
              ))}
            </ol>
          )}
        </section>
      )}
    </>
  );
}

export function LevelUpNotice({ leveled }: { leveled: { level: number; gems: number }[] | undefined }) {
  const text = levelUpText(leveled);
  if (!text) return null;
  return (
    <p className="r-note">
      <Ic n="spark" /> {text}
    </p>
  );
}
