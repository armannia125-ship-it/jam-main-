"use client";

import { useCallback, useEffect, useRef } from "react";
import type { SiegeSnapshot, UnitSnapshot } from "./types";

const W = 960;
const H = 760;
const SQ = 22;
const ORIGIN_X = 480;
const ORIGIN_Y = 155;
const ISO_X = 21;
const ISO_Y = 10.5;

const BUILDING_ART: Record<string, string> = {
  th: "th",
  vault: "vault",
  camp: "camp",
  mine: "mine",
  tower: "tower",
  bazaar: "bazaar",
  fountain: "fountain",
  chest: "chest",
  hero: "hero",
};

const UNIT_ART: Record<string, string> = {
  guard: "guard",
  sentinel: "guard",
  archer: "archer",
  volley: "archer",
  golem: "golem",
  mage: "mage",
  spark: "mage",
  meteor: "meteor",
  ballista: "ballista",
  scouts: "scouts",
  frost: "frost",
  heal: "frost",
};

const imageCache = new Map<string, HTMLImageElement>();

function image(src: string): HTMLImageElement {
  const cached = imageCache.get(src);
  if (cached) return cached;
  const element = new Image();
  element.src = src;
  imageCache.set(src, element);
  return element;
}

function iso(x: number, y: number): { x: number; y: number } {
  return { x: ORIGIN_X + (x - y) * ISO_X, y: ORIGIN_Y + (x + y) * ISO_Y };
}

function uniso(x: number, y: number): { x: number; y: number } {
  const a = (x - ORIGIN_X) / ISO_X;
  const b = (y - ORIGIN_Y) / ISO_Y;
  return { x: (a + b) / 2, y: (b - a) / 2 };
}

function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}

function diamond(ctx: CanvasRenderingContext2D, cx: number, cy: number, halfW: number, halfH: number) {
  ctx.beginPath();
  ctx.moveTo(cx, cy - halfH);
  ctx.lineTo(cx + halfW, cy);
  ctx.lineTo(cx, cy + halfH);
  ctx.lineTo(cx - halfW, cy);
  ctx.closePath();
}

export default function SiegeField({
  snapshot,
  selected,
  onDeploy,
  onMessage,
}: {
  snapshot: SiegeSnapshot;
  selected: number | null;
  onDeploy: (gx: number, gy: number) => void;
  onMessage: (message: string) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const previousRef = useRef<SiegeSnapshot | null>(null);
  const currentRef = useRef<SiegeSnapshot | null>(null);
  const changedAtRef = useRef(0);
  const selectedRef = useRef<number | null>(selected);
  const deployRef = useRef(onDeploy);

  useEffect(() => {
    selectedRef.current = selected;
    deployRef.current = onDeploy;
  }, [selected, onDeploy]);

  useEffect(() => {
    if (currentRef.current !== snapshot) {
      previousRef.current = currentRef.current;
      currentRef.current = snapshot;
      changedAtRef.current = performance.now();
    }
  }, [snapshot]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let frame = 0;
    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      canvas.width = Math.max(1, Math.round(rect.width * dpr));
      canvas.height = Math.max(1, Math.round(rect.height * dpr));
    };
    resize();
    const observer = new ResizeObserver(resize);
    observer.observe(canvas);

    const render = (now: number) => {
      frame = requestAnimationFrame(render);
      const current = currentRef.current;
      if (!current) return;
      const previous = previousRef.current;
      const alpha = previous ? Math.min(1, (now - changedAtRef.current) / 650) : 1;
      const width = canvas.width;
      const height = canvas.height;
      if (!width || !height) return;
      ctx.setTransform(width / W, 0, 0, height / H, 0, 0);
      ctx.clearRect(0, 0, W, H);

      const grass = ctx.createLinearGradient(0, 0, 0, H);
      grass.addColorStop(0, "#9ec97a");
      grass.addColorStop(1, "#5d8f4d");
      ctx.fillStyle = grass;
      ctx.fillRect(0, 0, W, H);

      // Ground diamond
      const corners = [iso(0, 0), iso(SQ, 0), iso(SQ, SQ), iso(0, SQ)];
      ctx.beginPath();
      ctx.moveTo(corners[0].x, corners[0].y);
      for (const corner of corners.slice(1)) ctx.lineTo(corner.x, corner.y);
      ctx.closePath();
      ctx.fillStyle = "#7baf5f";
      ctx.fill();
      ctx.strokeStyle = "rgba(255,255,255,.25)";
      ctx.stroke();

      // Faint grid
      ctx.strokeStyle = "rgba(38,74,32,.10)";
      ctx.lineWidth = 1;
      for (let i = 1; i < SQ; i += 1) {
        const a = iso(i, 0);
        const b = iso(i, SQ);
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
        const c = iso(0, i);
        const d = iso(SQ, i);
        ctx.beginPath();
        ctx.moveTo(c.x, c.y);
        ctx.lineTo(d.x, d.y);
        ctx.stroke();
      }

      // Deployment border hint
      if (selectedRef.current !== null) {
        ctx.fillStyle = "rgba(91,192,255,.20)";
        for (let i = 0; i < SQ; i += 1) {
          for (const [gx, gy] of [[i, 0], [i, SQ - 1], [0, i], [SQ - 1, i]]) {
            const { x, y } = iso(gx + 0.5, gy + 0.5);
            diamond(ctx, x, y, ISO_X, ISO_Y);
            ctx.fill();
          }
        }
        ctx.strokeStyle = "rgba(30,90,160,.5)";
        ctx.strokeRect(iso(0, SQ).x, iso(0, SQ).y, ISO_X * SQ * 2, ISO_Y * SQ + 8);
      }

      // Walls
      for (const wall of current.walls) {
        const before = previous?.walls.find((item) => item.id === wall.id);
        const hp = before ? lerp(before.hp, wall.hp, alpha) : wall.hp;
        if (hp <= 0) continue;
        const { x, y } = iso(wall.gx + 0.5, wall.gy + 0.5);
        const height = 16;
        diamond(ctx, x, y, ISO_X, ISO_Y);
        ctx.fillStyle = "#8a6640";
        ctx.fill();
        diamond(ctx, x, y - height, ISO_X, ISO_Y);
        ctx.fillStyle = "#b08a5d";
        ctx.fill();
        ctx.fillStyle = "rgba(60,40,20,.35)";
        ctx.fillRect(x - ISO_X, y - height, ISO_X * 2, height);
        ctx.fillStyle = hp / wall.max_hp < 0.5 ? "#ff9e8a" : "#f0d9b6";
        ctx.fillRect(x - ISO_X, y - height - 4, ISO_X * 2 * Math.max(0, hp / wall.max_hp), 3);
      }

      // Buildings
      for (const building of current.buildings) {
        const before = previous?.buildings.find((item) => item.id === building.id);
        const hp = before ? lerp(before.hp, building.hp, alpha) : building.hp;
        const alive = hp > 0;
        const { x, y } = iso(building.x, building.y);
        ctx.save();
        if (!alive) ctx.globalAlpha = 0.42;
        ctx.beginPath();
        ctx.ellipse(x, y + 8, building.s * 16, 9, 0, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(20,40,20,.22)";
        ctx.fill();
        const art = BUILDING_ART[building.t] || building.t;
        const picture = image(`/jamplay/art-${art}.webp`);
        const width = building.s * 30;
        if (picture.complete && picture.naturalWidth > 0) {
          ctx.drawImage(picture, x - width / 2, y - building.s * 22 - 6, width, building.s * 26);
        } else {
          ctx.fillStyle = "#c9a06a";
          ctx.fillRect(x - width / 2, y - 30, width, 30);
        }
        if (!alive) {
          ctx.fillStyle = "rgba(20,25,30,.55)";
          ctx.fillRect(x - width / 2, y - 22, width, 22);
        }
        ctx.restore();
        if (hp < building.max_hp) {
          ctx.fillStyle = "rgba(5,15,25,.6)";
          ctx.fillRect(x - width / 2, y - building.s * 22 - 14, width, 5);
          ctx.fillStyle = building.t === "th" ? "#ffd36a" : "#7ee0d6";
          ctx.fillRect(x - width / 2, y - building.s * 22 - 14, width * Math.max(0, hp / building.max_hp), 5);
        }
      }

      // Path + target lines
      for (const unit of current.units) {
        if (unit.path && unit.path.length) {
          ctx.save();
          ctx.fillStyle = unit.team === 0 ? "rgba(91,192,255,.4)" : "rgba(255,140,130,.4)";
          for (const step of unit.path.slice(0, 8)) {
            const point = iso(step[0] + 0.5, step[1] + 0.5);
            ctx.beginPath();
            ctx.arc(point.x, point.y, 3, 0, Math.PI * 2);
            ctx.fill();
          }
          ctx.restore();
        }
        if (unit.target) {
          const target = current.buildings.find((building) => building.id === unit.target);
          const wall = current.walls.find((item) => item.id === unit.target);
          const targetUnit = current.units.find((item) => item.id === unit.target);
          const source = target
            ? iso(target.x, target.y)
            : wall
              ? iso(wall.gx + 0.5, wall.gy + 0.5)
              : targetUnit
                ? iso(targetUnit.x, targetUnit.y)
                : null;
          if (source) {
            const origin = iso(unit.x, unit.y);
            ctx.save();
            ctx.strokeStyle = unit.team === 0 ? "rgba(120,200,255,.25)" : "rgba(255,140,130,.25)";
            ctx.setLineDash([3, 6]);
            ctx.beginPath();
            ctx.moveTo(origin.x, origin.y);
            ctx.lineTo(source.x, source.y);
            ctx.stroke();
            ctx.restore();
          }
        }
      }

      // Units
      for (const unit of current.units) {
        const before = previous?.units.find((item: UnitSnapshot) => item.id === unit.id);
        const gx = before ? lerp(before.x, unit.x, alpha) : unit.x;
        const gy = before ? lerp(before.y, unit.y, alpha) : unit.y;
        const { x, y } = iso(gx, gy);
        const hp = before ? lerp(before.hp, unit.hp, alpha) : unit.hp;
        const size = unit.k === "golem" ? 30 : 24;
        const picture = image(`/jamplay/unit-${UNIT_ART[unit.k] || unit.k}.webp`);
        ctx.save();
        ctx.beginPath();
        ctx.arc(x, y, size * 0.55, 0, Math.PI * 2);
        ctx.fillStyle = unit.team === 0 ? "rgba(60,140,220,.35)" : "rgba(210,80,70,.35)";
        ctx.fill();
        if (picture.complete && picture.naturalWidth > 0) {
          ctx.drawImage(picture, x - size / 2, y - size, size, size);
        } else {
          ctx.fillStyle = unit.team === 0 ? "#d7ecff" : "#ffd7d2";
          ctx.beginPath();
          ctx.arc(x, y - size / 2, size * 0.28, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
        ctx.fillStyle = "rgba(0,0,0,.55)";
        ctx.fillRect(x - size / 2, y - size - 5, size, 3);
        ctx.fillStyle = unit.team === 0 ? "#5bc0ff" : "#ff6b6b";
        ctx.fillRect(x - size / 2, y - size - 5, size * Math.max(0, hp / unit.max_hp), 3);
      }

      // Effects
      for (const fx of current.fx) {
        const life = fx.max ? Math.max(0, fx.ttl / fx.max) : 0;
        const { x, y } = iso(fx.x, fx.y);
        ctx.fillStyle = `rgba(91,192,255,${0.35 * life})`;
        ctx.beginPath();
        ctx.ellipse(x, y, ISO_X * fx.r, ISO_Y * fx.r, 0, 0, Math.PI * 2);
        ctx.fill();
      }
    };
    frame = requestAnimationFrame(render);
    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
    };
  }, []);

  const handlePointer = useCallback(
    (event: React.PointerEvent<HTMLCanvasElement>) => {
      if (selectedRef.current === null) {
        onMessage("اول یک نیرو را انتخاب کن.");
        return;
      }
      const canvas = canvasRef.current;
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      const worldX = ((event.clientX - rect.left) / rect.width) * W;
      const worldY = ((event.clientY - rect.top) / rect.height) * H;
      const grid = uniso(worldX, worldY);
      deployRef.current(Math.round(grid.x * 2) / 2, Math.round(grid.y * 2) / 2);
    },
    [onMessage],
  );

  return (
    <div className="b-field" style={{ width: "100%", height: "100%" }}>
      <canvas
        ref={canvasRef}
        tabIndex={0}
        aria-label="میدان محاصره"
        onPointerDown={handlePointer}
        style={{ aspectRatio: W / H, maxHeight: "100%", maxWidth: "100%" }}
      />
    </div>
  );
}
