"use client";

import { useCallback, useEffect, useRef } from "react";
import type { ArenaSnapshot, TowerSnapshot, UnitSnapshot } from "./types";

const W = 600;
const H = 900;
const RIVER_TOP = 426;
const RIVER_BOTTOM = 474;
const BRIDGES = [150, 450];

const UNIT_ART: Record<string, string> = {
  guard: "guard",
  sentinel: "guard",
  archer: "archer",
  volley: "archer",
  golem: "golem",
  mage: "mage",
  spark: "mage",
  meteor: "meteor",
  ballista: "ballista",
  scouts: "scouts",
  frost: "frost",
  heal: "frost",
};

const imageCache = new Map<string, HTMLImageElement>();

function image(src: string): HTMLImageElement {
  const cached = imageCache.get(src);
  if (cached) return cached;
  const element = new Image();
  element.src = src;
  imageCache.set(src, element);
  return element;
}

function drawUnitArt(
  ctx: CanvasRenderingContext2D,
  key: string,
  x: number,
  y: number,
  size: number,
  team: number,
) {
  const art = UNIT_ART[key] || key;
  const picture = image(`/jamplay/unit-${art}.webp`);
  ctx.save();
  ctx.beginPath();
  ctx.arc(x, y, size * 0.62, 0, Math.PI * 2);
  ctx.fillStyle = team === 0 ? "rgba(38,110,200,.22)" : "rgba(210,70,60,.22)";
  ctx.fill();
  ctx.strokeStyle = team === 0 ? "#5bc0ff" : "#ff8b84";
  ctx.lineWidth = 2;
  ctx.stroke();
  if (picture.complete && picture.naturalWidth > 0) {
    ctx.drawImage(picture, x - size / 2, y - size / 2, size, size);
  } else {
    ctx.fillStyle = team === 0 ? "#cfe5ff" : "#ffd7d2";
    ctx.beginPath();
    ctx.arc(x, y, size * 0.3, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function hpBar(ctx: CanvasRenderingContext2D, x: number, y: number, width: number, ratio: number, team: number) {
  ctx.fillStyle = "rgba(4,12,22,.65)";
  ctx.fillRect(x - width / 2, y, width, 5);
  ctx.fillStyle = team === 0 ? "#5bc0ff" : "#ff6b6b";
  ctx.fillRect(x - width / 2, y, Math.max(0, Math.min(1, ratio)) * width, 5);
}

function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}

function towerByName(list: TowerSnapshot[], id: string): TowerSnapshot | undefined {
  return list.find((tower) => tower.id === id);
}

export default function ArenaField({
  snapshot,
  selected,
  onDeploy,
  onMessage,
}: {
  snapshot: ArenaSnapshot;
  selected: number | null;
  onDeploy: (x: number, y: number) => void;
  onMessage: (message: string) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const previousRef = useRef<ArenaSnapshot | null>(null);
  const currentRef = useRef<ArenaSnapshot | null>(null);
  const changedAtRef = useRef(0);
  const selectedRef = useRef<number | null>(selected);
  const deployRef = useRef(onDeploy);

  useEffect(() => {
    selectedRef.current = selected;
    deployRef.current = onDeploy;
  }, [selected, onDeploy]);

  useEffect(() => {
    if (currentRef.current !== snapshot) {
      previousRef.current = currentRef.current;
      currentRef.current = snapshot;
      changedAtRef.current = performance.now();
    }
  }, [snapshot]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let frame = 0;

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      canvas.width = Math.max(1, Math.round(rect.width * dpr));
      canvas.height = Math.max(1, Math.round(rect.height * dpr));
    };
    resize();
    const observer = new ResizeObserver(resize);
    observer.observe(canvas);

    const render = (now: number) => {
      frame = requestAnimationFrame(render);
      const current = currentRef.current;
      if (!current) return;
      const previous = previousRef.current;
      const alpha = previous ? Math.min(1, (now - changedAtRef.current) / 650) : 1;
      const width = canvas.width;
      const height = canvas.height;
      if (!width || !height) return;
      ctx.setTransform(width / W, 0, 0, height / H, 0, 0);
      ctx.clearRect(0, 0, W, H);

      const sky = ctx.createLinearGradient(0, 0, 0, H);
      sky.addColorStop(0, "#7fb3d4");
      sky.addColorStop(0.42, "#a9cf8f");
      sky.addColorStop(0.58, "#93c079");
      sky.addColorStop(1, "#6fa35b");
      ctx.fillStyle = sky;
      ctx.fillRect(0, 0, W, H);

      // River + bridges
      const river = ctx.createLinearGradient(0, RIVER_TOP, 0, RIVER_BOTTOM);
      river.addColorStop(0, "#4aa6c9");
      river.addColorStop(0.5, "#2f83ad");
      river.addColorStop(1, "#4aa6c9");
      ctx.fillStyle = river;
      ctx.fillRect(0, RIVER_TOP, W, RIVER_BOTTOM - RIVER_TOP);
      ctx.fillStyle = "#b98a52";
      for (const bridge of BRIDGES) {
        ctx.fillRect(bridge - 34, RIVER_TOP - 6, 68, RIVER_BOTTOM - RIVER_TOP + 12);
        ctx.fillStyle = "rgba(255,255,255,.22)";
        ctx.fillRect(bridge - 30, RIVER_TOP - 4, 60, 4);
        ctx.fillStyle = "#b98a52";
      }

      // Deployable half hint
      if (selectedRef.current !== null) {
        ctx.fillStyle = "rgba(91,192,255,.14)";
        ctx.fillRect(30, 490, W - 60, 360);
        ctx.strokeStyle = "rgba(91,192,255,.5)";
        ctx.setLineDash([10, 8]);
        ctx.strokeRect(30, 490, W - 60, 360);
        ctx.setLineDash([]);
      }

      // Towers
      for (const tower of current.towers) {
        const before = previous ? towerByName(previous.towers, tower.id) : undefined;
        const hp = before ? lerp(before.hp, tower.hp, alpha) : tower.hp;
        const ratio = tower.max_hp ? hp / tower.max_hp : 0;
        const size = tower.king ? 116 : 94;
        const baseY = tower.y + 10;
        ctx.save();
        ctx.beginPath();
        ctx.ellipse(tower.x, baseY, size * 0.46, 18, 0, 0, Math.PI * 2);
        ctx.fillStyle = tower.team === 0 ? "rgba(30,90,160,.35)" : "rgba(170,50,45,.35)";
        ctx.fill();
        const picture = image(tower.king ? "/jamplay/art-th.webp" : "/jamplay/art-tower.webp");
        if (picture.complete && picture.naturalWidth > 0) {
          ctx.globalAlpha = hp > 0 ? 1 : 0.35;
          ctx.drawImage(picture, tower.x - size / 2, tower.y - size + 24, size, size);
          ctx.globalAlpha = 1;
        }
        ctx.restore();
        hpBar(ctx, tower.x, tower.y - size + 20, size * 0.8, ratio, tower.team);
        if (hp <= 0) {
          ctx.fillStyle = "rgba(20,28,40,.7)";
          ctx.font = "900 22px Vazirmatn, sans-serif";
          ctx.textAlign = "center";
          ctx.fillText("✕", tower.x, tower.y - size / 2);
        }
      }

      // Target selection lines
      for (const unit of current.units) {
        if (!unit.target) continue;
        const targetTower = current.towers.find((tower) => tower.id === unit.target);
        const targetUnit = current.units.find((item) => item.id === unit.target);
        const point = targetTower
          ? { x: targetTower.x, y: targetTower.y }
          : targetUnit
            ? { x: targetUnit.x, y: targetUnit.y }
            : null;
        if (!point) continue;
        ctx.save();
        ctx.strokeStyle = unit.team === 0 ? "rgba(120,200,255,.28)" : "rgba(255,140,130,.28)";
        ctx.setLineDash([3, 6]);
        ctx.beginPath();
        ctx.moveTo(unit.x, unit.y);
        ctx.lineTo(point.x, point.y);
        ctx.stroke();
        ctx.restore();
      }

      // Units
      for (const unit of current.units) {
        const before = previous?.units.find((item: UnitSnapshot) => item.id === unit.id);
        const x = before ? lerp(before.x, unit.x, alpha) : unit.x;
        const y = before ? lerp(before.y, unit.y, alpha) : unit.y;
        const hp = before ? lerp(before.hp, unit.hp, alpha) : unit.hp;
        const size = unit.k === "golem" ? 52 : unit.k === "scouts" ? 30 : 40;
        drawUnitArt(ctx, unit.k, x, y, size, unit.team);
        if (unit.hit > 0) {
          ctx.fillStyle = "rgba(255,90,70,.32)";
          ctx.beginPath();
          ctx.arc(x, y, size * 0.55, 0, Math.PI * 2);
          ctx.fill();
        }
        hpBar(ctx, x, y - size * 0.72, size * 0.9, unit.max_hp ? hp / unit.max_hp : 0, unit.team);
        if (unit.freeze > 0) {
          ctx.strokeStyle = "rgba(140,220,255,.85)";
          ctx.beginPath();
          ctx.arc(x, y, size * 0.62, 0, Math.PI * 2);
          ctx.stroke();
        }
      }

      // Effects
      for (const fx of current.fx) {
        const life = fx.max ? Math.max(0, fx.ttl / fx.max) : 0;
        if (fx.type === "spawn") {
          ctx.strokeStyle = `rgba(91,192,255,${0.7 * life})`;
          ctx.beginPath();
          ctx.arc(fx.x, fx.y, fx.r * (1.2 - life * 0.4), 0, Math.PI * 2);
          ctx.stroke();
        } else {
          ctx.fillStyle =
            fx.type === "heal"
              ? `rgba(90,220,140,${0.32 * life})`
              : fx.type === "frost"
                ? `rgba(130,210,255,${0.32 * life})`
                : `rgba(255,170,80,${0.32 * life})`;
          ctx.beginPath();
          ctx.arc(fx.x, fx.y, fx.r, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    };
    frame = requestAnimationFrame(render);
    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
    };
  }, []);

  const handlePointer = useCallback(
    (event: React.PointerEvent<HTMLCanvasElement>) => {
      if (selectedRef.current === null) {
        onMessage("اول یک کارت را انتخاب کن.");
        return;
      }
      const canvas = canvasRef.current;
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      const x = ((event.clientX - rect.left) / rect.width) * W;
      const y = ((event.clientY - rect.top) / rect.height) * H;
      deployRef.current(Math.round(x), Math.round(y));
    },
    [onMessage],
  );

  const ratio = W / H;
  return (
    <div className="b-field" style={{ width: "100%", height: "100%" }}>
      <canvas
        ref={canvasRef}
        tabIndex={0}
        aria-label="میدان آوردگاه"
        onPointerDown={handlePointer}
        style={{ aspectRatio: ratio, maxHeight: "100%", maxWidth: "100%" }}
      />
    </div>
  );
}
