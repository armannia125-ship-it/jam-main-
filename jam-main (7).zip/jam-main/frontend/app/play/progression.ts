/**
 * Pure JamPlay Phase 2 presentation helpers.
 *
 * Kept free of React and network access so progression, mission, reward and
 * social states can be unit tested with `node --test` (no extra dependencies).
 */

import type {
  Achievement,
  FriendItem,
  LevelUpAward,
  Mission,
  MissionRewards,
  Profile,
} from "./types";

export type MissionState = "claimed" | "ready" | "locked";

export function missionState(mission: Pick<Mission, "claimed" | "ready">): MissionState {
  if (mission.claimed) return "claimed";
  if (mission.ready) return "ready";
  return "locked";
}

export function missionActionLabel(mission: Pick<Mission, "claimed" | "ready">): string {
  const state = missionState(mission);
  if (state === "claimed") return "دریافت شد";
  if (state === "ready") return "دریافت";
  return "در مسیر";
}

export function missionPercent(mission: Pick<Mission, "progress" | "target">): number {
  if (!mission.target || mission.target <= 0) return 0;
  return Math.min(100, Math.round((mission.progress / mission.target) * 100));
}

export function levelPercent(
  value: Pick<Profile, "xp_in_level" | "xp_need"> | { xp_in_level: number; xp_need: number },
): number {
  if (!value.xp_need || value.xp_need <= 0) return 0;
  return Math.min(100, Math.max(0, Math.round((value.xp_in_level / value.xp_need) * 100)));
}

export function achievementPercent(achievement: Pick<Achievement, "progress" | "target">): number {
  if (!achievement.target || achievement.target <= 0) return 100;
  return Math.min(100, Math.round((achievement.progress / achievement.target) * 100));
}

export interface RewardChip {
  kind: "xp" | "coins" | "gems";
  label: string;
  value: number;
}

export function rewardChips(rewards: MissionRewards): RewardChip[] {
  const chips: RewardChip[] = [];
  if (rewards.xp) chips.push({ kind: "xp", label: "تجربه", value: rewards.xp });
  if (rewards.coins) chips.push({ kind: "coins", label: "سکه", value: rewards.coins });
  if (rewards.gems) chips.push({ kind: "gems", label: "الماس", value: rewards.gems });
  return chips;
}

export function rewardText(rewards: MissionRewards): string {
  return rewardChips(rewards)
    .map((chip) => `${chip.value.toLocaleString("fa-IR")} ${chip.label}`)
    .join(" · ");
}

export function levelUpText(leveled: LevelUpAward[] | undefined): string {
  if (!leveled || leveled.length === 0) return "";
  const last = leveled[leveled.length - 1];
  const gems = leveled.reduce((sum, item) => sum + item.gems, 0);
  return `به سطح ${last.level.toLocaleString("fa-IR")} رسیدی · ${gems.toLocaleString("fa-IR")} الماس`;
}

export function relationLabel(relation: FriendItem["relation"]): string {
  switch (relation) {
    case "accepted":
      return "دوست";
    case "outgoing":
      return "در انتظار پاسخ";
    case "incoming":
      return "درخواست دریافتی";
    default:
      return "افزودن دوست";
  }
}

export function canChallenge(relation: FriendItem["relation"]): boolean {
  return relation === "accepted";
}

export function rankLabel(rank: number): string {
  return rank.toLocaleString("fa-IR");
}

export function progressSummary(stats: { arena_wins: number; siege_wins: number }): number {
  return stats.arena_wins + stats.siege_wins;
}
