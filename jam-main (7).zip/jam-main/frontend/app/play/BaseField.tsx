"use client";

import type { BuildingItem, BuilderInfo } from "./types";

const TW = 64;
const TH = 32;
const GRID = 22;

function iso(x: number, y: number): { x: number; y: number } {
  return { x: (x - y) * (TW / 2), y: (x + y) * (TH / 2) };
}

function footprint(size: number): string {
  return [iso(0, 0), iso(size, 0), iso(size, size), iso(0, size)]
    .map((point) => `${point.x},${point.y}`)
    .join(" ");
}

export default function BaseField({
  buildings,
  builder,
  onSelect,
}: {
  buildings: BuildingItem[];
  builder: BuilderInfo;
  onSelect: (key: string) => void;
}) {
  const outer = [iso(-2, -2), iso(GRID + 2, -2), iso(GRID + 2, GRID + 2), iso(-2, GRID + 2)]
    .map((point) => `${point.x},${point.y}`)
    .join(" ");

  return (
    <svg
      className="base-svg"
      viewBox="-1320 -460 2640 1560"
      preserveAspectRatio="xMidYMid meet"
      role="img"
      aria-label="پایگاه جم‌پلی"
    >
      <defs>
        <linearGradient id="jg-grass" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#a8cf86" />
          <stop offset="1" stopColor="#6d9b55" />
        </linearGradient>
        <pattern id="jg-tile" width="64" height="64" patternUnits="userSpaceOnUse">
          <path d="M32 0 64 16 32 32 0 16Z" fill="none" stroke="rgba(58,96,44,.10)" />
        </pattern>
      </defs>
      <polygon points={outer} fill="#5d8749" opacity="0.7" />
      <polygon points={footprint(GRID)} fill="url(#jg-grass)" stroke="rgba(255,255,255,.18)" />
      <polygon points={footprint(GRID)} fill="url(#jg-tile)" />

      {/* decorative pond */}
      <ellipse cx={iso(19, 3).x} cy={iso(19, 3).y} rx="66" ry="34" fill="#4aa6c9" opacity="0.65" />
      <ellipse cx={iso(19, 3).x} cy={iso(19, 3).y} rx="48" ry="22" fill="#6fc3df" opacity="0.5" />

      {buildings.map((building) => {
        const size = building.size || 2;
        const center = iso(building.grid_x + size / 2, building.grid_y + size / 2);
        const width = size * 52;
        const height = size * 60;
        const busy = builder.busy && builder.building_key === building.key;
        const remaining = busy ? builder.remaining_seconds : 0;
        const timer = `${Math.floor(remaining / 60)}:${String(remaining % 60).padStart(2, "0")}`;
        return (
          <g
            key={building.key}
            className={`bld ${busy ? "building" : ""}`}
            onClick={() => onSelect(building.key)}
            role="button"
            tabIndex={0}
            aria-label={`${building.name} سطح ${building.level}`}
            style={{ cursor: "pointer" }}
          >
            <ellipse
              cx={center.x}
              cy={center.y + height * 0.1}
              rx={width * 0.42}
              ry={width * 0.18}
              fill="rgba(20,40,20,.22)"
            />
            <image
              href={`/jamplay/art-${building.art}.webp`}
              x={center.x - width / 2}
              y={center.y - height * 0.72}
              width={width}
              height={height}
              preserveAspectRatio="xMidYMid meet"
            />
            <g className="lv" transform={`translate(${center.x}, ${center.y + height * 0.18})`}>
              <circle r="16" />
              <text y="5" textAnchor="middle">
                {building.level}
              </text>
            </g>
            {busy ? (
              <g className="bub timer" transform={`translate(${center.x + width * 0.42}, ${center.y - height * 0.72})`}>
                <rect x="-34" y="-16" width="68" height="26" rx="13" />
                <text textAnchor="middle" y="3" fontSize="13" fontWeight="900" fill="#fff">
                  {timer}
                </text>
              </g>
            ) : null}
          </g>
        );
      })}
    </svg>
  );
}
