import { NextRequest } from "next/server";

/* پروکسی هم‌مبدأ به API جنگو.
   - API_INTERNAL_URL فقط سمت سرور خوانده می‌شود؛ در بیلد داخل کد نمی‌نشیند.
   - هیچ پاسخ API کش نمی‌شود.
   - مسیر /api/media-proxy/* فقط برای دارایی‌های عمومی رسانه است. */

export const dynamic = "force-dynamic";

const API_TARGET = (process.env.API_INTERNAL_URL || "http://localhost:8000").replace(/\/$/, "");

async function proxy(request: NextRequest, ctx: { params: Promise<{ path: string[] }> }) {
  const { path } = await ctx.params;
  const isMedia = path[0] === "media-proxy";
  // Django's URLconf uses trailing slashes. Next strips them from incoming
  // paths, so always restore the slash to avoid an internal-host redirect.
  const target = isMedia
    ? `${API_TARGET}/media/${path.slice(1).join("/")}`
    : `${API_TARGET}/api/${path.join("/")}/`;
  const url = new URL(target);
  url.search = request.nextUrl.search;

  const headers = new Headers();
  for (const key of [
    "authorization",
    "content-type",
    "accept",
    "accept-language",
    "cookie",
    "x-bot-token",
    "x-forwarded-proto",
    "x-forwarded-host",
    "x-forwarded-for",
  ]) {
    const value = request.headers.get(key);
    if (value) headers.set(key, value);
  }

  const init: RequestInit = { method: request.method, headers, redirect: "manual", cache: "no-store" };
  if (!["GET", "HEAD"].includes(request.method)) {
    init.body = await request.arrayBuffer();
  }

  let upstream: Response;
  try {
    upstream = await fetch(url, init);
  } catch {
    return new Response(JSON.stringify({ detail: "API is unreachable.", code: "api_unreachable" }), {
      status: 502,
      headers: { "Content-Type": "application/json" },
    });
  }

  const responseHeaders = new Headers();
  const contentType = upstream.headers.get("content-type");
  if (contentType) responseHeaders.set("Content-Type", contentType);
  const location = upstream.headers.get("location");
  if (location) responseHeaders.set("Location", location);
  if (upstream.headers.get("content-disposition")) {
    responseHeaders.set("Content-Disposition", upstream.headers.get("content-disposition")!);
  }
  responseHeaders.set("Cache-Control", isMedia ? "public, max-age=86400" : "no-store");

  return new Response(upstream.body, { status: upstream.status, headers: responseHeaders });
}

export const GET = proxy;
export const POST = proxy;
export const PUT = proxy;
export const PATCH = proxy;
export const DELETE = proxy;
export const HEAD = proxy;
