"use client";

/* سفارش‌های من — فهرست سفارش‌های فعال و قبلی (نسخهٔ نمایشی؛ localStorage) */

import Link from "next/link";
import { Ic } from "@/components/icons";
import { useJam, type Order } from "@/lib/state";
import { ACTIVE_STATUS, STATUS, brandMonogram, store as findStore } from "@/lib/data";
import { ago, fa, tomanT } from "@/lib/format";
import { isDemoMode } from "@/lib/demo";
import { ServerOrdersPage } from "@/components/features/server-orders";

function LocalOrdersPage() {
  const { orders, ready, addToCart, toast } = useJam();

  const mine = [...orders].sort((a, b) => b.placedAt - a.placedAt);
  const act = mine.filter((o) => ACTIVE_STATUS.includes(o.status));
  const past = mine.filter((o) => !ACTIVE_STATUS.includes(o.status));

  const reorder = (o: Order) => {
    o.items.forEach((i) => addToCart(o.sid, i.pid, i.qty));
    toast("به سبد اضافه شد", "ok", { label: "مشاهده سبد", href: "/cart" });
  };

  const row = (o: Order) => {
    const s = findStore(o.sid);
    const st = STATUS[o.status];
    return (
      <Link href={`/order/${o.id}`} className="order-row">
        <span className={`lg tone tone-${s?.tone ?? "restaurant"}`}>
          <span className={`brand-monogram bm-${o.sid}`}>{s ? brandMonogram(s) : "جم"}</span>
        </span>
        <div style={{ minWidth: 0 }}>
          <b>{s?.name ?? o.sid}</b>
          <div className="muted ellipsis" style={{ fontSize: 14 }}>
            {o.items.map((i) => `${fa(i.qty)}× ${i.name}`).join("، ")}
          </div>
          <div className="faint tnum" style={{ fontSize: 14 }}>
            {ago(o.placedAt)} · {o.mode === "pickup" ? "تحویل حضوری" : "ارسال"} · {o.id}
          </div>
        </div>
        <div style={{ textAlign: "left", display: "flex", flexDirection: "column", gap: 6, alignItems: "flex-end" }}>
          <span className={`pill ${st?.c ?? "gray"}`}><span className="dot" />{st?.short ?? o.status}</span>
          <b className="tnum">{tomanT(o.totals.total)}</b>
        </div>
      </Link>
    );
  };

  return (
    <div className="container" style={{ maxWidth: 880 }}>
      <div className="page-title"><h1>سفارش‌های من</h1></div>

      {!ready ? (
        <div style={{ minHeight: "30vh" }} />
      ) : !mine.length ? (
        <div className="card" style={{ marginTop: 16 }}>
          <div className="empty">
            <div className="e-ic"><Ic n="list" /></div>
            <b>هنوز سفارشی ثبت نکرده‌اید</b>
            <div style={{ fontSize: 14 }}>از فروشگاه‌های جم سفارش دهید؛ وضعیت سفارش‌ها اینجا نمایش داده می‌شود.</div>
            <div style={{ marginTop: 16 }}>
              <Link href="/" className="btn btn-primary">شروع خرید</Link>
            </div>
          </div>
        </div>
      ) : (
        <>
          {act.length > 0 && (
            <>
              <h2 style={{ fontSize: 16, margin: "20px 0 10px" }}>سفارش‌های فعال</h2>
              <div className="card">{act.map((o) => <div key={o.id}>{row(o)}</div>)}</div>
            </>
          )}
          {past.length > 0 && (
            <>
              <h2 style={{ fontSize: 16, margin: "24px 0 10px" }}>سفارش‌های قبلی</h2>
              <div className="card">
                {past.map((o) => (
                  <div className="ux-order-repeat-row" key={o.id}>
                    {row(o)}
                    <button className="btn btn-soft" onClick={() => reorder(o)}>
                      <Ic n="refresh" c="sm" />سفارش مجدد
                    </button>
                  </div>
                ))}
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
}

export default function OrdersPage() {
  return isDemoMode() ? <LocalOrdersPage /> : <ServerOrdersPage />;
}
