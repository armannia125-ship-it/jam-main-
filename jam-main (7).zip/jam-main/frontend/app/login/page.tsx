"use client";
/* ورود/ثبت‌نام با کد یک‌بارمصرف — از همان API احراز هویت موجود. */

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth";

export default function LoginPage() {
  const { ready, isAuthenticated, requestCode, login, signUp } = useAuth();
  const router = useRouter();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [identifier, setIdentifier] = useState("");
  const [code, setCode] = useState("");
  const [step, setStep] = useState<"phone" | "code">("phone");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [next, setNext] = useState("/panel");

  useEffect(() => {
    const requested = new URLSearchParams(window.location.search).get("next") || "/panel";
    setNext(requested.startsWith("/") && !requested.startsWith("//") ? requested : "/panel");
  }, []);

  useEffect(() => {
    if (ready && isAuthenticated) router.replace(next);
  }, [ready, isAuthenticated, router, next]);

  const send = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    setNotice("");
    setBusy(true);
    try {
      await requestCode(identifier.trim());
      setStep("code");
      setNotice("اگر شماره معتبر باشد، کد تأیید ارسال شده است.");
    } catch (x) {
      setErr((x as Error).message || "ارسال کد ناموفق بود.");
    } finally {
      setBusy(false);
    }
  };

  const verify = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    setBusy(true);
    try {
      if (mode === "login") await login(identifier.trim(), code.trim());
      else await signUp(identifier.trim(), code.trim());
      router.replace(next);
    } catch (x) {
      setErr((x as Error).message || "کد تأیید نامعتبر است.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="container rv" style={{ maxWidth: 520 }}>
      <header className="rv-heading">
        <h1 tabIndex={-1}>{mode === "login" ? "ورود به پنل فروشنده" : "ساخت حساب فروشنده"}</h1>
        <p>با شمارهٔ موبایل ایرانی وارد شوید. همین حساب برای مدیریت فروشگاه، باشگاه و تسویه استفاده می‌شود.</p>
      </header>

      <section className="rv-card">
        <div className="c7-actions" role="tablist" aria-label="نوع ورود">
          <button type="button" className={`btn ${mode === "login" ? "btn-primary" : "btn-ghost"}`} onClick={() => { setMode("login"); setStep("phone"); }}>
            ورود
          </button>
          <button type="button" className={`btn ${mode === "signup" ? "btn-primary" : "btn-ghost"}`} onClick={() => { setMode("signup"); setStep("phone"); }}>
            ثبت‌نام
          </button>
        </div>

        {step === "phone" ? (
          <form onSubmit={send}>
            <label className="rv-field" htmlFor="login-phone">
              <span>شمارهٔ موبایل</span>
              <input
                id="login-phone"
                dir="ltr"
                inputMode="tel"
                autoComplete="tel"
                required
                placeholder="09xxxxxxxxx"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
              />
            </label>
            <button className="btn btn-primary" type="submit" disabled={busy || !identifier.trim()}>
              {busy ? "در حال ارسال…" : "دریافت کد تأیید"}
            </button>
          </form>
        ) : (
          <form onSubmit={verify}>
            <p className="c7-small">کد ارسال‌شده به {identifier} را وارد کنید.</p>
            <label className="rv-field" htmlFor="login-code">
              <span>کد تأیید</span>
              <input
                id="login-code"
                dir="ltr"
                inputMode="numeric"
                autoComplete="one-time-code"
                required
                value={code}
                onChange={(e) => setCode(e.target.value)}
              />
            </label>
            <div className="c7-actions">
              <button className="btn btn-primary" type="submit" disabled={busy || !code.trim()}>
                {busy ? "در حال بررسی…" : "تأیید و ورود"}
              </button>
              <button type="button" className="btn btn-ghost" onClick={() => setStep("phone")}>
                تغییر شماره
              </button>
            </div>
          </form>
        )}

        <p className="c7-error" role="alert">{err}</p>
        {notice ? <p className="c7-small">{notice}</p> : null}
        <p className="c7-small">
          <Link href="/">بازگشت به بازار جم</Link>
        </p>
      </section>
    </div>
  );
}
