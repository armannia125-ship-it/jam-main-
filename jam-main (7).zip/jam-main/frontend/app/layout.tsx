import type { Metadata, Viewport } from "next";
import "./globals.css";
import { AuthProvider } from "@/lib/auth";
import { JamProvider } from "@/lib/state";
import { CommerceProvider } from "@/lib/commerce";
import Header from "@/components/header";
import Footer from "@/components/footer";
import BottomNav from "@/components/bottom-nav";
import FloatingCart from "@/components/floating-cart";
import BodySync from "@/components/body-sync";
import ServiceWorkerRegistration from "./service-worker-registration";

export const metadata: Metadata = {
  title: "جم لایف | بازار آنلاین کسب‌وکارهای شهر جم",
  description:
    "جم لایف؛ فروشگاه‌ها، رستوران‌ها و کسب‌وکارهای شهر جم در یک‌جا. سفارش آنلاین، تحویل حضوری یا ارسال به محل، و منوی دیجیتال با QR برای کسب‌وکارها.",
  manifest: "/manifest.json",
  icons: { icon: "/favicon.svg", apple: "/icon-192.png" },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: "#FCFDFB",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fa" dir="rtl" data-theme="light">
      <head>
        <link rel="icon" href="/favicon.svg" type="image/svg+xml" />
      </head>
      <body>
        <ServiceWorkerRegistration />
        <a className="sr" href="#app">رفتن به محتوای اصلی</a>
        <noscript>
          <p style={{ padding: 24, textAlign: "center", fontFamily: "var(--font)" }}>
            برای استفاده از جم لایف، جاوا اسکریپت مرورگر را فعال کنید.
          </p>
        </noscript>
        <AuthProvider>
          <JamProvider>
            <CommerceProvider>
              <BodySync />
              <Header />
              <main id="app" tabIndex={-1}>
                {children}
              </main>
              <Footer />
              <BottomNav />
              <FloatingCart />
            </CommerceProvider>
          </JamProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
