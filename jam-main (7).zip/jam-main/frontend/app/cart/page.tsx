"use client";

/* سبد خرید — صفحهٔ کامل (نسخهٔ نمایشی؛ داده‌ها فقط در localStorage) */

import Link from "next/link";
import { Ic } from "@/components/icons";
import { cartSummary, useJam } from "@/lib/state";
import { brandMonogram, openState, productById, productPhoto, storeHref, type Product } from "@/lib/data";
import { fa, tomanT } from "@/lib/format";
import type { OrderLine } from "@/lib/state";

export default function CartPage() {
  const { cart, inc, dec, clearCart, ready } = useJam();
  const cs = cartSummary(cart);
  const s = cs.store;

  if (!ready) return <div className="container" style={{ minHeight: "40vh" }} />;

  const rows: { l: OrderLine; p: Product }[] = [];
  for (const l of cs.lines) {
    const p = productById(l.pid)?.product;
    if (p) rows.push({ l, p });
  }

  /* سبد خالی — وضعیت صادقانه */
  if (!cart || !rows.length || !s) {
    return (
      <div className="container">
        <div className="crumbs">
          <Link href="/" className="ui-tap-link">خانه</Link>
          <Ic n="chevL" c="sm" />
          <span>سبد خرید</span>
        </div>
        <div className="page-title"><h1>سبد خرید</h1></div>
        <div className="card" style={{ marginTop: 16 }}>
          <div className="empty">
            <div className="e-ic"><Ic n="bag" /></div>
            <b>سبد خرید خالی است</b>
            <div style={{ fontSize: 14 }}>محصولات موردنظرتان را از منو اضافه کنید.</div>
            <div style={{ marginTop: 16 }}>
              <Link href="/search" className="btn btn-soft">دیدن فروشگاه‌ها</Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const st = openState(s);
  const sub = cs.items + cs.discount;
  const need = s.minOrder - cs.items;

  return (
    <div className="container">
      <div className="crumbs">
        <Link href="/" className="ui-tap-link">خانه</Link>
        <Ic n="chevL" c="sm" />
        <Link href={storeHref(s)} className="ui-tap-link">{s.name}</Link>
        <Ic n="chevL" c="sm" />
        <span>سبد خرید</span>
      </div>
      <div className="page-title"><h1>سبد خرید</h1></div>

      <div className="co-layout">
        <aside className="card cart-box">
          <div className="cart-head">
            <h3>
              سبد خرید <span className="faint" style={{ fontWeight: 500, fontSize: 14 }}>({fa(cs.count)})</span>
            </h3>
            <button className="btn btn-sm btn-plain" onClick={clearCart}>
              <Ic n="trash" c="sm" />
              حذف همه
            </button>
          </div>

          <Link href={storeHref(s)} className="row" style={{ padding: "12px 18px", borderBottom: "1px solid var(--line)" }}>
            <span className={`tone tone-${s.tone}`} style={{ width: 36, height: 36, borderRadius: 10, display: "grid", placeItems: "center", fontSize: 18 }}>
              <span className={`brand-monogram bm-${s.id}`} style={{ fontSize: 18 }}>{brandMonogram(s)}</span>
            </span>
            <span className="grow">
              <b style={{ fontSize: 14 }}>{s.name}</b>
              <small className="faint" style={{ display: "block", fontSize: 14 }}>
                {st.open ? "باز است" : "بسته · سفارش در ساعت بازگشایی پردازش می‌شود"}
              </small>
            </span>
          </Link>

          <div className="cart-list">
            {rows.map(({ l, p }) => {
              const photo = productPhoto(p);
              return (
                <div className="c-row" key={l.pid}>
                  <span className={`th tone tone-${s.tone}`} aria-hidden="true">
                    {photo ? <img className="media-photo" src={photo} alt="" loading="lazy" /> : p.em}
                  </span>
                  <div className="grow">
                    <div className="nm ellipsis">{p.name}</div>
                    <div className="pr tnum">{tomanT(p.price * l.qty)}</div>
                  </div>
                  <span className="qc" data-pid={l.pid}>
                    <span className="stepper light" role="group" aria-label={`تعداد ${p.name}`}>
                      <button onClick={() => inc(l.pid)} aria-label="افزایش"><Ic n="plus" c="sm" /></button>
                      <b className="tnum" aria-live="polite">{fa(l.qty)}</b>
                      <button onClick={() => dec(l.pid)} aria-label={l.qty === 1 ? "حذف" : "کاهش"}>
                        <Ic n={l.qty === 1 ? "trash" : "minus"} c="sm" />
                      </button>
                    </span>
                  </span>
                </div>
              );
            })}
          </div>

          <div className="cart-sum">
            <div className="sum-row"><span>جمع اقلام</span><span className="tnum">{tomanT(sub)}</span></div>
            {cs.discount > 0 && (
              <div className="sum-row green"><span>تخفیف محصولات</span><span className="tnum">−{tomanT(cs.discount)}</span></div>
            )}
            <div className="sum-row">
              <span>هزینه ارسال</span>
              <span className="tnum">{cs.delivery ? tomanT(cs.delivery) : "رایگان"}</span>
            </div>
            <div className="sum-row total"><span>مبلغ قابل پرداخت</span><span className="tnum">{tomanT(cs.total)}</span></div>

            {need > 0 && (
              <div style={{ marginTop: 10, fontSize: 14, color: "var(--amber)" }}>
                {fa(need)} تومان تا حداقل سفارش ({tomanT(s.minOrder)})
                <div className="progress"><i style={{ width: `${Math.min(100, (cs.items / s.minOrder) * 100)}%`, background: "var(--amber)" }} /></div>
              </div>
            )}

            {need > 0 ? (
              <button className="btn btn-primary btn-lg btn-block" style={{ marginTop: 14 }} disabled aria-disabled="true">
                ادامه و ثبت سفارش <Ic n="arrowL" />
              </button>
            ) : (
              <Link href="/checkout" className="btn btn-primary btn-lg btn-block" style={{ marginTop: 14 }}>
                ادامه و ثبت سفارش <Ic n="arrowL" />
              </Link>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
}
