import { OrderTrackingPage } from "@/components/features/order-tracking-page";
import { ServerOrderTracking } from "@/components/features/server-orders";
import { isDemoMode } from "@/lib/demo";

type PageProps = {
  params: Promise<{ id: string }>;
};

export default async function OrderTrackingPageRoute({ params }: PageProps) {
  const { id } = await params;
  return isDemoMode() ? <OrderTrackingPage orderId={id} /> : <ServerOrderTracking orderId={id} />;
}
