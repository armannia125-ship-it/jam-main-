"use client";
/* =========================================================
   جم لایف — تسویهٔ اشتراک با پرداخت آنلاین
   جریان: انتخاب کسب‌وکار → ثبت درخواست خرید (قیمت سمت سرور) →
   پیوند درگاه → بازگشت از درگاه → بررسی وضعیت.
   هیچ مبلغی از کلاینت ارسال نمی‌شود؛ در دسترس‌نبودن درگاه صادقانه
   اعلام می‌شود و هیچ دستورالعمل پرداخت جایگزین نمایش داده نمی‌شود.
   ========================================================= */

import { Suspense, useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { ApiError, apiFetch } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { fa, fmtDate } from "@/lib/format";
import {
  ENTITLEMENT_TYPE_LABELS,
  PURCHASE_STATUS_LABELS,
  purchaseStatusPill,
  remainingDays,
  useSubProducts,
  type SubProduct,
  type SubPurchaseStatus,
} from "@/lib/subscriptions-api";
import Ic from "@/components/icons";

type BusinessesResponse = { results?: { id: number; name: string; slug: string }[] };

type PurchaseCreated = {
  purchase_id: number;
  amount_toman: number;
  payment_url: string;
  authority: string;
};

function LoginRequiredCard({ next }: { next: string }) {
  return (
    <section className="rv-card">
      <h2>برای خرید اشتراک وارد شوید</h2>
      <p>ثبت خرید و پرداخت آنلاین فقط با حساب کاربری شما انجام می‌شود.</p>
      <Link className="btn btn-primary" href={`/login?next=${encodeURIComponent(next)}`}>
        ورود / ثبت‌نام
      </Link>
    </section>
  );
}

function UnconfiguredNotice() {
  return (
    <section className="rv-card">
      <h2>پرداخت آنلاین موقتاً در دسترس نیست</h2>
      <p>
        ثبت خرید انجام نشد، چون درگاه پرداخت هنوز پیکربندی نشده است. خرید اشتراک پس از فعال‌شدن
        درگاه از همین صفحه در دسترس خواهد بود.
      </p>
      <div className="notice amber">
        <Ic n="alert" c="ic" />
        <span>
          تا فعال‌شدن درگاه، هیچ پرداخت آنلاین یا دستورالعمل پرداخت جایگزینی ارائه نمی‌شود. لطفاً
          بعداً دوباره تلاش کنید.
        </span>
      </div>
      <Link className="btn btn-ghost" href="/subscriptions">
        بازگشت به کاتالوگ اشتراک‌ها
      </Link>
    </section>
  );
}

function CheckoutInner() {
  const params = useSearchParams();
  const slug = params.get("product") || "";
  const requestedBusiness = params.get("business") || "";
  const next = `/subscriptions/checkout?product=${encodeURIComponent(slug)}${
    requestedBusiness ? `&business=${encodeURIComponent(requestedBusiness)}` : ""
  }`;
  const { ready, isAuthenticated } = useAuth();
  const { products, loading: productsLoading } = useSubProducts();

  const product: SubProduct | undefined = products.find((p) => p.slug === slug);

  const [businesses, setBusinesses] = useState<{ id: number; name: string }[]>([]);
  const [businessError, setBusinessError] = useState<string | null>(null);
  const [businessId, setBusinessId] = useState<string>("");

  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [unconfigured, setUnconfigured] = useState(false);
  const [created, setCreated] = useState<PurchaseCreated | null>(null);

  const [statusRow, setStatusRow] = useState<SubPurchaseStatus | null>(null);
  const [statusError, setStatusError] = useState<string | null>(null);
  const [checking, setChecking] = useState(false);

  /* فهرست کسب‌وکارهای کاربر برای انتخاب مقصد اشتراک */
  useEffect(() => {
    if (!ready || !isAuthenticated) return;
    let alive = true;
    setBusinessError(null);
    apiFetch<BusinessesResponse | { id: number; name: string }[]>("/businesses/")
      .then((res) => {
        if (!alive) return;
        const rows = Array.isArray(res) ? res : res.results || [];
        setBusinesses(rows);
        const requested = rows.find((row) => String(row.id) === requestedBusiness);
        if (requested) setBusinessId(String(requested.id));
        else if (rows[0]) setBusinessId(String(rows[0].id));
      })
      .catch((err) => {
        if (!alive) return;
        setBusinesses([]);
        setBusinessError(err instanceof ApiError ? err.message : "دریافت کسب‌وکارها ناموفق بود.");
      });
    return () => {
      alive = false;
    };
  }, [ready, isAuthenticated, requestedBusiness]);

  const startPurchase = async () => {
    if (!product || !businessId) return;
    setBusy(true);
    setError(null);
    setUnconfigured(false);
    try {
      const res = await apiFetch<PurchaseCreated>("/subscriptions/purchases/", {
        method: "POST",
        body: { product_slug: product.slug, business_id: Number(businessId) },
      });
      setCreated(res);
      setStatusRow(null);
      setStatusError(null);
    } catch (err) {
      if (err instanceof ApiError && err.status === 503 && err.code === "payment_provider_unconfigured") {
        setUnconfigured(true);
        setCreated(null);
      } else {
        setError(err instanceof ApiError ? err.message : "ثبت خرید ناموفق بود.");
      }
    } finally {
      setBusy(false);
    }
  };

  /* بررسی وضعیت خرید — پس از بازگشت از درگاه یا هر زمان دیگر */
  const checkStatus = useCallback(async () => {
    if (!created) return;
    setChecking(true);
    setStatusError(null);
    try {
      setStatusRow(await apiFetch<SubPurchaseStatus>(`/subscriptions/purchases/${created.purchase_id}/`));
    } catch (err) {
      setStatusRow(null);
      setStatusError(err instanceof ApiError ? err.message : "بررسی وضعیت ناموفق بود.");
    } finally {
      setChecking(false);
    }
  }, [created]);

  if (!slug || (!productsLoading && !product)) {
    return (
      <section className="rv-card">
        <h2>محصول اشتراک انتخاب نشده است</h2>
        <p>برای خرید، ابتدا یکی از اشتراک‌های کاتالوگ را انتخاب کنید.</p>
        <Link className="btn btn-primary" href="/subscriptions">
          مشاهدهٔ کاتالوگ اشتراک‌ها
        </Link>
      </section>
    );
  }

  if (!ready || productsLoading) {
    return <p className="rv-empty">در حال بارگذاری…</p>;
  }

  if (!isAuthenticated) {
    return <LoginRequiredCard next={next} />;
  }

  if (unconfigured) {
    return <UnconfiguredNotice />;
  }

  return (
    <>
      <section className="rv-card">
        <h2>خرید اشتراک «{product?.name || slug}»</h2>
        {product ? (
          <p className="c7-small">
            {product.description} · اعتبار {fa(product.duration_days)} روز · تعرفهٔ ثبت‌شده در سرور:{" "}
            <bdi dir="ltr" className="tnum">
              {fa(product.price_toman)}
            </bdi>{" "}
            تومان
          </p>
        ) : null}

        {!created ? (
          <>
            <label className="rv-field" htmlFor="checkout-business">
              <span>کسب‌وکار مقصد اشتراک</span>
              <select
                id="checkout-business"
                value={businessId}
                onChange={(e) => setBusinessId(e.target.value)}
              >
                {businesses.length === 0 ? <option value="">کسب‌وکاری ثبت نشده است</option> : null}
                {businesses.map((b) => (
                  <option key={b.id} value={String(b.id)}>
                    {b.name}
                  </option>
                ))}
              </select>
            </label>

            {businessError ? (
              <p className="c7-error" role="alert">
                {businessError}
              </p>
            ) : null}

            {businesses.length === 0 && !businessError ? (
              <p className="c7-small">
                برای خرید اشتراک، ابتدا یک کسب‌وکار در حساب خود بسازید و سپس به این صفحه برگردید.
              </p>
            ) : null}

            <div className="c7-actions">
              <button
                type="button"
                className="btn btn-primary"
                disabled={busy || !businessId}
                onClick={startPurchase}
              >
                {busy ? "در حال ثبت…" : "ثبت خرید و ساخت پرداخت"}
              </button>
              <Link className="btn btn-ghost" href="/subscriptions">
                بازگشت
              </Link>
            </div>
          </>
        ) : (
          <>
            <strong className="c7-price">
              <span className="v11-amount">
                <bdi dir="ltr">{fa(created.amount_toman)}</bdi>{" "}
                <span className="v11-currency">تومان</span>
              </span>
              <small>مبلغ تأییدشدهٔ سرور برای این خرید</small>
            </strong>

            <div className="c7-actions">
              <a
                className="btn btn-primary"
                href={created.payment_url}
                target="_blank"
                rel="noopener noreferrer"
              >
                ادامه به درگاه پرداخت <Ic n="chevL" c="sm" />
              </a>
              <button type="button" className="btn btn-ghost" onClick={() => setCreated(null)}>
                انصراف از این فاکتور
              </button>
            </div>

            <div className="notice blue">
              <Ic n="info" c="ic" />
              <span>
                پس از بازگشت از درگاه، با دکمهٔ «بررسی وضعیت» نتیجهٔ پرداخت را ببینید. فعال‌سازی
                اشتراک فقط پس از تأیید نهایی درگاه انجام می‌شود و ممکن است چند لحظه طول بکشد.
              </span>
            </div>

            <div className="c7-actions">
              <button type="button" className="btn btn-soft" disabled={checking} onClick={checkStatus}>
                {checking ? "در حال بررسی…" : "بررسی وضعیت"}
              </button>
            </div>

            {statusError ? (
              <p className="c7-error" role="alert">
                {statusError}
              </p>
            ) : null}

            {statusRow ? (
              <div className="rv-line">
                <div>
                  <b>
                    وضعیت خرید:{" "}
                    <span className={purchaseStatusPill(statusRow.status)}>
                      {PURCHASE_STATUS_LABELS[statusRow.status] || statusRow.status}
                    </span>
                  </b>
                  <small>
                    {statusRow.payment_status
                      ? `وضعیت نزد درگاه: ${
                          PURCHASE_STATUS_LABELS[statusRow.payment_status] || statusRow.payment_status
                        } · `
                      : ""}
                    شناسهٔ خرید: {fa(statusRow.id)}
                  </small>
                </div>
              </div>
            ) : null}

            {statusRow && statusRow.status === "paid" ? (
              statusRow.entitlements.length > 0 ? (
                <div className="notice green">
                  <Ic n="check" c="ic" />
                  <span>
                    پرداخت تأیید شد و اعتبار فعال شد:
                    <ul style={{ margin: "8px 0 0", paddingInlineStart: 20 }}>
                      {statusRow.entitlements.map((e, i) => (
                        <li key={i}>
                          {ENTITLEMENT_TYPE_LABELS[e.type] || e.type} — از{" "}
                          {e.starts_at ? fmtDate(e.starts_at) : "—"} تا {e.ends_at ? fmtDate(e.ends_at) : "—"}
                          {remainingDays(e.ends_at) !== null
                            ? ` (${fa(remainingDays(e.ends_at) || 0)} روز باقی‌مانده)`
                            : ""}
                        </li>
                      ))}
                    </ul>
                  </span>
                </div>
              ) : (
                <div className="notice green">
                  <Ic n="check" c="ic" />
                  <span>
                    پرداخت تأیید شد؛ فعال‌سازی اعتبار در جریان است. چند لحظه بعد دوباره «بررسی وضعیت»
                    را بزنید.
                  </span>
                </div>
              )
            ) : null}

            {statusRow && statusRow.status === "pending" ? (
              <div className="notice amber">
                <Ic n="clock" c="ic" />
                <span>
                  پرداخت هنوز تکمیل نشده است. اگر پرداخت را انجام داده‌اید، چند لحظه صبر کنید و
                  دوباره «بررسی وضعیت» را بزنید.
                </span>
              </div>
            ) : null}

            {statusRow && statusRow.status === "failed" ? (
              <div className="notice red">
                <Ic n="alert" c="ic" />
                <span>
                  این خرید ناموفق ثبت شده است. می‌توانید با «ثبت خرید و ساخت پرداخت» تازه شروع کنید؛
                  مبلغی بدون تأیید درگاه برداشت نمی‌شود.
                </span>
              </div>
            ) : null}
          </>
        )}

        {error ? (
          <p className="c7-error" role="alert">
            {error}
          </p>
        ) : null}
      </section>

      <p className="g10-info">
        خرید اشتراک فقط از مسیر پرداخت آنلاین انجام می‌شود؛ هیچ پرداخت حضوری یا واریز دستی از طریق
        این سایت پذیرفته نمی‌شود.
      </p>
    </>
  );
}

export default function SubscriptionCheckoutPage() {
  return (
    <div className="container rv" style={{ maxWidth: 760 }}>
      <header className="rv-heading">
        <span>اشتراک‌های جم لایف</span>
        <h1 tabIndex={-1}>تسویهٔ اشتراک</h1>
        <p>کسب‌وکار مقصد را انتخاب کنید، خرید را ثبت کنید و از درگاه پرداخت بازگردید.</p>
      </header>
      <Suspense fallback={<p className="rv-empty">در حال بارگذاری…</p>}>
        <CheckoutInner />
      </Suspense>
    </div>
  );
}
