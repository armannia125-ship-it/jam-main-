"use client";
/* =========================================================
   جم لایف — کاتالوگ عمومی اشتراک‌ها (پنج محصول رسمی)
   قیمت‌ها و توضیحات فقط از سرور خوانده می‌شود؛ هیچ مبلغی در
   کلاینت ثبت یا تخمین زده نمی‌شود. خرید فقط با پرداخت آنلاین.
   ========================================================= */

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth";
import { fa } from "@/lib/format";
import { useSubProducts } from "@/lib/subscriptions-api";
import Ic from "@/components/icons";

const CATEGORY_LABELS: Record<string, string> = {
  menu: "اشتراک منو",
  club: "باشگاه فروشندگان",
  combo: "ترکیبی",
};

export default function SubscriptionsCatalogPage() {
  const router = useRouter();
  const { ready, isAuthenticated } = useAuth();
  const { products, loading, error, refresh } = useSubProducts();
  const [loginHint, setLoginHint] = useState(false);

  /* CTA خرید — نیازمند ورود: کاربر مهمان به صفحهٔ ورود با مقصد برگشتی می‌رود */
  const goToCheckout = (slug: string) => {
    const target = `/subscriptions/checkout?product=${encodeURIComponent(slug)}`;
    if (isAuthenticated) {
      router.push(target);
    } else {
      setLoginHint(true);
      router.push(`/login?next=${encodeURIComponent(target)}`);
    }
  };

  return (
    <div className="container rv">
      <header className="rv-heading">
        <span>جم لایف برای فروشندگان</span>
        <h1 tabIndex={-1}>اشتراک‌های رسمی جم لایف</h1>
        <p>
          پنج اشتراک رسمی، همه برای دورهٔ ۳۰ روزه؛ قیمت هر اشتراک همان تعرفهٔ ثبت‌شده در سرور است و
          فعال‌سازی فقط با پرداخت آنلاین انجام می‌شود.
        </p>
      </header>

      {loading ? <p className="rv-empty">در حال دریافت کاتالوگ اشتراک‌ها…</p> : null}

      {error ? (
        <section className="rv-card">
          <p className="c7-error" role="alert">
            {error}
          </p>
          <button type="button" className="btn btn-ghost" onClick={() => refresh()}>
            تلاش دوباره
          </button>
        </section>
      ) : null}

      {!loading && !error && products.length === 0 ? (
        <p className="rv-empty">فعلاً محصولی برای خرید در کاتالوگ ثبت نشده است.</p>
      ) : null}

      <div className="plans">
        {products.map((p) => (
          <article className={`card plan${p.slug === "gold" ? " pop" : ""}`} key={p.slug}>
            <div>
              <h3>{p.name}</h3>
              <div className="muted" style={{ fontSize: 14 }}>
                {CATEGORY_LABELS[p.category] || p.category}
                {p.description ? ` · ${p.description}` : ""}
              </div>
            </div>
            <div className="pp tnum">
              <bdi dir="ltr">{fa(p.price_toman)}</bdi> <small>تومان / {fa(p.duration_days)} روز</small>
            </div>

            {p.slug === "gold" ? (
              <span className="c7-tag">
                دو اعتبار مستقل ۳۰ روزه: منو + باشگاه، هرکدام با تاریخ و وضعیت جدا
              </span>
            ) : null}
            {p.slug === "seller_club" ? (
              <span className="c7-tag">مستقل از اشتراک منو؛ عضویت باشگاه به‌تنهایی</span>
            ) : null}

            <ul>
              {p.features.map((f) => (
                <li key={f}>
                  <Ic n="check" />
                  <span>{f}</span>
                </li>
              ))}
            </ul>

            <div style={{ marginTop: "auto" }}>
              <button
                type="button"
                className={`btn ${p.slug === "gold" ? "btn-primary" : "btn-soft"} btn-block`}
                disabled={!ready}
                onClick={() => goToCheckout(p.slug)}
              >
                خرید با پرداخت آنلاین <Ic n="chevL" c="sm" />
              </button>
              <small className="muted" style={{ display: "block", marginTop: 8, fontSize: 14 }}>
                مدت اعتبار: {fa(p.duration_days)} روز · فعال‌سازی پس از تأیید پرداخت درگاه
              </small>
            </div>
          </article>
        ))}
      </div>

      {loginHint && !isAuthenticated ? (
        <div className="notice blue">
          <Ic n="info" c="ic" />
          <span>
            برای خرید اشتراک ابتدا وارد حساب خود شوید؛{" "}
            <Link href="/login?next=%2Fsubscriptions">ورود / ثبت‌نام</Link>
          </span>
        </div>
      ) : null}

      <p className="g10-info">
        هر اشتراک برای یک کسب‌وکار فعال می‌شود. اشتراک طلایی دو اعتبار مستقل ۳۰ روزه می‌سازد (منو و
        باشگاه)؛ هیچ بسته‌ای تخفیف یا فروش تضمین‌شده ندارد. باشگاه فروشندگان جدا از اشتراک منو است و
        خرید آن به‌تنهایی منوی دیجیتال نمی‌دهد.
      </p>
    </div>
  );
}
