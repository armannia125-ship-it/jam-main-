import { CheckoutPage } from "@/components/features/checkout-page"

export default function CheckoutPageRoute() {
  return <CheckoutPage />
}