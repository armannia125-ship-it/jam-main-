"use client";

import { useEffect } from "react";

/* ثبت سرویس‌ورکر PWA — فقط در بیلد تولیدی (در dev ثبت نمی‌شود) */
export default function ServiceWorkerRegistration() {
  useEffect(() => {
    if (process.env.NODE_ENV !== "production") return;
    if (!("serviceWorker" in navigator)) return;
    const onLoad = () => {
      navigator.serviceWorker
        .register("/sw.js")
        .then((registration) => {
          // بررسی به‌روزرسانی سرویس‌ورکر در هر بازدید
          registration.update().catch(() => {});
        })
        .catch(() => {
          /* ثبت ناموفق؛ برنامه بدون آفلاین کار می‌کند */
        });
    };
    if (document.readyState === "complete") onLoad();
    else window.addEventListener("load", onLoad, { once: true });
    return () => window.removeEventListener("load", onLoad);
  }, []);
  return null;
}
