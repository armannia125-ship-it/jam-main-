import type { Config } from "tailwindcss";

export default {
  content: [
    "./app/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
    "./public/**/*.{html,js,jsx,tsx,css}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
} satisfies Config;