/* =========================================================
   جم لایف — سرویس‌ورکر (PWA)
   راهبرد:
   - منوی عمومی (/m/*): network-first؛ HTML پاسخ‌داده‌شده شامل
     دادهٔ واقعی API است و در کش «jam-menus» ذخیره می‌شود.
   - API عمومی منو (/api/public/menus/*): network-first با کش
     JSON؛ فقط همین API عمومی کش می‌شود.
   - دارایی‌های ثابت (/_next/static) و تصاویر (/media/*،
     /api/media-proxy/*): cache-first تا منو آفلاین بماند.
   - سایر مسیرهای عمومی: network-first؛ در نبود شبکه صفحهٔ /offline
     نمایش داده می‌شود.
   - HTML صفحات عمومی در کش نگه داشته نمی‌شود: HTML قدیمی به
     chunkهای هش‌دارِ حذف‌شدهٔ همان بیلد اشاره می‌کند و باعث
     صفحهٔ بدون CSS/JS پس از هر دیپلوی می‌شد.
   - هرگز کش نمی‌شوند: احراز هویت، پنل، سبد، سفارش، پرداخت،
     درآمد، تسویه و هر API خصوصی.
   - تغییر نسخهٔ کش: در فعال‌سازی، کش‌های قدیمی حذف می‌شوند.
   - هیچ درخواستی نباید به unhandled rejection منجر شود؛ شکست شبکه
     با پاسخ ۵۰۳ یا صفحهٔ offline پوشش داده می‌شود.
   ========================================================= */

const VERSION = "v4";
const MENUS_CACHE = `jam-menus-${VERSION}`;
const STATIC_CACHE = `jam-static-${VERSION}`;
const SHELL_CACHE = `jam-shell-${VERSION}`;
const OFFLINE_URL = "/offline";
const MENU_MAX_AGE_MS = 24 * 60 * 60 * 1000;
/* سقف تقریبی کش دارایی‌ها؛ هر بیلد فایل‌های هش‌دار تازه می‌سازد. */
const STATIC_MAX_ENTRIES = 200;

const SHELL_ASSETS = [OFFLINE_URL, "/manifest.json", "/icon-192.png", "/icon-512.png", "/favicon.svg"];
const STATIC_ASSET_RE = /\/_next\/static\/[^"'\s>]+?\.(?:js|css)/g;

const offlineFallback = () =>
  caches
    .match(OFFLINE_URL)
    .then(
      (hit) =>
        hit ||
        new Response("آفلاین", { status: 503, headers: { "Content-Type": "text/plain; charset=utf-8" } }),
    )
    .catch(() => new Response("آفلاین", { status: 503, headers: { "Content-Type": "text/plain; charset=utf-8" } }));

const networkError = () => new Response("", { status: 503, statusText: "Offline" });

/* صفحهٔ آفلاین بدون chunkهای خودش فقط خطای Next را نشان می‌دهد؛ پس
   HTML آن و دارایی‌های همان بیلد در زمان نصب کش می‌شوند. */
async function precacheOfflinePage(shellCache) {
  try {
    const res = await fetch(OFFLINE_URL, { cache: "no-store" });
    if (!res.ok) return;
    const html = await res.clone().text();
    await shellCache.put(new URL(OFFLINE_URL, self.location.origin).href, withCachedAt(res));
    const staticCache = await caches.open(STATIC_CACHE);
    const paths = [...new Set(html.match(STATIC_ASSET_RE) || [])];
    await Promise.all(
      paths.map(async (path) => {
        try {
          const url = new URL(path, self.location.origin).href;
          const asset = await fetch(url);
          if (asset.ok) await staticCache.put(url, asset);
        } catch {
          /* best effort */
        }
      }),
    );
  } catch {
    /* صفحهٔ آفلاین در زمان نصب در دسترس نبود */
  }
}

self.addEventListener("install", (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(SHELL_CACHE);
      /* یک دارایی گمشده نباید نصب کل ورکر را متوقف کند. */
      await Promise.all(
        SHELL_ASSETS.filter((asset) => asset !== OFFLINE_URL).map((asset) => cache.add(asset).catch(() => undefined)),
      );
      await precacheOfflinePage(cache);
      await self.skipWaiting();
    })(),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((k) => k.startsWith("jam-") && ![MENUS_CACHE, STATIC_CACHE, SHELL_CACHE].includes(k))
            .map((k) => caches.delete(k)),
        ),
      )
      .then(() => self.clients.claim()),
  );
});

function withCachedAt(response) {
  const headers = new Headers(response.headers);
  headers.set("x-jam-cached-at", String(Date.now()));
  return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
}

async function putWithTimestamp(cache, request, response) {
  const url = typeof request === "string" ? new URL(request, self.location.origin).href : request.url;
  await cache.put(url, withCachedAt(response.clone()));
}

function cacheIsFresh(response) {
  if (!response) return false;
  const at = Number(response.headers.get("x-jam-cached-at") || 0);
  return at > 0 && Date.now() - at <= MENU_MAX_AGE_MS;
}

async function dropCached(cacheName, request) {
  try {
    const cache = await caches.open(cacheName);
    await cache.delete(request);
  } catch {
    /* best effort */
  }
}

/* کش دارایی‌ها نامحدود رشد نکند؛ قدیمی‌ترین‌ها اول حذف می‌شوند. */
async function trimCache(cacheName, maxEntries) {
  try {
    const cache = await caches.open(cacheName);
    const keys = await cache.keys();
    if (keys.length <= maxEntries) return;
    await Promise.all(keys.slice(0, keys.length - maxEntries).map((key) => cache.delete(key)));
  } catch {
    /* best effort */
  }
}

const isStaticAsset = (url) =>
  url.pathname.startsWith("/_next/static/") || url.pathname === "/favicon.svg" || url.pathname.startsWith("/icon-");
const isMedia = (url) => url.pathname.startsWith("/media/") || url.pathname.startsWith("/api/media-proxy/");
const isMenuPage = (url) => url.pathname.startsWith("/m/");
/* فقط منوی عمومی؛ هیچ API خصوصی مجاز به کش نیست */
const isPublicMenuApi = (url) => url.pathname.startsWith("/api/public/menus/");
const isPrivate = (url) =>
  (url.pathname.startsWith("/api/") && !url.pathname.startsWith("/api/media-proxy/")) ||
  url.pathname.startsWith("/panel") ||
  url.pathname.startsWith("/login") ||
  url.pathname.startsWith("/checkout") ||
  url.pathname.startsWith("/order") ||
  url.pathname.startsWith("/cart") ||
  url.pathname.startsWith("/orders") ||
  url.pathname.startsWith("/revenue") ||
  url.pathname.startsWith("/visit") ||
  url.pathname.startsWith("/club");

self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  /* دادهٔ عمومی منو: network-first + کش JSON */
  if (isPublicMenuApi(url)) {
    event.respondWith(
      fetch(request)
        .then(async (res) => {
          if (res.ok) {
            try {
              const cache = await caches.open(MENUS_CACHE);
              await putWithTimestamp(cache, request, res.clone());
            } catch {
              /* خطای کش نباید پاسخ را خراب کند */
            }
          } else if (res.status === 404 || res.status === 410) {
            await dropCached(MENUS_CACHE, request);
          }
          return res;
        })
        .catch(async () => {
          try {
            const cache = await caches.open(MENUS_CACHE);
            const hit = await cache.match(request);
            if (cacheIsFresh(hit)) return hit;
          } catch {
            /* کش در دسترس نیست؛ پاسخ ۵۰۳ */
          }
          return new Response(JSON.stringify({ detail: "Offline and no fresh cached menu data." }), {
            status: 503,
            headers: { "Content-Type": "application/json; charset=utf-8" },
          });
        }),
    );
    return;
  }

  /* دارایی‌های تصویری عمومی پیش از قاعدهٔ خصوصی بررسی می‌شوند */
  if (isMedia(url)) {
    event.respondWith(
      (async () => {
        const cache = await caches.open(MENUS_CACHE);
        const hit = await cache.match(request);
        if (hit) return hit;
        try {
          const res = await fetch(request);
          if (res.ok) cache.put(request.url, res.clone()).catch(() => undefined);
          return res;
        } catch {
          return networkError();
        }
      })(),
    );
    return;
  }

  /* درخواست‌های خصوصی/تراکنشی: هیچ‌گاه کش نمی‌شوند. صفحات خصوصی
     آفلاین به صفحهٔ offline می‌رسند، نه به HTML قدیمی. */
  if (isPrivate(url)) {
    if (request.mode === "navigate") {
      event.respondWith(fetch(request).catch(() => offlineFallback()));
    }
    return;
  }

  if (isStaticAsset(url)) {
    event.respondWith(
      (async () => {
        const cache = await caches.open(STATIC_CACHE);
        const hit = await cache.match(request);
        if (hit) return hit;
        try {
          const res = await fetch(request);
          if (res.ok) {
            cache
              .put(request, res.clone())
              .then(() => trimCache(STATIC_CACHE, STATIC_MAX_ENTRIES))
              .catch(() => undefined);
          }
          return res;
        } catch {
          /* شکست شبکه برای یک chunk نباید به unhandled rejection
             تبدیل شود؛ پاسخ ۵۰۳ یک خطای شبکهٔ معمولی است. */
          return networkError();
        }
      })(),
    );
    return;
  }

  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request)
        .then(async (res) => {
          if (isMenuPage(url) && res.ok) {
            try {
              const cache = await caches.open(MENUS_CACHE);
              await putWithTimestamp(cache, request, res);
              self.clients.matchAll().then((clients) =>
                clients.forEach((client) => client.postMessage({ type: "JAM_MENU_CACHED", url: url.pathname })),
              );
            } catch {
              /* خطای کش نباید پاسخ صفحه را خراب کند */
            }
          } else if (isMenuPage(url) && (res.status === 404 || res.status === 410)) {
            await dropCached(MENUS_CACHE, request);
          }
          return res;
        })
        .catch(async () => {
          if (isMenuPage(url)) {
            try {
              const cache = await caches.open(MENUS_CACHE);
              const hit = (await cache.match(request)) || (await cache.match(request, { ignoreSearch: true }));
              if (cacheIsFresh(hit)) return hit;
            } catch {
              /* کش در دسترس نیست */
            }
          }
          return offlineFallback();
        }),
    );
  }
});

self.addEventListener("unhandledrejection", (event) => {
  self.clients.matchAll().then((clients) => clients.forEach((c) => c.postMessage({ type: "JAM_SW_ERROR", error: String(event.reason) })));
});

self.addEventListener("message", (event) => {
  const msg = event.data || {};
  if (msg.type === "JAM_REFRESH_MENU" && typeof msg.url === "string") {
    event.waitUntil(
      (async () => {
        try {
          const res = await fetch(msg.url, { cache: "no-store" });
          if (res.ok) {
            const cache = await caches.open(MENUS_CACHE);
            await putWithTimestamp(cache, msg.url, res.clone());
            const clients = await self.clients.matchAll();
            clients.forEach((client) => client.postMessage({ type: "JAM_MENU_CACHED", url: msg.url }));
          }
        } catch {
          /* همچنان آفلاین */
        }
      })(),
    );
  }
  if (msg.type === "JAM_SKIP_WAITING") self.skipWaiting();
});
