"use client";
/* =========================================================
   جم لایف — نشست احراز هویت (OTP + JWT)
   توکن‌ها در localStorage نگهداری می‌شوند؛ هیچ توکنی در HTML یا
   لاگ چاپ نمی‌شود. برای جریان‌های حساس، انقضای نشست به‌صورت
   یکسان با خطای 401 مدیریت می‌شود.
   ========================================================= */

import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import {
  clearSession,
  readSession,
  requestOtp,
  signup as apiSignup,
  verifyOtp,
  writeSession,
  type AuthTokens,
} from "./api";

export type SessionUser = { id: number; phone?: string | null; email?: string | null } | null;

type AuthCtx = {
  ready: boolean;
  user: SessionUser;
  isAuthenticated: boolean;
  login: (identifier: string, code: string) => Promise<void>;
  signUp: (identifier: string, code: string) => Promise<void>;
  requestCode: (identifier: string) => Promise<void>;
  logout: () => void;
};

const Ctx = createContext<AuthCtx | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);
  const [user, setUser] = useState<SessionUser>(null);

  const sync = useCallback(() => {
    const session = readSession();
    setUser(session?.user || null);
  }, []);

  useEffect(() => {
    sync();
    setReady(true);
    const onChange = () => sync();
    window.addEventListener("jam-auth", onChange);
    window.addEventListener("storage", onChange);
    return () => {
      window.removeEventListener("jam-auth", onChange);
      window.removeEventListener("storage", onChange);
    };
  }, [sync]);

  const apply = useCallback((tokens: AuthTokens, nextUser?: SessionUser) => {
    writeSession(tokens, nextUser || undefined);
    setUser(nextUser || null);
  }, []);

  const login = useCallback(
    async (identifier: string, code: string) => {
      const res = await verifyOtp(identifier, code);
      apply({ access: res.access, refresh: res.refresh }, res.user);
    },
    [apply],
  );

  const signUp = useCallback(
    async (identifier: string, code: string) => {
      const res = await apiSignup(identifier, code);
      const session = readSession();
      apply({ access: res.access, refresh: res.refresh }, session?.user || { id: 0, phone: identifier });
    },
    [apply],
  );

  const requestCode = useCallback(async (identifier: string) => {
    await requestOtp(identifier);
  }, []);

  const logout = useCallback(() => {
    clearSession();
    setUser(null);
  }, []);

  const value = useMemo<AuthCtx>(
    () => ({ ready, user, isAuthenticated: !!user, login, signUp, requestCode, logout }),
    [ready, user, login, signUp, requestCode, logout],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
