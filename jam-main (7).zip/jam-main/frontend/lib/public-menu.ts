import type { Product, Store } from "./data";

/* دادهٔ منوی عمومی از بک‌اند — فقط سمت سرور مصرف می‌شود.
   تصاویر از مسیر پروکسی هم‌مبدأ می‌آیند تا سرویس‌ورکر بتواند
   آن‌ها را برای نمایش آفلاین کش کند. */

export type ApiPublicMenu = {
  title: string;
  slug: string;
  business: { id: number; name: string; slug: string; description: string; logo: string | null };
  delivery_fee_toman?: number;
  categories: {
    id: number;
    name: string;
    sort_order: number;
    products: {
      id: number;
      name: string;
      description: string;
      price_toman: number;
      sort_order: number;
      image: string | null;
    }[];
  }[];
};

const API_INTERNAL_URL = (process.env.API_INTERNAL_URL || "http://localhost:8000").replace(/\/$/, "");

export function mediaSrc(url: string | null | undefined): string | undefined {
  if (!url) return undefined;
  const index = url.indexOf("/media/");
  if (index >= 0) return `/api/media-proxy/${url.slice(index + "/media/".length)}`;
  return /^https?:\/\//.test(url) ? url : undefined;
}

export function apiMenuToStore(menu: ApiPublicMenu): Store {
  const products: Product[] = menu.categories.flatMap((category) =>
    category.products.map((product) => ({
      id: `api-p${product.id}`,
      name: product.name,
      em: "🍽",
      price: product.price_toman,
      sec: category.name,
      desc: product.description || "",
      old: 0,
      available: true,
      pop: false,
      image: mediaSrc(product.image),
    })),
  );

  const sections = menu.categories.map((c) => c.name);

  return {
    id: `api:${menu.slug}`,
    slug: menu.slug,
    menuSlug: menu.slug,
    apiBusinessId: menu.business.id,
    api: true,
    deliveryFee: menu.delivery_fee_toman ?? 0,
    name: menu.business.name,
    cat: "restaurant",
    tone: "restaurant",
    em: "🍽",
    tagline: "منوی دیجیتال جم لایف",
    desc: menu.business.description || "",
    rating: 0,
    reviews: 0,
    km: 0,
    hours: [["09:00", "23:59"]],
    phone: "",
    address: "",
    minOrder: 0,
    prep: 20,
    delivery: true,
    pickup: true,
    discount: 0,
    sections,
    products,
  };
}

export type ApiPublicStore = {
  id: number;
  name: string;
  slug: string;
  description: string;
  logo: string | null;
  menu_slug: string;
  menu_title: string;
  delivery_fee_toman: number;
  products_count: number;
  categories: string[];
};

export function apiStoreToStore(row: ApiPublicStore): Store {
  return {
    id: `api:${row.menu_slug}`,
    slug: row.slug,
    menuSlug: row.menu_slug,
    apiBusinessId: row.id,
    api: true,
    name: row.name,
    cat: "restaurant",
    tone: "restaurant",
    em: "🍽",
    tagline: row.menu_title || "منوی دیجیتال",
    desc: row.description || "",
    rating: 0,
    reviews: 0,
    km: 0,
    hours: [["00:00", "23:59"]],
    phone: "",
    address: "",
    minOrder: 0,
    prep: 20,
    delivery: true,
    pickup: true,
    discount: 0,
    sections: row.categories,
    products: [],
    deliveryFee: row.delivery_fee_toman,
    coverImage: mediaSrc(row.logo),
  };
}

export async function fetchPublicStores(): Promise<ApiPublicStore[] | null> {
  try {
    const res = await fetch(`${API_INTERNAL_URL}/api/commerce/public/stores/`, {
      next: { revalidate: 60 },
      headers: { Accept: "application/json" },
    });
    if (!res.ok) return null;
    const data = (await res.json()) as { results?: ApiPublicStore[] };
    return Array.isArray(data.results) ? data.results : [];
  } catch {
    return null;
  }
}

export async function fetchPublicMenu(slug: string): Promise<ApiPublicMenu | null> {
  try {
    const res = await fetch(`${API_INTERNAL_URL}/api/public/menus/${encodeURIComponent(slug)}/`, {
      next: { revalidate: 60 },
      headers: { Accept: "application/json" },
    });
    if (!res.ok) return null;
    return (await res.json()) as ApiPublicMenu;
  } catch {
    return null;
  }
}
