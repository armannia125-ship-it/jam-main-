"use client";
/* =========================================================
   جم لایف — لایهٔ دادهٔ سرور برای درآمد، باشگاه، خرید حضوری،
   گزارش‌ها و تسویه.
   دیگر هیچ‌کدام از این جریان‌ها در localStorage نوشته نمی‌شوند؛
   فقط انتخاب فروشگاه به‌عنوان ترجیح رابط کاربری نگه داشته می‌شود.
   خطاها به‌صورت وضعیت خطای واقعی نمایش داده می‌شوند و به دادهٔ
   نمایشی برنمی‌گردند.
   ========================================================= */

import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { ApiError, apiFetch } from "./api";
import { useAuth } from "./auth";
import type { Store } from "./data";

export type SellerConfig = {
  commission_rate: string;
  setup_fee_toman: number;
  monthly_fee_toman: number;
  delivery_fee_toman: number;
  updated_at?: string;
};

export type ClubSummary = {
  status: "inactive" | "trial" | "active" | "expired" | "cancelled";
  is_active: boolean;
  trial_used: boolean;
  trial_started_at: string | null;
  trial_ends_at: string | null;
  starts_at: string | null;
  ends_at: string | null;
  terms_version: string | null;
  offer: string;
};

export type SellerBusiness = {
  id: number;
  name: string;
  slug: string;
  description: string;
  logo: string | null;
  club: ClubSummary;
  config: SellerConfig;
};

export type Acceptance = {
  id: number;
  kind: "seller" | "club";
  version_id: number;
  version_label: string;
  accepted_name: string;
  rate_snapshot: string | null;
  monthly_snapshot: number | null;
  created_at: string;
};

export type Terms = { id: number; kind: string; version: string; body: string; effective_at: string };

export type Invoice = {
  id: number;
  kind: "setup" | "ad" | "campaign";
  title: string;
  amount_toman: number;
  status: "pending" | "simulated_paid" | "paid" | "canceled";
  provider_reference: string;
  terms_acceptance: number | null;
  created_at: string;
  paid_at: string | null;
};

export type ClubResponse = {
  membership: Omit<ClubSummary, "offer">;
  terms: Terms;
  offer: { text: string; is_active: boolean; updated_at: string | null };
  acceptance: Acceptance | null;
  trial_days: number;
};

export type Campaign = {
  id: number;
  title: string;
  budget_toman: number;
  discount_pct: number;
  cap_toman: number;
  min_purchase_toman: number;
  days: number;
  seller_share_pct: number;
  platform_share_pct: number;
  brand_share_pct: number;
  service_fee_toman: number;
  is_active: boolean;
  is_funded: boolean;
  starts_at: string | null;
  ends_at: string | null;
  created_at: string;
};

export type Ad = {
  id: number;
  title: string;
  placement: "home" | "mission";
  budget_toman: number;
  days: number;
  is_active: boolean;
  ends_at: string | null;
  created_at: string;
};

export type RevenueResponse = {
  business: { id: number; name: string; slug: string };
  config: SellerConfig;
  summary: {
    commission_earned_toman: number;
    invoices_paid_toman: number;
    commissionable_orders: number;
    settlement_eligible_toman: number;
    settlement_pending_toman: number;
  };
  invoices: Invoice[];
  campaigns: Campaign[];
  ads: Ad[];
  launch: { area: string; category: string };
  commission_history: { id: number; rate: string; basis: string; note: string; created_at: string }[];
};

export type SettlementEntry = {
  id: number;
  order_number: string;
  goods_toman: number;
  delivery_toman: number;
  gross_toman: number;
  commission_toman: number;
  net_payable_toman: number;
  rate: string;
  status: "pending_payment" | "awaiting_delivery" | "awaiting_onboarding" | "eligible" | "reversed" | "failed";
  paid_at: string | null;
  created_at: string;
  updated_at: string;
  reversals: { id: number; amount_toman: number; reason: string; created_at: string }[];
};

export type SettlementResponse = {
  account: {
    legal_name: string;
    iban: string;
    iban_checksum_valid: boolean;
    provider_status: "unconfigured" | "pending_review" | "verified";
    provider_verified_at: string | null;
    updated_at: string;
  } | null;
  ledger: SettlementEntry[];
  seller_agreement_accepted: boolean;
  real_settlement_available: boolean;
  detail: string;
};

export type MetricsResponse = {
  visits: number;
  codes_issued: number;
  purchases_confirmed: number;
  returning_customers: number;
  unique_customers: number;
};

export type Purchase = {
  id: number;
  code_hint: string;
  status: "confirmed" | "revoked";
  confirmed_at: string;
  revoked_at: string | null;
  perk: string;
  customer_label: string;
  business_id?: number;
  business_name?: string;
};

export type PublicClubStore = {
  id: number;
  name: string;
  slug: string;
  description: string;
  logo: string | null;
  offer: string;
};

export const SETTLEMENT_STATE_LABELS: Record<SettlementEntry["status"], string> = {
  pending_payment: "در انتظار پرداخت",
  awaiting_delivery: "در انتظار تحویل",
  awaiting_onboarding: "نیازمند پذیرش شرایط و اتصال ارائه‌دهنده",
  eligible: "واجد شرایط تسویه؛ واریزی انجام نشده",
  reversed: "برگشت‌خورده",
  failed: "ناموفق / لغوشده پیش از تسویه",
};

export const money = (n: number) => `${Math.round(n || 0).toLocaleString("fa-IR")} تومان`;

const SID_KEY = "jam.seller.sid";

type Ctx = {
  ready: boolean;
  loading: boolean;
  error: string | null;
  loginRequired: boolean;
  businesses: SellerBusiness[];
  sid: number | null;
  setSid: (id: number) => void;
  refresh: () => Promise<void>;
  business: (id: number | null) => SellerBusiness | undefined;
  storeOf: (id: number | null) => Store | null;
};

const CommerceCtx = createContext<Ctx | null>(null);

function fallbackStore(business: SellerBusiness): Store {
  return {
    id: String(business.id),
    slug: business.slug,
    name: business.name,
    cat: "restaurant",
    tone: "restaurant",
    em: "🏪",
    tagline: "فروشندهٔ جم لایف",
    desc: business.description || "",
    rating: 0,
    reviews: 0,
    km: 0,
    hours: [["09:00", "21:00"]],
    phone: "",
    address: "",
    minOrder: 0,
    prep: 0,
    delivery: true,
    pickup: true,
    discount: 0,
    sections: [],
    products: [],
  };
}

export function CommerceProvider({ children }: { children: React.ReactNode }) {
  const { ready: authReady, isAuthenticated, user } = useAuth();
  const [businesses, setBusinesses] = useState<SellerBusiness[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sid, setSidState] = useState<number | null>(null);

  const load = useCallback(async () => {
    if (!isAuthenticated) {
      setBusinesses([]);
      setSidState(null);
      setError(null);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const data = await apiFetch<{ results: SellerBusiness[] }>("/commerce/businesses/");
      setBusinesses(data.results);
      setSidState((current) => {
        if (current && data.results.some((b) => b.id === current)) return current;
        const stored = Number(typeof window !== "undefined" ? localStorage.getItem(SID_KEY) : 0);
        if (stored && data.results.some((b) => b.id === stored)) return stored;
        return data.results[0]?.id ?? null;
      });
    } catch (err) {
      setBusinesses([]);
      setError(err instanceof ApiError ? err.message : "دریافت اطلاعات فروشگاه ناموفق بود.");
    } finally {
      setLoading(false);
    }
  }, [isAuthenticated, user?.id]);

  useEffect(() => {
    if (!authReady) return;
    load();
  }, [authReady, load]);

  const setSid = useCallback((id: number) => {
    setSidState(id);
    if (typeof window !== "undefined") localStorage.setItem(SID_KEY, String(id));
  }, []);

  const business = useCallback(
    (id: number | null) => (id == null ? undefined : businesses.find((b) => b.id === id)),
    [businesses],
  );

  const storeOf = useCallback(
    (id: number | null) => {
      const found = business(id);
      return found ? fallbackStore(found) : null;
    },
    [business],
  );

  const value: Ctx = useMemo(
    () => ({
      ready: authReady && !loading,
      loading,
      error,
      loginRequired: authReady && !isAuthenticated,
      businesses,
      sid,
      setSid,
      refresh: load,
      business,
      storeOf,
    }),
    [authReady, loading, error, isAuthenticated, businesses, sid, setSid, load, business, storeOf],
  );

  return <CommerceCtx.Provider value={value}>{children}</CommerceCtx.Provider>;
}

export function useCommerce() {
  const ctx = useContext(CommerceCtx);
  if (!ctx) throw new Error("useCommerce must be used inside CommerceProvider");
  return ctx;
}

/* ---------- دادهٔ عمومی باشگاه ---------- */

export function usePublicClubStores() {
  const [data, setData] = useState<PublicClubStore[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiFetch<{ results: PublicClubStore[] }>("/commerce/public/club/stores/", { auth: false });
      setData(res.results);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "دریافت فهرست باشگاه ناموفق بود.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);
  return { data, loading, error, refresh: load };
}

/* ---------- باشگاه ---------- */

export function useClub(sid: number | null) {
  const [data, setData] = useState<ClubResponse | null>(null);
  const [loading, setLoading] = useState(!!sid);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    if (!sid) {
      setData(null);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      setData(await apiFetch<ClubResponse>(`/commerce/businesses/${sid}/club/`));
    } catch (err) {
      setData(null);
      setError(err instanceof ApiError ? err.message : "دریافت وضعیت باشگاه ناموفق بود.");
    } finally {
      setLoading(false);
    }
  }, [sid]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const acceptTerms = useCallback(
    async (name: string, kind: "club" | "seller" = "club") => {
      if (!sid) throw new Error("فروشگاه انتخاب نشده است.");
      const accepted = await apiFetch<Acceptance>(`/commerce/businesses/${sid}/agreements/accept/`, {
        method: "POST",
        body: { kind, accepted_name: name },
      });
      await refresh();
      return accepted;
    },
    [sid, refresh],
  );

  const saveOffer = useCallback(
    async (text: string) => {
      if (!sid) throw new Error("فروشگاه انتخاب نشده است.");
      await apiFetch(`/commerce/businesses/${sid}/club/offer/`, {
        method: "PUT",
        body: { text, is_active: true },
      });
      await refresh();
    },
    [sid, refresh],
  );

  return { data, loading, error, refresh, acceptTerms, saveOffer };
}

/* ---------- درآمد ---------- */

export function useRevenue(sid: number | null) {
  const [data, setData] = useState<RevenueResponse | null>(null);
  const [loading, setLoading] = useState(!!sid);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    if (!sid) {
      setData(null);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      setData(await apiFetch<RevenueResponse>(`/commerce/businesses/${sid}/revenue/`));
    } catch (err) {
      setData(null);
      setError(err instanceof ApiError ? err.message : "دریافت اطلاعات درآمد ناموفق بود.");
    } finally {
      setLoading(false);
    }
  }, [sid]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const saveConfig = useCallback(
    async (payload: { commission_rate?: number; monthly_fee_toman?: number; setup_fee_toman?: number }) => {
      if (!sid) return;
      await apiFetch(`/commerce/businesses/${sid}/revenue/config/`, { method: "PATCH", body: payload });
      await refresh();
    },
    [sid, refresh],
  );

  const addCampaign = useCallback(
    async (body: Record<string, unknown>) => {
      if (!sid) return;
      await apiFetch(`/commerce/businesses/${sid}/campaigns/`, { method: "POST", body });
      await refresh();
    },
    [sid, refresh],
  );

  const toggleCampaign = useCallback(
    async (id: number) => {
      if (!sid) return;
      await apiFetch(`/commerce/businesses/${sid}/campaigns/${id}/toggle/`, { method: "POST", body: {} });
      await refresh();
    },
    [sid, refresh],
  );

  const addAd = useCallback(
    async (body: Record<string, unknown>) => {
      if (!sid) return;
      await apiFetch(`/commerce/businesses/${sid}/ads/`, { method: "POST", body });
      await refresh();
    },
    [sid, refresh],
  );

  const toggleAd = useCallback(
    async (id: number) => {
      if (!sid) return;
      await apiFetch(`/commerce/businesses/${sid}/ads/${id}/toggle/`, { method: "POST", body: {} });
      await refresh();
    },
    [sid, refresh],
  );

  const saveLaunch = useCallback(
    async (area: string, category: string) => {
      if (!sid) return;
      await apiFetch(`/commerce/businesses/${sid}/launch/`, { method: "PATCH", body: { area, category } });
      await refresh();
    },
    [sid, refresh],
  );

  const createInvoice = useCallback(
    async (body: { kind: Invoice["kind"]; title: string; amount_toman: number }) => {
      if (!sid) return;
      await apiFetch(`/commerce/businesses/${sid}/invoices/`, { method: "POST", body });
      await refresh();
    },
    [sid, refresh],
  );

  return {
    data, loading, error, refresh,
    saveConfig, addCampaign, toggleCampaign, addAd, toggleAd, saveLaunch, createInvoice,
  };
}

/* ---------- تسویه ---------- */

export function useSettlement(sid: number | null) {
  const [data, setData] = useState<SettlementResponse | null>(null);
  const [loading, setLoading] = useState(!!sid);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    if (!sid) {
      setData(null);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      setData(await apiFetch<SettlementResponse>(`/commerce/businesses/${sid}/settlement/`));
    } catch (err) {
      setData(null);
      setError(err instanceof ApiError ? err.message : "دریافت اطلاعات تسویه ناموفق بود.");
    } finally {
      setLoading(false);
    }
  }, [sid]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const saveOnboarding = useCallback(
    async (legalName: string, iban: string) => {
      if (!sid) return;
      await apiFetch(`/commerce/businesses/${sid}/settlement/onboarding/`, {
        method: "PUT",
        body: { legal_name: legalName, iban },
      });
      await refresh();
    },
    [sid, refresh],
  );

  const reverseEntry = useCallback(
    async (entryId: number, reason: string) => {
      if (!sid) return;
      await apiFetch(`/commerce/businesses/${sid}/settlement/ledger/${entryId}/reverse/`, {
        method: "POST",
        body: { reason },
      });
      await refresh();
    },
    [sid, refresh],
  );

  return { data, loading, error, refresh, saveOnboarding, reverseEntry };
}

/* ---------- توافق‌نامه‌ها ---------- */

export function useAgreements(sid: number | null, kind: "seller" | "club" = "seller") {
  const [versions, setVersions] = useState<Terms[]>([]);
  const [acceptances, setAcceptances] = useState<Acceptance[]>([]);
  const [loading, setLoading] = useState(!!sid);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    if (!sid) {
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await apiFetch<{ versions: Terms[]; acceptances: Acceptance[] }>(
        `/commerce/businesses/${sid}/agreements/?kind=${kind}`,
      );
      setVersions(res.versions);
      setAcceptances(res.acceptances);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "دریافت شرایط همکاری ناموفق بود.");
    } finally {
      setLoading(false);
    }
  }, [sid, kind]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const accept = useCallback(
    async (name: string) => {
      if (!sid) throw new Error("فروشگاه انتخاب نشده است.");
      await apiFetch(`/commerce/businesses/${sid}/agreements/accept/`, {
        method: "POST",
        body: { kind, accepted_name: name },
      });
      await refresh();
    },
    [sid, kind, refresh],
  );

  return { versions, acceptances, loading, error, refresh, accept, current: versions[0] || null };
}

/* ---------- گزارش ---------- */

export function useMetrics(sid: number | null, range: { start?: string; end?: string } = {}) {
  const [data, setData] = useState<MetricsResponse | null>(null);
  const [loading, setLoading] = useState(!!sid);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    if (!sid) {
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const query = new URLSearchParams();
      if (range.start) query.set("start", range.start);
      if (range.end) query.set("end", range.end);
      setData(await apiFetch<MetricsResponse>(`/commerce/businesses/${sid}/metrics/?${query.toString()}`));
    } catch (err) {
      setData(null);
      setError(err instanceof ApiError ? err.message : "دریافت گزارش ناموفق بود.");
    } finally {
      setLoading(false);
    }
  }, [sid, range.start, range.end]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return { data, loading, error, refresh };
}

/* ---------- خرید حضوری فروشنده ---------- */

export function useSellerPurchases(sid: number | null) {
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [loading, setLoading] = useState(!!sid);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    if (!sid) {
      setPurchases([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await apiFetch<{ results: Purchase[] }>(`/commerce/businesses/${sid}/purchases/`);
      setPurchases(res.results);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "دریافت خریدها ناموفق بود.");
    } finally {
      setLoading(false);
    }
  }, [sid]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const validate = useCallback(
    async (code: string) => {
      if (!sid) throw new Error("فروشگاه انتخاب نشده است.");
      return apiFetch<{ state: string; code_hint: string; expires_at: string; customer_label: string }>(
        `/commerce/businesses/${sid}/purchase-codes/validate/`,
        { method: "POST", body: { code } },
      );
    },
    [sid],
  );

  const confirm = useCallback(
    async (code: string) => {
      if (!sid) throw new Error("فروشگاه انتخاب نشده است.");
      const res = await apiFetch<{ created: boolean; already_confirmed: boolean; purchase: Purchase }>(
        `/commerce/businesses/${sid}/purchase-codes/confirm/`,
        { method: "POST", body: { code } },
      );
      await refresh();
      return res;
    },
    [sid, refresh],
  );

  const revoke = useCallback(
    async (purchaseId: number) => {
      if (!sid) return;
      await apiFetch(`/commerce/businesses/${sid}/purchases/${purchaseId}/revoke/`, {
        method: "POST",
        body: {},
      });
      await refresh();
    },
    [sid, refresh],
  );

  return { purchases, loading, error, refresh, validate, confirm, revoke };
}

/* ---------- خرید حضوری مشتری ---------- */

export function useCustomerPurchases() {
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { isAuthenticated, ready } = useAuth();

  const refresh = useCallback(async () => {
    if (!ready) return;
    if (!isAuthenticated) {
      setPurchases([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await apiFetch<{ results: Purchase[] }>("/commerce/club/purchases/mine/");
      setPurchases(res.results);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "دریافت خریدهای شما ناموفق بود.");
    } finally {
      setLoading(false);
    }
  }, [ready, isAuthenticated]);

  useEffect(() => {
    refresh();
  }, [refresh]);
  return { purchases, loading, error, refresh };
}

/* ---------- سفارش‌ها ---------- */

export type OrderRow = {
  number: string;
  business_id: number;
  business_name: string;
  mode: "delivery" | "pickup";
  status: string;
  payment_method: "online" | "offline";
  payment_state: "pending" | "paid" | "refunded";
  subtotal_toman: number;
  goods_total_toman: number;
  delivery_fee_toman: number;
  total_toman: number;
  commission_rate: string | null;
  commission_amount_toman: number | null;
  created_at: string;
  items: { id: number; name: string; quantity: number; unit_price_toman: number }[];
  history?: { status: string; at: string }[];
  customer?: { id: number; name: string; phone: string };
  address_text?: string;
  note?: string;
  preferred_time?: string;
};

export function useMyOrders() {
  const { ready, isAuthenticated } = useAuth();
  const [orders, setOrders] = useState<OrderRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    if (!ready) return;
    if (!isAuthenticated) {
      setOrders([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await apiFetch<{ results: OrderRow[] }>("/commerce/orders/mine/");
      setOrders(res.results);
    } catch (err) {
      setOrders([]);
      setError(err instanceof ApiError ? err.message : "دریافت سفارش‌ها ناموفق بود.");
    } finally {
      setLoading(false);
    }
  }, [ready, isAuthenticated]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return { orders, loading, error, refresh };
}

export function useSellerOrders(sid: number | null) {
  const [orders, setOrders] = useState<OrderRow[]>([]);
  const [loading, setLoading] = useState(!!sid);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    if (!sid) {
      setOrders([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await apiFetch<{ results: OrderRow[] }>(`/commerce/businesses/${sid}/orders/`);
      setOrders(res.results);
    } catch (err) {
      setOrders([]);
      setError(err instanceof ApiError ? err.message : "دریافت سفارش‌ها ناموفق بود.");
    } finally {
      setLoading(false);
    }
  }, [sid]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const setStatus = useCallback(
    async (number: string, next: string) => {
      if (!sid) return;
      await apiFetch(`/commerce/businesses/${sid}/orders/${number}/status/`, {
        method: "POST",
        body: { status: next },
      });
      await refresh();
    },
    [sid, refresh],
  );

  const simulatePayment = useCallback(
    async (number: string) => {
      if (!sid) return;
      await apiFetch(`/commerce/businesses/${sid}/orders/${number}/simulate-payment/`, {
        method: "POST",
        body: {},
      });
      await refresh();
    },
    [sid, refresh],
  );

  return { orders, loading, error, refresh, setStatus, simulatePayment };
}

/* ---------- کمکی ---------- */
export function rateOf(value: string | number | null | undefined): number {
  const n = typeof value === "number" ? value : parseFloat(value || "0");
  return Number.isFinite(n) ? n : 0;
}

export function statusLabel(status: ClubSummary["status"], active: boolean, trialUsed: boolean) {
  if (active) return status === "trial" ? "دورهٔ آزمایشی فعال" : "اشتراک فعال";
  if (status === "expired" || trialUsed) return "پایان اعتبار";
  return "هنوز فعال نشده";
}
