/* =========================================================
   جم لایف — داده‌های نمایشی
   این فایل منبع دادهٔ نسخهٔ نمایشی است و به بک‌اند وصل نیست.
   ساختار داده‌ها مطابق مرجع طراحی (jam-life.html) است.
   نام فروشگاه‌ها، امتیازها، شماره تلفن‌ها و فاصله‌ها همگی نمونه‌اند
   و نباید به‌عنوان اطلاعات واقعی کسب‌وکار به کاربر ارائه شوند.
   ========================================================= */

export type Product = {
  id: string;
  name: string;
  em: string;
  price: number;
  sec: string;
  desc: string;
  old: number;
  available: boolean;
  pop: boolean;
  unit?: string;
  image?: string;
};

export type Store = {
  id: string;
  slug: string;
  name: string;
  cat: string;
  tone: string;
  cover?: string;
  em: string;
  tagline: string;
  desc: string;
  rating: number;
  reviews: number;
  km: number;
  hours: [string, string][];
  phone: string;
  address: string;
  minOrder: number;
  prep: number;
  delivery: boolean;
  pickup: boolean;
  discount: number;
  featured?: boolean;
  isNew?: boolean;
  service?: boolean;
  retail?: boolean;
  chainColor?: string;
  chainShort?: string;
  sections: string[];
  products: Product[];
  /** True for stores registered from the backend public catalog. */
  api?: boolean;
  menuSlug?: string;
  apiBusinessId?: number;
  deliveryFee?: number;
  coverImage?: string;
};

export type Plan = { id: string; name: string; price: number; desc: string; pop?: boolean; feats: [string, number][] };

export type StatusInfo = { t: string; short: string; c: "green" | "red" | "amber" | "blue" | "violet" | "gray"; icon: string };

export const DATA_KIND = "demo" as const;

import { fa, faD } from "./format";

/* ---------- دسته‌بندی‌ها ---------- */
export const CATS = [
  { id: "restaurant", name: "رستوران و کافه", sub: "غذا، فست‌فود، کافه", icon: "utensils" },
  { id: "market", name: "سوپرمارکت", sub: "مواد غذایی و روزانه", icon: "cart" },
  { id: "hyper", name: "هایپرمارکت و زنجیره‌ای", sub: "افق کوروش، رفاه و خرید سبدی", icon: "store" },
  { id: "pastry", name: "شیرینی و خوراکی", sub: "شیرینی، نان، آجیل", icon: "cake" },
  { id: "fashion", name: "پوشاک", sub: "لباس و لوازم شخصی", icon: "shirt" },
  { id: "home", name: "لوازم خانگی", sub: "خانه و آشپزخانه", icon: "sofa" },
  { id: "services", name: "خدمات محلی", sub: "خشکشویی، تعمیرات", icon: "wrench" },
];

export const catById = (id: string | undefined) =>
  CATS.find((c) => c.id === id) || { id: "all", name: "همه", sub: "", icon: "grid" };

export const COVERS: Record<string, string> = {
  restaurant: "linear-gradient(135deg,#FF9A5A,#E2552B)",
  cafe: "linear-gradient(135deg,#C99366,#7E4E27)",
  market: "linear-gradient(135deg,#3FCB94,#0B8C5E)",
  hyper: "linear-gradient(135deg,#E8EFF9,#BACFE5)",
  pastry: "linear-gradient(135deg,#F58BBE,#D0306F)",
  fashion: "linear-gradient(135deg,#8D97FA,#4B42D6)",
  home: "linear-gradient(135deg,#4CC4F5,#0B79B8)",
  services: "linear-gradient(135deg,#B39BFA,#6F3FE0)",
};

/* ---------- عکس‌ها (دارایی‌های استخراج‌شده از مرجع) ---------- */
export const MEDIA: Record<string, string> = {
  ghormeh: "/media/ghormeh.webp", pizza: "/media/pizza.webp", home: "/media/home.webp",
  burger: "/media/burger.webp", pastry: "/media/pastry.webp", icecream: "/media/icecream.webp",
  salad: "/media/salad.webp", soup: "/media/soup.webp", bread: "/media/bread.webp",
  produce: "/media/produce.webp", coffee: "/media/coffee.webp", grill: "/media/grill.webp",
  fashion: "/media/fashion.webp", laundry: "/media/laundry.webp", cake: "/media/cake.webp",
  tea: "/media/tea.webp", chicken: "/media/chicken.webp", juice: "/media/juice.webp",
  rice: "/media/rice.webp",
};
export const RETAIL_MEDIA: Record<string, string> = {
  milk: "/media/retail-milk.webp", yogurt: "/media/retail-yogurt.webp", oil: "/media/retail-oil.webp",
  rice: "/media/retail-rice.webp", pasta: "/media/retail-pasta.webp", eggs: "/media/retail-eggs.webp",
  water: "/media/retail-water.webp", tea: "/media/retail-tea.webp", detergent: "/media/retail-detergent.webp",
  tissue: "/media/retail-tissue.webp", biscuit: "/media/retail-biscuit.webp", apples: "/media/retail-apples.webp",
};

export const STORE_PHOTOS: Record<string, string> = {
  s1: "grill", s2: "coffee", s3: "pizza", s4: "produce", s5: "pastry",
  s6: "fashion", s7: "home", s8: "bread", s9: "laundry", s10: "icecream",
};

export const storePhoto = (s: Store) => MEDIA[STORE_PHOTOS[s.id] || "grill"];

const P = (id: string, name: string, em: string, price: number, sec: string, o: { d?: string; old?: number; na?: number; pop?: number } = {}): Product => ({
  id, name, em, price, sec, desc: o.d || "", old: o.old || 0, available: !o.na, pop: !!o.pop,
});

/* ---------- فروشگاه‌های نمونه ---------- */
export const STORES: Store[] = [
  { id: "s1", slug: "nakhl", name: "رستوران سنتی نخل", cat: "restaurant", tone: "restaurant", em: "🍢", tagline: "کباب و غذای ایرانی", desc: "غذای خانگی و کباب ذغالی با مواد اولیهٔ تازه؛ از سال ۱۳۸۹ در خدمت مردم جم.", rating: 4.8, reviews: 1240, km: 1.6, hours: [["11:30", "16:00"], ["18:30", "23:45"]], phone: "077-37621234", address: "جم، بلوار امام خمینی، نبش کوچه ۱۴", minOrder: 150000, prep: 25, delivery: true, pickup: true, discount: 15, featured: true,
    sections: ["کباب‌ها", "خورش و پلو", "پیش‌غذا", "نوشیدنی"],
    products: [
      P("p101", "چلوکباب کوبیده", "🍢", 285000, "کباب‌ها", { d: "دو سیخ کوبیده ۱۱۰ گرمی، برنج ایرانی، گوجه کبابی و کره", old: 320000, pop: 1 }),
      P("p102", "چلوجوجه‌کباب", "🍗", 265000, "کباب‌ها", { d: "سینهٔ مرغ زعفرانی ۳۰۰ گرم، برنج ایرانی و گوجه کبابی", pop: 1 }),
      P("p103", "کباب برگ مخصوص", "🥩", 465000, "کباب‌ها", { d: "فیله گوسفندی ۲۵۰ گرم، برنج و گوجه" }),
      P("p104", "سلطانی", "🍖", 520000, "کباب‌ها", { d: "یک سیخ برگ و یک سیخ کوبیده به همراه برنج", na: 1 }),
      P("p105", "قورمه‌سبزی", "🍛", 210000, "خورش و پلو", { d: "خورش قورمه‌سبزی جاافتاده با گوشت گوسفندی و برنج", pop: 1 }),
      P("p106", "قیمه نثار", "🍲", 230000, "خورش و پلو", { d: "قیمه با خلال بادام و پسته، برنج زعفرانی" }),
      P("p107", "قلیه ماهی جنوبی", "🐟", 295000, "خورش و پلو", { d: "قلیه ماهی تند به سبک بوشهری، برنج کته", old: 330000 }),
      P("p108", "سالاد شیرازی", "🥗", 45000, "پیش‌غذا", { d: "خیار، گوجه، پیاز، آبغوره" }),
      P("p109", "سوپ جو", "🥣", 55000, "پیش‌غذا", { d: "سوپ جو با شیر و جعفری" }),
      P("p110", "ماست و خیار", "🥛", 38000, "پیش‌غذا", { d: "ماست چکیده، خیار، نعناع خشک" }),
      P("p111", "دوغ محلی", "🥤", 30000, "نوشیدنی", { d: "یک لیتری، گازدار" }),
      P("p112", "نوشابه قوطی", "🥫", 25000, "نوشیدنی", { d: "۳۳۰ میلی‌لیتر" }),
    ] },
  { id: "s2", slug: "abi-cafe", name: "کافه آبی", cat: "restaurant", tone: "cafe", cover: "cafe", em: "☕", tagline: "قهوه تخصصی و کیک خانگی", desc: "قهوه تخصصی، دسرهای روز و صبحانه؛ فضایی آرام برای کار و گفت‌وگو.", rating: 4.7, reviews: 860, km: 0.9, hours: [["08:00", "24:00"]], phone: "077-37625544", address: "جم، خیابان طالقانی، روبه‌روی پارک شهر", minOrder: 80000, prep: 12, delivery: true, pickup: true, discount: 0, featured: true, isNew: true,
    sections: ["قهوه", "نوشیدنی سرد", "کیک و دسر", "صبحانه"],
    products: [
      P("p201", "اسپرسو دبل", "☕", 75000, "قهوه", { d: "۶۰/۴۰ عربیکا و روبوستا", pop: 1 }),
      P("p202", "لاته", "🥛", 98000, "قهوه", { d: "اسپرسو، شیر بخارداده، فوم نرم", pop: 1 }),
      P("p203", "کاپوچینو", "☕", 95000, "قهوه", { d: "اسپرسو با فوم غلیظ شیر" }),
      P("p204", "موکا", "🍫", 110000, "قهوه", { d: "اسپرسو، شکلات، شیر" }),
      P("p205", "آیس‌لاته", "🧋", 115000, "نوشیدنی سرد", { d: "اسپرسو، شیر سرد، یخ" }),
      P("p206", "لیموناد نعناع", "🍋", 85000, "نوشیدنی سرد", { d: "لیموی تازه، نعناع، سودا", old: 95000 }),
      P("p207", "اسموتی انبه", "🥭", 120000, "نوشیدنی سرد", { d: "انبه، ماست، عسل", na: 1 }),
      P("p208", "چیزکیک نیویورکی", "🍰", 135000, "کیک و دسر", { d: "یک برش، با سس توت‌فرنگی", pop: 1 }),
      P("p209", "کیک شکلاتی", "🎂", 115000, "کیک و دسر", { d: "کیک خیس شکلاتی خانگی" }),
      P("p210", "صبحانه انگلیسی", "🍳", 185000, "صبحانه", { d: "تخم‌مرغ، سوسیس، لوبیا، نان تست" }),
      P("p211", "املت خانگی", "🍅", 120000, "صبحانه", { d: "گوجه، تخم‌مرغ محلی، نان بربری" }),
    ] },
  { id: "s3", slug: "sahel", name: "فست‌فود ساحل", cat: "restaurant", tone: "restaurant", em: "🍔", tagline: "پیتزا، برگر و ساندویچ", desc: "پیتزای تنوری و برگر دست‌ساز گوشت تازه؛ تا پاسی از شب.", rating: 4.5, reviews: 2110, km: 2.4, hours: [["12:00", "02:00"]], phone: "077-37629090", address: "جم، میدان معلم، جنب بانک ملی", minOrder: 120000, prep: 20, delivery: true, pickup: true, discount: 20, featured: true,
    sections: ["پیتزا", "برگر", "ساندویچ", "پیش‌غذا و نوشیدنی"],
    products: [
      P("p301", "پیتزا مخصوص ساحل", "🍕", 345000, "پیتزا", { d: "ژامبون گوشت، قارچ، فلفل دلمه، پنیر موزارلا ۳۰ سانتی", old: 410000, pop: 1 }),
      P("p302", "پیتزا پپرونی", "🍕", 325000, "پیتزا", { d: "پپرونی تند، پنیر موزارلا، سس مخصوص" }),
      P("p303", "پیتزا سبزیجات", "🫑", 265000, "پیتزا", { d: "قارچ، زیتون، ذرت، فلفل دلمه" }),
      P("p304", "چیزبرگر دوبل", "🍔", 295000, "برگر", { d: "دو لایه گوشت ۱۲۰ گرمی، پنیر چدار، سس مخصوص", pop: 1 }),
      P("p305", "برگر قارچ و پنیر", "🍔", 255000, "برگر", { d: "گوشت ۱۵۰ گرم، قارچ سوخاری، پنیر" }),
      P("p306", "هات‌داگ پنیری", "🌭", 165000, "ساندویچ", { d: "سوسیس آلمانی، پنیر گودا، خیارشور" }),
      P("p307", "ساندویچ مرغ سوخاری", "🥪", 185000, "ساندویچ", { d: "فیله سوخاری، کاهو، سس سیر", old: 210000 }),
      P("p308", "سیب‌زمینی ویژه", "🍟", 115000, "پیش‌غذا و نوشیدنی", { d: "با پنیر و قارچ", pop: 1 }),
      P("p309", "نوشابه خانواده", "🥤", 45000, "پیش‌غذا و نوشیدنی", { d: "۱/۵ لیتری" }),
    ] },
  { id: "s4", slug: "hyper-jam", name: "سوپرمارکت جم", cat: "market", tone: "market", em: "🛒", tagline: "خرید روزانه از سوپرمارکت محله", desc: "بیش از ۳۰۰۰ قلم کالای اساسی و روزانه؛ لبنیات تازه هر روز صبح.", rating: 4.6, reviews: 1540, km: 1.1, hours: [["07:00", "24:00"]], phone: "077-37620011", address: "جم، بلوار پاسداران، مجتمع تجاری ستاره", minOrder: 200000, prep: 15, delivery: true, pickup: true, discount: 10, featured: true,
    sections: ["لبنیات", "نان و صبحانه", "میوه و سبزی", "کالای اساسی", "شوینده"],
    products: [
      P("p401", "شیر کم‌چرب یک لیتری", "🥛", 42000, "لبنیات", { d: "پاستوریزه، ۱/۵٪ چربی", pop: 1 }),
      P("p402", "ماست همزده ۹۰۰ گرمی", "🥣", 68000, "لبنیات", { d: "ماست پرچرب" }),
      P("p403", "پنیر سفید ۴۰۰ گرمی", "🧀", 95000, "لبنیات", { d: "پنیر UF", old: 108000 }),
      P("p404", "تخم‌مرغ ۱۲ عددی", "🥚", 125000, "نان و صبحانه", { d: "تخم‌مرغ تازه درجه یک", pop: 1 }),
      P("p405", "نان تست سبوس‌دار", "🍞", 48000, "نان و صبحانه", { d: "۴۵۰ گرم" }),
      P("p406", "عسل طبیعی ۵۰۰ گرمی", "🍯", 290000, "نان و صبحانه", { d: "عسل کوهستان", na: 1 }),
      P("p407", "سیب قرمز (کیلو)", "🍎", 78000, "میوه و سبزی", { d: "سیب لبنانی درجه یک" }),
      P("p408", "موز (کیلو)", "🍌", 115000, "میوه و سبزی", { d: "موز اکوادوری" }),
      P("p409", "گوجه‌فرنگی (کیلو)", "🍅", 42000, "میوه و سبزی", { d: "گوجه گلخانه‌ای", old: 49000 }),
      P("p410", "برنج هاشمی ۵ کیلویی", "🍚", 1150000, "کالای اساسی", { d: "برنج ایرانی معطر درجه یک", pop: 1 }),
      P("p411", "روغن مایع ۱/۵ لیتری", "🫒", 185000, "کالای اساسی", { d: "روغن آفتابگردان" }),
      P("p412", "مایع ظرفشویی ۷۵۰ گرمی", "🧴", 72000, "شوینده", { d: "رایحه لیمو" }),
      P("p413", "دستمال کاغذی ۱۰۰ برگ", "🧻", 38000, "شوینده", { d: "دولایه" }),
    ] },
  { id: "s5", slug: "golestan", name: "شیرینی‌سرای گلستان", cat: "pastry", tone: "pastry", em: "🧁", tagline: "شیرینی تر و خشک، کیک تولد", desc: "شیرینی تازه هر روز، کیک تولد سفارشی با ۲۴ ساعت پیش‌سفارش.", rating: 4.9, reviews: 720, km: 1.9, hours: [["08:00", "22:30"]], phone: "077-37627788", address: "جم، خیابان شهید بهشتی، پلاک ۴۲", minOrder: 100000, prep: 10, delivery: true, pickup: true, discount: 0, featured: true,
    sections: ["شیرینی تر", "شیرینی خشک", "کیک", "سنتی جنوبی"],
    products: [
      P("p501", "شیرینی ناپلئونی (کیلو)", "🥮", 420000, "شیرینی تر", { d: "خامه تازه، لایه‌های ترد", pop: 1 }),
      P("p502", "رولت خامه‌ای (کیلو)", "🍥", 390000, "شیرینی تر", { d: "خامه و میوه" }),
      P("p503", "کاپ‌کیک (۶ عددی)", "🧁", 260000, "شیرینی تر", { d: "طعم وانیل و شکلات" }),
      P("p504", "شیرینی کشمشی (کیلو)", "🍪", 360000, "شیرینی خشک", { d: "کره‌ای، کشمش پلویی" }),
      P("p505", "نان برنجی (کیلو)", "🍘", 380000, "شیرینی خشک", { d: "با گلاب و خشخاش", old: 420000 }),
      P("p506", "کیک تولد شکلاتی ۱/۵ کیلویی", "🎂", 890000, "کیک", { d: "نیاز به ۲۴ ساعت پیش‌سفارش", pop: 1 }),
      P("p507", "کیک میوه‌ای", "🍓", 760000, "کیک", { d: "توت‌فرنگی و کیوی", na: 1 }),
      P("p508", "باقلوا جنوبی (کیلو)", "🥮", 480000, "سنتی جنوبی", { d: "با هل و گلاب" }),
      P("p509", "حلوا مسقطی (کیلو)", "🍮", 320000, "سنتی جنوبی", { d: "سنتی بوشهری", old: 350000 }),
      P("p510", "رنگینک (کیلو)", "🍯", 290000, "سنتی جنوبی", { d: "شهدی و خوش‌عطر" }),
    ] },
  { id: "s6", slug: "mahan", name: "پوشاک ماهان", cat: "fashion", tone: "fashion", em: "👕", tagline: "پوشاک روزمرهٔ مردانه و زنانه", desc: "پوشاک نخی مناسب هوای گرم جنوب، سایزبندی کامل.", rating: 4.4, reviews: 310, km: 2.1, hours: [["09:30", "13:30"], ["17:00", "22:30"]], phone: "077-37623030", address: "جم، پاساژ ولیعصر، طبقهٔ اول", minOrder: 0, prep: 30, delivery: true, pickup: true, discount: 0,
    sections: ["مردانه", "زنانه", "اکسسوری"],
    products: [
      P("p601", "تی‌شرت نخی ساده", "👕", 380000, "مردانه", { d: "۱۰۰٪ نخ پنبه، سایز M تا XXL", old: 490000, pop: 1 }),
      P("p602", "پیراهن کتان آستین کوتاه", "👔", 640000, "مردانه", { d: "کتان سبک، سه رنگ" }),
      P("p603", "شلوار جین راسته", "👖", 890000, "مردانه", { d: "جین کش‌دار" }),
      P("p604", "مانتو تابستانه نخی", "🥻", 1250000, "زنانه", { d: "نخ کرپ خنک، سایز ۳۸ تا ۴۶", pop: 1 }),
      P("p605", "شومیز کتان", "👚", 720000, "زنانه", { d: "کتان، چهار رنگ", old: 850000 }),
      P("p606", "کلاه نقاب‌دار", "🧢", 260000, "اکسسوری", { d: "نخی، قابل تنظیم" }),
      P("p607", "کفش اسپرت", "👟", 1650000, "اکسسوری", { d: "زیره طبی، سایز ۳۷ تا ۴۵", na: 1 }),
    ] },
  { id: "s7", slug: "pars-home", name: "لوازم خانگی پارس", cat: "home", tone: "home", em: "🫖", tagline: "لوازم آشپزخانه و برقی کوچک", desc: "لوازم برقی کوچک، ظروف آشپزخانه و ملزومات خانه با گارانتی معتبر.", rating: 4.5, reviews: 280, km: 3.2, hours: [["09:00", "21:00"]], phone: "077-37624545", address: "جم، بلوار شهید کرمی، پلاک ۷۷", minOrder: 0, prep: 45, delivery: true, pickup: true, discount: 5,
    sections: ["برقی کوچک", "آشپزخانه", "روشنایی و ابزار"],
    products: [
      P("p701", "کتری برقی ۱/۷ لیتری", "🫖", 1450000, "برقی کوچک", { d: "استیل، ۲۲۰۰ وات، گارانتی ۱۸ ماهه", pop: 1 }),
      P("p702", "پنکه رومیزی", "🌀", 1890000, "برقی کوچک", { d: "سه سرعته، چرخشی", old: 2150000 }),
      P("p703", "ماهیتابه نچسب ۲۸", "🍳", 980000, "آشپزخانه", { d: "گرانیتی، دستهٔ ضدحرارت" }),
      P("p704", "سرویس لیوان ۶ عددی", "🥛", 420000, "آشپزخانه", { d: "شیشه سکوریت" }),
      P("p705", "لامپ LED ۱۲ وات", "💡", 95000, "روشنایی و ابزار", { d: "مهتابی، کم‌مصرف" }),
      P("p706", "چندراهی برق ۴ خانه", "🔌", 360000, "روشنایی و ابزار", { d: "محافظ‌دار، کابل ۳ متر" }),
    ] },
  { id: "s8", slug: "nan-mahalle", name: "نانوایی بربری محله", cat: "pastry", tone: "pastry", em: "🥖", tagline: "نان تازه تنوری", desc: "بربری و سنگک تازه؛ امکان پیش‌سفارش و تحویل حضوری بدون صف.", rating: 4.7, reviews: 530, km: 0.6, hours: [["06:00", "11:30"], ["16:30", "20:30"]], phone: "077-37628111", address: "جم، خیابان انقلاب، جنب بازار روز", minOrder: 0, prep: 15, delivery: false, pickup: true, discount: 0,
    sections: ["نان"],
    products: [
      P("p801", "نان بربری", "🥖", 15000, "نان", { d: "هر عدد", pop: 1 }),
      P("p802", "نان بربری کنجدی", "🥖", 18000, "نان", { d: "با کنجد و سیاه‌دانه" }),
      P("p803", "نان سنگک", "🫓", 22000, "نان", { d: "هر عدد، کنجدی" }),
      P("p804", "نان محلی جنوبی", "🫓", 25000, "نان", { d: "نان تیری، بستهٔ ۵ عددی", na: 1 }),
    ] },
  { id: "s9", slug: "pak", name: "خشکشویی پاک", cat: "services", tone: "services", em: "🧺", tagline: "شست‌وشو و اتوی تخصصی", desc: "خشکشویی و اتوی تخصصی؛ تحویل در ۴۸ ساعت، امکان دریافت و ارسال در محل.", rating: 4.6, reviews: 190, km: 1.4, hours: [["08:00", "20:00"]], phone: "077-37626262", address: "جم، خیابان امام رضا، پلاک ۱۸", minOrder: 0, prep: 2880, delivery: true, pickup: true, discount: 10, service: true,
    sections: ["شست‌وشو", "اتو", "تخصصی"],
    products: [
      P("p901", "شست‌وشو و اتوی پیراهن", "👔", 70000, "شست‌وشو", { d: "تحویل ۴۸ ساعته", pop: 1 }),
      P("p902", "خشکشویی کت و شلوار", "🧥", 260000, "شست‌وشو", { d: "تحویل ۴۸ ساعته" }),
      P("p903", "اتوی شلوار", "👖", 45000, "اتو", { d: "اتوی بخار" }),
      P("p904", "شست‌وشوی پتو دونفره", "🛏️", 320000, "تخصصی", { d: "تحویل ۷۲ ساعته", old: 360000 }),
      P("p905", "شست‌وشوی پرده (متر)", "🪟", 85000, "تخصصی", { d: "پرده حریر و مخمل" }),
    ] },
  { id: "s10", slug: "yakhnoosh", name: "آبمیوه‌بستنی یخ‌نوش", cat: "restaurant", tone: "cafe", cover: "pastry", em: "🍨", tagline: "آبمیوه طبیعی و بستنی", desc: "آبمیوه طبیعی، بستنی سنتی و فالوده؛ همراه گرمای جنوب.", rating: 4.6, reviews: 980, km: 1.3, hours: [["10:00", "01:00"]], phone: "077-37625050", address: "جم، بلوار امام خمینی، روبه‌روی پمپ بنزین", minOrder: 60000, prep: 8, delivery: true, pickup: true, discount: 12,
    sections: ["آبمیوه", "بستنی", "فالوده و دسر"],
    products: [
      P("p1001", "آب‌پرتقال طبیعی", "🍊", 95000, "آبمیوه", { d: "لیوان بزرگ، بدون شکر", pop: 1 }),
      P("p1002", "آب‌هندوانه", "🍉", 75000, "آبمیوه", { d: "لیوان بزرگ" }),
      P("p1003", "معجون مخصوص", "🥤", 145000, "آبمیوه", { d: "موز، شیر، بستنی، آجیل", old: 165000 }),
      P("p1004", "بستنی سنتی زعفرانی", "🍨", 85000, "بستنی", { d: "دو اسکوپ با پسته", pop: 1 }),
      P("p1005", "بستنی قیفی", "🍦", 45000, "بستنی", { d: "وانیل یا شکلات" }),
      P("p1006", "فالوده شیرازی", "🍧", 70000, "فالوده و دسر", { d: "با آبلیمو و آلبالو" }),
    ] },
];

/* ---------- فروشگاه‌های زنجیره‌ای (کاتالوگ نمونه) ----------
   کالاها و قیمت‌ها نمونهٔ نمایشی‌اند و به شعبه، قیمت یا موجودی
   واقعی هیچ برندی وصل نیستند؛ مطابق مرجع طراحی. */
const LIFE_RETAIL_ITEMS: [string, string, string, number, string][] = [
  ["milk", "شیر کم‌چرب", "۱ لیتر", 65000, "لبنیات و تخم‌مرغ"],
  ["yogurt", "ماست ساده", "۹۰۰ گرم", 130000, "لبنیات و تخم‌مرغ"],
  ["oil", "روغن مایع", "۹۰۰ میلی‌لیتر", 145000, "برنج و خواربار"],
  ["rice", "برنج ایرانی", "کیسهٔ ۱ کیلوگرمی", 225000, "برنج و خواربار"],
  ["pasta", "ماکارونی رشته‌ای", "۵۰۰ گرم", 45000, "برنج و خواربار"],
  ["eggs", "تخم‌مرغ", "بستهٔ ۶ عددی", 90000, "لبنیات و تخم‌مرغ"],
  ["water", "آب معدنی", "۱٫۵ لیتر", 15000, "نوشیدنی و چای"],
  ["tea", "چای سیاه", "بستهٔ ۲۵۰ گرمی", 190000, "نوشیدنی و چای"],
  ["detergent", "مایع لباس‌شویی", "۱ لیتر", 180000, "شوینده و بهداشت"],
  ["tissue", "دستمال کاغذی", "جعبهٔ ۲۰۰ برگ", 75000, "شوینده و بهداشت"],
  ["biscuit", "بیسکویت ساده", "بستهٔ ۱۲۰ گرمی", 45000, "تنقلات"],
  ["apples", "سیب تازه", "بستهٔ ۱ کیلوگرمی", 110000, "میوه و سبزی"],
];

const LIFE_RETAIL_STORES: [string, string, string, string, string][] = [
  ["h1", "ofogh-koorosh", "افق کوروش", "کوروش", "#AA3143"],
  ["h2", "refah", "رفاه", "رفاه", "#2369A4"],
  ["h3", "jam-hyper", "هایپرمارکت نمونهٔ جم", "هایپر", "#38604E"],
];

const roundK = (n: number) => Math.round(n / 1000) * 1000;

for (const [idx, [id, slug, name, short, color]] of LIFE_RETAIL_STORES.entries()) {
  const items: Product[] = LIFE_RETAIL_ITEMS.map(([key, n, unit, price, sec], i) => {
    const v = roundK(price * (1 + idx * 0.035));
    const offer = (i + idx) % 3 === 0;
    return {
      id: `rh${idx}p${i}`, name: n, em: "📦", price: v, old: offer ? roundK(v * 1.15) : 0, sec,
      desc: `${unit} · کالای نمونهٔ نمایشی، بدون برند تجاری`, unit, image: RETAIL_MEDIA[key],
      available: !(idx === 1 && i === 9), pop: false,
    };
  });
  STORES.push({
    id, slug, name, cat: "hyper", tone: "market", cover: "hyper", em: "🛒",
    tagline: "کاتالوگ نمونهٔ فروشگاه زنجیره‌ای",
    desc: "این کاتالوگ صرفاً برای نمایش تجربهٔ خرید است؛ به شعبه، قیمت یا موجودی واقعی این برند وصل نیست.",
    rating: 4.5, reviews: 300 + idx * 120, km: 2.5 + idx * 0.9, hours: [["08:00", "23:00"]],
    phone: "077-37620000", address: "جم، بلوار اصلی (نمونه)", minOrder: 300000, prep: 30,
    delivery: true, pickup: true, discount: 0, retail: true, chainColor: color, chainShort: short,
    sections: [], products: items,
  });
  STORE_PHOTOS[id] = "produce";
}

/* ---------- اشتراک‌ها ---------- */
export const PLANS: Plan[] = [
  { id: "basic", name: "پایه", price: 200000, desc: "شروع حضور دیجیتال", feats: [["منوی دیجیتال با ۳ قالب آماده", 1], ["لینک اختصاصی و QR Code", 1], ["مدیریت منو از پنل سایت", 1], ["تا ۸۰ محصول", 1], ["دریافت سفارش آنلاین", 0], ["نمایش ویژهٔ باشگاه؛ اشتراک جدا", 0]] },
  { id: "pro", name: "حرفه‌ای", price: 350000, desc: "منو + دریافت سفارش", pop: true, feats: [["همه امکانات پایه", 1], ["دریافت سفارش آنلاین و پرداخت", 1], ["پیگیری سفارش در پنل سایت", 1], ["محصولات نامحدود", 1], ["گزارش بازدید و فروش", 1], ["نمایش ویژهٔ باشگاه؛ اشتراک جدا", 0]] },
  { id: "plus", name: "ویژه", price: 550000, desc: "بیشترین دیده‌شدن", feats: [["همه امکانات حرفه‌ای", 1], ["تنظیم قالب و رنگ منو", 1], ["مدیریت چیدمان دسته‌بندی‌ها", 1], ["گزارش‌های پیشرفته", 1], ["طراحی اختصاصی منو", 1], ["پشتیبانی اولویت‌دار", 1]] },
];

/* ---------- وضعیت سفارش‌ها ---------- */
export const STATUS: Record<string, StatusInfo> = {
  refunded: { t: "مرجوع‌شده", short: "مرجوع شد", c: "red", icon: "refresh" },
  placed: { t: "در انتظار تأیید فروشگاه", short: "ثبت شد", c: "amber", icon: "clock" },
  accepted: { t: "تأیید شد", short: "تأیید شد", c: "blue", icon: "check" },
  preparing: { t: "در حال آماده‌سازی", short: "آماده‌سازی", c: "blue", icon: "chef" },
  ready: { t: "آماده تحویل در فروشگاه", short: "آماده تحویل", c: "green", icon: "pkg" },
  sent: { t: "ارسال شد", short: "ارسال شد", c: "violet", icon: "truck" },
  done: { t: "تحویل داده شد", short: "تحویل شد", c: "gray", icon: "check" },
  rejected: { t: "رد شده توسط فروشگاه", short: "رد شد", c: "red", icon: "ban" },
  canceled: { t: "لغو شده", short: "لغو شد", c: "red", icon: "ban" },
};

export const FLOW: Record<"delivery" | "pickup", string[]> = {
  delivery: ["placed", "accepted", "preparing", "sent", "done"],
  pickup: ["placed", "accepted", "preparing", "ready", "done"],
};

export const ACTIVE_STATUS = ["placed", "accepted", "preparing", "ready", "sent"];

/* ---------- قالب و رنگ منوی دیجیتال ---------- */
export const ACCENTS = ["#2C7A8C", "#B34230", "#247355", "#815A32", "#6B49A4", "#202734"];
export const TPLS: Record<string, string> = { modern: "مدرن", classic: "کلاسیک", dark: "تیره" };

/* ---------- کمکی‌ها ---------- */
export const store = (idOrSlug: string) => STORES.find((s) => s.id === idOrSlug || s.slug === idOrSlug);

/** ثبت فروشگاه واقعیِ دریافتی از API در رجیستری کلاینت
    (برای سبد خرید و رندر محصولات همان صفحه). */
const API_STORES_KEY = "jam.apiStores.v1";

function readApiStores(): Store[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(API_STORES_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as Store[]).filter((s) => s && s.id && Array.isArray(s.products)) : [];
  } catch {
    return [];
  }
}

/** Restore public backend store snapshots so a cart survives a reload. */
export function hydrateApiStores() {
  for (const s of readApiStores()) {
    if (!STORES.some((x) => x.id === s.id)) STORES.push(s);
  }
}

export function registerStore(s: Store) {
  if (!STORES.some((x) => x.id === s.id)) STORES.push(s);
  if (s.api && typeof window !== "undefined") {
    try {
      const rows = readApiStores().filter((x) => x.id !== s.id);
      localStorage.setItem(API_STORES_KEY, JSON.stringify([...rows, s]));
    } catch {
      /* Storage may be unavailable; the in-memory store still works. */
    }
  }
}

export const storeHref = (s: Store) => (s.api ? `/m/${s.menuSlug || s.slug}` : `/store/${s.id}`);
export const productById = (pid: string): { product: Product; store: Store } | undefined => {
  for (const s of STORES) {
    const product = s.products.find((p) => p.id === pid);
    if (product) return { product, store: s };
  }
  return undefined;
};

export const STORE_NAMES: Record<string, string> = {
  s1: "نخل", s2: "آبی", s3: "ساحل", s4: "جم", s5: "گلستان",
  s6: "ماهان", s7: "پارس", s8: "محله", s9: "پاک", s10: "یخ‌نوش",
};

const minutesOf = (t: string) => {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
};

export type OpenState = { open: boolean; closesAt?: string; opensAt?: string; tomorrow?: boolean };

/** وضعیت باز بودن فروشگاه — مطابق مرجع (پشتیبانی از شیفت شب) */
export function openState(s: Store, d = new Date()): OpenState {
  const now = d.getHours() * 60 + d.getMinutes();
  for (const [a, b] of s.hours) {
    const o = minutesOf(a);
    const c = minutesOf(b) <= o ? minutesOf(b) + 1440 : minutesOf(b);
    if ((now >= o && now < c) || (now + 1440 >= o && now + 1440 < c)) return { open: true, closesAt: b };
  }
  const opens = s.hours.map((h) => minutesOf(h[0])).sort((a, b) => a - b);
  const next = opens.find((o) => o > now);
  const n = next ?? opens[0];
  return {
    open: false,
    opensAt: `${String(Math.floor(n / 60)).padStart(2, "0")}:${String(n % 60).padStart(2, "0")}`,
    tomorrow: next == null,
  };
}

/** فروشگاه در حال حاضر باز است؟ (سازگاری با کد قبلی) */
export const isOpenNow = (s: Store, now = new Date()) => openState(s, now).open;

export const hoursText = (s: Store) =>
  s.hours.map((h) => `${faD(h[0])} تا ${faD(h[1] === "24:00" ? "۲۴:۰۰" : h[1])}`).join(" و ");

export const deliveryFee = (s: Store) => s.deliveryFee ?? roundK(12000 + s.km * 7000);

export const deliveryEta = (s: Store) =>
  s.service ? "۴۸ ساعت" : `${fa(Math.round((s.prep + 8 + s.km * 4) / 5) * 5)} دقیقه`;

export const prepText = (s: Store) => (s.service ? "۴۸ ساعت" : `${fa(s.prep)} دقیقه`);

export const discPct = (p: Product) => (p.old && p.old > p.price ? Math.round((1 - p.price / p.old) * 100) : 0);

/** انتخاب عکس محصول بر اساس نام/فروشگاه — مطابق مرجع */
export function productPhoto(p: Product, sid?: string): string | null {
  if (p.image && (p.image.startsWith("/media/") || p.image.startsWith("/api/media-proxy/") || /^https?:\/\//.test(p.image))) return p.image;
  const n = p.name || "";
  const s = sid || productById(p.id)?.store.id;
  if (/چای/.test(n)) return MEDIA.tea;
  if (/قهوه|لاته|کاپوچینو|آمریکانو|اسپرسو|موکا/.test(n)) return MEDIA.coffee;
  if (/کیک|چیزکیک/.test(n)) return MEDIA.cake;
  if (/سالاد/.test(n)) return MEDIA.salad;
  if (/سوپ/.test(n)) return MEDIA.soup;
  if (/جوجه/.test(n)) return MEDIA.chicken;
  if (/کباب|سلطانی/.test(n)) return MEDIA.grill;
  if (/قورمه/.test(n)) return MEDIA.ghormeh;
  if (/قیمه|قلیه|برنج/.test(n)) return MEDIA.rice;
  if (/پیتزا/.test(n)) return MEDIA.pizza;
  if (/برگر|ساندویچ/.test(n)) return MEDIA.burger;
  if (/آبمیوه|پرتقال|انبه|لیموناد/.test(n)) return MEDIA.juice;
  if (/بستنی|فالوده|شیک|معجون/.test(n)) return MEDIA.icecream;
  if (/نان|بربری|سنگک/.test(n)) return MEDIA.bread;
  if (/شیرینی|کوکی|کروسان/.test(n)) return MEDIA.pastry;
  if (s && ["s6", "s7", "s9"].includes(s)) return MEDIA[STORE_PHOTOS[s]];
  return null;
}

export function brandMonogram(s: Store) {
  return STORE_NAMES[s.id] || s.name.split(" ")[0];
}
