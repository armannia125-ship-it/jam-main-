"use client";
/* =========================================================
   جم لایف — وضعیت نمایشی سبد خرید و سفارش‌ها
   دقیقاً مانند مرجع طراحی، داده‌ها فقط در localStorage همین
   مرورگر نگهداری می‌شوند (نسخهٔ نمایشی؛ بدون بک‌اند).
   ========================================================= */

import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { productById, store as findStore, deliveryFee, hydrateApiStores } from "./data";
import { isDemoMode } from "./demo";

export type CartItem = { pid: string; qty: number };
export type Cart = { sid: string; items: CartItem[] } | null;

export type Address = { id: string; title: string; text: string };

export type OrderLine = { pid: string; name: string; em: string; qty: number; price: number };

export type Order = {
  id: string;
  sid: string;
  mode: "delivery" | "pickup";
  addrText?: string;
  name: string;
  phone: string;
  when: string;
  note: string;
  pay: "online" | "offline";
  items: OrderLine[];
  totals: { items: number; discount: number; delivery: number; total: number };
  code?: string;
  codeDisc?: number;
  refunded?: boolean;
  status: string;
  placedAt: number;
  history: { st: string; at: number }[];
};

export type Toast = { id: string; msg: string; kind?: "ok" | "err"; action?: { label: string; href: string } };

type Persisted = {
  cart: Cart;
  orders: Order[];
  favs: string[];
  addrs: Address[];
  profile: { name: string; phone: string };
};

const STORAGE_KEY = "jam.state.v1";

const initial: Persisted = {
  cart: null,
  orders: [],
  favs: [],
  addrs: isDemoMode() ? [{ id: "a1", title: "خانه", text: "جم، بلوار امام خمینی، کوچهٔ ۱۲، پلاک ۸" }] : [],
  profile: { name: "", phone: "" },
};

function load(): Persisted {
  if (typeof window === "undefined") return initial;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return initial;
    const parsed = JSON.parse(raw);
    const merged: Persisted = { ...initial, ...parsed };
    // Never resurrect a demo cart in a production build.
    if (!isDemoMode() && merged.cart && !merged.cart.sid.startsWith("api:")) {
      merged.cart = null;
    }
    return merged;
  } catch {
    return initial;
  }
}

type Ctx = {
  ready: boolean;
  cart: Cart;
  orders: Order[];
  favs: string[];
  addrs: Address[];
  profile: { name: string; phone: string };
  cartCount: number;
  cartTotal: number;
  toasts: Toast[];
  addToCart: (sid: string, pid: string, qty?: number) => void;
  setQty: (pid: string, qty: number) => void;
  inc: (pid: string) => void;
  dec: (pid: string) => void;
  clearCart: () => void;
  clearCartOf: (sid: string) => void;
  placeOrder: (o: Omit<Order, "id" | "status" | "placedAt" | "history" | "items" | "totals"> & { items: OrderLine[]; totals: Order["totals"] }) => Order;
  advanceOrder: (id: string) => void;
  rejectOrder: (id: string) => void;
  cancelOrder: (id: string) => void;
  refundOrder: (id: string) => void;
  toggleFav: (sid: string) => void;
  addAddress: (a: Omit<Address, "id">) => Address;
  setProfile: (p: { name: string; phone: string }) => void;
  toast: (msg: string, kind?: "ok" | "err", action?: { label: string; href: string }) => void;
  dismissToast: (id: string) => void;
};

const JamCtx = createContext<Ctx | null>(null);

export function JamProvider({ children }: { children: React.ReactNode }) {
  const [st, setSt] = useState<Persisted>(initial);
  const [ready, setReady] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const timers = useRef<Record<string, ReturnType<typeof setTimeout>>>({});

  useEffect(() => {
    hydrateApiStores();
    setSt(load());
    setReady(true);
    return () => Object.values(timers.current).forEach(clearTimeout);
  }, []);

  useEffect(() => {
    if (ready) localStorage.setItem(STORAGE_KEY, JSON.stringify(st));
  }, [st, ready]);

  const toast = useCallback((msg: string, kind: "ok" | "err" = "ok", action?: { label: string; href: string }) => {
    const id = Math.random().toString(36).slice(2, 8);
    setToasts((t) => [...t.slice(-3), { id, msg, kind, action }]);
    timers.current[id] = setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4000);
  }, []);

  const dismissToast = useCallback((id: string) => {
    clearTimeout(timers.current[id]);
    setToasts((t) => t.filter((x) => x.id !== id));
  }, []);

  const addToCart = useCallback((sid: string, pid: string, qty = 1) => {
    setSt((s) => {
      // هر سفارش فقط از یک فروشگاه — مطابق مرجع
      if (s.cart && s.cart.sid !== sid && s.cart.items.length > 0) return s; // تماس‌گیرنده قبلاً تأیید گرفته
      const base: Cart = s.cart && s.cart.sid === sid ? s.cart : { sid, items: [] };
      const items = [...base.items];
      const i = items.findIndex((x) => x.pid === pid);
      if (i >= 0) items[i] = { ...items[i], qty: Math.min(99, items[i].qty + qty) };
      else items.push({ pid, qty: Math.min(99, qty) });
      return { ...s, cart: { sid, items } };
    });
  }, []);

  const mutateCart = useCallback((fn: (items: CartItem[]) => CartItem[]) => {
    setSt((s) => (s.cart ? { ...s, cart: { ...s.cart, items: fn(s.cart.items) } } : s));
  }, []);

  const setQty = useCallback((pid: string, qty: number) => {
    mutateCart((items) =>
      qty <= 0 ? items.filter((x) => x.pid !== pid) : items.map((x) => (x.pid === pid ? { ...x, qty: Math.min(99, qty) } : x)),
    );
  }, [mutateCart]);
  const inc = useCallback((pid: string) => mutateCart((items) => items.map((x) => (x.pid === pid ? { ...x, qty: Math.min(99, x.qty + 1) } : x))), [mutateCart]);
  const dec = useCallback((pid: string) => mutateCart((items) => items.map((x) => (x.pid === pid ? { ...x, qty: x.qty - 1 } : x)).filter((x) => x.qty > 0)), [mutateCart]);
  const clearCart = useCallback(() => setSt((s) => ({ ...s, cart: null })), []);
  const clearCartOf = useCallback((sid: string) => setSt((s) => (s.cart?.sid === sid ? { ...s, cart: null } : s)), []);

  const placeOrder: Ctx["placeOrder"] = useCallback((payload) => {
    const now = Date.now();
    const order: Order = {
      ...payload,
      id: "JM" + Math.random().toString(16).slice(2, 10).toUpperCase(),
      status: "placed",
      placedAt: now,
      history: [{ st: "placed", at: now }],
    };
    setSt((s) => ({ ...s, orders: [order, ...s.orders], cart: s.cart?.sid === payload.sid ? null : s.cart }));
    return order;
  }, []);

  const mutateOrder = useCallback((id: string, fn: (o: Order) => Order | null) => {
    setSt((s) => {
      let changed: Order | null = null;
      const orders = s.orders.map((o) => {
        if (o.id !== id) return o;
        const next = fn(o);
        if (next) changed = next;
        return next || { ...o, status: o.status };
      });
      return changed ? { ...s, orders: orders as Order[] } : s;
    });
  }, []);

  const advanceOrder = useCallback(
    (id: string) => {
      mutateOrder(id, (o) => {
        const flow = o.mode === "pickup" ? ["placed", "accepted", "preparing", "ready", "done"] : ["placed", "accepted", "preparing", "sent", "done"];
        const i = flow.indexOf(o.status);
        if (i < 0 || i >= flow.length - 1) return null;
        const st2 = flow[i + 1];
        return { ...o, status: st2, history: [...o.history, { st: st2, at: Date.now() }] };
      });
      toast("وضعیت سفارش به‌روز شد");
    },
    [mutateOrder, toast],
  );

  const rejectOrder = useCallback(
    (id: string) => {
      mutateOrder(id, (o) => ({ ...o, status: "rejected", history: [...o.history, { st: "rejected", at: Date.now() }] }));
      toast("سفارش رد شد", "err");
    },
    [mutateOrder, toast],
  );

  const cancelOrder = useCallback(
    (id: string) => {
      mutateOrder(id, (o) => (["done", "rejected", "canceled", "refunded"].includes(o.status) ? null : { ...o, status: "canceled", history: [...o.history, { st: "canceled", at: Date.now() }] }));
      toast("سفارش لغو شد");
    },
    [mutateOrder, toast],
  );

  /* مرجوعی آزمایشی — مطابق مرجع: سفارش تحویل‌شده به وضعیت مرجوع می‌رود */
  const refundOrder = useCallback(
    (id: string) => {
      mutateOrder(id, (o) => (o.status !== "done" ? null : { ...o, refunded: true, status: "refunded", history: [...o.history, { st: "refunded", at: Date.now() }] }));
      toast("مرجوعی آزمایشی ثبت شد؛ هیچ وجه واقعی برگشت داده نمی‌شود");
    },
    [mutateOrder, toast],
  );

  const toggleFav = useCallback((sid: string) => {
    setSt((s) => {
      const has = s.favs.includes(sid);
      return { ...s, favs: has ? s.favs.filter((x) => x !== sid) : [...s.favs, sid] };
    });
  }, []);

  const addAddress = useCallback((a: Omit<Address, "id">) => {
    const addr = { ...a, id: Math.random().toString(36).slice(2, 8) };
    setSt((s) => ({ ...s, addrs: [...s.addrs, addr] }));
    return addr;
  }, []);

  const setProfile = useCallback((p: { name: string; phone: string }) => setSt((s) => ({ ...s, profile: p })), []);

  const { cartCount, cartTotal } = useMemo(() => {
    if (!st.cart) return { cartCount: 0, cartTotal: 0 };
    let count = 0;
    let total = 0;
    for (const it of st.cart.items) {
      const found = productById(it.pid);
      if (!found) continue;
      count += it.qty;
      total += found.product.price * it.qty;
    }
    return { cartCount: count, cartTotal: total };
  }, [st.cart]);

  const value: Ctx = {
    ready, cart: st.cart, orders: st.orders, favs: st.favs, addrs: st.addrs, profile: st.profile,
    cartCount, cartTotal, toasts,
    addToCart, setQty, inc, dec, clearCart, clearCartOf,
    placeOrder, advanceOrder, rejectOrder, cancelOrder, refundOrder, toggleFav, addAddress, setProfile,
    toast, dismissToast,
  };

  return (
    <JamCtx.Provider value={value}>
      {children}
      <div className="toasts" id="toasts" aria-live="polite">
        {toasts.map((t) => (
          <div key={t.id} className={`toast${t.kind === "err" ? " err" : ""}`}>
            <span className="t-ic" aria-hidden="true" />
            <span className="t-msg">{t.msg}</span>
            {t.action ? (
              <a className="t-action" href={t.action.href} onClick={() => dismissToast(t.id)}>
                {t.action.label}
              </a>
            ) : null}
            <button type="button" className="t-close ui-toast-close" aria-label="بستن" onClick={() => dismissToast(t.id)}>
              ×
            </button>
          </div>
        ))}
      </div>
    </JamCtx.Provider>
  );
}

export function useJam() {
  const ctx = useContext(JamCtx);
  if (!ctx) throw new Error("useJam must be used inside JamProvider");
  return ctx;
}

/** جمع اقلام سبدِ یک فروشگاه مشخص */
export function cartSummary(cart: Cart) {
  if (!cart) return { count: 0, items: 0, discount: 0, delivery: 0, total: 0, lines: [] as OrderLine[], store: undefined as ReturnType<typeof findStore> };
  const s = findStore(cart.sid);
  const lines: OrderLine[] = [];
  let items = 0;
  let discount = 0;
  let delivery = 0;
  for (const it of cart.items) {
    const found = productById(it.pid);
    if (!found) continue;
    items += found.product.price * it.qty;
    if (found.product.old > found.product.price) discount += (found.product.old - found.product.price) * it.qty;
    lines.push({ pid: it.pid, name: found.product.name, em: found.product.em, qty: it.qty, price: found.product.price });
  }
  if (s && cart.items.length && s.delivery) {
    delivery = deliveryFee(s);
  }
  return { count: lines.reduce((a, l) => a + l.qty, 0), items, discount, delivery, total: Math.max(0, items - discount + delivery), lines, store: s };
}
