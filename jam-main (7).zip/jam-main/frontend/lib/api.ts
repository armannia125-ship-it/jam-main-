/* =========================================================
   جم لایف — کلاینت API
   همهٔ درخواست‌های خصوصی با JWT ارسال می‌شوند. توکن‌ها فقط در
   مرورگر نگهداری می‌شوند و هرگز در کد عمومی چاپ نمی‌شوند.
   ========================================================= */

export const API_BASE = (process.env.NEXT_PUBLIC_API_BASE || "/api").replace(/\/$/, "");

export type AuthTokens = { access: string; refresh: string };

const AUTH_KEY = "jam.auth.v1";

export class ApiError extends Error {
  status: number;
  code?: string;
  data?: unknown;

  constructor(message: string, status: number, code?: string, data?: unknown) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
    this.data = data;
  }
}

let refreshing: Promise<AuthTokens | null> | null = null;

export function readSession(): { tokens: AuthTokens; user?: { id: number; phone?: string | null; email?: string | null } } | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(AUTH_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed?.tokens?.access) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function writeSession(tokens: AuthTokens, user?: { id: number; phone?: string | null; email?: string | null }) {
  if (typeof window === "undefined") return;
  localStorage.setItem(AUTH_KEY, JSON.stringify({ tokens, user }));
  window.dispatchEvent(new Event("jam-auth"));
}

export function clearSession() {
  if (typeof window === "undefined") return;
  localStorage.removeItem(AUTH_KEY);
  window.dispatchEvent(new Event("jam-auth"));
}

export function getAccessToken(): string | null {
  return readSession()?.tokens.access || null;
}

async function refreshAccess(): Promise<AuthTokens | null> {
  const session = readSession();
  if (!session?.tokens.refresh) return null;
  if (!refreshing) {
    refreshing = (async () => {
      try {
        const res = await fetch(`${API_BASE}/auth/refresh/`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ refresh: session.tokens.refresh }),
          cache: "no-store",
        });
        if (!res.ok) return null;
        const data = await res.json();
        const tokens = { access: data.access, refresh: data.refresh || session.tokens.refresh };
        writeSession(tokens, session.user);
        return tokens;
      } catch {
        return null;
      } finally {
        refreshing = null;
      }
    })();
  }
  return refreshing;
}

type RequestOptions = Omit<RequestInit, "body"> & { body?: unknown; auth?: boolean; retried?: boolean };

export async function apiFetch<T = unknown>(path: string, options: RequestOptions = {}): Promise<T> {
  const { body, auth = true, retried = false, headers, ...rest } = options;
  const finalHeaders = new Headers(headers);
  if (body !== undefined && !(body instanceof FormData)) {
    finalHeaders.set("Content-Type", "application/json");
  }
  const token = auth ? getAccessToken() : null;
  if (token) finalHeaders.set("Authorization", `Bearer ${token}`);

  // Callers pass canonical Django paths (with trailing slash). The slash must
  // be preserved: Django's APPEND_SLASH cannot redirect a POST safely, and the
  // same-origin /api proxy forwards the path verbatim.
  const [rawPath, rawQuery] = path.split("?");
  const url = `${API_BASE}${rawPath}${rawQuery ? `?${rawQuery}` : ""}`;

  const res = await fetch(url, {
    ...rest,
    headers: finalHeaders,
    body: body === undefined || body instanceof FormData ? (body as BodyInit | undefined) : JSON.stringify(body),
    cache: "no-store",
  });

  if (res.status === 401 && auth && !retried) {
    const next = await refreshAccess();
    if (next) return apiFetch<T>(path, { ...options, retried: true });
    clearSession();
  }

  if (res.status === 204) return undefined as T;

  const text = await res.text();
  let data: unknown = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = text;
  }

  if (!res.ok) {
    const payload = data as { detail?: string; code?: string } | null;
    const message =
      payload?.detail ||
      (typeof data === "string" ? data : "") ||
      (res.status === 401 ? "نشست شما منقضی شده است؛ دوباره وارد شوید." : "درخواست به سرور ناموفق بود.");
    throw new ApiError(message, res.status, payload?.code, data);
  }
  return data as T;
}

export function authHeaders(tokens: AuthTokens): HeadersInit {
  return { Authorization: `Bearer ${tokens.access}`, "Content-Type": "application/json" };
}

export async function requestOtp(identifier: string) {
  return apiFetch<{ detail: string }>("/auth/request-otp/", {
    method: "POST",
    auth: false,
    body: { identifier },
  });
}

export async function verifyOtp(identifier: string, code: string) {
  return apiFetch<{ access: string; refresh: string; user: { id: number; phone?: string | null; email?: string | null } }>(
    "/auth/verify-otp/",
    { method: "POST", auth: false, body: { identifier, code } },
  );
}

export async function signup(identifier: string, code: string) {
  return apiFetch<{ access: string; refresh: string; verified: boolean }>("/auth/signup/", {
    method: "POST",
    auth: false,
    body: { identifier, code },
  });
}
