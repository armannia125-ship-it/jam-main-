/* Demo mode is explicit in production. In development it stays enabled unless
   NEXT_PUBLIC_DEMO_MODE=false, so the design reference remains available.
   Production deployments must set NEXT_PUBLIC_DEMO_MODE=true to expose demo
   stores; otherwise only backend data is shown. */
export function isDemoMode(): boolean {
  const flag = process.env.NEXT_PUBLIC_DEMO_MODE;
  if (flag === "true") return true;
  if (flag === "false") return false;
  return process.env.NODE_ENV !== "production";
}
