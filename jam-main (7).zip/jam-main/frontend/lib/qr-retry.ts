/* =========================================================
   جم لایف — طبقه‌بندی خطای ساخت QR
   خطاهای گذرا ارزش «تلاش دوباره» دارند؛ خطاهای پیکربندی و
   درخواست نامعتبر نه. این تابع تنها منبع این تصمیم است.
   ========================================================= */

/** Errors that never become healthy by retrying the same request. */
const PERMANENT_CODES = new Set(["public_frontend_url_unconfigured"]);

/**
 * A QR request is worth retrying for any HTTP 5xx (a proxy or the API may
 * return 500/502/503/504 without the request being invalid) and for 429.
 * Known permanent configuration failures stay non-retryable even though the
 * API represents them as 503, and ordinary 4xx responses are not retryable.
 */
export function isRetryableQrError(status: number, code?: string): boolean {
  if (code && PERMANENT_CODES.has(code)) return false;
  if (status >= 500 && status <= 599) return true;
  return status === 429;
}
