/* کمکی‌های قالب‌بندی فارسی — مطابق مرجع طراحی */

export const fa = (n: number | string) => Number(n || 0).toLocaleString("fa-IR");

export const faD = (s: string | number) => String(s).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[Number(d)]);

export const enD = (s: string) =>
  String(s)
    .replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)));

export const toman = (n: number) => `${fa(n)} <small>تومان</small>`;

export const tomanT = (n: number) => `${fa(n)} تومان`;

export const norm = (s: string) =>
  String(s || "")
    .toLowerCase()
    .replace(/ي/g, "ی")
    .replace(/ك/g, "ک")
    .replace(/[\u200c\s]+/g, " ")
    .trim();

export const uid = (p = "") => p + Math.random().toString(36).slice(2, 8);

export const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

export const fmtTime = (d: number | string | Date) =>
  new Date(d).toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" });

export const fmtDate = (d: number | string | Date) =>
  new Date(d).toLocaleDateString("fa-IR", { day: "numeric", month: "long", year: "numeric" });

export const fmtDay = (d: number | Date) => new Date(d).toLocaleDateString("fa-IR", { weekday: "short" });

export function ago(t: number) {
  const m = Math.round((Date.now() - t) / 60000);
  if (m < 1) return "همین الان";
  if (m < 60) return `${fa(m)} دقیقه پیش`;
  const h = Math.round(m / 60);
  if (h < 24) return `${fa(h)} ساعت پیش`;
  return fmtDate(t);
}
