"use client";
/* =========================================================
   جم لایف — اشتراک‌ها و اعتبارها (API جدید پرداخت آنلاین)
   قرارداد سرور:
   - قیمت فقط سمت سرور محاسبه می‌شود؛ کلاینت هرگز مبلغ نمی‌فرستد.
   - نقش «مدیر» فقط از GET /auth/me/ (سمت سرور) خوانده می‌شود و
     هرگز به مقدار ذخیره‌شدهٔ سمت کلاینت اتکا نمی‌شود.
   ========================================================= */

import { useCallback, useEffect, useState } from "react";
import { ApiError, apiFetch, getAccessToken } from "./api";

export type SubProduct = {
  slug: string;
  name: string;
  description: string;
  category: "menu" | "club" | "combo";
  price_toman: number;
  duration_days: number;
  features: string[];
  max_products: number | null;
};

export type SubPurchaseRow = {
  id: number;
  product: string;
  business: string;
  business_id: number;
  price_toman: number;
  status: "pending" | "paid" | "failed";
  created_at: string;
  confirmed_at: string | null;
};

export type SubEntitlement = {
  type: "menu" | "club";
  starts_at: string | null;
  ends_at: string | null;
};

export type SubPurchaseStatus = {
  id: number;
  status: "pending" | "paid" | "failed";
  product: string;
  amount_toman: number;
  confirmed_at: string | null;
  payment_status: string | null;
  entitlements: SubEntitlement[];
};

export type SubNotification = {
  id: number;
  kind: string;
  payload: {
    entitlement_type?: string;
    product_name?: string;
    business_name?: string;
    ends_at?: string;
    remaining_days?: number;
  };
  created_at: string;
  read_at: string | null;
};

export type Me = {
  id: number;
  phone: string | null;
  email: string | null;
  name: string;
  role: "user" | "admin";
  is_active: boolean;
};

/* نقش سمت سرور — فقط از /auth/me/؛ هرگز از نشست ذخیره‌شده نه */
export function useServerRole() {
  const [role, setRole] = useState<"user" | "admin" | null>(null);

  useEffect(() => {
    let alive = true;
    const load = () => {
      if (!getAccessToken()) {
        setRole(null);
        return;
      }
      apiFetch<Me>("/auth/me/")
        .then((me) => {
          if (alive) setRole(me.role === "admin" ? "admin" : "user");
        })
        .catch(() => {
          if (alive) setRole(null);
        });
    };
    load();
    window.addEventListener("jam-auth", load);
    return () => {
      alive = false;
      window.removeEventListener("jam-auth", load);
    };
  }, []);

  return role;
}

/* کاتالوگ عمومی پنج محصول اشتراک */
export function useSubProducts() {
  const [products, setProducts] = useState<SubProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiFetch<{ results: SubProduct[] }>("/subscriptions/products/", { auth: false });
      setProducts(res.results || []);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "دریافت کاتالوگ اشتراک ناموفق بود.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { products, loading, error, refresh: load };
}

/* برچسب‌های فارسی مشترک */
export const ENTITLEMENT_TYPE_LABELS: Record<string, string> = {
  menu: "منوی دیجیتال",
  club: "باشگاه فروشندگان",
};

export const PURCHASE_STATUS_LABELS: Record<string, string> = {
  pending: "در انتظار پرداخت",
  paid: "پرداخت‌شده",
  failed: "ناموفق",
};

export function purchaseStatusPill(status: string): string {
  if (status === "paid") return "pill green";
  if (status === "failed") return "pill red";
  return "pill amber";
}

/* روزهای باقی‌ماندهٔ اعتبار — گرد‌شده به پایین، حداقل صفر */
export function remainingDays(endsAt: string | null): number | null {
  if (!endsAt) return null;
  const ms = new Date(endsAt).getTime() - Date.now();
  if (!Number.isFinite(ms)) return null;
  return Math.max(0, Math.floor(ms / 86_400_000));
}
