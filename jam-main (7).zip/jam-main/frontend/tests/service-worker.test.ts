/**
 * Regression tests for `public/sw.js`.
 *
 * The worker is plain JavaScript that runs in a ServiceWorkerGlobalScope, so
 * these tests load the real file into a Node `vm` context with minimal
 * CacheStorage/fetch stubs. They cover the failure modes that broke /play:
 *
 * - a failed static-asset fetch must resolve to a normal 503 response instead
 *   of rejecting `respondWith` (which surfaced as "TypeError: Failed to fetch"
 *   and left the page without CSS or JS);
 * - page HTML must no longer be cached, so a new deployment cannot serve old
 *   HTML that references deleted hashed chunks.
 *
 * Run with `npm test` (Node's built-in test runner + native TS stripping).
 */

import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { test } from "node:test";
import { fileURLToPath } from "node:url";
import vm from "node:vm";

const ORIGIN = "https://localhost";
const here = dirname(fileURLToPath(import.meta.url));
const workerSource = readFileSync(join(here, "..", "public", "sw.js"), "utf8");

interface FakeRequest {
  url: string;
  method?: string;
  mode?: string;
}

type RequestLike = string | FakeRequest;

const requestUrl = (request: RequestLike): string =>
  typeof request === "string" ? new URL(request, ORIGIN).href : request.url;

class FakeCache {
  readonly entries = new Map<string, Response>();

  private readonly fetcher: (url: string) => Promise<Response>;

  constructor(fetcher: (url: string) => Promise<Response>) {
    this.fetcher = fetcher;
  }

  /* Mirrors Cache.add: fetch the URL, fail on a non-ok response, then store. */
  async add(request: string): Promise<void> {
    const url = requestUrl(request);
    const response = await this.fetcher(url);
    if (!response.ok) throw new Error(`Cache.add failed with ${response.status} for ${url}`);
    await this.put(url, response);
  }

  async match(request: RequestLike): Promise<Response | undefined> {
    return this.entries.get(requestUrl(request));
  }

  async put(request: RequestLike, response: Response): Promise<void> {
    this.entries.set(requestUrl(request), response);
  }

  async delete(request: RequestLike): Promise<boolean> {
    return this.entries.delete(requestUrl(request));
  }

  async keys(): Promise<{ url: string }[]> {
    return [...this.entries.keys()].map((url) => ({ url }));
  }
}

interface Harness {
  caches: Map<string, FakeCache>;
  fetchCalls: string[];
  setFetch(next: (url: string) => Promise<Response>): void;
  dispatch(type: "fetch" | "install" | "activate" | "message", event: unknown): void;
  skippedWaiting(): boolean;
  claimedClients(): boolean;
  keys(): string[];
  cache(name: string): FakeCache;
}

function createHarness(): Harness {
  const stores = new Map<string, FakeCache>();
  const listeners = new Map<string, ((event: unknown) => void)[]>();
  const fetchCalls: string[] = [];
  let fetchImpl: (url: string) => Promise<Response> = async () => new Response("ok", { status: 200 });
  let skipWaiting = false;
  let claim = false;

  const openCache = (name: string): FakeCache => {
    let cache = stores.get(name);
    if (!cache) {
      cache = new FakeCache((url) => {
        fetchCalls.push(url);
        return fetchImpl(url);
      });
      stores.set(name, cache);
    }
    return cache;
  };

  const cachesStub = {
    async open(name: string) {
      return openCache(name);
    },
    async keys() {
      return [...stores.keys()];
    },
    async delete(name: string) {
      return stores.delete(name);
    },
    async match(request: RequestLike) {
      for (const cache of stores.values()) {
        const hit = await cache.match(request);
        if (hit) return hit;
      }
      return undefined;
    },
  };

  const selfStub = {
    location: { origin: ORIGIN },
    addEventListener(type: string, handler: (event: unknown) => void) {
      const list = listeners.get(type) ?? [];
      list.push(handler);
      listeners.set(type, list);
    },
    async skipWaiting() {
      skipWaiting = true;
    },
    clients: {
      async claim() {
        claim = true;
      },
      async matchAll() {
        return [];
      },
    },
  };

  const context = vm.createContext({
    self: selfStub,
    caches: cachesStub,
    fetch: (request: RequestLike) => {
      const url = requestUrl(request);
      fetchCalls.push(url);
      return fetchImpl(url);
    },
    Response,
    Headers,
    URL,
    console,
  });
  vm.runInContext(workerSource, context);

  return {
    caches: stores,
    fetchCalls,
    setFetch(next) {
      fetchImpl = next;
    },
    dispatch(type, event) {
      for (const handler of listeners.get(type) ?? []) handler(event);
    },
    skippedWaiting: () => skipWaiting,
    claimedClients: () => claim,
    keys: () => [...stores.keys()].sort(),
    cache(name) {
      return openCache(name);
    },
  };
}

async function fetchEvent(harness: Harness, request: FakeRequest): Promise<Response> {
  let response: Promise<Response> | undefined;
  harness.dispatch("fetch", {
    request,
    respondWith(promise: Promise<Response>) {
      response = promise;
    },
  });
  assert.ok(response, "worker should call respondWith for a same-origin GET");
  return response;
}

/** Let cache-write microtasks/timers settle before asserting on cache state. */
const flush = (): Promise<void> => new Promise((resolve) => setTimeout(resolve, 10));

const runEvent = (harness: Harness, type: "install" | "activate"): Promise<unknown> => {
  let done: Promise<unknown> | undefined;
  harness.dispatch(type, {
    waitUntil(promise: Promise<unknown>) {
      done = promise;
    },
  });
  assert.ok(done, `${type} handler should call waitUntil`);
  return done;
};

test("failed static-asset fetch resolves to 503 instead of an unhandled rejection", async () => {
  const harness = createHarness();
  harness.setFetch(async () => {
    throw new TypeError("Failed to fetch");
  });

  const response = await fetchEvent(harness, {
    url: `${ORIGIN}/_next/static/chunks/app/play/page-deadbeef.js`,
    method: "GET",
    mode: "cors",
  });

  assert.equal(response.status, 503);
  assert.equal(await response.text(), "");
});

test("static assets are served cache-first and network is not contacted on a hit", async () => {
  const harness = createHarness();
  const cached = new Response("console.log(1)", { status: 200 });
  await harness.cache("jam-static-v4").put(`${ORIGIN}/_next/static/chunks/app/page-123.js`, cached);
  harness.setFetch(async () => {
    throw new TypeError("Failed to fetch");
  });

  const response = await fetchEvent(harness, {
    url: `${ORIGIN}/_next/static/chunks/app/page-123.js`,
    method: "GET",
    mode: "cors",
  });

  assert.equal(response.status, 200);
  assert.equal(await response.text(), "console.log(1)");
  assert.deepEqual(harness.fetchCalls, []);
});

test("a successful static-asset response is cached for later offline loads", async () => {
  const harness = createHarness();
  harness.setFetch(async () => new Response("body{}", { status: 200 }));

  await fetchEvent(harness, { url: `${ORIGIN}/_next/static/css/app.css`, method: "GET", mode: "cors" });
  await flush();

  const cached = await harness.cache("jam-static-v4").match(`${ORIGIN}/_next/static/css/app.css`);
  assert.ok(cached, "static asset should be stored in the static cache");
});

test("page HTML is never cached, so a deployment cannot serve stale chunk references", async () => {
  const harness = createHarness();
  harness.setFetch(async () => new Response("<html>new build</html>", { status: 200 }));

  const response = await fetchEvent(harness, { url: `${ORIGIN}/play`, method: "GET", mode: "navigate" });
  assert.equal(response.status, 200);
  await flush();

  for (const [name, cache] of harness.caches) {
    assert.equal(
      await cache.match(`${ORIGIN}/play`),
      undefined,
      `${name} must not cache page HTML for /play`,
    );
  }
});

test("offline navigation falls back to the offline page", async () => {
  const harness = createHarness();
  await harness
    .cache("jam-shell-v4")
    .put(`${ORIGIN}/offline`, new Response("<html>offline</html>", { status: 200 }));
  harness.setFetch(async () => {
    throw new TypeError("Failed to fetch");
  });

  const response = await fetchEvent(harness, { url: `${ORIGIN}/play`, method: "GET", mode: "navigate" });
  assert.equal(response.status, 200);
  assert.equal(await response.text(), "<html>offline</html>");
});

test("public menu navigation is still cached and served offline (PWA behaviour preserved)", async () => {
  const harness = createHarness();
  harness.setFetch(async () => new Response("<html>menu</html>", { status: 200 }));

  await fetchEvent(harness, { url: `${ORIGIN}/m/demo-cafe`, method: "GET", mode: "navigate" });
  await flush();

  const cached = await harness.cache("jam-menus-v4").match(`${ORIGIN}/m/demo-cafe`);
  assert.ok(cached, "public menu page should be cached in jam-menus");

  harness.setFetch(async () => {
    throw new TypeError("Failed to fetch");
  });
  const offline = await fetchEvent(harness, { url: `${ORIGIN}/m/demo-cafe`, method: "GET", mode: "navigate" });
  assert.equal(await offline.text(), "<html>menu</html>");
});

test("activation deletes caches from older versions and claims clients", async () => {
  const harness = createHarness();
  await harness.cache("jam-static-v3").put(`${ORIGIN}/_next/static/chunks/old.js`, new Response("old"));
  await harness.cache("jam-shell-v2").put(`${ORIGIN}/offline`, new Response("old offline"));
  await harness.cache("unrelated-cache").put(`${ORIGIN}/x`, new Response("x"));

  await runEvent(harness, "activate");

  assert.deepEqual(harness.keys(), ["unrelated-cache"]);
  assert.equal(harness.claimedClients(), true);
});

test("installation precaches the offline page's own build assets", async () => {
  const harness = createHarness();
  harness.setFetch(async (url) => {
    if (url.endsWith("/offline")) {
      return new Response('<html><script src="/_next/static/chunks/app/offline/page-abc.js"></script></html>', {
        status: 200,
      });
    }
    if (url.endsWith("/page-abc.js")) return new Response("console.log(1)", { status: 200 });
    return new Response(`asset ${url}`, { status: 200 });
  });

  await runEvent(harness, "install");

  assert.ok(await harness.cache("jam-shell-v4").match(`${ORIGIN}/offline`));
  assert.ok(
    await harness.cache("jam-static-v4").match(`${ORIGIN}/_next/static/chunks/app/offline/page-abc.js`),
    "offline page chunks must be cached so the fallback renders offline",
  );
});

test("installation survives a missing shell asset and still takes over", async () => {
  const harness = createHarness();
  harness.setFetch(async (url) => {
    if (url.endsWith("/icon-512.png")) return new Response("missing", { status: 404 });
    return new Response(`asset ${url}`, { status: 200 });
  });

  await runEvent(harness, "install");

  assert.equal(harness.skippedWaiting(), true);
  const shell = harness.cache("jam-shell-v4");
  assert.ok(await shell.match(`${ORIGIN}/manifest.json`));
  assert.equal(await shell.match(`${ORIGIN}/icon-512.png`), undefined);
});
