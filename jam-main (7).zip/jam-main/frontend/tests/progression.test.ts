/**
 * Frontend unit tests for the pure JamPlay Phase 2 helpers.
 *
 * Run with `npm test` (Node's built-in test runner + native TypeScript type
 * stripping). No test framework dependency is added.
 */

import assert from "node:assert/strict";
import { test } from "node:test";

import {
  achievementPercent,
  canChallenge,
  levelPercent,
  levelUpText,
  missionActionLabel,
  missionPercent,
  missionState,
  rankLabel,
  relationLabel,
  rewardChips,
  rewardText,
} from "../app/play/progression.ts";

test("mission state follows claimed > ready > locked precedence", () => {
  assert.equal(missionState({ claimed: true, ready: true }), "claimed");
  assert.equal(missionState({ claimed: false, ready: true }), "ready");
  assert.equal(missionState({ claimed: false, ready: false }), "locked");
});

test("mission button labels are Persian and non-actionable while locked", () => {
  assert.equal(missionActionLabel({ claimed: false, ready: false }), "در مسیر");
  assert.equal(missionActionLabel({ claimed: false, ready: true }), "دریافت");
  assert.equal(missionActionLabel({ claimed: true, ready: false }), "دریافت شد");
});

test("mission percent clamps progress to a 0-100 bar", () => {
  assert.equal(missionPercent({ progress: 0, target: 3 }), 0);
  assert.equal(missionPercent({ progress: 2, target: 3 }), 67);
  assert.equal(missionPercent({ progress: 9, target: 3 }), 100);
  assert.equal(missionPercent({ progress: 1, target: 0 }), 0);
});

test("level percent clamps XP progress", () => {
  assert.equal(levelPercent({ xp_in_level: 60, xp_need: 120 }), 50);
  assert.equal(levelPercent({ xp_in_level: 500, xp_need: 120 }), 100);
  assert.equal(levelPercent({ xp_in_level: -5, xp_need: 120 }), 0);
  assert.equal(levelPercent({ xp_in_level: 10, xp_need: 0 }), 0);
});

test("reward chips mirror the mission reward bundle", () => {
  assert.deepEqual(rewardChips({ xp: 40, coins: 200 }), [
    { kind: "xp", label: "تجربه", value: 40 },
    { kind: "coins", label: "سکه", value: 200 },
  ]);
  assert.deepEqual(rewardChips({}), []);
  assert.equal(rewardText({ xp: 20, gems: 2 }), "۲۰ تجربه · ۲ الماس");
});

test("level up text reports the highest level and total gems", () => {
  assert.equal(levelUpText([]), "");
  assert.equal(levelUpText(undefined), "");
  assert.equal(
    levelUpText([
      { level: 2, gems: 8 },
      { level: 3, gems: 8 },
    ]),
    "به سطح ۳ رسیدی · ۱۶ الماس",
  );
});

test("achievement percent never divides by zero", () => {
  assert.equal(achievementPercent({ progress: 1, target: 3 }), 33);
  assert.equal(achievementPercent({ progress: 3, target: 3 }), 100);
  assert.equal(achievementPercent({ progress: 0, target: 0 }), 100);
});

test("friend relation labels and challenge eligibility", () => {
  assert.equal(relationLabel("accepted"), "دوست");
  assert.equal(relationLabel("outgoing"), "در انتظار پاسخ");
  assert.equal(relationLabel("incoming"), "درخواست دریافتی");
  assert.equal(relationLabel("none"), "افزودن دوست");
  assert.equal(canChallenge("accepted"), true);
  assert.equal(canChallenge("outgoing"), false);
});

test("rank label uses Persian digits", () => {
  assert.equal(rankLabel(1), "۱");
  assert.equal(rankLabel(24), "۲۴");
});
