"use client";

import { useEffect } from "react";
import { usePathname } from "next/navigation";

/* بدنهٔ صفحه مطابق مرجع: body[data-view] و body.bare (برای منوی عمومی) */
const VIEW_MAP: [RegExp, string][] = [
  [/^\/$/, "home"],
  [/^\/search/, "search"],
  [/^\/store\//, "store"],
  [/^\/cart/, "cart"],
  [/^\/checkout/, "checkout"],
  [/^\/order\//, "order"],
  [/^\/orders/, "orders"],
  [/^\/business/, "business"],
  [/^\/panel/, "panel"],
  [/^\/play/, "play"],
  [/^\/visit\//, "visit"],
  [/^\/club/, "club"],
  [/^\/revenue/, "revenue"],
];

export default function BodySync() {
  const pathname = usePathname() ?? "/";
  useEffect(() => {
    const bare = pathname.startsWith("/m/");
    const view = bare ? "m" : VIEW_MAP.find(([re]) => re.test(pathname))?.[1] || "home";
    document.body.setAttribute("data-view", view);
    document.body.classList.toggle("bare", bare);
  }, [pathname]);
  return null;
}
