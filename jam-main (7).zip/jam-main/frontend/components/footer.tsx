import Link from "next/link";

export default function Footer() {
  return (
    <footer className="ftr" id="ftr">
      <div className="container">
        <div className="ftr-grid">
          <div>
            <Link href="/" className="logo">
              <span className="logo-mark">
                <svg viewBox="0 0 24 24" aria-hidden="true" dangerouslySetInnerHTML={{ __html: '<path d="M6 8h12l-1.2 10.2A2 2 0 0 1 14.8 20H9.2a2 2 0 0 1-2-1.8z" fill="currentColor" stroke="none" opacity=".95"/><path d="M9 8V7a3 3 0 0 1 6 0v1" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="13.5" r="1.6" fill="#08805A" stroke="none"/>' }} />
              </span>
              <span>جم</span>
            </Link>
            <p className="muted" style={{ fontSize: 14, maxWidth: 340, margin: "12px 0 0", lineHeight: 1.9 }}>
              بازار آنلاین کسب‌وکارهای شهر جم؛ فروشگاه‌ها و محصولات را پیدا کنید، قیمت‌ها را ببینید و سفارش دهید — تحویل حضوری یا ارسال به محل.
            </p>
          </div>
          <div>
            <h4>مشتریان</h4>
            <ul>
              <li><Link href="/search">جست‌وجوی فروشگاه‌ها</Link></li>
              <li><Link href="/search?f=discount">تخفیف‌های محلی</Link></li>
              <li><Link href="/orders">پیگیری سفارش</Link></li>
            </ul>
          </div>
          <div>
            <h4>کسب‌وکارها</h4>
            <ul>
              <li><Link href="/business">منوی دیجیتال و QR</Link></li>
              <li><Link href="/business#plans">تعرفه اشتراک</Link></li>
              <li><Link href="/panel">ورود به پنل فروشنده</Link></li>
            </ul>
          </div>
          <div>
            <h4>ارتباط با ما</h4>
            <ul>
              <li>جم، استان بوشهر</li>
              <li className="tnum">پشتیبانی: ۰۷۷-۳۷۶۲۰۰۰۰</li>
              <li><Link href="/panel">مدیریت فروشگاه در سایت</Link></li>
            </ul>
          </div>
        </div>
        <div className="ftr-bottom">
          <span>© ۱۴۰۵ جم لایف — نسخه آزمایشی</span>
          <span>ساخته‌شده برای کسب‌وکارهای شهر جم</span>
        </div>
      </div>
    </footer>
  );
}
