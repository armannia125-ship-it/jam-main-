"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import Ic from "./icons";

const ITEMS = [
  { href: "/", label: "خانه", icon: "home", exact: true },
  { href: "/search", label: "جست‌وجو", icon: "search" },
  { href: "/orders", label: "سفارش‌ها", icon: "list" },
  { href: "/business", label: "کسب‌وکار", icon: "brief" },
  { href: "/play", label: "جم‌پلی", icon: "spark" },
];

export default function BottomNav() {
  const pathname = usePathname() ?? "/";
  return (
    <nav className="bnav" id="bnav" aria-label="ناوبری اصلی">
      <div className="bnav-in">
        {ITEMS.map((it) => {
          const active = it.exact ? pathname === "/" : pathname.startsWith(it.href);
          return (
            <Link key={it.href} href={it.href} className={active ? "on" : ""}>
              <Ic n={it.icon} c="lg" />
              <span>{it.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
