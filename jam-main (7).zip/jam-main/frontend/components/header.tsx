"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { FormEvent } from "react";
import { CATS } from "@/lib/data";
import { useJam } from "@/lib/state";
import { fa } from "@/lib/format";
import { useServerRole } from "@/lib/subscriptions-api";
import Ic from "./icons";

export default function Header() {
  const router = useRouter();
  const { cart, cartCount, cartTotal, addrs } = useJam();
  const cartHas = !!cart && cart.items.length > 0;
  const addr = addrs[0];
  /* نقش مدیر فقط از سرور (GET /auth/me/) خوانده می‌شود، نه از نشست
     ذخیره‌شدهٔ کلاینت؛ برای نشست‌های قدیمی هم درست کار می‌کند. */
  const role = useServerRole();
  const isAdmin = role === "admin";

  const submitSearch = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const q = new FormData(e.currentTarget).get("q");
    router.push(`/search${q ? `?q=${encodeURIComponent(String(q))}` : ""}`);
  };

  return (
    <header className="hdr" id="hdr">
      <div className="container hdr-in">
        <Link href="/" className="logo" aria-label="جم لایف، صفحهٔ اصلی">
          <span className="jam-wordmark life-logotype">جم <span>لایف</span></span>
          <span className="brand-descriptor">زندگی، نزدیک‌تر</span>
        </Link>
        <button type="button" className="addr-btn" aria-label="انتخاب آدرس">
          <Ic n="pin" />
          <span className="grow" style={{ textAlign: "start" }}>
            <span className="k">ارسال به</span>
            <span className="v ellipsis" style={{ display: "block" }}>
              {addr ? `${addr.title} · ${addr.text}` : "انتخاب آدرس"}
            </span>
          </span>
          <Ic n="chevD" c="sm faint" />
        </button>
        <div className="search" role="search">
          <Ic n="search" c="s-ic" />
          <form onSubmit={submitSearch} className="search-form">
            <input
              id="hs"
              type="search"
              autoComplete="off"
              placeholder="جست‌وجو در جم؛ غذا، فروشگاه یا محصول"
              aria-label="جست‌وجو"
              name="q"
              maxLength={200}
            />
          </form>
          <span className="kbd">/</span>
        </div>
        <div className="hdr-actions">
          <Link href="/orders" className="nav-link">
            <Ic n="list" />
            <span>سفارش‌ها</span>
          </Link>
          <Link href="/business" className="nav-link">
            <Ic n="brief" />
            <span>کسب‌وکارها</span>
          </Link>
          {isAdmin ? (
            <Link href="/admin" className="nav-link">
              <Ic n="shield" />
              <span>پنل مدیریت</span>
            </Link>
          ) : null}
          <Link href="/panel" className="icon-btn panel-ic" title="پنل فروشنده" aria-label="پنل فروشنده">
            <Ic n="dash" />
          </Link>
          <span className="cart-slot">
            <Link
              href="/cart"
              className={`cart-btn${cartHas ? "" : " is-empty"}`}
              aria-label={`سبد خرید، ${fa(cartCount)} کالا`}
            >
              <Ic n="bag" />
              <span className="lbl">
                {cartHas ? (
                  <>
                    {fa(cartTotal)} <small>تومان</small>
                  </>
                ) : (
                  "سبد خرید"
                )}
              </span>
              {cartHas ? <span className="cnt">{fa(cartCount)}</span> : null}
            </Link>
          </span>
        </div>
      </div>
      <div className="subnav">
        <div className="container subnav-in">
          <details className="category-menu">
            <summary>
              <Ic n="grid" c="sm" /> دسته‌بندی‌ها <Ic n="chevD" c="sm" />
            </summary>
            <div className="mega-menu">
              <div className="mega-title">
                <b>چه چیزی نیاز دارید؟</b>
                <Link href="/search">
                  همه کسب‌وکارها <Ic n="arrowL" c="sm" />
                </Link>
              </div>
              <div className="mega-cats">
                {CATS.map((c) => (
                  <Link key={c.id} href={`/search?cat=${c.id}`}>
                    <Ic n={c.icon} c="lg" />
                    <span>
                      <b>{c.name}</b>
                      <small>{c.sub}</small>
                    </span>
                    <Ic n="chevL" c="sm" />
                  </Link>
                ))}
              </div>
            </div>
          </details>
          <Link href="/search?cat=restaurant">رستوران و کافه</Link>
          <Link href="/search?cat=market">سوپرمارکت</Link>
          <Link href="/search?cat=hyper" className="life-hyper-link" title="هایپرمارکت و فروشگاه‌های زنجیره‌ای">
            هایپرمارکت
          </Link>
          <Link href="/search?cat=pastry">شیرینی و خوراکی</Link>
          <Link href="/search?cat=services">خدمات</Link>
          <Link href="/subscriptions">اشتراک‌ها</Link>
          <Link href="/play" className="jg-market-link">
            <Ic n="spark" c="sm" /> جم‌پلی
          </Link>
          <Link href="/search?f=discount" className="nav-deals">
            <Ic n="tag" c="sm" /> پیشنهادهای امروز
          </Link>
          <Link href="/panel" className="subnav-seller">
            ورود فروشندگان <Ic n="arrowL" c="sm" />
          </Link>
          <Link href="/club" data-c7-club>
            باشگاه حضوری
          </Link>
        </div>
      </div>
      <div className="container m-search">
        <div className="search" role="search">
          <Ic n="search" c="s-ic" />
          <form onSubmit={submitSearch} className="search-form">
            <input
              id="ms"
              type="search"
              autoComplete="off"
              placeholder="جست‌وجو در جم؛ غذا، فروشگاه یا محصول"
              aria-label="جست‌وجو"
              name="q"
              maxLength={200}
            />
          </form>
        </div>
      </div>
      <div style={{ height: 12 }} className="m-search" />
    </header>
  );
}
