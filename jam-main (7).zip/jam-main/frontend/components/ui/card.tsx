import * as React from "react"
import { cx } from "class-variance-authority"

interface CardProps {
  className?: string
  children: React.ReactNode
  header?: React.ReactNode
  title?: string
  subtitle?: string
}

export function Card({
  className,
  children,
  header,
  title,
  subtitle,
}: CardProps) {
  return (
    <div
      className={cx(
        "bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden",
        className
      )}
    >
      {header || title ? (
        <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
          {header || (
            <div className="flex items-center gap-2">
              {title && <h3 className="font-medium text-lg">{title}</h3>}
              {subtitle && <p className="text-sm text-gray-600 dark:text-gray-300">{subtitle}</p>}
            </div>
          )}
        </div>
      ) : null}
      <div className="px-6 py-4">{children}</div>
    </div>
  )
}