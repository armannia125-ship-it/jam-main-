import * as React from "react"
import { cx } from "class-variance-authority"

interface InputProps extends React.HTMLAttributes<HTMLInputElement | HTMLTextAreaElement> {
  className?: string
  placeholder?: string
  error?: string
  disabled?: boolean
  textarea?: boolean
}

export function Input({
  className,
  placeholder,
  error,
  disabled,
  textarea = false,
  ...props
}: InputProps) {
  const Comp = textarea ? "textarea" : "input"

  return (
    <Comp
      type={textarea ? "text" : undefined}
      className={cx(
        "w-full rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-900 text-sm dark:text-gray-100 focus outline-none focus:ring-2 focus:ring-primary-400 focus:border-primary-400 disabled:opacity-50",
        "placeholder:placeholder:text-gray-400",
        textarea ? "resize-none min-h-[84px]" : "",
        className
      )}
      placeholder={placeholder}
      disabled={disabled}
      {...props}
    />
  )
}

export function InputLtr({
  className,
  placeholder,
  error,
  disabled,
  ...props
}: InputProps & { direction?: "ltr" }) {
  return (
    <Input
      className={cx("direction-ltr text-right", className)}
      placeholder={placeholder}
      error={error}
      disabled={disabled}
      {...props}
    />
  )
}

export function Textarea({
  className,
  placeholder,
  error,
  disabled,
  ...props
}: Omit<InputProps, "textarea"> & { placeholder?: string }) {
  return <Input textarea={true} className={className} placeholder={placeholder} error={error} disabled={disabled} {...props} />
}

export function Select({
  className,
  placeholder = "انتخاب کنید",
  error,
  disabled,
  children,
  ...props
}: React.SelectHTMLAttributes<HTMLSelectElement> & { placeholder?: string; error?: string; disabled?: boolean }) {
  return (
    <select
      className={cx(
        "w-full rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-900 text-sm dark:text-gray-100 focus outline-none focus:ring-2 focus:ring-primary-400 focus:border-primary-400 disabled:opacity-50",
        className
      )}
      disabled={disabled}
      {...props}
    >
      <option value="" disabled>{placeholder}</option>
      {children}
    </select>
  )
}

export function Chip({
  className,
  selected = false,
  onSelect,
  children,
  ...props
}: {
  className?: string
  selected?: boolean
  onSelect?: () => void
  children: React.ReactNode
}) {
  return (
    <div
      className={cx(
        "inline-flex items-center gap-2 rounded-md text-sm font-medium transition-colors",
        selected
          ? "bg-primary text-primary-foreground"
          : "bg-background text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-gray-300",
        className
      )}
      onClick={onSelect}
      {...props}
    >
      {children}
    </div>
  )
}

export function Pill({
  className,
  selected = false,
  children,
  ...props
}: {
  className?: string
  selected?: boolean
  children: React.ReactNode
}) {
  return (
    <div
      className={cx(
        "inline-flex items-center gap-2 rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors",
        selected
          ? "bg-primary text-primary-foreground"
          : "bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300",
        className
      )}
      {...props}
    >
      {children}
    </div>
  )
}

export function Seg({
  className,
  children,
  ...props
}: {
  className?: string
  children: React.ReactNode
}) {
  return (
    <div
      className={cx(
        "inline-flex items-center gap-2 rounded-md bg-gray-100 dark:bg-gray-800 px-2 py-0.5 text-xs",
        className
      )}
      {...props}
    >
      {children}
    </div>
  )
}