"use client";

/* پیگیری سفارش — وضعیت، خط زمان و جزئیات (نسخهٔ نمایشی؛ بدون بک‌اند) */

import { Suspense } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Ic } from "@/components/icons";
import { useJam, type Order } from "@/lib/state";
import { ACTIVE_STATUS, FLOW, STATUS, brandMonogram, productById, productPhoto, store as findStore } from "@/lib/data";
import { fa, faD, fmtDate, fmtTime, tomanT } from "@/lib/format";

const TL_LABELS: Record<string, (mode: Order["mode"]) => string> = {
  placed: () => "ثبت سفارش",
  accepted: () => "تأیید فروشگاه",
  preparing: () => "آماده‌سازی",
  ready: () => "آماده تحویل",
  sent: () => "ارسال",
  done: (mode) => (mode === "pickup" ? "تحویل گرفته شد" : "تحویل"),
};

const TL_ICONS: Record<string, string> = {
  placed: "receipt",
  accepted: "check",
  preparing: "chef",
  ready: "pkg",
  sent: "truck",
  done: "home",
};

function statusMessage(o: Order): string {
  switch (o.status) {
    case "placed": return "سفارش شما برای فروشگاه ارسال شد. معمولاً ظرف چند دقیقه تأیید می‌شود.";
    case "accepted": return "فروشگاه سفارش شما را پذیرفت و به‌زودی آماده‌سازی شروع می‌شود.";
    case "preparing": return "سفارش در حال آماده‌سازی است و پس از آن به پیک تحویل داده می‌شود.";
    case "ready": return "سفارش آماده است! به فروشگاه مراجعه کنید و کد تحویل را اعلام کنید.";
    case "sent": return "سفارش توسط پیک در راه است.";
    case "done": return "سفارش با موفقیت تحویل شد. نوش جان!";
    case "rejected": return "فروشگاه امکان انجام این سفارش را نداشت.";
    case "refunded": return "این سفارش مرجوع شده است؛ برگشت سهم‌ها فقط در شبیه‌ساز ثبت می‌شود.";
    case "canceled": return "این سفارش لغو شد." + (o.pay === "online" ? " برگشت فقط آزمایشی است و واریز واقعی انجام نمی‌شود." : "");
    default: return "";
  }
}

/** کد تحویل ۴ رقمی پایدار — مشتق از شناسهٔ سفارش */
function pickupCodeOf(id: string): string {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return String(1000 + (h % 9000));
}

function OrderTrackingInner({ orderId }: { orderId: string }) {
  const { orders, cancelOrder, addToCart, toast } = useJam();
  const sp = useSearchParams();
  const isNew = sp.get("new") === "1";
  const o = orders.find((x) => x.id === orderId);

  const reorder = (order: Order) => {
    order.items.forEach((i) => addToCart(order.sid, i.pid, i.qty));
    toast("به سبد اضافه شد", "ok", { label: "مشاهده سبد", href: "/cart" });
  };

  /* سفارش پیدا نشد — وضعیت صادقانه */
  if (!o) {
    return (
      <div className="container">
        <div className="card" style={{ marginTop: 32 }}>
          <div className="empty">
            <div className="e-ic"><Ic n="alert" /></div>
            <b>سفارش پیدا نشد</b>
            <div style={{ fontSize: 14 }}>ممکن است آدرس اشتباه باشد یا این مورد حذف شده باشد.</div>
            <div style={{ marginTop: 16 }}>
              <Link href="/" className="btn btn-primary">بازگشت به خانه</Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const s = findStore(o.sid);
  const st = STATUS[o.status];
  const flow = FLOW[o.mode];
  const idx = flow.indexOf(o.status);
  const failed = ["rejected", "canceled", "refunded"].includes(o.status);
  const active = ACTIVE_STATUS.includes(o.status);
  const code = pickupCodeOf(o.id);
  const count = o.items.reduce((a, i) => a + i.qty, 0);
  const payLabel = o.pay === "online" ? "آنلاین" : o.mode === "pickup" ? "در فروشگاه" : "هنگام تحویل";

  return (
    <div className="container" style={{ maxWidth: 960 }}>
      <div className="crumbs">
        <Link href="/" className="ui-tap-link">خانه</Link>
        <Ic n="chevL" c="sm" />
        <Link href="/orders" className="ui-tap-link">سفارش‌ها</Link>
        <Ic n="chevL" c="sm" />
        <span className="tnum">{o.id}</span>
      </div>

      {isNew && (
        <div className="notice green" style={{ marginTop: 16 }}>
          <Ic n="check" />
          <span><b>سفارش شما با موفقیت ثبت شد.</b> کد پیگیری: <b className="tnum">{o.id}</b></span>
        </div>
      )}

      <div className="card" style={{ marginTop: 16, overflow: "hidden" }}>
        <div className="track-hero">
          <div>
            <span className={`pill ${st?.c ?? "gray"}`}><span className="dot" />{st?.short ?? o.status}</span>
            <h1 style={{ marginTop: 10 }}>{st?.t ?? "وضعیت نامشخص"}</h1>
            <p className="muted" style={{ margin: "6px 0 0", maxWidth: 560, lineHeight: 1.85 }}>{statusMessage(o)}</p>
          </div>
          <div className={`big-status tone tone-${s?.tone ?? "restaurant"}`} style={{ fontSize: 36 }}>
            <span className={`brand-monogram bm-${o.sid}`}>{s ? brandMonogram(s) : "جم"}</span>
          </div>
        </div>
        {!failed && (
          <div className="ux-tracking-next">
            <Ic n="info" c="sm" />
            <span>قدم بعدی: وضعیت آماده‌سازی را همین‌جا پیگیری کنید. نیازی به ثبت دوبارهٔ سفارش نیست.</span>
          </div>
        )}
        {!failed && (
          <div className="timeline" role="list">
            {flow.map((k, i) => {
              const h = o.history.find((x) => x.st === k);
              return (
                <div key={k} className={`tl ${i <= idx ? "done" : ""} ${i === idx && o.status !== "done" ? "cur" : ""}`} role="listitem">
                  <span className="b"><Ic n={i < idx || o.status === "done" ? "check" : TL_ICONS[k] || "clock"} /></span>
                  {TL_LABELS[k]?.(o.mode) ?? k}
                  {h && <div className="faint tnum" style={{ fontWeight: 500, fontSize: 14 }}>{fmtTime(h.at)}</div>}
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="co-layout" style={{ gridTemplateColumns: "1fr 340px" }}>
        <div>
          {/* کد تحویل حضوری */}
          {o.mode === "pickup" && ["ready", "preparing", "accepted"].includes(o.status) && s && (
            <div className="card pad" style={{ marginBottom: 16, textAlign: "center" }}>
              <b>کد تحویل سفارش</b>
              <p className="muted" style={{ margin: "4px 0 0", fontSize: 14 }}>این کد را هنگام تحویل به فروشنده اعلام کنید</p>
              <div className="pickup-code">
                {code.split("").map((d, i) => <span key={i}>{faD(d)}</span>)}
              </div>
              <a
                className="btn btn-soft btn-sm"
                target="_blank"
                rel="noopener"
                href={`https://www.google.com/maps/search/${encodeURIComponent(s.address)}`}
              >
                <Ic n="nav" c="sm" />مسیریابی تا فروشگاه
              </a>
            </div>
          )}

          {/* اقلام سفارش */}
          <div className="card">
            <div className="cart-head">
              <h3>اقلام سفارش</h3>
              <span className="faint tnum" style={{ fontSize: 14 }}>{fa(count)} کالا</span>
            </div>
            <div style={{ padding: "4px 18px" }}>
              {o.items.map((i) => {
                const p = productById(i.pid)?.product;
                const photo = p ? productPhoto(p) : null;
                return (
                  <div className="c-row" key={i.pid}>
                    <span className={`th tone tone-${s?.tone ?? "restaurant"}`} aria-hidden="true">
                      {photo ? <img className="media-photo" src={photo} alt="" loading="lazy" /> : i.em}
                    </span>
                    <div className="grow">
                      <div className="nm">{i.name}</div>
                      <div className="pr tnum">{fa(i.qty)} × {tomanT(i.price)}</div>
                    </div>
                    <b className="tnum" style={{ fontSize: 14 }}>{tomanT(i.price * i.qty)}</b>
                  </div>
                );
              })}
            </div>
            <div className="cart-sum">
              <div className="sum-row"><span>جمع اقلام</span><span className="tnum">{tomanT(o.totals.items)}</span></div>
              {o.totals.discount > 0 && (
                <div className="sum-row green">
                  <span>{o.code ? `کد تخفیف (${o.code})` : "تخفیف محصولات"}</span>
                  <span className="tnum">−{tomanT(o.totals.discount)}</span>
                </div>
              )}
              <div className="sum-row">
                <span>هزینه ارسال</span>
                <span className="tnum">{o.totals.delivery ? tomanT(o.totals.delivery) : "رایگان"}</span>
              </div>
              <div className="sum-row total">
                <span>{o.pay === "online" ? "پرداخت شده" : "قابل پرداخت هنگام تحویل"}</span>
                <span className="tnum">{tomanT(o.totals.total)}</span>
              </div>
            </div>
          </div>
        </div>

        <aside>
          <div className="card pad">
            <dl className="kv" style={{ margin: 0 }}>
              <dt>فروشگاه</dt>
              <dd><Link className="link" href={`/store/${o.sid}`}>{s?.name ?? o.sid}</Link></dd>
              <dt>کد پیگیری</dt><dd className="tnum">{o.id}</dd>
              <dt>زمان ثبت</dt><dd className="tnum">{fmtTime(o.placedAt)} · {fmtDate(o.placedAt)}</dd>
              <dt>روش دریافت</dt><dd>{o.mode === "pickup" ? "تحویل حضوری" : "ارسال به محل"}</dd>
              <dt>زمان</dt><dd>{o.when}</dd>
              <dt>{o.mode === "pickup" ? "آدرس فروشگاه" : "آدرس تحویل"}</dt>
              <dd style={{ fontWeight: 500, lineHeight: 1.7 }}>{o.addrText}</dd>
              <dt>پرداخت</dt><dd>{payLabel}</dd>
              {o.note && <><dt>توضیحات</dt><dd style={{ fontWeight: 500 }}>{o.note}</dd></>}
            </dl>
            <div style={{ display: "flex", flexDirection: "column", gap: 8, marginTop: 18 }}>
              {s && (
                <a href={`tel:${s.phone}`} className="btn btn-ghost btn-block">
                  <Ic n="phone" c="sm" />تماس با فروشگاه
                </a>
              )}
              {active && (
                <button
                  className="btn btn-danger btn-block"
                  onClick={() => {
                    if (window.confirm("این سفارش لغو شود؟ این کار در نسخهٔ نمایشی برگشت پول ندارد.")) cancelOrder(o.id);
                  }}
                >
                  لغو سفارش
                </button>
              )}
              {["done", "rejected", "canceled", "refunded"].includes(o.status) && (
                <button className="btn btn-soft btn-block" onClick={() => reorder(o)}>
                  <Ic n="refresh" c="sm" />سفارش مجدد
                </button>
              )}
            </div>
          </div>
          {active && (
            <div className="notice blue" style={{ marginTop: 12 }}>
              <Ic n="info" />
              <span>نسخه نمایشی: وضعیت را می‌توانید از <Link className="link" href="/panel/orders">پنل فروشنده</Link> تغییر دهید؛ این صفحه خودکار به‌روز می‌شود.</span>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}

export function OrderTrackingPage({ orderId }: { orderId: string }) {
  return (
    <Suspense fallback={<div className="container" style={{ minHeight: "40vh" }} />}>
      <OrderTrackingInner orderId={orderId} />
    </Suspense>
  );
}
