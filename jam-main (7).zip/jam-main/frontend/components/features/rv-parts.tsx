"use client";

import React from "react";

/* قطعات مشترک صفحات rv (مرکز درآمد / باشگاه) — کلاس‌های مرجع */

export function RvHeading({ over, title, text }: { over: string; title: string; text: string }) {
  return (
    <header className="rv-heading">
      <span>{over}</span>
      <h1>{title}</h1>
      <p>{text}</p>
    </header>
  );
}

export function RvNote({ children }: { children?: React.ReactNode }) {
  return (
    <div className="rv-note">
      {children || "نسخهٔ نمایشی و محلی؛ بدون پرداخت، قرارداد، تأیید هویت یا تسویهٔ واقعی. همهٔ تعرفه‌ها پیشنهادی و قابل‌تغییرند."}
    </div>
  );
}

export function RvField({ id, label, value, onChange, type = "number", extra, children }: {
  id: string;
  label: string;
  value?: string | number;
  onChange?: (v: string) => void;
  type?: string;
  extra?: React.InputHTMLAttributes<HTMLInputElement>;
  children?: React.ReactNode;
}) {
  return (
    <label className="rv-field" htmlFor={id}>
      <span>{label}</span>
      {children || (
        <input id={id} name={id} type={type} value={value} onChange={(e) => onChange?.(e.target.value)} required {...extra} />
      )}
    </label>
  );
}

export function C7Error({ msg }: { msg: string }) {
  return (
    <p className="c7-error" role="alert">
      {msg}
    </p>
  );
}
