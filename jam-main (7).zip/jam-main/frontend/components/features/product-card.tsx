"use client";

import Link from "next/link";
import { Product, Store, discPct, productPhoto } from "@/lib/data";
import { fa } from "@/lib/format";
import Ic from "@/components/icons";
import { QtyCtl } from "./store-card";

/* کارت محصول — مطابق prodCard در مرجع */
export default function ProductCard({ p, s }: { p: Product; s: Store }) {
  const d = discPct(p);
  const photo = productPhoto(p, s.id);
  return (
    <div className="p-card">
      <button type="button" className={`p-thumb tone tone-${s.tone}`} aria-label={`جزئیات ${p.name}`}>
        {photo ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img className="media-photo" src={photo} alt="" loading="lazy" />
        ) : (
          <span className="product-symbol">
            <Ic n={s.id === "s4" ? "cart" : "pkg"} />
          </span>
        )}
        {d ? <span className="disc-badge">{fa(d)}٪</span> : ""}
      </button>
      <div>
        <div className="p-name ellipsis">{p.name}</div>
        <Link href={`/store/${s.id}`} className="p-store ellipsis">
          <Ic n="store" c="sm" />
          {s.name}
        </Link>
      </div>
      <div className="p-foot">
        <div className="price">
          {d ? <s className="tnum">{fa(p.old)}</s> : ""}
          <b className="tnum">
            {fa(p.price)} <small>تومان</small>
          </b>
        </div>
        <QtyCtl product={p} s={s} />
      </div>
    </div>
  );
}
