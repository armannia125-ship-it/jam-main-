import Link from "next/link";
import StoreCard from "@/components/features/store-card";
import Ic from "@/components/icons";
import { apiStoreToStore, fetchPublicStores } from "@/lib/public-menu";

/* Production catalog screens. They never fall back to demo stores: a failed
   backend request is shown as an error, and an empty list as an empty state. */

export async function RealHomePage() {
  const rows = await fetchPublicStores();

  return (
    <div className="container home-v4 ux-home life-home">
      <section className="ux-welcome">
        <div>
          <span className="ux-overline">زندگی در جم، کمی ساده‌تر</span>
          <h1>فروشگاه‌های جم لایف</h1>
          <p>منوی دیجیتال کسب‌وکارهای فعال؛ قیمت‌ها و موجودی از سرور خوانده می‌شود.</p>
        </div>
        <Link href="/search" className="ux-live-link">
          <span className="dot" /> جست‌وجو <Ic n="chevL" c="sm" />
        </Link>
      </section>

      <section className="section">
        <div className="section-intro">
          <div>
            <span className="overline">کاتالوگ فعال</span>
            <h2>همین حالا سفارش بده</h2>
          </div>
          <Link href="/search" className="text-action">
            همه <Ic n="arrowL" c="sm" />
          </Link>
        </div>

        {rows === null ? (
          <div className="card">
            <div className="empty">
              <div className="e-ic"><Ic n="alert" /></div>
              <b>دریافت فهرست فروشگاه‌ها ناموفق بود</b>
              <div style={{ fontSize: 14 }}>داده‌های نمایشی جایگزین نمی‌شوند. لطفاً بعداً دوباره تلاش کنید.</div>
            </div>
          </div>
        ) : rows.length === 0 ? (
          <div className="card">
            <div className="empty">
              <div className="e-ic"><Ic n="store" /></div>
              <b>فروشگاه فعالی برای نمایش نیست</b>
              <div style={{ fontSize: 14 }}>پس از انتشار منو توسط کسب‌وکارها، اینجا نمایش داده می‌شود.</div>
            </div>
          </div>
        ) : (
          <div className="grid-stores home-store-grid">
            {rows.map((row) => (
              <StoreCard key={row.menu_slug} s={apiStoreToStore(row)} />
            ))}
          </div>
        )}
      </section>

      <section className="c7-home-club">
        <div>
          <span>خرید حضوری، بدون پیچیدگی</span>
          <h2>از اعضای باشگاه خرید کن.</h2>
          <p>کد خرید را نشان بده؛ فروشنده تأیید می‌کند و مسیر پاداش خرید باز می‌شود.</p>
        </div>
        <Link href="/club" className="btn btn-ghost">فروشگاه‌های عضو باشگاه</Link>
      </section>
    </div>
  );
}
