"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { useRouter } from "next/navigation";
import { CATS } from "@/lib/data";
import { STORES } from "@/lib/data";

interface SearchInputProps {
  className?: string;
  defaultValue?: string;
  onResultClick?: (value: string) => void;
}

export function SearchInput({ className, defaultValue = "", onResultClick }: SearchInputProps) {
  const router = useRouter();
  const [q, setQ] = useState(defaultValue);
  const [open, setOpen] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLUListElement>(null);

  const handleChange = useCallback((value: string) => {
    setQ(value);
    setOpen(value.length > 0);
  }, []);

  const handleSelect = useCallback((value: string) => {
    setQ(value);
    setOpen(false);
    if (onResultClick) onResultClick(value);
    else router.push(`/search?q=${encodeURIComponent(value)}`);
  }, [router, onResultClick]);

  // Focus trap: open on focus, close on blur
  useEffect(() => {
    const el = inputRef.current;
    if (!el) return;
    const onFocus = () => setOpen(q.length > 0);
    const onBlur = (e: FocusEvent) => {
      if (!(e.relatedTarget instanceof HTMLElement) || !listRef.current?.contains(e.relatedTarget)) {
        setOpen(false);
      }
    };
    el.addEventListener("focus", onFocus);
    el.addEventListener("blur", onBlur);
    return () => {
      el.removeEventListener("focus", onFocus);
      el.removeEventListener("blur", onBlur);
    };
  }, [q]);

  const suggestions = q.trim().length > 0 ? [
    ...CATS
      .filter(c => c.name.includes(q) || c.sub.includes(q))
      .slice(0, 4)
      .map(c => ({ label: c.name, sub: c.sub, href: `/search?cat=${c.id}`, kind: "cat" })),
    ...STORES
      .filter(s => s.name.includes(q) || s.tagline.includes(q))
      .slice(0, 4)
      .map(s => ({ label: s.name, sub: s.tagline, href: `/store/${s.id}`, kind: "store" })),
  ].filter(Boolean) : [];

  const catSuggestions = suggestions.filter(s => s.kind === "cat");
  const storeSuggestions = suggestions.filter(s => s.kind === "store");

  return (
    <div className={`search-input ${className || ""}`}>
      <div className="search-input-wrap">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" className="ic" aria-hidden="true">
          <circle cx="11" cy="11" r="8" />
          <path d="M21 21l-4.3-4.3" />
        </svg>
        <input
          ref={inputRef}
          type="search"
          className="search-input-field"
          value={q}
          onChange={e => handleChange(e.target.value)}
          placeholder="جستجو در جم..."
          aria-label="جستجو"
          aria-expanded={open}
          aria-controls="search-suggestions"
          aria-autocomplete="list"
          role="combobox"
        />
        {q && (
          <button
            className="search-input-clear"
            onClick={() => handleChange("")}
            aria-label="پاک کردن جستجو"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" className="ic" aria-hidden="true"><path d="M18 6L6 18M6 6l12 12" /></svg>
          </button>
        )}
        <button
          className="search-input-go"
          onClick={() => {
            if (q.trim()) {
              handleSelect(q);
            }
          }}
          aria-label="جستجو"
        >
          جستجو
        </button>
      </div>

      {open && suggestions.length > 0 && (
        <ul
          ref={listRef}
          id="search-suggestions"
          className="search-suggestions"
          role="listbox"
        >
          {catSuggestions.length > 0 && (
            <li className="suggestions-group-label">دسته‌بندی</li>
          )}
          {catSuggestions.map(s => (
            <li key={s.href} role="option" aria-selected={q === s.label}>
              <a
                href={s.href}
                className="suggestion-item cat"
                onClick={e => { e.preventDefault(); handleSelect(s.label); }}
              >
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" className="ic" aria-hidden="true"><rect x="3" y="3" width="7" height="7" /><rect x="14" y="3" width="7" height="7" /><rect x="3" y="14" width="7" height="7" /><rect x="14" y="14" width="7" height="7" /></svg>
                <span className="suggestion-label">{s.label}</span>
                <span className="suggestion-sub">{s.sub}</span>
              </a>
            </li>
          ))}
          {storeSuggestions.length > 0 && (
            <li className="suggestions-group-label">فروشگاه</li>
          )}
          {storeSuggestions.map(s => (
            <li key={s.href} role="option" aria-selected={q === s.label}>
              <a
                href={s.href}
                className="suggestion-item store"
                onClick={e => { e.preventDefault(); handleSelect(s.label); }}
              >
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" className="ic" aria-hidden="true"><path d="M3 21l1-1h4l3-3M8 14v-2l4-4 4 4v2M12 21v-7l4-4" /></svg>
                <span className="suggestion-label">{s.label}</span>
                <span className="suggestion-sub">{s.sub}</span>
              </a>
            </li>
          ))}
          <li className="suggestion-footer">
            <a
              href={`/search?q=${encodeURIComponent(q)}`}
              className="suggestion-footer-link"
              onClick={e => e.preventDefault()}
            >
              مشاهده همه نتایج برای «{q}»
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" className="ic sm" aria-hidden="true"><path d="m9 18 6-6-6-6" /></svg>
            </a>
          </li>
        </ul>
      )}

      {open && suggestions.length === 0 && q.trim().length > 0 && (
        <ul
          ref={listRef}
          id="search-suggestions"
          className="search-suggestions"
          role="listbox"
        >
          <li className="suggestions-empty">
            <span>نتیجه‌ای پیدا نشد</span>
            <span className="muted">عبارت دیگری را امتحان کنید.</span>
          </li>
        </ul>
      )}
    </div>
  );
}
