"use client";

interface CartItemProps {
  name: string;
  price: string;
  qty: number;
  onRemove?: () => void;
}

export function CartItem({ name, price, qty, onRemove }: CartItemProps) {
  return (
    <div className="c-row">
      <div className="c-img">
        <span className="em">🍽️</span>
      </div>
      <div className="c-info">
        <span className="c-name">{name}</span>
        <span className="muted">{qty} عدد</span>
      </div>
      <div className="c-price">
        <b className="tnum">{price}</b>
        <small>تومان</small>
      </div>
      <div className="stepper light">
        <button className="qty-btn" aria-label="کاهش تعداد">−</button>
        <b className="qty">{qty}</b>
        <button className="qty-btn" aria-label="افزایش تعداد">+</button>
      </div>
      {onRemove && (
        <button
          className="icon-btn"
          aria-label="حذف از سبد"
          onClick={onRemove}
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" className="ic" aria-hidden="true"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" /></svg>
        </button>
      )}
    </div>
  );
}
