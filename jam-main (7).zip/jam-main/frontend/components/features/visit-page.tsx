"use client";

/* =========================================================
   جم لایف — صفحهٔ خرید حضوری مشتری (/visit/[storeId])
   ثبت بازدید، صدور کد و تاریخچهٔ خرید همه از API سرور انجام
   می‌شود. کد یک‌بارمصرف فقط در پاسخ صدور برمی‌گردد و اعتبار
   آن را سرور تعیین می‌کند؛ شمارش معکوس فقط اطلاعاتی است.
   ========================================================= */

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { fmtDate } from "@/lib/format";
import { useJam } from "@/lib/state";
import { useAuth } from "@/lib/auth";
import { ApiError, apiFetch } from "@/lib/api";
import { useCustomerPurchases, usePublicClubStores } from "@/lib/commerce";
import { RvHeading, RvNote } from "@/components/features/rv-parts";
import Ic from "@/components/icons";

type IssuedCode = { code: string; expires_at: string };

export default function VisitClient({ storeId }: { storeId: string }) {
  const businessId = Number(storeId);
  const validId = Number.isInteger(businessId) && businessId > 0;
  const { toast } = useJam();
  const { ready: authReady, isAuthenticated } = useAuth();
  const stores = usePublicClubStores();
  const purchases = useCustomerPurchases();
  const [code, setCode] = useState<IssuedCode | null>(null);
  const [now, setNow] = useState(Date.now());
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const store = useMemo(() => stores.data.find((s) => s.id === businessId), [stores.data, businessId]);

  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  const recordVisit = useCallback(async () => {
    if (!validId || !isAuthenticated) return;
    try {
      await apiFetch(`/commerce/club/businesses/${businessId}/visit/`, { method: "POST", body: {} });
    } catch {
      /* بازدید نباید صفحه را بشکند */
    }
  }, [businessId, validId, isAuthenticated]);

  useEffect(() => {
    if (authReady) recordVisit();
  }, [authReady, recordVisit]);

  const mine = useMemo(
    () => purchases.purchases.filter((p) => p.business_id === businessId),
    [purchases.purchases, businessId],
  );
  const confirmedToday = mine.some(
    (p) => p.status === "confirmed" && new Date(p.confirmed_at).toDateString() === new Date().toDateString(),
  );

  const issue = async () => {
    setErr("");
    setBusy(true);
    try {
      const res = await apiFetch<{ code: string; expires_at: string }>(
        `/commerce/club/businesses/${businessId}/codes/`,
        { method: "POST", body: {} },
      );
      setCode({ code: res.code, expires_at: res.expires_at });
      toast("کد صادر شد؛ فقط تا پنج دقیقه معتبر است.");
    } catch (x) {
      setErr(x instanceof ApiError ? x.message : "صدور کد ناموفق بود.");
    } finally {
      setBusy(false);
    }
  };

  const copyCode = async (value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      toast("کد کپی شد.");
    } catch {
      toast("کد را از روی صفحه وارد کن.", "err");
    }
  };

  if (!validId) {
    return (
      <div className="container rv">
        <section className="rv-card">
          <h1>این فروشگاه در باشگاه ثبت نشده است</h1>
          <p>شناسهٔ فروشگاه باید از فهرست باشگاه انتخاب شود.</p>
          <Link className="btn btn-primary" href="/club">رفتن به باشگاه</Link>
        </section>
      </div>
    );
  }

  return (
    <div className="container rv c7-customer">
      <nav className="crumbs" aria-label="مسیر">
        <Link href="/">بازار جم</Link>
        <Ic n="chevL" c="sm" />
        <Link href="/club">باشگاه حضوری</Link>
        <Ic n="chevL" c="sm" />
        <span>{store?.name || "فروشگاه"}</span>
      </nav>
      <RvHeading
        over="خرید حضوری در باشگاه"
        title={store?.name || "فروشگاه باشگاه"}
        text="پول را نقدی یا با کارت‌خوان به خود فروشگاه پرداخت کن؛ برای پاداش، خرید باید توسط فروشنده تأیید شود."
      />
      <RvNote>
        کد با منبع تصادفی رمزنگاری‌شده ساخته می‌شود، فقط هش آن ذخیره می‌شود و وابسته به همین فروشگاه است. کد منقضی یا کد فروشگاه دیگر پذیرفته نمی‌شود.
      </RvNote>

      {stores.loading ? <p className="rv-empty">در حال دریافت اطلاعات فروشگاه…</p> : null}
      {!stores.loading && !store ? (
        <section className="rv-card">
          <h2>فروشگاه عضو فعال باشگاه نیست</h2>
          <p>یا فروشگاه حذف/غیرفعال شده است یا عضویت آن فعال نیست.</p>
          <Link className="btn btn-ghost" href="/club">بازگشت به فهرست باشگاه</Link>
        </section>
      ) : null}

      {store ? (
        <section className="rv-card">
          <span className="c7-tag">{store.offer || "عضو باشگاه"}</span>
          <h2>کد یک‌بارمصرف خرید</h2>
          <p>بعد از پرداخت، کد را به فروشنده نشان بده. اسکن شدنِ صفحه به‌تنهایی خرید محسوب نمی‌شود.</p>

          {!authReady ? <p className="rv-empty">در حال بررسی نشست…</p> : null}
          {authReady && !isAuthenticated ? (
            <>
              <p className="c7-small">برای دریافت کد و ثبت خرید، با شمارهٔ موبایل وارد شوید.</p>
              <Link className="btn btn-primary" href="/login">ورود / ثبت‌نام</Link>
            </>
          ) : null}

          {isAuthenticated ? (
            <>
              {code && new Date(code.expires_at).getTime() > now ? (
                <>
                  <code className="c7-code" dir="ltr">{code.code}</code>
                  <p className="c7-small">
                    اعتبار تا {new Date(code.expires_at).toLocaleTimeString("fa-IR")} (
                    {Math.max(0, Math.round((new Date(code.expires_at).getTime() - now) / 1000))} ثانیه) · فقط {store.name}
                  </p>
                  <div className="c7-actions">
                    <button type="button" className="btn btn-ghost" onClick={() => copyCode(code.code)}>کپی کد</button>
                  </div>
                </>
              ) : (
                <div className="c7-actions">
                  <button type="button" className="btn btn-primary" onClick={issue} disabled={busy || confirmedToday}>
                    {confirmedToday ? "پاداش امروز ثبت شده است" : busy ? "در حال صدور…" : "دریافت کد بعد از خرید"}
                  </button>
                </div>
              )}
              {code && new Date(code.expires_at).getTime() <= now ? (
                <p className="c7-error" role="alert">کد قبلی منقضی شده است؛ کد تازه بگیر.</p>
              ) : null}
              <p className="c7-error" role="alert">{err}</p>
              <p className="c7-small">
                سقف روزانه و اعتبار کد توسط سرور کنترل می‌شود. کد صادرشده تا تأیید فروشنده خرید نیست.
              </p>
            </>
          ) : null}
        </section>
      ) : null}

      {isAuthenticated ? (
        <section className="rv-card">
          <h2>رسید خریدهای حضوری من</h2>
          {purchases.loading ? <p className="rv-empty">در حال دریافت…</p> : null}
          {purchases.error ? <p className="c7-error" role="alert">{purchases.error}</p> : null}
          {mine.length ? (
            mine.map((t) => (
              <div className="rv-line" key={t.id}>
                <div>
                  <b>خرید {t.status === "confirmed" ? "تأییدشده" : "لغوشده"}</b>
                  <small>
                    {new Date(t.confirmed_at).toLocaleString("fa-IR", { dateStyle: "medium", timeStyle: "short" })} · کد …{t.code_hint}
                    {t.perk ? ` · ${t.perk}` : ""}
                  </small>
                </div>
                <span>پورسانت حضوری: صفر</span>
              </div>
            ))
          ) : (
            !purchases.loading ? <p>هنوز خریدی تأیید نشده است.</p> : null
          )}
        </section>
      ) : null}

      <p className="c7-small">اشتراک فروشنده پولی است؛ مشتری برای دریافت کد نیاز به خرید اشتراک ندارد.</p>
      <p className="c7-small">امروز: {fmtDate(Date.now())} — رکوردها سمت سرور نگهداری می‌شوند.</p>
    </div>
  );
}
