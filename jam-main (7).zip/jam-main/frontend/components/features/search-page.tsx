"use client";

/* صفحهٔ جست‌وجو — بازسازی دقیق DOM مرجع (/tmp/.../dom/search.html → <!-- APP -->) */

import { Suspense, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { CATS, STORES, catById, deliveryFee, discPct, openState, type Product, type Store } from "@/lib/data";
import { fa, norm } from "@/lib/format";
import Ic from "@/components/icons";
import StoreCard from "./store-card";
import ProductCard from "./product-card";

type SqlFilter = "open" | "discount" | "pickup" | "delivery";

const FILTERS: [SqlFilter, string, string][] = [
  ["open", "باز است", "clock"],
  ["discount", "تخفیف‌دار", "percent"],
  ["pickup", "تحویل حضوری", "walk"],
  ["delivery", "ارسال به محل", "truck"],
];

const SORTS: [string, string][] = [
  ["best", "پیشنهاد جم"],
  ["rate", "بیشترین امتیاز"],
  ["near", "نزدیک‌ترین"],
  ["fee", "کمترین هزینه ارسال"],
];

function SearchContent() {
  const params = useSearchParams();
  const q = norm(params.get("q") || "");
  const cat = params.get("cat") || "all";
  const f = (params.get("f") || "").split(",").filter(Boolean) as SqlFilter[];
  const sort = params.get("sort") || "best";
  const [filtersOpen, setFiltersOpen] = useState(false);

  const title = q
    ? `نتایج «${params.get("q")}»`
    : cat !== "all"
      ? catById(cat).name
      : f.includes("discount")
        ? "تخفیف‌های محلی"
        : "همه کسب‌وکارها";

  const buildHref = (overrides: Partial<{ cat: string; f: SqlFilter[]; sort: string }>) => {
    const o: Record<string, string> = {};
    if (params.get("q")) o.q = params.get("q") as string;
    const nextCat = overrides.cat !== undefined ? overrides.cat : cat;
    if (nextCat && nextCat !== "all") o.cat = nextCat;
    const nextF = overrides.f !== undefined ? overrides.f : f;
    if (nextF.length) o.f = nextF.join(",");
    const nextSort = overrides.sort !== undefined ? overrides.sort : sort;
    if (nextSort && nextSort !== "best") o.sort = nextSort;
    const s = new URLSearchParams(o).toString();
    return "/search" + (s ? `?${s}` : "");
  };

  const filtered = STORES.filter((s) => {
    if (cat !== "all" && s.cat !== cat) return false;
    if (f.includes("open") && !openState(s).open) return false;
    if (f.includes("discount") && !(s.discount || s.products.some((p) => discPct(p)))) return false;
    if (f.includes("pickup") && !s.pickup) return false;
    if (f.includes("delivery") && !s.delivery) return false;
    return true;
  });

  let prods: { p: Product; s: Store }[] = [];
  let list = filtered;
  if (q) {
    prods = filtered.flatMap((s) => s.products.filter((p) => norm(p.name + " " + p.desc + " " + p.sec).includes(q)).map((p) => ({ p, s })));
    list = filtered.filter(
      (s) => norm(s.name + " " + s.tagline + " " + catById(s.cat).name).includes(q) || prods.some(({ s: ps }) => ps.id === s.id),
    );
  } else if (f.includes("discount")) {
    prods = filtered.flatMap((s) => s.products.filter((p) => discPct(p) && p.available).map((p) => ({ p, s })));
  }

  const sorters: Record<string, (a: Store, b: Store) => number> = {
    best: (a, b) => Number(openState(b).open) - Number(openState(a).open) || b.rating - a.rating,
    rate: (a, b) => b.rating - a.rating,
    near: (a, b) => a.km - b.km,
    fee: (a, b) => deliveryFee(a) - deliveryFee(b),
  };
  const results = [...list].sort(sorters[sort] || sorters.best);

  const clearable = f.length > 0 || cat !== "all" || !!q;

  /* پیشنهاد جایگزین حالت خالی: فروشگاه‌های باز، نزدیک‌ترین */
  const best = STORES.filter((s) => openState(s).open)
    .sort((a, b) => a.km - b.km)
    .slice(0, 2);

  return (
    <>
    <div className="container">
      <div className="crumbs">
        <Link href="/">خانه</Link>
        <Ic n="chevL" c="sm" />
        <span>جست‌وجو</span>
      </div>
      <div className="page-title">
        <h1>{title}</h1>
        <p className="ux-page-sub">{q ? "نام غذا، محصول یا کسب‌وکار را جست‌وجو کنید." : "زمان تحویل و هزینهٔ ارسال را پیش از انتخاب مقایسه کنید."}</p>
      </div>
      {clearable ? (
        <nav className="ux-active-filters" aria-label="فیلترهای فعال">
          <span>
            <Ic n="sliders" c="sm" />
            نتایج انتخاب شما
          </span>
          <Link href="/search">
            حذف همهٔ فیلترها <Ic n="x" c="sm" />
          </Link>
        </nav>
      ) : null}
      <div className="s-layout">
        <aside className={`card filters${filtersOpen ? " is-open" : ""}`} aria-label="فیلترها">
          <button
            type="button"
            className="filters-toggle"
            aria-expanded={filtersOpen}
            onClick={() => setFiltersOpen((v) => !v)}
          >
            <Ic n="sliders" />
            <span>فیلتر و مرتب‌سازی</span>
            {f.length ? <b>{fa(f.length)}</b> : ""}
            <Ic n="chevD" c="sm" />
          </button>
          <div className="filter-content">
            <div className="f-group">
              <h4>دسته‌بندی</h4>
              <div className="chips" style={{ flexWrap: "wrap" }}>
                {[{ id: "all", name: "همه" }, ...CATS].map((c) => (
                  <Link key={c.id} href={buildHref({ cat: c.id })} className={`chip ${cat === c.id ? "on" : ""}`}>
                    {c.name}
                  </Link>
                ))}
              </div>
            </div>
            <div className="f-group">
              <h4>فیلتر</h4>
              {FILTERS.map(([k, label, icon]) => (
                <Link
                  key={k}
                  href={buildHref({ f: f.includes(k) ? f.filter((x) => x !== k) : [...f, k] })}
                  className="radio-row"
                  role="checkbox"
                  aria-checked={f.includes(k)}
                >
                  <span className="switch" aria-hidden="true">
                    <span className="qa13-check" aria-hidden="true" />
                    <span />
                  </span>
                  <Ic n={icon} c="sm faint" />
                  {label}
                </Link>
              ))}
            </div>
            <div className="f-group" role="radiogroup" aria-label="مرتب‌سازی">
              <h4>مرتب‌سازی</h4>
              {SORTS.map(([k, label]) => (
                <Link key={k} href={buildHref({ sort: k })} className="radio-row" role="radio" aria-checked={sort === k}>
                  <span className="qa13-check" aria-hidden="true">
                    {sort === k ? "✓" : ""}
                  </span>
                  {label}
                </Link>
              ))}
            </div>
          </div>
        </aside>
        <div>
          <div className="res-head">
            <span className="muted">
              {fa(results.length)} کسب‌وکار{prods.length ? ` · ${fa(prods.length)} محصول` : ""}
            </span>
            {clearable ? (
              <Link href="/search" className="link">
                پاک کردن فیلترها
              </Link>
            ) : null}
          </div>
          {prods.length ? (
            <>
              <h2 style={{ fontSize: 16, margin: "0 0 12px" }}>محصولات</h2>
              <div className="hscroll" style={{ marginBottom: 24 }}>
                {prods.slice(0, 16).map(({ p, s }) => (
                  <ProductCard key={p.id} p={p} s={s} />
                ))}
              </div>
              <h2 style={{ fontSize: 16, margin: "0 0 12px" }}>فروشگاه‌ها</h2>
            </>
          ) : null}
          {results.length ? (
            <div className="grid-stores">
              {results.map((s) => (
                <StoreCard key={s.id} s={s} />
              ))}
            </div>
          ) : (
            <>
              <div className="card">
                <div className="empty">
                  <div className="e-ic">
                    <Ic n="search" />
                  </div>
                  <b>نتیجه‌ای پیدا نشد</b>
                  <div style={{ fontSize: 14 }}>عبارت دیگری را امتحان کنید یا فیلترها را کم کنید.</div>
                  <div className="ux-empty-actions">
                    <Link href="/search" className="btn btn-primary">
                      پاک‌کردن فیلترها
                    </Link>
                    <Link href="/search?f=open&sort=near" className="btn btn-ghost">
                      باز و نزدیک
                    </Link>
                  </div>
                </div>
              </div>
              {best.length ? (
                <section className="ux-empty-suggestions">
                  <div className="ux-section-heading">
                    <div>
                      <span>یک انتخاب جایگزین</span>
                      <h2>این‌ها هم نزدیک شما هستند</h2>
                    </div>
                    <Link href="/search">
                      همه را ببینید <Ic n="arrowL" c="sm" />
                    </Link>
                  </div>
                  <div className="grid-stores">
                    {best.map((s) => (
                      <StoreCard key={s.id} s={s} />
                    ))}
                  </div>
                </section>
              ) : null}
            </>
          )}
        </div>
      </div>
    </div>
    <aside className="qa13-demo-bar container">
      <span>نمونهٔ محلی؛ پرداخت و واریز واقعی ندارد.</span>
      <Link href="/panel/settings">محدودیت‌های امنیت</Link>
    </aside>
    </>
  );
}

export function SearchPage() {
  return (
    <Suspense
      fallback={
        <div className="container text-center py-20">
          <span className="pill">در حال بارگذاری...</span>
        </div>
      }
    >
      <SearchContent />
    </Suspense>
  );
}
