"use client";

import { Suspense, useEffect, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import StoreCard from "@/components/features/store-card";
import Ic from "@/components/icons";
import { apiFetch } from "@/lib/api";
import { apiStoreToStore, type ApiPublicStore } from "@/lib/public-menu";

export function RealCatalogSearch() {
  return (
    <Suspense fallback={<div className="container" style={{ minHeight: "40vh" }} />}>
      <RealCatalogResults />
    </Suspense>
  );
}

function RealCatalogResults() {
  const params = useSearchParams();
  const q = (params.get("q") || "").trim();
  const [rows, setRows] = useState<ApiPublicStore[] | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    setError("");
    apiFetch<{ results: ApiPublicStore[] }>("/commerce/public/stores/", { auth: false })
      .then((res) => {
        if (active) setRows(res.results);
      })
      .catch((err) => {
        if (active) {
          setRows([]);
          setError(err instanceof Error ? err.message : "دریافت کاتالوگ ناموفق بود.");
        }
      });
    return () => {
      active = false;
    };
  }, []);

  const visible = (rows || []).filter((row) => {
    if (!q) return true;
    const haystack = `${row.name} ${row.description} ${row.categories.join(" ")}`.toLowerCase();
    return haystack.includes(q.toLowerCase());
  });

  return (
    <div className="container">
      <div className="crumbs">
        <Link href="/">خانه</Link>
        <Ic n="chevL" c="sm" />
        <span>جست‌وجو</span>
      </div>
      <div className="page-title">
        <h1>{q ? `نتایج «${q}»` : "همه کسب‌وکارها"}</h1>
        <p className="ux-page-sub">فقط کسب‌وکارهای دارای منوی فعال از سرور نمایش داده می‌شوند.</p>
      </div>

      {error ? (
        <div className="card">
          <div className="empty">
            <div className="e-ic"><Ic n="alert" /></div>
            <b>دریافت کاتالوگ ناموفق بود</b>
            <div style={{ fontSize: 14 }}>{error}</div>
          </div>
        </div>
      ) : rows === null ? (
        <div className="card"><div className="empty">در حال دریافت…</div></div>
      ) : visible.length === 0 ? (
        <div className="card">
          <div className="empty">
            <div className="e-ic"><Ic n="search" /></div>
            <b>نتیجه‌ای پیدا نشد</b>
            <div style={{ fontSize: 14 }}>عبارت دیگری را امتحان کنید.</div>
            <div style={{ marginTop: 16 }}><Link href="/search" className="btn btn-soft">پاک‌کردن جست‌وجو</Link></div>
          </div>
        </div>
      ) : (
        <div className="grid-stores">
          {visible.map((row) => <StoreCard key={row.menu_slug} s={apiStoreToStore(row)} />)}
        </div>
      )}
    </div>
  );
}
