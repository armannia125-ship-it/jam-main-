"use client";

/* Checkout for backend public-store carts. The server validates every item and
   returns the authoritative totals; the client never submits prices. */

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Ic } from "@/components/icons";
import { useAuth } from "@/lib/auth";
import { ApiError, apiFetch } from "@/lib/api";
import { useJam, cartSummary } from "@/lib/state";
import { storeHref, type Store } from "@/lib/data";
import { enD, fa, tomanT } from "@/lib/format";

type Quote = {
  mode: "delivery" | "pickup";
  subtotal_toman: number;
  discount_toman: number;
  delivery_fee_toman: number;
  total_toman: number;
  items: { product_id: number; name: string; unit_price_toman: number; quantity: number; line_total_toman: number }[];
};

export function ApiCheckoutPage({ store }: { store: Store }) {
  const router = useRouter();
  const { ready: authReady, isAuthenticated, user } = useAuth();
  const { cart, ready, addrs, addAddress, clearCart, profile, setProfile, toast } = useJam();
  const cs = cartSummary(cart);

  const [mode, setMode] = useState<"delivery" | "pickup">("delivery");
  const [addrId, setAddrId] = useState("");
  const [name, setName] = useState(profile.name);
  const [phone, setPhone] = useState(profile.phone || user?.phone?.replace(/^\+98/, "0") || "");
  const [note, setNote] = useState("");
  const [newAddress, setNewAddress] = useState("");
  const [showAddress, setShowAddress] = useState(false);
  const [quote, setQuote] = useState<Quote | null>(null);
  const [quoteError, setQuoteError] = useState("");
  const [quoteLoading, setQuoteLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");
  const idem = useRef("");

  const items = useMemo(
    () =>
      (cart?.sid === store.id ? cart.items : [])
        .map((item) => {
          const match = /^api-p(\d+)$/.exec(item.pid);
          return match ? { product_id: Number(match[1]), quantity: item.qty } : null;
        })
        .filter((x): x is { product_id: number; quantity: number } => !!x),
    [cart, store.id],
  );
  const itemsKey = JSON.stringify(items);

  useEffect(() => {
    idem.current = "";
  }, [itemsKey, mode]);

  useEffect(() => {
    if (addrs.length && !addrs.some((a) => a.id === addrId)) setAddrId(addrs[0].id);
  }, [addrs, addrId]);

  useEffect(() => {
    if (!authReady || !isAuthenticated || !items.length) {
      setQuote(null);
      return;
    }
    let active = true;
    setQuoteLoading(true);
    setQuoteError("");
    apiFetch<Quote>("/commerce/orders/quote/", {
      method: "POST",
      body: { business_id: store.apiBusinessId, items, mode },
    })
      .then((res) => {
        if (active) setQuote(res);
      })
      .catch((err) => {
        if (active) {
          setQuote(null);
          setQuoteError(err instanceof Error ? err.message : "محاسبهٔ مبلغ ناموفق بود.");
        }
      })
      .finally(() => {
        if (active) setQuoteLoading(false);
      });
    return () => {
      active = false;
    };
  }, [authReady, isAuthenticated, itemsKey, mode, store.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const address = addrs.find((a) => a.id === addrId) || addrs[0];
  const money = quote || {
    subtotal_toman: cs.items,
    discount_toman: cs.discount,
    delivery_fee_toman: mode === "delivery" ? cs.delivery : 0,
    total_toman: cs.items - cs.discount + (mode === "delivery" ? cs.delivery : 0),
  };

  const saveAddress = () => {
    const text = newAddress.trim();
    if (text.length < 6) {
      toast("آدرس را کامل‌تر وارد کنید", "err");
      return;
    }
    const created = addAddress({ title: "آدرس جدید", text });
    setAddrId(created.id);
    setNewAddress("");
    setShowAddress(false);
  };

  const submit = async () => {
    setSubmitError("");
    if (!isAuthenticated) {
      router.push("/login?next=/checkout");
      return;
    }
    if (!items.length) {
      setSubmitError("سبد خرید خالی است.");
      return;
    }
    if (name.trim().length < 3) {
      setSubmitError("نام و نام خانوادگی را کامل وارد کنید.");
      return;
    }
    const normalizedPhone = enD(phone).trim();
    if (!/^09\d{9}$/.test(normalizedPhone)) {
      setSubmitError("شمارهٔ موبایل باید ۱۱ رقم و با ۰۹ شروع شود.");
      return;
    }
    const addressText = mode === "delivery" ? (address ? `${address.title} — ${address.text}` : "") : "";
    if (mode === "delivery" && !addressText) {
      setSubmitError("برای ارسال، یک آدرس ثبت کنید.");
      return;
    }
    if (!quote) {
      setSubmitError("مبلغ سفارش هنوز از سرور تأیید نشده است.");
      return;
    }
    if (!idem.current) {
      idem.current =
        typeof crypto !== "undefined" && "randomUUID" in crypto
          ? crypto.randomUUID()
          : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    }
    setSubmitting(true);
    try {
      const res = await apiFetch<{ created: boolean; order: { number: string } }>("/commerce/orders/", {
        method: "POST",
        body: {
          business_id: store.apiBusinessId,
          items,
          mode,
          payment_method: "offline",
          customer_name: name.trim(),
          customer_phone: normalizedPhone,
          address_text: addressText,
          note,
          idempotency_key: idem.current,
        },
      });
      setProfile({ name: name.trim(), phone: normalizedPhone });
      clearCart();
      router.push(`/order/${res.order.number}?new=1`);
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        router.push("/login?next=/checkout");
        return;
      }
      setSubmitError(err instanceof Error ? err.message : "ثبت سفارش ناموفق بود.");
    } finally {
      setSubmitting(false);
    }
  };

  if (!ready) return <div className="container" style={{ minHeight: "40vh" }} />;
  if (!items.length) {
    return (
      <div className="container">
        <div className="page-title"><h1>تکمیل سفارش</h1></div>
        <div className="card">
          <div className="empty">
            <div className="e-ic"><Ic n="bag" /></div>
            <b>سبد خرید شما خالی است</b>
            <div style={{ marginTop: 16 }}><Link href={storeHref(store)} className="btn btn-primary">بازگشت به منو</Link></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="crumbs">
        <Link href="/" className="ui-tap-link">خانه</Link>
        <Ic n="chevL" c="sm" />
        <Link href={storeHref(store)} className="ui-tap-link">{store.name}</Link>
        <Ic n="chevL" c="sm" />
        <span>تکمیل سفارش</span>
      </div>
      <div className="page-title">
        <h1>تکمیل سفارش</h1>
        <p className="ux-page-sub">قیمت‌ها و جمع نهایی توسط سرور محاسبه می‌شود.</p>
      </div>

      {!authReady ? null : !isAuthenticated ? (
        <div className="notice blue" style={{ marginBottom: 16 }}>
          <Ic n="info" />
          <span>
            برای ثبت سفارش وارد حساب شوید. <Link className="link" href="/login?next=/checkout">ورود با کد یک‌بارمصرف</Link>
          </span>
        </div>
      ) : null}

      <div className="co-layout">
        <div>
          <section className="card co-step">
            <h2><span className="n">۱</span>روش دریافت سفارش</h2>
            <div className="opt-grid" role="radiogroup">
              <button className={`opt ${mode === "pickup" ? "on" : ""}`} role="radio" aria-checked={mode === "pickup"} onClick={() => setMode("pickup")}>
                <span className="radio" /><span className="oi"><Ic n="walk" /></span>
                <span><b>تحویل حضوری</b><small>بدون هزینه ارسال</small></span>
              </button>
              <button className={`opt ${mode === "delivery" ? "on" : ""}`} role="radio" aria-checked={mode === "delivery"} onClick={() => setMode("delivery")}>
                <span className="radio" /><span className="oi"><Ic n="truck" /></span>
                <span>
                  <b>ارسال به محل</b>
                  <small>{quote ? `هزینه ارسال: ${tomanT(quote.delivery_fee_toman)}` : "هزینه ارسال را سرور محاسبه می‌کند"}</small>
                </span>
              </button>
            </div>
          </section>

          {mode === "delivery" && (
            <section className="card co-step">
              <h2><span className="n">۲</span>آدرس تحویل</h2>
              <div className="addr-list">
                {addrs.map((a) => (
                  <button key={a.id} className={`addr-opt ${a.id === address?.id ? "on" : ""}`} onClick={() => setAddrId(a.id)} role="radio" aria-checked={a.id === address?.id}>
                    <span className="oi"><Ic n="home" /></span>
                    <span className="grow"><b style={{ display: "block", fontSize: "14.5px" }}>{a.title}</b><span className="muted" style={{ fontSize: 14 }}>{a.text}</span></span>
                    {a.id === address?.id && <Ic n="check" />}
                  </button>
                ))}
                {!showAddress ? (
                  <button className="btn btn-ghost" onClick={() => setShowAddress(true)} style={{ alignSelf: "flex-start" }}>
                    <Ic n="plus" c="sm" /> افزودن آدرس جدید
                  </button>
                ) : (
                  <div className="form-grid" style={{ width: "100%" }}>
                    <div className="field full">
                      <label htmlFor="api-addr">آدرس</label>
                      <textarea className="textarea" id="api-addr" value={newAddress} onChange={(e) => setNewAddress(e.target.value)} placeholder="محله، خیابان، کوچه و پلاک" maxLength={300} />
                    </div>
                    <div className="full row" style={{ gap: 10 }}>
                      <button className="btn btn-primary" onClick={saveAddress}>ذخیره آدرس</button>
                      <button className="btn btn-ghost" onClick={() => setShowAddress(false)}>انصراف</button>
                    </div>
                  </div>
                )}
              </div>
            </section>
          )}

          <section className="card co-step">
            <h2><span className="n">{mode === "delivery" ? "۳" : "۲"}</span>اطلاعات تماس</h2>
            <div className="form-grid">
              <div className="field">
                <label htmlFor="api-name">نام و نام خانوادگی</label>
                <input className="input" id="api-name" value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" maxLength={120} />
              </div>
              <div className="field">
                <label htmlFor="api-phone">شماره موبایل</label>
                <input className="input input-ltr tnum" id="api-phone" dir="ltr" inputMode="numeric" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="09xxxxxxxxx" autoComplete="tel" maxLength={11} />
              </div>
              <div className="field full">
                <label htmlFor="api-note">توضیحات <span className="faint">(اختیاری)</span></label>
                <textarea className="textarea" id="api-note" value={note} onChange={(e) => setNote(e.target.value)} maxLength={1000} />
              </div>
            </div>
          </section>

          <section className="card co-step">
            <h2><span className="n">{mode === "delivery" ? "۴" : "۳"}</span>روش پرداخت</h2>
            <div className="notice amber">
              <Ic n="info" />
              <span>پرداخت آنلاین سفارش به درگاه پرداخت متصل نیست. سفارش با پرداخت {mode === "pickup" ? "در فروشگاه" : "هنگام تحویل"} ثبت می‌شود.</span>
            </div>
          </section>
        </div>

        <aside className="co-summary" style={{ position: "sticky", top: "calc(var(--header-h) + 16px)" }}>
          <div className="card summary">
            <div className="s-store">
              <span className={`lg tone tone-${store.tone}`}><span className="brand-monogram">{store.name.slice(0, 2)}</span></span>
              <div className="grow"><b>{store.name}</b><div className="faint" style={{ fontSize: 14 }}>{fa(cs.count)} کالا</div></div>
            </div>
            <div style={{ padding: "8px 18px", maxHeight: 240, overflow: "auto" }}>
              {(quote?.items || cs.lines.map((l) => ({ product_id: l.pid, name: l.name, quantity: l.qty, unit_price_toman: l.price, line_total_toman: l.price * l.qty }))).map((l) => (
                <div className="sum-row" style={{ color: "var(--ink)" }} key={String(l.product_id)}>
                  <span className="ellipsis" style={{ maxWidth: "70%" }}>{fa(l.quantity)}× {l.name}</span>
                  <span className="tnum">{tomanT(l.line_total_toman)}</span>
                </div>
              ))}
            </div>
            <div className="cart-sum">
              <div className="sum-row"><span>جمع اقلام</span><span className="tnum">{tomanT(money.subtotal_toman)}</span></div>
              <div className="sum-row"><span>هزینه ارسال</span><span className="tnum">{money.delivery_fee_toman ? tomanT(money.delivery_fee_toman) : "رایگان"}</span></div>
              <div className="sum-row total"><span>مبلغ قابل پرداخت</span><span className="tnum">{tomanT(money.total_toman)}</span></div>
              {quoteLoading ? <p className="hint">در حال تأیید مبلغ از سرور…</p> : null}
              {quoteError ? <p className="err-msg" role="alert"><Ic n="alert" c="sm" />{quoteError}</p> : null}
              {submitError ? <p className="err-msg" role="alert"><Ic n="alert" c="sm" />{submitError}</p> : null}
              <button className="btn btn-primary btn-lg btn-block" style={{ marginTop: 14 }} onClick={submit} disabled={submitting || quoteLoading || !quote}>
                {submitting ? "در حال ثبت…" : "ثبت سفارش"} <Ic n="arrowL" />
              </button>
              <p className="hint" style={{ textAlign: "center", margin: "10px 0 0" }}>با ثبت سفارش، قوانین جم را می‌پذیرید.</p>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
