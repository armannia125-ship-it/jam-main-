"use client";

import Link from "next/link";
import { Product, Store, STORE_PHOTOS, brandMonogram, deliveryEta, deliveryFee, prepText, openState, storeHref } from "@/lib/data";
import { useJam } from "@/lib/state";
import { useAddToCart } from "@/components/features/add-to-cart";
import { fa, tomanT } from "@/lib/format";
import Ic from "@/components/icons";

/* کنترل تعداد — دقیقاً مطابق qtyCtl در مرجع */
export function QtyCtl({ product, s, light = false }: { product: Product; s: Store; light?: boolean }) {
  const { cart, setQty } = useJam();
  const add = useAddToCart();
  const q = cart?.sid === s.id ? cart.items.find((x) => x.pid === product.id)?.qty ?? 0 : 0;
  if (!product.available) {
    return (
      <span className="qc">
        <span className="na-tag">ناموجود</span>
      </span>
    );
  }
  if (!q) {
    return (
      <span className="qc">
        <button
          type="button"
          className="add"
          aria-label={`افزودن ${product.name} به سبد`}
          onClick={() => add(s.id, product.id)}
        >
          <Ic n="plus" />
        </button>
      </span>
    );
  }
  return (
    <span className={`stepper${light ? " light" : ""}`} role="group" aria-label={`تعداد ${product.name}`}>
      <button type="button" aria-label="افزایش" onClick={() => setQty(product.id, q + 1)}>
        <Ic n="plus" c="sm" />
      </button>
      <b className="tnum" aria-live="polite">{fa(q)}</b>
      <button type="button" aria-label={q === 1 ? "حذف" : "کاهش"} onClick={() => setQty(product.id, q - 1)}>
        <Ic n={q === 1 ? "trash" : "minus"} c="sm" />
      </button>
    </span>
  );
}

export default function StoreCard({ s, pickupMode = false }: { s: Store; pickupMode?: boolean }) {
  const { favs, toggleFav, toast } = useJam();
  const st = openState(s);
  const fav = favs.includes(s.id);
  const pickup = pickupMode || !s.delivery;
  const fee = deliveryFee(s);
  return (
    <article className="store-card">
      <Link href={storeHref(s)} className="cover" aria-label={`مشاهده ${s.name}`}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img className="media-photo" src={s.coverImage || `/media/${STORE_PHOTOS[s.id] || "grill"}.webp`} alt="" loading="lazy" />
        {s.discount ? <span className="store-discount">تا {fa(s.discount)}٪ تخفیف</span> : ""}
        <span className="store-availability">
          <span className="dot" />
          {st.open ? "سفارش می‌پذیرد" : "امکان پیش‌سفارش"}
        </span>
      </Link>
      <button
        type="button"
        className={`fav${fav ? " on" : ""}`}
        aria-label={`${fav ? "حذف از" : "افزودن به"} علاقه‌مندی‌ها`}
        aria-pressed={fav}
        onClick={() => {
          toggleFav(s.id);
          toast(fav ? "از علاقه‌مندی‌ها حذف شد" : "به علاقه‌مندی‌ها اضافه شد");
        }}
      >
        <Ic n="heart" />
      </button>
      <Link href={storeHref(s)} className="sc-body">
        <div className="sc-identity">
          <span className="s-logo">
            <span className={`brand-monogram bm-${s.id}`}>{s.chainShort || brandMonogram(s)}</span>
          </span>
          <span className="grow">
            <h3>{s.name}</h3>
            <span className="sc-sub">{s.tagline}</span>
          </span>
          {s.api ? null : (
            <span className="rating-block">
              <span>
                <Ic n="star" />
                {fa(s.rating)}
              </span>
              <small>{fa(s.reviews)} نظر</small>
            </span>
          )}
        </div>
        <div className="sc-meta">
          <span>
            <Ic n="clock" c="sm" />
            {pickup ? prepText(s) : deliveryEta(s)}
          </span>
          <span>
            <Ic n="pin" c="sm" />
            {s.api ? "منوی دیجیتال" : `${fa(s.km)} کیلومتر`}
          </span>
          <span className="sc-delivery">
            {pickup ? "تحویل رایگان" : fee ? `ارسال ${tomanT(fee)}` : "ارسال رایگان"}
          </span>
        </div>
      </Link>
    </article>
  );
}
