"use client";

/* قطعات کمکی صفحهٔ اصلی — مطابق DOM مرجع (home.html) */

import Link from "next/link";
import { STATUS, brandMonogram, openState, productById, store, storePhoto } from "@/lib/data";
import { faD } from "@/lib/format";
import { useJam, type Order } from "@/lib/state";
import Ic from "@/components/icons";

/* بنر سفارش فعال — دقیقاً مطابق activeOrderBanner در مرجع */
export function ActiveOrderBanner({ o }: { o: Order }) {
  const s = store(o.sid);
  if (!s) return null;
  const st = STATUS[o.status];
  if (!st) return null;
  return (
    <Link
      href={`/order/${o.id}`}
      className="card active-order-banner"
      style={{ display: "flex", alignItems: "center", gap: 14, padding: "14px 16px", marginTop: 16, borderColor: "var(--brand-400)" }}
    >
      <span className={`big-status tone tone-${s.tone}`} style={{ width: 48, height: 48, borderRadius: 13, fontSize: 24 }}>
        <span className={`brand-monogram bm-${s.id}`}>{brandMonogram(s)}</span>
      </span>
      <span className="grow">
        <b style={{ display: "block" }}>سفارش فعال از {s.name}</b>
        <span className={`pill ${st.c}`} style={{ marginTop: 4 }}>
          <span className="dot" />
          {st.t}
        </span>
      </span>
      <span className="btn btn-soft btn-sm">
        پیگیری <Ic n="chevL" c="sm" />
      </span>
    </Link>
  );
}

/* بخش «همان انتخابِ خوب قبلی» — فقط با سفارش‌های قبلی؛ مطابق repeatSection در مرجع */
export function RepeatSection({ orders }: { orders: Order[] }) {
  const { addToCart, toast } = useJam();
  const past = orders
    .filter((o) => !["canceled", "rejected"].includes(o.status))
    .sort((a, b) => b.placedAt - a.placedAt);
  const unique = past.filter((o, i) => past.findIndex((x) => x.sid === o.sid) === i).slice(0, 3);
  if (!unique.length) return null;
  return (
    <section className="ux-repeat">
      <div className="ux-section-heading">
        <div>
          <span>برای خودِ شما</span>
          <h2>همان انتخابِ خوب قبلی</h2>
        </div>
        <Link href="/orders">
          سفارش‌های من <Ic n="arrowL" c="sm" />
        </Link>
      </div>
      <div className="ux-repeat-grid">
        {unique.map((o) => {
          const s = store(o.sid);
          if (!s) return null;
          const st = openState(s);
          const available = o.items.filter((i) => productById(i.pid)?.product.available);
          return (
            <article className="ux-repeat-card" key={o.id}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={storePhoto(s)} alt="" loading="lazy" />
              <div>
                <b>{s.name}</b>
                <p>
                  {o.items.slice(0, 2).map((i) => i.name).join("، ")}
                  {o.items.length > 2 ? " و…" : ""}
                </p>
                <small>
                  {st.open ? "هم‌اکنون باز" : `پیش‌سفارش برای ${faD(st.opensAt || "")}`} · قیمت روز در سبد
                </small>
              </div>
              <button
                type="button"
                className="btn btn-soft"
                data-ux="repeat"
                data-id={o.id}
                disabled={!available.length}
                onClick={() => {
                  available.forEach((i) => addToCart(s.id, i.pid, i.qty));
                  toast("به سبد اضافه شد", "ok", { label: "مشاهده سبد", href: "/cart" });
                }}
              >
                <Ic n="refresh" c="sm" />
                دوباره سفارش بده
              </button>
            </article>
          );
        })}
      </div>
    </section>
  );
}
