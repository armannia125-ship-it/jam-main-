"use client";

/* پنل سبد خرید کنار منو — دقیقاً مطابق دامپ store-s1 / cart-drawer */
import Link from "next/link";
import type { Store } from "@/lib/data";
import { productPhoto, deliveryFee, openState, brandMonogram, storeHref } from "@/lib/data";
import { useJam } from "@/lib/state";
import { fa, tomanT } from "@/lib/format";
import { Ic } from "@/components/icons";
import { QtyCtl } from "@/components/features/store-card";

export function CartBox({ s }: { s: Store }) {
  const { cart, clearCart, toast } = useJam();
  const st = openState(s);
  const mine = cart && cart.sid === s.id ? cart : null;
  const count = mine ? mine.items.reduce((a, it) => a + it.qty, 0) : 0;

  /* جمع‌ها مطابق دامپ: اقلام با قیمت قبل از تخفیف، تخفیف محصولات، ارسال، قابل پرداخت */
  const rows = mine
    ? mine.items
        .map((it) => {
          const p = s.products.find((x) => x.id === it.pid);
          return p ? { p, qty: it.qty } : null;
        })
        .filter(Boolean) as { p: (typeof s.products)[number]; qty: number }[]
    : [];
  const itemsOld = rows.reduce((a, r) => a + (r.p.old > r.p.price ? r.p.old : r.p.price) * r.qty, 0);
  const discount = rows.reduce((a, r) => a + (r.p.old > r.p.price ? (r.p.old - r.p.price) * r.qty : 0), 0);
  const delivery = rows.length && s.delivery ? deliveryFee(s) : 0;
  const total = Math.max(0, itemsOld - discount + delivery);
  const belowMin = s.minOrder > 0 && itemsOld - discount < s.minOrder;
  const pct = s.minOrder > 0 ? Math.min(100, Math.round(((itemsOld - discount) / s.minOrder) * 100)) : 100;

  return (
    <div className="card cart-box" data-cart-panel="side">
      <div className="cart-head">
        <h3>
          سبد خرید{" "}
          {count ? (
            <span className="faint" style={{ fontWeight: 500, fontSize: 14 }}>
              ({fa(count)})
            </span>
          ) : null}
        </h3>
        {count ? (
          <button
            type="button"
            className="btn btn-sm btn-plain"
            onClick={() => {
              clearCart();
              toast("سبد خرید خالی شد");
            }}
          >
            <Ic n="trash" c="sm" />
            حذف همه
          </button>
        ) : null}
      </div>

      {!mine || !rows.length ? (
        <div className="empty">
          <div className="e-ic">
            <Ic n="bag" />
          </div>
          <b>سبد خرید خالی است</b>
          <div style={{ fontSize: 14 }}>محصولات موردنظرتان را از منو اضافه کنید.</div>
        </div>
      ) : (
        <>
          <Link
            href={storeHref(s)}
            className="row"
            style={{ padding: "12px 18px", borderBottom: "1px solid var(--line)" }}
          >
            <span
              className={`tone tone-${s.tone}`}
              style={{ width: 36, height: 36, borderRadius: 10, display: "grid", placeItems: "center", fontSize: 18 }}
            >
              <span className={`brand-monogram bm-${s.id}`} style={{ fontSize: 18 }}>
                {s.chainShort || brandMonogram(s)}
              </span>
            </span>
            <span className="grow">
              <b style={{ fontSize: 14 }}>{s.name}</b>
              <small className="faint" style={{ display: "block", fontSize: 14 }}>
                {st.open ? "باز · سفارش‌ها بلافاصله پردازش می‌شود" : "بسته · سفارش در ساعت بازگشایی پردازش می‌شود"}
              </small>
            </span>
          </Link>
          <div className="cart-list">
            {rows.map((r) => {
              const photo = productPhoto(r.p, s.id);
              return (
                <div className="c-row" key={r.p.id}>
                  <span className={`th tone tone-${s.tone}`} aria-hidden="true">
                    {photo ? (
                      /* eslint-disable-next-line @next/next/no-img-element */
                      <img className="media-photo" src={photo} alt="" loading="lazy" />
                    ) : (
                      r.p.em
                    )}
                  </span>
                  <div className="grow">
                    <div className="nm ellipsis">{r.p.name}</div>
                    <div className="pr tnum">{tomanT(r.p.price * r.qty)}</div>
                  </div>
                  <QtyCtl product={r.p} s={s} light />
                </div>
              );
            })}
          </div>
          <div className="cart-sum">
            <div className="sum-row">
              <span>جمع اقلام</span>
              <span className="tnum">{tomanT(itemsOld)}</span>
            </div>
            {discount > 0 ? (
              <div className="sum-row green">
                <span>تخفیف محصولات</span>
                <span className="tnum">−{tomanT(discount)}</span>
              </div>
            ) : null}
            <div className="sum-row">
              <span>هزینه ارسال</span>
              <span className="tnum">{tomanT(delivery)}</span>
            </div>
            <div className="sum-row total">
              <span>مبلغ قابل پرداخت</span>
              <span className="tnum">{tomanT(total)}</span>
            </div>
            {s.minOrder > 0 ? (
              <>
                <div className="progress">
                  <i style={{ width: `${pct}%` }} />
                </div>
                <p className="hint">
                  {belowMin
                    ? `تا حداقل سفارش ${tomanT(s.minOrder - (itemsOld - discount))} باقی مانده است`
                    : "حداقل سفارش تأمین شد؛ آمادهٔ ثبت سفارش هستید."}
                </p>
              </>
            ) : null}
            {belowMin ? (
              <button type="button" className="btn btn-primary btn-lg btn-block" style={{ marginTop: 14 }} disabled>
                ادامه و ثبت سفارش <Ic n="arrowL" />
              </button>
            ) : (
              <Link href="/checkout" className="btn btn-primary btn-lg btn-block" style={{ marginTop: 14 }}>
                ادامه و ثبت سفارش <Ic n="arrowL" />
              </Link>
            )}
          </div>
        </>
      )}
    </div>
  );
}

export default CartBox;
