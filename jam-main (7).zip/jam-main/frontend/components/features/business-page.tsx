"use client";
/* صفحهٔ کسب‌وکارها — لایهٔ نهایی مطابق DOM مرجع (business.html):
   سه کارت اشتراک (منو / باشگاه / طلایی) + ناوبری اشتراک‌ها + نکته‌های
   صداقت نمایشی + کارت‌های توضیح تسهیم. بدون مودال ثبت‌نام؛ CTAها به پنل می‌روند. */

import Link from "next/link";
import { fa } from "@/lib/format";
import Ic from "@/components/icons";

type Offer = {
  kind: "menu" | "club" | "gold";
  icon: string;
  small: string;
  title: string;
  price: number;
  priceNote: string;
  cta: [string, string, "btn-ghost" | "btn-primary"];
  feats: string[];
};

const OFFERS: Offer[] = [
  {
    kind: "menu",
    icon: "qr",
    small: "منوی خودت را داشته باش",
    title: "اشتراک منو",
    price: 200000,
    priceNote: "از این مبلغ برای ۳۰ روز · پیشنهادی",
    cta: ["دیدن پلن‌های منو", "/panel/menu", "btn-ghost"],
    feats: ["منوی فروشگاه با لینک و QR", "مدیریت محصول، قیمت و قالب در سایت", "بدون مزیت نمایش ویژهٔ باشگاه"],
  },
  {
    kind: "club",
    icon: "spark",
    small: "مخصوص فروشندگان؛ برای بهتر دیده‌شدن",
    title: "باشگاه فروشندگان",
    price: 350000,
    priceNote: "برای ۳۰ روز · پیشنهادی",
    cta: ["دیدن امکانات باشگاه", "/panel/plan", "btn-ghost"],
    feats: ["معرفی در بخش ویژهٔ فروشگاه‌های باشگاه", "نمایش عضویت و پیشنهاد مشخص فروشگاه", "ابزار بازگشت مشتری؛ بدون تضمین فروش"],
  },
  {
    kind: "gold",
    icon: "star",
    small: "کامل‌ترین منو + معرفی ویژهٔ فروشگاه",
    title: "اشتراک طلایی",
    price: 810000,
    priceNote: "منوی ویژه + باشگاه · ۳۰ روز · پیشنهادی",
    cta: ["دیدن بستهٔ طلایی", "/panel/plan", "btn-primary"],
    feats: ["همهٔ امکانات منوی ویژه و باشگاه", "۱۰٪ کمتر از خرید جداگانهٔ همین دو", "یک پرداخت؛ دو اعتبار مستقل و مشخص"],
  },
];

const OFFER_NAV: [string, string, boolean][] = [
  ["همه", "/business", true],
  ["منو", "/panel/menu", false],
  ["باشگاه", "/panel/plan", false],
  ["طلایی", "/panel/plan", false],
];

export function BusinessPage() {
  return (
    <>
      <div className="container rv">
      <header className="rv-heading">
        <span>جم لایف برای فروشندگان</span>
        <h1 tabIndex={-1}>منوی خودت؛ نمایش ویژهٔ فروشگاهت.</h1>
        <p>منو و باشگاه دو خدمت متفاوت‌اند؛ با طلایی هر دو را در یک بسته بگیر.</p>
      </header>

      <nav className="g10-offer-nav" aria-label="اشتراک‌های فروشگاه">
        {OFFER_NAV.map(([label, href, cur]) => (
          <Link key={label} href={href} aria-current={cur ? "page" : undefined}>
            {label}
          </Link>
        ))}
      </nav>

      <div className="g10-offers">
        {OFFERS.map((o) => (
          <article className={`g10-offer ${o.kind}`} key={o.kind}>
            <div className="g10-offer-top">
              <span className="g10-icon">
                <Ic n={o.icon} />
              </span>
              <span className="g10-state">فعال نشده</span>
            </div>
            <span className="g10-small">{o.small}</span>
            <h2>{o.title}</h2>
            <div className="g10-offer-price">
              <strong className="v11-amount">
                <bdi dir="ltr">{fa(o.price)}</bdi> <span className="v11-currency">تومان</span>
              </strong>
              <small>{o.priceNote}</small>
            </div>
            <Link className={`btn ${o.cta[2]}`} href={o.cta[1]}>
              {o.cta[0]} <Ic n="chevL" c="sm" />
            </Link>
            <ul>
              {o.feats.map((f) => (
                <li key={f}>
                  <Ic n="check" c="sm" />
                  <span>{f}</span>
                </li>
              ))}
            </ul>
          </article>
        ))}
      </div>

      <p className="g10-info">
        خرید منو به‌تنهایی نمایش ویژه نمی‌دهد. خرید باشگاه به‌تنهایی اشتراک منو نیست. طلایی شامل هر دو است؛ هیچ بسته‌ای فروش
        تضمین‌شده یا بودجهٔ تخفیف نامحدود ندارد.
      </p>

      <p className="g10-demo">
        <Ic n="info" c="sm" />
        نسخهٔ محلی و نمایشی؛ پرداخت و واریز واقعی انجام نمی‌شود.
      </p>

      <details className="rv-note ui-demo-note">
        <summary>
          <Ic n="info" c="sm" />
          نسخهٔ آزمایشی؛ بدون پرداخت واقعی <Ic n="chevD" c="sm" />
        </summary>
        <p>
          نسخهٔ محلی و نمایشی: پذیرش شرایط، اشتراک، تأیید خرید و تسویه آزمایشی‌اند. احراز هویت، دریافت وجه و واریز بانکی
          واقعی انجام نمی‌شود؛ دو دستگاه مستقل دادهٔ مشترک ندارند.
        </p>
      </details>

      <section className="rv-card">
        <h2>برای فروشنده، فقط یک تأیید</h2>
        <ol className="c7-steps">
          <li>مشتری پول را با کارت‌خوان یا نقدی به خودت می‌دهد.</li>
          <li>کد مشتری را اسکن می‌کنی و «خرید انجام شد» را می‌زنی.</li>
          <li>خرید تأییدشده، مسیر پاداش خرید و بازی و بازگشت مشتری را فعال می‌کند.</li>
        </ol>
        <p>بدون ثبت مبلغ فاکتور، عکس رسید یا بدهی بابت هر خرید حضوری.</p>
      </section>

      <section className="rv-card">
        <h2>برای خرید آنلاین: سهم‌ها جدا، تسویه خودکار</h2>
        <p>
          درصد پذیرفته‌شدهٔ جم لایف و سهم فروشنده در هر سفارش ثبت می‌شود. پس از تحویل و پذیرندگی، سرویس پرداخت باید تسویه
          را انجام دهد. این نسخه فقط شبیه‌ساز است.
        </p>
        <Link className="btn btn-ghost" href="/panel/plan">
          دیدن جریان تسهیم
        </Link>
        <Link className="c7-text-link" href="/panel/settings">
          شرایط همکاری داخل سایت
        </Link>
      </section>
      </div>

      <aside className="qa13-demo-bar container">
        <span>نمونهٔ محلی؛ پرداخت و واریز واقعی ندارد.</span>
        <Link href="/panel/settings">محدودیت‌های امنیت</Link>
      </aside>
    </>
  );
}

export default BusinessPage;
