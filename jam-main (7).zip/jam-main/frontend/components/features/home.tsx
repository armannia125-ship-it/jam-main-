"use client";

/* صفحهٔ اصلی — بازسازی دقیق DOM مرجع (/tmp/.../dom/home.html → <!-- APP -->) */

import { useState } from "react";
import Link from "next/link";
import {
  ACTIVE_STATUS,
  CATS,
  MEDIA,
  STORES,
  STORE_PHOTOS,
  discPct,
  store,
  type Product,
  type Store,
} from "@/lib/data";
import { fa } from "@/lib/format";
import { useJam } from "@/lib/state";
import Ic from "@/components/icons";
import StoreCard from "./store-card";
import ProductCard from "./product-card";
import { ActiveOrderBanner, RepeatSection } from "./home-parts";

/* فروشگاه‌های پیشنهاد صفحهٔ اصلی — به ترتیب DOM مرجع: s8, s2, s4, s10 */
const HOME_STORES = ["s8", "s2", "s4", "s10"];

/* کارت‌های «جم، فقط سفارش غذا نیست» — دقیقاً مطابق مرجع */
const EVERYDAY: [string, string, string][] = [
  ["s4", "خریدهای هر روز", "یک سبد تازه برای خانه"],
  ["s6", "به سلیقه خودت", "پوشاک و انتخاب‌های تازه"],
  ["s9", "وقتت برای خودت", "کارها را به متخصصش بسپار"],
];

/* کارت‌های قصد خرید — مطابق nav.ux-intents مرجع */
const INTENTS: { cls: string; cat: string; b: string; span: string; img: string }[] = [
  { cls: "restaurant", cat: "restaurant", b: "غذا و نوشیدنی", span: "برای یک وعدهٔ دلچسب", img: "/media/grill.webp" },
  { cls: "market", cat: "market", b: "سوپرمارکت", span: "خریدهای روزانه و محلی", img: "/media/produce.webp" },
  { cls: "hyper", cat: "hyper", b: "هایپر و زنجیره‌ای", span: "افق کوروش، رفاه و بیشتر", img: "/media/retail-oil.webp" },
  { cls: "services", cat: "services", b: "خدمات محلی", span: "کارها را به متخصص بسپار", img: "/media/laundry.webp" },
];

export function HomePage() {
  const { orders } = useJam();
  const [mode, setMode] = useState<"delivery" | "pickup">("delivery");

  const activeOrder = orders
    .filter((o) => ACTIVE_STATUS.includes(o.status))
    .sort((a, b) => b.placedAt - a.placedAt)[0];

  /* خوش‌قیمت‌های امروز: محصولات تخفیف‌دار موجود، مرتب بر اساس درصد تخفیف */
  const deals = STORES.filter((s) => !s.retail)
    .flatMap((s) => s.products.map((p) => ({ p, s })))
    .filter(({ p }) => p.available && p.old > p.price)
    .sort((a, b) => discPct(b.p) - discPct(a.p))
    .slice(0, 4);

  const chains = STORES.filter((s) => s.retail);

  const homeStores = HOME_STORES.map((id) => store(id)).filter((s): s is Store => !!s);

  return (
    <>
    <div className="container home-v4 ux-home life-home">
      {activeOrder ? <ActiveOrderBanner o={activeOrder} /> : null}
      <section className="ux-welcome">
        <div>
          <span className="ux-overline">زندگی در جم، کمی ساده‌تر</span>
          <h1>امروز چی لازم داری؟</h1>
          <p>غذا، سوپرمارکت، فروشگاه زنجیره‌ای و خدمات؛ یک‌جا در جم لایف.</p>
        </div>
        <Link href="/search?f=open&sort=near" className="ux-live-link">
          <span className="dot" />
          باز و نزدیک <Ic n="chevL" c="sm" />
        </Link>
      </section>
      <nav className="ux-intents" aria-label="شروع سریع خرید">
        {INTENTS.map((it) => (
          <Link key={it.cls} href={`/search?cat=${it.cat}`} className={`ux-intent life-intent-${it.cls}`}>
            <div>
              <b>{it.b}</b>
              <span>{it.span}</span>
              <i>
                <Ic n="arrowL" c="sm" />
              </i>
            </div>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={it.img} alt="" loading="eager" />
          </Link>
        ))}
      </nav>
      <RepeatSection orders={orders} />
      <details className="ux-categories">
        <summary>
          <Ic n="grid" />
          همهٔ دسته‌بندی‌ها <Ic n="chevD" c="sm" />
        </summary>
        <nav className="v4-services" aria-label="دسته‌بندی‌ها">
          {CATS.map((c, i) => (
            <Link key={c.id} href={`/search?cat=${c.id}`}>
              <span className={`svc-ic svc-${i}`}>
                <Ic n={c.icon} c="lg" />
              </span>
              <span>
                <b>{c.name}</b>
                <small>{c.sub}</small>
              </span>
              <Ic n="chevL" c="sm" />
            </Link>
          ))}
        </nav>
      </details>
      <section className="section v4-recommend">
        <div className="section-intro">
          <div>
            <span className="overline">بر اساس نزدیکی و سابقهٔ شما</span>
            <h2>پیشنهادهای امروز</h2>
          </div>
          <Link href="/search" className="text-action">
            همه <Ic n="arrowL" c="sm" />
          </Link>
        </div>
        <div className="v4-filter-row">
          <div className="v4-filter-tabs">
            <Link href="/search" className="on">
              پیشنهاد جم
            </Link>
            <Link href="/search?sort=near" className="">
              نزدیک‌ترین
            </Link>
            <Link href="/search?sort=rate" className="">
              بیشترین امتیاز
            </Link>
            <Link href="/search?f=discount" className="">
              تخفیف‌دار
            </Link>
          </div>
          <div className="home-mode">
            <div className="seg" role="tablist" aria-label="روش دریافت">
              <button
                type="button"
                role="tab"
                aria-selected={mode === "delivery"}
                className={mode === "delivery" ? "on" : ""}
                data-act="mode"
                data-v="delivery"
                onClick={() => setMode("delivery")}
              >
                <Ic n="truck" />
                ارسال به محل
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={mode === "pickup"}
                className={mode === "pickup" ? "on" : ""}
                data-act="mode"
                data-v="pickup"
                onClick={() => setMode("pickup")}
              >
                <Ic n="walk" />
                تحویل حضوری
              </button>
            </div>
          </div>
        </div>
        <div className="grid-stores home-store-grid">
          {homeStores.map((s) => (
            <StoreCard key={s.id} s={s} pickupMode={mode === "pickup"} />
          ))}
        </div>
      </section>
      <section className="life-home-chains">
        <div className="life-section-header">
          <div>
            <span>یک کاتالوگ متفاوت برای خرید سبدی</span>
            <h2>هایپرمارکت‌ها و فروشگاه‌های زنجیره‌ای</h2>
          </div>
          <Link href="/search?cat=hyper">
            همه <Ic n="arrowL" c="sm" />
          </Link>
        </div>
        <div className="life-chain-grid">
          {chains.map((s) => (
            <article
              key={s.id}
              className="store-card life-chain-card"
              style={s.chainColor ? ({ "--chain-color": s.chainColor } as React.CSSProperties) : undefined}
            >
              <Link href={`/store/${s.id}`} className="life-chain-link" aria-label={`کاتالوگ نمایشی ${s.name}`}>
                <span className="life-chain-logo" style={s.id === "h1" ? { fontSize: 15 } : undefined}>
                  {s.chainShort}
                </span>
                <span>
                  <small>فروشگاه زنجیره‌ای · نمونه</small>
                  <h3>{s.name}</h3>
                  <span>{fa(s.products.length)} کالای نمونه · خرید سبدی</span>
                </span>
                <Ic n="chevL" c="sm" />
              </Link>
              <div className="life-chain-meta">
                <span>
                  <Ic n="pkg" c="sm" />
                  کالاهای بسته‌بندی
                </span>
                <Link href={`/store/${s.id}`}>
                  دیدن کاتالوگ <Ic n="arrowL" c="sm" />
                </Link>
              </div>
            </article>
          ))}
        </div>
        <p className="life-sample-note">این فروشگاه‌ها و کاتالوگ‌ها نمونهٔ نمایشی‌اند و به شعبهٔ واقعی متصل نیستند.</p>
      </section>
      <section className="c7-home-club">
        <div>
          <span>خرید حضوری، بدون پیچیدگی</span>
          <h2>از اعضای باشگاه خرید کن.</h2>
          <p>کد خرید را نشان بده؛ فروشنده تأیید می‌کند و مسیر پاداش خرید و بازی باز می‌شود.</p>
        </div>
        <Link href="/club" className="btn btn-ghost">
          فروشگاه‌های عضو باشگاه
        </Link>
      </section>
      <section className="v4-deals section">
        <div className="deals-heading">
          <span className="overline">خوش‌قیمت‌های امروز</span>
          <h2>
            بیشتر لذت ببر.
            <br />
            <span>کمتر پرداخت کن.</span>
          </h2>
          <p>
            تخفیف روی محصولات منتخب
            <br />
            کسب‌وکارهای جم.
          </p>
          <Link href="/search?f=discount" className="btn btn-primary">
            دیدن همه <Ic n="arrowL" c="sm" />
          </Link>
          <div className="deals-symbol" aria-hidden="true">
            ٪
          </div>
        </div>
        <div className="hscroll">
          {deals.map(({ p, s }: { p: Product; s: Store }) => (
            <ProductCard key={p.id} p={p} s={s} />
          ))}
        </div>
      </section>
      <section className="v4-hero" aria-label="کشف جم">
        <div className="hero-main">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/media/home.webp" alt="برگر تازه با سبزیجات" fetchPriority="high" />
          <div className="hero-shade" />
          <div className="hero-copy">
            <span className="eyebrow">
              <i />
              برای هر روزِ شما
            </span>
            <h2 className="ux-editorial-title">
              هر چی بخوای،
              <br />
              <span>همین نزدیکی‌ست.</span>
            </h2>
            <p>
              از یک وعده دلچسب تا خریدهای هر روز؛
              <br />
              انتخاب‌های خوب شهر، یک‌جا در جم.
            </p>
            <Link href="/search" className="hero-action">
              کشف کسب‌وکارها <Ic n="arrowL" />
            </Link>
          </div>
          <Link href="/store/s3" className="hero-credit">
            <span className="credit-logo" style={{ fontSize: 10 }}>
              ساحل
            </span>
            <span>
              طعمِ یک انتخاب خوب
              <small>
                فست‌فود ساحل <Ic n="arrowL" c="sm" />
              </small>
            </span>
          </Link>
        </div>
        <div className="hero-side">
          <Link href="/search?cat=market" className="daily-story">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={MEDIA.produce} alt="میوه و سبزیجات تازه" />
            <div>
              <span>از سبد تا درِ خانه</span>
              <h2>
                خرید روزانه،
                <br />
                بدون رفت‌وآمد.
              </h2>
              <span className="story-arrow">
                <Ic n="arrowL" />
              </span>
            </div>
          </Link>
          <Link href="/search?f=pickup" className="pickup-story" data-act="mode-link" data-v="pickup">
            <span className="pickup-icon">
              <Ic n="walk" c="lg" />
            </span>
            <div>
              <span>سفارش آنلاین، تحویل حضوری</span>
              <h2>سرِ راه بردار.</h2>
              <p>
                بدون هزینه ارسال <Ic n="arrowL" c="sm" />
              </p>
            </div>
          </Link>
        </div>
      </section>
      <section className="section everyday-section">
        <div className="section-intro">
          <div>
            <span className="overline">همراه زندگی روزمره</span>
            <h2>جم، فقط سفارش غذا نیست.</h2>
          </div>
          <Link href="/search" className="text-action">
            بیشتر ببینید <Ic n="arrowL" c="sm" />
          </Link>
        </div>
        <div className="everyday-grid">
          {EVERYDAY.map(([id, t, d]) => {
            const s = store(id);
            if (!s) return null;
            return (
              <Link key={id} href={`/store/${id}`} className="everyday-card">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={`/media/${STORE_PHOTOS[s.id] || "grill"}.webp`} alt="" loading="lazy" />
                <div>
                  <small>{t}</small>
                  <h3>{d}</h3>
                  <span>
                    {s.name} <Ic n="arrowL" c="sm" />
                  </span>
                </div>
              </Link>
            );
          })}
        </div>
      </section>
      <section id="jg-market-promo" className="container life-reward-bridge">
        <span className="life-reward-icon">
          <Ic n="spark" c="lg" />
        </span>
        <div>
          <span>جم‌پلی · انتخابی برای وقت آزاد</span>
          <h2>پاداش بازی، برای خرید بعدی.</h2>
          <p>خرید حضوری تأییدشده یا آنلاین تحویل‌شده + بازی ← پاداش بودجه‌دار</p>
        </div>
        <Link href="/play?tab=rewards" className="life-reward-button">
          دیدن پاداش‌ها <Ic n="arrowL" c="sm" />
        </Link>
      </section>
      <details className="life-business-fold">
        <summary>
          <Ic n="brief" /> جم لایف برای کسب‌وکارها <Ic n="chevD" c="sm" />
        </summary>
        <section className="v4-partner section">
          <div>
            <span className="overline">جم برای کسب‌وکارها</span>
            <h2>
              از یک آدرس،
              <br />
              به انتخابِ هر روز مشتری‌ها.
            </h2>
            <p>
              ویترین فروشگاه، منوی دیجیتال و سفارش آنلاین.
              <br />
              ابزارهای فروش شما؛ ساده، یکپارچه و در دسترس.
            </p>
            <Link href="/business" className="btn btn-primary btn-lg">
              شروع همکاری با جم <Ic n="arrowL" />
            </Link>
          </div>
          <div className="partner-proof">
            <span>
              <Ic n="qr" c="lg" />
            </span>
            <b>
              منوی شما.
              <br />
              همیشه در دسترس.
            </b>
            <Link href="/m/nakhl">
              مشاهده منوی نمونه <Ic n="arrowL" c="sm" />
            </Link>
            <div className="partner-mini">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={MEDIA.grill} alt="" loading="lazy" />
              <span>
                رستوران سنتی نخل
                <small>منوی دیجیتال • سفارش آنلاین</small>
              </span>
            </div>
          </div>
        </section>
      </details>
    </div>
    <aside className="qa13-demo-bar container">
      <span>نمونهٔ محلی؛ پرداخت و واریز واقعی ندارد.</span>
      <Link href="/panel/settings">محدودیت‌های امنیت</Link>
    </aside>
    </>
  );
}
