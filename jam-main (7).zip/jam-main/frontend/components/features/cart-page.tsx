"use client";

import Link from "next/link";

export function CartPage() {
  return (
    <main>
      <div className="page-title">
        <h1>سبد خرید</h1>
        <div className="crumbs">
          <Link href="/">جم لایف</Link>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" className="ic sm" aria-hidden="true"><path d="m9 18 6-6-6-6" /></svg>
          <span>سبد خرید</span>
        </div>
      </div>

      <div className="cart-layout">
        <div>
          {/* cart is empty — honest empty state */}
          <div className="card cart-empty-state">
            <div className="e-ic">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" className="ic" aria-hidden="true"><path d="M3 3h18v18H3zM12 8v8m-4-4h8" /></svg>
            </div>
            <h3>سبد خرید شما خالی است</h3>
            <p className="muted">هیچ محصولی اضافه نشده است.</p>
            <Link href="/search" className="btn btn-primary">
              شروع خرید ←
            </Link>
          </div>
        </div>

        <aside className="cart-summary">
          {/* placeholder for summary */}
        </aside>
      </div>
    </main>
  );
}
