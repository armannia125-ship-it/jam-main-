"use client";
/* =========================================================
   جم لایف — پوستهٔ مشترک پنل فروشنده (لایهٔ نهایی g10)
   مطابق DOM مرجع jam-life.html (sidebar سه‌گروهی + انتخابگر
   بخش پنل + کارت اشتراک‌ها + ناوبری فروشنده در موبایل).
   Export shape:
   - default  PanelShell({ children, mainClass? }) → .panel = .p-side + .p-main
   - usePanelSid() → { sid, setSid }   (فروشگاه انتخابی پنل؛ پیش‌فرض s1)
   - PTop({ title, sub, actions })      → سربرگ تب‌های پنل (.p-top)
   - EmptyBlock({ icon, title, desc })  → حالت خالی مطابق مرجع
   - PlanCard({ p, cur?, onSelect })    → کارت پلن اشتراک
   - ProductArt({ p, sid? })            → عکس یا نماد محصول (مطابق مرجع)
   - BrandMark({ s })                   → مونوگرام فروشگاه
   ========================================================= */

import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { STORES, STORE_NAMES, productPhoto, type Plan, type Product, type Store } from "@/lib/data";
import { fa } from "@/lib/format";
import { statusLabel, useCommerce } from "@/lib/commerce";
import Ic from "@/components/icons";

/* ناوبری فروشنده در موبایل (#g10-seller-nav) — مطابق مرجع */
const SELLER_NAV: [string, string, string][] = [
  ["/panel", "خانه پنل", "dash"],
  ["/panel/orders", "سفارش‌ها", "list"],
  ["/panel/menu", "منو", "qr"],
];

/* گروه‌های سایدبار — برچسب‌ها و آیکن‌ها دقیقاً مطابق DOM مرجع.
   مقصدهای بدون مسیر موجود به نزدیک‌ترین مسیر نگاشت شده‌اند. */
type SideItem = { key: string; label: string; icon: string; href: string };
const SIDE_GROUPS: [string, SideItem[]][] = [
  [
    "کارهای روزمره",
    [
      { key: "overview", label: "خانه پنل", icon: "dash", href: "/panel" },
      { key: "orders", label: "سفارش‌ها", icon: "list", href: "/panel/orders" },
      { key: "menu", label: "ویرایش منو و QR", icon: "qr", href: "/panel/menu" },
      { key: "products", label: "محصول و قیمت", icon: "layers", href: "/panel/products" },
      { key: "inperson", label: "تأیید خرید حضوری", icon: "qr", href: "/panel/inperson" },
    ],
  ],
  [
    "رشد فروشگاه",
    [
      { key: "my-subscriptions", label: "اشتراک‌ها", icon: "card", href: "/panel/subscriptions" },
      { key: "subscriptions", label: "همه اشتراک‌ها", icon: "card", href: "/panel/plan" },
      { key: "menu-plan", label: "اشتراک منو", icon: "qr", href: "/panel/menu" },
      { key: "plan", label: "اشتراک باشگاه", icon: "spark", href: "/panel/plan" },
      { key: "gold", label: "اشتراک طلایی", icon: "star", href: "/panel/plan" },
      { key: "campaigns", label: "کمپین خرید و بازی", icon: "brief", href: "/revenue" },
      { key: "ads", label: "تبلیغات اختیاری", icon: "brief", href: "/revenue" },
      { key: "metrics", label: "گزارش باشگاه", icon: "dash", href: "/panel/metrics" },
    ],
  ],
  [
    "حساب و تنظیمات",
    [
      { key: "finance", label: "صورتحساب‌ها", icon: "brief", href: "/revenue" },
      { key: "settlement", label: "حساب مقصد و تسهیم", icon: "card", href: "/panel/settlement" },
      { key: "agreement", label: "شرایط همکاری", icon: "list", href: "/panel/agreement" },
      { key: "settings", label: "تنظیمات فروشگاه", icon: "sliders", href: "/panel/settings" },
      { key: "security", label: "امنیت و حریم خصوصی", icon: "shield", href: "/panel/settings" },
    ],
  ],
];

/* انتخابگر «بخش پنل» — گزینه‌ها دقیقاً مطابق DOM مرجع (مقدار = مسیر مرجع) */
const PICKER_OPTS: [string, string, string][] = [
  ["#/panel/overview", "داشبورد", "/panel"],
  ["#/panel/orders", "سفارش‌ها", "/panel/orders"],
  ["#/panel/my-subscriptions", "اشتراک‌ها (خرید و سوابق)", "/panel/subscriptions"],
  ["#/panel/products", "محصولات و قیمت", "/panel/products"],
  ["#/panel/menu", "منوی دیجیتال و QR", "/panel/menu"],
  ["#/panel/subscriptions", "همه اشتراک‌ها", "/panel/plan"],
  ["#/panel/menu-plan", "اشتراک منوی دیجیتال", "/panel/menu"],
  ["#/panel/plan", "اشتراک جذب و بازگشت مشتری", "/panel/plan"],
  ["#/panel/settings", "تنظیمات فروشگاه", "/panel/settings"],
  ["#/panel/finance", "کمیسیون و صورتحساب", "/revenue"],
  ["#/panel/campaigns", "کمپین خرید و بازی", "/revenue"],
  ["#/panel/ads", "تبلیغات و حامی", "/revenue"],
  ["#/revenue", "مرکز درآمد · مدیریت نمونه", "/revenue"],
  ["#/panel/inperson", "خرید حضوری و اسکن", "/panel/inperson"],
  ["#/panel/settlement", "تسهیم و حساب مقصد", "/panel/settlement"],
  ["#/panel/agreement", "شرایط همکاری", "/panel/agreement"],
  ["#/panel/metrics", "گزارش باشگاه", "/panel/metrics"],
  ["#/panel/gold", "اشتراک طلایی", "/panel/plan"],
  ["#/panel/security", "امنیت و حریم خصوصی", "/panel/settings"],
];

type PanelSid = { sid: number | null; setSid: (id: number) => void };
const PanelSidCtx = createContext<PanelSid>({ sid: null, setSid: () => {} });

/** فروشگاه انتخاب‌شدهٔ پنل — داخل محتوای تب‌ها مصرف می‌شود */
export function usePanelSid(): PanelSid {
  return useContext(PanelSidCtx);
}

export default function PanelShell({ children, mainClass }: { children: React.ReactNode; mainClass?: string }) {
  const pathname = usePathname() ?? "/panel";
  const router = useRouter();
  const { ready, loading, error, loginRequired, businesses, sid, setSid, storeOf, business, refresh } = useCommerce();
  const current = business(sid);
  const clubStatus = current ? statusLabel(current.club.status, current.club.is_active, current.club.trial_used) : "—";
  const s = storeOf(sid) || STORES[0];
  const [toolsOpen, setToolsOpen] = useState(false);

  /* بدنهٔ صفحه در مرجع برای پنل کلاس g10-panel می‌گیرد (CSS ناوبری فروشنده و سایدبار) */
  useEffect(() => {
    document.body.classList.add("g10-panel");
    return () => document.body.classList.remove("g10-panel");
  }, []);

  const ctx = useMemo<PanelSid>(() => ({ sid, setSid }), [sid, setSid]);

  /* گزینهٔ انتخابگر مطابق مسیر جاری */
  const pickerValue = useMemo(() => {
    const hit = PICKER_OPTS.find(([, , to]) => (to === "/panel" ? pathname === "/panel" : pathname.startsWith(to)));
    return hit ? hit[0] : undefined;
  }, [pathname]);

  if (loginRequired) {
    return (
      <div className="container rv" style={{ maxWidth: 620 }}>
        <section className="rv-card">
          <h1>برای مدیریت فروشگاه وارد شوید</h1>
          <p>پنل فروشنده، باشگاه، درآمد و تسویه فقط با حساب صاحب فروشگاه در دسترس است.</p>
          <Link className="btn btn-primary" href="/login">
            ورود / ثبت‌نام
          </Link>
        </section>
      </div>
    );
  }

  if (loading && !businesses.length) {
    return (
      <div className="container rv">
        <p className="rv-empty">در حال دریافت فروشگاه‌های شما…</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container rv">
        <section className="rv-card">
          <h1>دریافت اطلاعات ناموفق بود</h1>
          <p className="c7-error" role="alert">{error}</p>
          <button type="button" className="btn btn-primary" onClick={() => refresh()}>
            تلاش دوباره
          </button>
        </section>
      </div>
    );
  }

  if (ready && businesses.length === 0) {
    return (
      <div className="container rv">
        <section className="rv-card">
          <h1>هنوز فروشگاهی به این حساب وصل نیست</h1>
          <p>برای مدیریت باشگاه، درآمد و تسویه، ابتدا یک کسب‌وکار برای این حساب ایجاد کنید.</p>
          <Link className="btn btn-ghost" href="/">
            بازگشت به بازار جم
          </Link>
        </section>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="panel">
        <aside className="card p-side" aria-label="منوی پنل">
          <div className="p-store">
            <span className={`lg tone tone-${s.tone}`}>
              <BrandMark s={s} />
            </span>
            <div className="grow">
              <label className="sr" htmlFor="p-sw">
                انتخاب فروشگاه
              </label>
              <select id="p-sw" value={sid ?? ""} onChange={(e) => setSid(Number(e.target.value))}>
                {businesses.map((x) => (
                  <option key={x.id} value={x.id}>
                    {x.name}
                  </option>
                ))}
              </select>
              <div className="faint" style={{ fontSize: 14 }}>
                پنل فروشنده · نسخه نمایشی
              </div>
            </div>
          </div>
          <label className="ui-panel-picker">
            <span>بخش پنل</span>
            <select id="ui-panel-nav" aria-label="انتخاب بخش پنل" value={pickerValue} onChange={(e) => router.push(PICKER_OPTS.find(([v]) => v === e.target.value)?.[2] || "/panel")}>
              {!pickerValue ? <option value="" hidden /> : null}
              {PICKER_OPTS.map(([v, l]) => (
                <option key={v} value={v}>
                  {l}
                </option>
              ))}
            </select>
          </label>
          <nav className="p-nav" aria-label="بخش‌های پنل فروشنده" style={toolsOpen ? { display: "block" } : undefined}>
            {SIDE_GROUPS.map(([title, items]) => (
              <section className="g10-sidebar-group" key={title}>
                <h3>{title}</h3>
                {items.map((it) => {
                  const on = pathname === it.href || (it.href !== "/panel" && pathname.startsWith(it.href));
                  return (
                    <Link key={it.key} href={it.href} className={on ? "on" : ""} aria-current={on ? "page" : undefined}>
                      <Ic n={it.icon} />
                      {it.label}
                    </Link>
                  );
                })}
              </section>
            ))}
            <Link href="/panel" data-g10="operator">
              مدیریت پلتفرم · نمونه
            </Link>
          </nav>
          <div className="sub-card">
            <b>اشتراک‌های این فروشگاه</b>
            <Link className="m9-side-status" href="/panel/menu">
              <span>منوی دیجیتال</span>
              <strong>فعال نشده</strong>
            </Link>
            <Link className="m9-side-status" href="/panel/plan">
              <span>باشگاه حضوری</span>
              <strong>{clubStatus}</strong>
            </Link>
            <Link href="/panel/plan" className="link">
              مدیریت همه اشتراک‌ها
            </Link>
          </div>
          <div className="g10-panel-tools">
            <button className="btn btn-ghost" data-g10="tools" aria-expanded={toolsOpen} onClick={() => setToolsOpen((v) => !v)}>
              <Ic n="grid" c="sm" />
              ابزارهای پنل
            </button>
          </div>
        </aside>
        <PanelSidCtx.Provider value={ctx}>
          <div className={`p-main rv g10-main${mainClass ? ` ${mainClass}` : ""}`}>
            <div className="ui-panel-context">
              <span>
                <Ic n="brief" c="sm" />
                پنل {s.name}
              </span>
              <Link href={`/m/${current?.slug || ""}`}>
                دیدن منوی عمومی <Ic n="chevL" c="sm" />
              </Link>
            </div>
            {children}
          </div>
        </PanelSidCtx.Provider>
      </div>
      <nav id="g10-seller-nav" aria-label="ناوبری فروشنده">
        {SELLER_NAV.map(([href, label, icon]) => {
          const on = pathname === href;
          return (
            <Link key={href} href={href} aria-current={on ? "page" : undefined}>
              <Ic n={icon} />
              <span>{label}</span>
            </Link>
          );
        })}
        <button type="button" onClick={() => setToolsOpen((v) => !v)}>
          <Ic n="grid" />
          <span>همه ابزارها</span>
        </button>
      </nav>
      <aside className="qa13-demo-bar container">
        <span>اطلاعات این پنل از سرور خوانده می‌شود؛ پرداخت و واریز بانکی واقعی متصل نیست.</span>
        <Link href="/panel/settings">محدودیت‌های امنیت</Link>
      </aside>
    </div>
  );
}

export function PTop({ title, sub, actions }: { title: React.ReactNode; sub?: React.ReactNode; actions?: React.ReactNode }) {
  return (
    <div className="p-top">
      <div>
        <h1 tabIndex={-1}>{title}</h1>
        {sub ? <p className="p-sub">{sub}</p> : null}
      </div>
      {actions ? <div className="row" style={{ flexWrap: "wrap" }}>{actions}</div> : null}
    </div>
  );
}

export function EmptyBlock({ icon, title, desc, children }: { icon: string; title: string; desc?: string; children?: React.ReactNode }) {
  return (
    <div className="empty">
      <span className="e-ic">
        <Ic n={icon} />
      </span>
      <b>{title}</b>
      {desc ? <p>{desc}</p> : null}
      {children}
    </div>
  );
}

export function BrandMark({ s }: { s: Store }) {
  return <span className={`brand-monogram bm-${s.id}`}>{STORE_NAMES[s.id] || s.name.split(" ")[0]}</span>;
}

export function ProductArt({ p, sid }: { p: Product; sid?: string }) {
  const photo = productPhoto(p, sid);
  if (photo) return <img className="media-photo" src={photo} alt="" loading="lazy" />;
  const n = p.name || "";
  const icon = /نوش|دوغ|ماست|آب/.test(n) ? "coffee" : "pkg";
  return (
    <span className="product-symbol">
      <Ic n={icon} />
    </span>
  );
}

export function PlanCard({ p, cur, onSelect }: { p: Plan; cur?: string; onSelect: (id: string) => void }) {
  const isCur = cur === p.id;
  return (
    <div className={`card plan${p.pop ? " pop" : ""}`}>
      {p.pop ? <span className="ribbon">پیشنهاد ما</span> : null}
      <div>
        <h3>{p.name}</h3>
        <div className="muted" style={{ fontSize: 14 }}>
          {p.desc}
        </div>
      </div>
      <div className="pp tnum">
        {fa(p.price / 1000)} <small>هزار تومان / ماه</small>
      </div>
      <ul>
        {p.feats.map(([f, on]) => (
          <li key={f} className={on ? "" : "off"}>
            <Ic n={on ? "check" : "x"} />
            {f}
          </li>
        ))}
      </ul>
      <div style={{ marginTop: "auto" }}>
        {isCur ? (
          <button className="btn btn-ghost btn-block" disabled>
            اشتراک فعلی شما
          </button>
        ) : (
          <button className={`btn ${p.pop ? "btn-primary" : "btn-soft"} btn-block`} onClick={() => onSelect(p.id)}>
            {cur ? "تغییر به این پلن" : `انتخاب ${p.name}`}
          </button>
        )}
      </div>
    </div>
  );
}
