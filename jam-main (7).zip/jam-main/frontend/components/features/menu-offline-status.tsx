"use client";

/* =========================================================
   نوار وضعیت آفلاین منوی عمومی:
   - هنگام قطع شبکه اطلاع می‌دهد که نسخهٔ ذخیره‌شده باز شده است.
   - «آخرین به‌روزرسانی» را از هدر x-jam-cached-at سرویس‌ورکر می‌خواند.
   - با بازگشت اتصال، منو را دوباره واکشی می‌کند و کش تازه می‌شود.
   ========================================================= */

import { useCallback, useEffect, useState } from "react";

export default function MenuOfflineStatus() {
  const [online, setOnline] = useState(true);
  const [cachedAt, setCachedAt] = useState<number | null>(null);
  const [refreshed, setRefreshed] = useState(false);

  const readCachedAt = useCallback(async () => {
    if (typeof caches === "undefined") return;
    try {
      const cacheNames = await caches.keys();
      for (const name of cacheNames) {
        if (!name.startsWith("jam-menus-")) continue;
        const cache = await caches.open(name);
        const hit = await cache.match(window.location.pathname, { ignoreSearch: false });
        if (hit) {
          const t = hit.headers.get("x-jam-cached-at");
          if (t) setCachedAt(Number(t));
          return;
        }
      }
    } catch {
      /* بدون کش */
    }
  }, []);

  useEffect(() => {
    setOnline(navigator.onLine);
    readCachedAt();
    const goOffline = () => setOnline(false);
    const goOnline = () => {
      setOnline(true);
      setRefreshed(false);
      /* با بازگشت اتصال، نسخهٔ تازه منو را می‌گیریم و کش به‌روز می‌شود */
      navigator.serviceWorker?.ready.then((reg) => {
        reg.active?.postMessage({ type: "JAM_REFRESH_MENU", url: window.location.pathname });
      });
      fetch(window.location.pathname, { cache: "no-store" })
        .then(() => {
          setRefreshed(true);
          setTimeout(() => readCachedAt(), 600);
        })
        .catch(() => {});
    };
    const onMsg = (e: MessageEvent) => {
      if (e.data?.type === "JAM_MENU_CACHED" && e.data.url === window.location.pathname) readCachedAt();
    };
    window.addEventListener("offline", goOffline);
    window.addEventListener("online", goOnline);
    navigator.serviceWorker?.addEventListener("message", onMsg);
    return () => {
      window.removeEventListener("offline", goOffline);
      window.removeEventListener("online", goOnline);
      navigator.serviceWorker?.removeEventListener("message", onMsg);
    };
  }, [readCachedAt]);

  return (
    <div className="jam-offline-status" role="status" aria-live="polite">
      {!online ? (
        <p className="c7-small" style={{ margin: 0 }}>
          اینترنت قطع است؛ نسخهٔ ذخیره‌شدهٔ منو باز شده است.
          {cachedAt ? ` آخرین به‌روزرسانی: ${new Date(cachedAt).toLocaleString("fa-IR", { dateStyle: "medium", timeStyle: "short" })}.` : ""}
        </p>
      ) : cachedAt ? (
        <p className="c7-small" style={{ margin: 0 }}>
          {refreshed ? "منو به‌روزرسانی شد. " : ""}
          نسخهٔ آفلاین ذخیره شده است؛ آخرین به‌روزرسانی:{" "}
          {new Date(cachedAt).toLocaleString("fa-IR", { dateStyle: "medium", timeStyle: "short" })}.
        </p>
      ) : null}
    </div>
  );
}
