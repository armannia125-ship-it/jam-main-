"use client";

/* صفحهٔ فروشگاه — رستوران/فروشگاه استاندارد + کاتالوگ زنجیره‌ای (retail)
   دقیقاً مطابق دامپ‌های store-s1.html و retail-h1.html */
import { useMemo, useState, type CSSProperties } from "react";
import Link from "next/link";
import { Ic } from "@/components/icons";
import {
  store as findStore,
  productPhoto,
  openState,
  hoursText,
  deliveryFee,
  deliveryEta,
  prepText,
  discPct,
  brandMonogram,
  STORE_PHOTOS,
  STORES,
  CATS,
  type Product,
  type Store,
} from "@/lib/data";
import { fa, faD, tomanT, norm } from "@/lib/format";
import { useJam } from "@/lib/state";
import { QtyCtl } from "@/components/features/store-card";
import { CartBox } from "@/components/features/cart-box";
import { usePublicClubStores } from "@/lib/commerce";

/* ---------- ردیف محصول منو (مشترک بین صفحهٔ فروشگاه و منوی دیجیتال) ---------- */
export function Item({ p, s, id }: { p: Product; s: Store; id: string }) {
  const photo = productPhoto(p, s.id);
  const pct = discPct(p);
  return (
    <article className={`item${p.available ? "" : " na"}`} id={id}>
      <button type="button" className="item-open" aria-label={`جزئیات ${p.name}`}>
        <span className="item-photo">
          {photo ? (
            /* eslint-disable-next-line @next/next/no-img-element */
            <img className="media-photo" src={photo} alt="" loading="lazy" />
          ) : (
            <span className="product-symbol">
              <Ic n="pkg" />
            </span>
          )}
          {p.pop ? <span className="item-choice">پیشنهاد جم</span> : null}
        </span>
        <span className="item-info">
          <h3>{p.name}</h3>
          <span className="item-description">{p.desc}</span>
          {!p.available ? <span className="sold-label">فعلاً ناموجود</span> : null}
        </span>
      </button>
      <div className="item-purchase">
        <div className="item-price">
          {pct > 0 && p.old > 0 ? (
            <span className="item-old">
              <s>{fa(p.old)}</s>
              <span>{fa(pct)}٪</span>
            </span>
          ) : null}
          <span>
            <b className="tnum">{fa(p.price)}</b>
            <small>تومان</small>
          </span>
        </div>
        <QtyCtl product={p} s={s} />
      </div>
    </article>
  );
}

/* ---------- بخش منو ---------- */
function MenuSec({ s, title, items, id }: { s: Store; title: string; items: Product[]; id: string }) {
  return (
    <section className="menu-sec" id={id}>
      <div className="menu-section-heading">
        <h2>{title}</h2>
        <span>{fa(items.length)} محصول</span>
      </div>
      <div className="items">
        {items.map((p) => (
          <Item key={p.id} p={p} s={s} id={`${id === "sec-pop" ? "pop" : "it"}-${p.id}`} />
        ))}
      </div>
    </section>
  );
}

/* ---------- کرامب‌ها ---------- */
function Crumbs({ s }: { s: Store }) {
  const catName = CATS.find((c) => c.id === s.cat)?.name || "";
  return (
    <div className="crumbs">
      <Link href="/" className="ui-tap-link">
        جم لایف
      </Link>
      <Ic n="chevL" c="sm" />
      <Link href={`/search?cat=${s.cat}`} className="ui-tap-link">
        {catName}
      </Link>
      <Ic n="chevL" c="sm" />
      <span>{s.name}</span>
    </div>
  );
}

/* ---------- صفحهٔ فروشگاه استاندارد ---------- */
function StandardStorefront({ s }: { s: Store }) {
  const { favs, toggleFav, toast } = useJam();
  const { data: clubStores } = usePublicClubStores();
  const clubEntry = clubStores.find((c) => c.slug === s.slug);
  const clubActive = !!clubEntry;
  const clubPerk = clubEntry?.offer || "";
  const [q, setQ] = useState("");
  const st = openState(s);
  const fav = favs.includes(s.id);

  const popItems = useMemo(() => s.products.filter((p) => p.pop), [s]);
  const secs = useMemo(
    () =>
      s.sections.map((title, i) => ({
        title,
        id: `sec-${i}`,
        items: s.products.filter((p) => p.sec === title),
      })),
    [s],
  );

  const filtering = norm(q).length > 0;
  const match = (p: Product) => norm(p.name).includes(norm(q)) || norm(p.desc).includes(norm(q));

  const openOthers = STORES_OPEN(s);

  return (
    <div className="container storefront">
      <Crumbs s={s} />

      <section className="store-profile">
        <div className="store-profile-copy">
          <div className="store-profile-top">
            <span className="profile-logo">
              <span className={`brand-monogram bm-${s.id}`}>{s.chainShort || brandMonogram(s)}</span>
            </span>
            <div className="grow">
              <span className={`profile-state${st.open ? "" : " closed"}`}>
                <span className="dot" />
                {st.open ? "سفارش می‌پذیرد" : "پیش‌سفارش برای زمان بازگشایی"}
              </span>
              <h1>{s.name}</h1>
              <span className="profile-tagline">{s.tagline}</span>
            </div>
            <button
              type="button"
              className="icon-btn"
              aria-pressed={fav}
              aria-label="ذخیره فروشگاه"
              onClick={() => {
                toggleFav(s.id);
                toast(fav ? "از علاقه‌مندی‌ها حذف شد" : "به علاقه‌مندی‌ها اضافه شد");
              }}
            >
              <Ic n="heart" />
            </button>
          </div>
          <div className="profile-meta">
            <span className="profile-rating">
              <Ic n="star" c="sm" />
              <b>{fa(s.rating)}</b>
              <span>از {fa(s.reviews)} نظر</span>
            </span>
            <span>
              <Ic n="clock" c="sm" />
              {hoursText(s)}
            </span>
          </div>
          <details className="ui-store-details">
            <summary>
              دربارهٔ فروشگاه و نشانی <Ic n="chevD" c="sm" />
            </summary>
            <p className="profile-description">{s.desc}</p>
            <div className="profile-bottom">
              <span>
                <Ic n="pin" c="sm" />
                {s.address}
              </span>
              <Link href={`/m/${s.slug}`} className="btn btn-ghost btn-sm">
                <Ic n="qr" c="sm" />
                منوی دیجیتال
              </Link>
            </div>
          </details>
        </div>
        <div className="store-profile-photo">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={`/media/${STORE_PHOTOS[s.id] || "grill"}.webp`} alt="" fetchPriority="high" />
          <a href={`tel:${s.phone}`} className="profile-call">
            <Ic n="phone" c="sm" />
            تماس با فروشگاه
          </a>
        </div>
      </section>

      {!st.open && openOthers.length ? (
        <aside className="ux-closed" aria-label="وضعیت پذیرش فروشگاه">
          <Ic n="clock" />
          <div>
            <b>
              الان بسته است؛ {st.tomorrow ? "فردا" : "امروز"} از ساعت {faD(st.opensAt || "")} باز می‌شود.
            </b>
            <p>می‌توانید برای زمان بازگشایی پیش‌سفارش ثبت کنید. اگر عجله دارید:</p>
            {openOthers.map((o) => (
              <Link key={o.id} href={`/store/${o.id}`}>
                {o.name} · باز است <Ic n="chevL" c="sm" />
              </Link>
            ))}
          </div>
        </aside>
      ) : null}

      {clubActive ? (
        <aside className="c7-store-club">
          <div>
            <span className="c7-tag">عضو باشگاه جم لایف</span>
            <b>خرید حضوری با تأیید فروشنده</b>
            <p>{clubPerk || "پیشنهادها و شرایط پاداش را قبل از خرید ببین."}</p>
          </div>
          <Link className="btn btn-ghost" href={`/visit/${s.id}`}>
            دریافت کد خرید حضوری
          </Link>
        </aside>
      ) : null}
      <div className="fulfilment-strip">
        <div>
          <Ic n="truck" />
          <span>
            ارسال به محل<b>{s.delivery ? `${deliveryEta(s)} · ${tomanT(deliveryFee(s))}` : "ندارد"}</b>
          </span>
        </div>
        <div>
          <Ic n="walk" />
          <span>
            تحویل حضوری<b>{s.pickup ? `رایگان · آماده در ${prepText(s)}` : "ندارد"}</b>
          </span>
        </div>
        <div>
          <Ic n="bag" />
          <span>
            حداقل سفارش<b>{s.minOrder ? tomanT(s.minOrder) : "رایگان"}</b>
          </span>
        </div>
        <div>
          <Ic n="pin" />
          <span>
            فاصله از شما<b>{fa(s.km)} کیلومتر</b>
          </span>
        </div>
      </div>

      {!st.open ? (
        <div className="notice amber" style={{ marginTop: 16 }}>
          <Ic n="info" />
          <span>
            این فروشگاه الان بسته است. می‌توانید سفارش را ثبت کنید تا در ساعت <b>{faD(st.opensAt || "")}</b> پردازش شود.
          </span>
        </div>
      ) : null}
      {s.discount > 0 ? (
        <div className="notice green" style={{ marginTop: 12 }}>
          <Ic n="percent" />
          <span>
            <b>تا {fa(s.discount)}٪ تخفیف</b> روی محصولات منتخب. کد <b>JAM10</b> را هم در مرحله پرداخت امتحان کنید.
          </span>
        </div>
      ) : null}

      <div className="store-layout">
        <div>
          <nav className="menu-nav" aria-label="بخش‌های منو">
            <div className="chips" id="secChips">
              {popItems.length ? (
                <a href="#sec-pop" className="chip on" data-sec="sec-pop">
                  <Ic n="spark" c="sm" />
                  محبوب‌ها
                </a>
              ) : null}
              {secs.map((sec) => (
                <a key={sec.id} href={`#${sec.id}`} className="chip" data-sec={sec.id}>
                  {sec.title}
                </a>
              ))}
            </div>
            <label className="mini-search">
              <Ic n="search" />
              <span className="sr">جست‌وجو در منو</span>
              <input
                type="search"
                placeholder="جست‌وجو در منو"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                maxLength={200}
              />
            </label>
          </nav>
          <div id="menuBody">
            {popItems.length && (!filtering || popItems.some(match)) ? (
              <MenuSec
                s={s}
                title="محبوب‌ترین انتخاب‌ها"
                id="sec-pop"
                items={filtering ? popItems.filter(match) : popItems}
              />
            ) : null}
            {secs.map((sec) => {
              const items = filtering ? sec.items.filter(match) : sec.items;
              if (!items.length) return null;
              return <MenuSec key={sec.id} s={s} title={sec.title} id={sec.id} items={items} />;
            })}
            {filtering && !s.products.some(match) ? (
              <div className="empty">
                <div className="e-ic">
                  <Ic n="search" />
                </div>
                <b>این طعم را پیدا نکردیم</b>
                <div style={{ fontSize: 14 }}>نام دیگری را امتحان کنید.</div>
              </div>
            ) : null}
          </div>
        </div>
        <aside className="side-cart" aria-label="سبد خرید">
          <CartBox s={s} />
        </aside>
      </div>
    </div>
  );
}

/* فروشگاه‌های باز دیگر — برای پیشنهاد در حالت بسته */
function STORES_OPEN(self: Store): Store[] {
  return STORES.filter((x) => x.id !== self.id && openState(x).open).slice(0, 2);
}

/* ---------- کاتالوگ زنجیره‌ای (retail) ---------- */
type SortKey = "suggested" | "low" | "high";

function RetailStorefront({ s }: { s: Store }) {
  const { favs, toggleFav, toast } = useJam();
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<string>("all");
  const [sort, setSort] = useState<SortKey>("suggested");
  const [offersOnly, setOffersOnly] = useState(false);
  const [stockOnly, setStockOnly] = useState(false);
  const fav = favs.includes(s.id);

  const cats = useMemo(() => {
    const out: [string, number][] = [];
    for (const p of s.products) {
      const i = out.findIndex(([c]) => c === p.sec);
      if (i >= 0) out[i][1] += 1;
      else out.push([p.sec, 1]);
    }
    return out;
  }, [s]);

  const list = useMemo(() => {
    let arr = s.products.slice();
    if (cat !== "all") arr = arr.filter((p) => p.sec === cat);
    if (norm(q)) {
      const n = norm(q);
      arr = arr.filter((p) => norm(p.name).includes(n) || norm(p.unit || "").includes(n));
    }
    if (offersOnly) arr = arr.filter((p) => p.old > p.price);
    if (stockOnly) arr = arr.filter((p) => p.available);
    if (sort === "low") arr.sort((a, b) => a.price - b.price);
    if (sort === "high") arr.sort((a, b) => b.price - a.price);
    return arr;
  }, [s, cat, q, sort, offersOnly, stockOnly]);

  return (
    <div className="container life-retail storefront" data-retail-store={s.id}>
      <Crumbs s={s} />

      <header className="life-retail-head" style={{ "--chain-color": s.chainColor } as CSSProperties}>
        <span className="life-chain-logo">{s.chainShort}</span>
        <div>
          <span className="life-retail-overline">خرید سبدی و کالاهای بسته‌بندی</span>
          <h1>{s.name}</h1>
          <p>کاتالوگ نمایشی؛ بدون اتصال به شعبه، قیمت یا موجودی واقعی</p>
        </div>
        <button
          type="button"
          className="icon-btn"
          aria-pressed={fav}
          aria-label="افزودن به علاقه‌مندی‌ها"
          onClick={() => {
            toggleFav(s.id);
            toast(fav ? "از علاقه‌مندی‌ها حذف شد" : "به علاقه‌مندی‌ها اضافه شد");
          }}
        >
          <Ic n="heart" />
        </button>
      </header>

      <div className="life-retail-fulfil">
        <span>
          <Ic n="truck" />
          ارسال · حدود {deliveryEta(s)}
        </span>
        <span>
          <Ic n="walk" />
          تحویل حضوری · رایگان
        </span>
        <span>
          <Ic n="bag" />
          حداقل سبد: {tomanT(s.minOrder)}
        </span>
      </div>

      <div className="life-retail-toolbar">
        <label className="life-retail-search">
          <Ic n="search" />
          <input
            type="search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="جست‌وجوی کالا، وزن یا کد محصول"
            aria-label={`جست‌وجو در کاتالوگ ${s.name}`}
            maxLength={200}
          />
        </label>
        <label className="life-retail-sort">
          <span>مرتب‌سازی</span>
          <select value={sort} onChange={(e) => setSort(e.target.value as SortKey)} aria-label="مرتب‌سازی کالاها">
            <option value="suggested">پیشنهادی</option>
            <option value="low">ارزان‌ترین</option>
            <option value="high">گران‌ترین</option>
          </select>
        </label>
      </div>

      <div className="life-retail-layout">
        <aside className="life-retail-categories">
          <h2>دسته‌های کالا</h2>
          <nav aria-label="دسته‌های کاتالوگ">
            <button
              type="button"
              className={cat === "all" ? "on" : ""}
              aria-pressed={cat === "all"}
              onClick={() => setCat("all")}
            >
              همهٔ کالاها<small>{fa(s.products.length)}</small>
            </button>
            {cats.map(([c, n]) => (
              <button
                key={c}
                type="button"
                className={cat === c ? "on" : ""}
                aria-pressed={cat === c}
                onClick={() => setCat(c)}
              >
                {c}
                <small>{fa(n)}</small>
              </button>
            ))}
          </nav>
          <div className="life-catalog-help">
            <Ic n="info" />
            <p>قیمت‌ها، موجودی و تصاویر نمونه‌اند؛ خرید در این فایل آزمایشی است.</p>
          </div>
        </aside>

        <section className="life-retail-catalog" aria-label="کالاها">
          <div className="life-catalog-filters">
            <span id="life-retail-count">{fa(list.length)} کالا</span>
            <div>
              <button
                type="button"
                aria-pressed={offersOnly}
                className={offersOnly ? "on" : ""}
                onClick={() => setOffersOnly((v) => !v)}
              >
                <Ic n="tag" c="sm" />
                تخفیف‌دار
              </button>
              <button
                type="button"
                aria-pressed={stockOnly}
                className={stockOnly ? "on" : ""}
                onClick={() => setStockOnly((v) => !v)}
              >
                <Ic n="check" c="sm" />
                فقط موجودها
              </button>
            </div>
          </div>
          <div className="life-retail-grid" id="life-retail-grid" aria-live="polite" aria-atomic="false">
            {list.map((p) => {
              const pct = discPct(p);
              return (
                <article className={`life-retail-product${p.available ? "" : " na"}`} key={p.id} id={`it-${p.id}`}>
                  <button type="button" className="life-retail-photo" aria-label={`جزئیات ${p.name}`}>
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={p.image} alt={`تصویر نمونهٔ ${p.name}`} loading="lazy" decoding="async" />
                    {pct > 0 ? <span className="life-retail-discount">{fa(pct)}٪</span> : null}
                  </button>
                  <div className="life-retail-info">
                    <small>{p.sec}</small>
                    <button type="button">
                      <h3>{p.name}</h3>
                    </button>
                    <span className="life-retail-unit">{p.unit}</span>
                    <div className="life-retail-price">
                      {p.old > p.price ? <s>{fa(p.old)}</s> : null}
                      <b>
                        {fa(p.price)} <small>تومان</small>
                      </b>
                    </div>
                  </div>
                  <QtyCtl product={p} s={s} />
                </article>
              );
            })}
          </div>
        </section>

        <aside className="side-cart life-retail-cart" aria-label="سبد خرید">
          <CartBox s={s} />
        </aside>
      </div>
    </div>
  );
}

/* ---------- ریشهٔ صفحه ---------- */
export function StorePage({ storeId }: { storeId: string }) {
  const s = findStore(storeId);
  if (!s) return null;
  return s.retail ? <RetailStorefront s={s} /> : <StandardStorefront s={s} />;
}

export default StorePage;
