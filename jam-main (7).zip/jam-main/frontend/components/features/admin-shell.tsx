"use client";
/* =========================================================
   جم لایف — پوستهٔ مشترک پنل مدیریت
   دسترسی فقط بر اساس نقش سمت سرور (GET /auth/me/) تعیین می‌شود؛
   پاسخ 403 هر صفحهٔ مدیریتی هم به‌صورت صادقانه نمایش داده می‌شود
   و هرگز دادهٔ ساختگی جایگزین نمی‌شود.
   ========================================================= */

import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { apiFetch } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import Ic from "@/components/icons";
import type { Me } from "@/lib/subscriptions-api";

const ADMIN_NAV: [string, string, string][] = [
  ["/admin", "داشبورد", "dash"],
  ["/admin/users", "کاربران", "user"],
  ["/admin/payments", "پرداخت‌ها", "card"],
  ["/admin/subscriptions", "اشتراک‌ها و اعتبارها", "layers"],
  ["/admin/admins", "مدیران", "shield"],
  ["/admin/audit", "حسابرسی", "list"],
];

type AdminCtx = { me: Me | null; refreshMe: () => Promise<void> };
const Ctx = createContext<AdminCtx>({ me: null, refreshMe: async () => {} });

export function useAdminShell(): AdminCtx {
  return useContext(Ctx);
}

/** درخواست مدیریتی با مدیریت صادقانهٔ 403؛ خطا پیام سرور یا پیام فارسی است */
export async function adminFetch<T>(path: string): Promise<T> {
  return apiFetch<T>(path);
}

export default function AdminShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname() || "/admin";
  const { ready, isAuthenticated } = useAuth();
  const [me, setMe] = useState<Me | null>(null);
  const [loading, setLoading] = useState(true);
  const [denied, setDenied] = useState(false);

  const refreshMe = async () => {
    setLoading(true);
    setDenied(false);
    try {
      const next = await apiFetch<Me>("/auth/me/");
      setMe(next);
      setDenied(next.role !== "admin");
    } catch {
      setMe(null);
      setDenied(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!ready) return;
    refreshMe();
  }, [ready, isAuthenticated]);

  const ctx = useMemo<AdminCtx>(() => ({ me, refreshMe }), [me]);

  if (!ready || loading) {
    return (
      <div className="container rv">
        <p className="rv-empty">در حال بررسی دسترسی…</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="container rv" style={{ maxWidth: 620 }}>
        <section className="rv-card">
          <h1>برای ورود به پنل مدیریت وارد شوید</h1>
          <p>این بخش فقط با حساب مدیر جم لایف در دسترس است.</p>
          <Link className="btn btn-primary" href="/login?next=%2Fadmin">
            ورود
          </Link>
        </section>
      </div>
    );
  }

  if (denied || me?.role !== "admin") {
    return (
      <div className="container rv" style={{ maxWidth: 620 }}>
        <section className="rv-card">
          <span className="pill red">۴۰۳</span>
          <h1 style={{ marginTop: 12 }}>دسترسی مجاز نیست</h1>
          <p>
            حساب شما نقش مدیر ندارد و پنل مدیریت فقط برای مدیران پلتفرم باز می‌شود. اگر فکر می‌کنید
            اشتباهی رخ داده، از یک مدیر دیگر بخواهید نقش شما را بررسی کند.
          </p>
          <Link className="btn btn-ghost" href="/">
            بازگشت به صفحهٔ اصلی
          </Link>
        </section>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="panel">
        <aside className="card p-side" aria-label="منوی پنل مدیریت">
          <div className="p-store">
            <span className="lg tone tone-restaurant">
              <Ic n="shield" />
            </span>
            <div className="grow">
              <b>پنل مدیریت</b>
              <div className="faint" style={{ fontSize: 14 }}>
                جم لایف · دسترسی مدیر
              </div>
            </div>
          </div>
          <nav className="p-nav" aria-label="بخش‌های پنل مدیریت">
            {ADMIN_NAV.map(([href, label, icon]) => {
              const on = pathname === href || (href !== "/admin" && pathname.startsWith(href));
              return (
                <Link key={href} href={href} className={on ? "on" : ""} aria-current={on ? "page" : undefined}>
                  <Ic n={icon} />
                  {label}
                </Link>
              );
            })}
            <Link href="/">
              <Ic n="home" />
              بازگشت به بازار جم
            </Link>
          </nav>
        </aside>
        <div className="p-main rv g10-main">
          <div className="ui-panel-context">
            <span>
              <Ic n="shield" c="sm" />
              پنل مدیریت · جم لایف
            </span>
            <span className="faint">
              {me?.name || me?.phone || "حساب مدیر"}
            </span>
          </div>
          <Ctx.Provider value={ctx}>{children}</Ctx.Provider>
        </div>
      </div>
    </div>
  );
}
