"use client";

/* منوی دیجیتال عمومی (بدون کروم سایت) — دقیقاً مطابق دامپ menu-s1.html */
import { useEffect, useMemo, useState, type CSSProperties } from "react";
import Link from "next/link";
import { Ic } from "@/components/icons";
import {
  store as findStore,
  ACCENTS,
  hoursText,
  openState,
  prepText,
  brandMonogram,
  productPhoto,
  STORE_PHOTOS,
  registerStore,
  type Store,
} from "@/lib/data";
import { fa, faD, tomanT, norm } from "@/lib/format";
import { useJam, cartSummary } from "@/lib/state";
import { QtyCtl } from "@/components/features/store-card";
import { Item } from "@/components/features/store-page";
import MenuOfflineStatus from "@/components/features/menu-offline-status";

export function DigitalMenuPage({ storeId, initialStore }: { storeId: string; initialStore?: Store }) {
  useEffect(() => {
    if (initialStore) registerStore(initialStore);
  }, [initialStore]);

  const s = findStore(storeId) || initialStore;
  if (!s) return null;
  return <MenuRoot key={s.id} s={s} />;
}

function MenuRoot({ s }: { s: NonNullable<ReturnType<typeof findStore>> }) {
  const { toast, cart } = useJam();
  const [q, setQ] = useState("");
  const [mode, setMode] = useState<"delivery" | "pickup">("delivery");
  const st = openState(s);
  const monogram = s.chainShort || brandMonogram(s);

  const popItems = useMemo(() => s.products.filter((p) => p.pop), [s]);
  const secs = useMemo(
    () =>
      s.sections.map((title, i) => ({
        title,
        id: `dm-${i}`,
        items: s.products.filter((p) => p.sec === title),
      })),
    [s],
  );

  const filtering = norm(q).length > 0;
  const match = (p: (typeof s.products)[number]) =>
    norm(p.name).includes(norm(q)) || norm(p.desc).includes(norm(q));
  const anyMatch = filtering ? s.products.some(match) : true;

  const mine = cart && cart.sid === s.id ? cart : null;
  const sum = cartSummary(mine);

  const share = () => {
    navigator.clipboard.writeText(location.href);
    toast("کپی شد");
  };

  return (
    <div className="dm t-modern dm-v4" style={{ "--acc": ACCENTS[0] } as CSSProperties} data-dm-store={s.id}>
      <header className="dm-top">
        <Link href="/" className="dm-home" aria-label="بازار جم">
          <span>
            جم<i></i>
          </span>
          <small>منوی دیجیتال</small>
        </Link>
        <span className="dm-top-title">{s.name}</span>
        <div className="dm-top-actions">
          <a href={`tel:${s.phone}`} className="dm-contact" aria-label="تماس با مجموعه">
            <Ic n="phone" />
          </a>
          <button type="button" className="dm-contact" onClick={share} aria-label="اشتراک‌گذاری منو">
            <Ic n="share" />
          </button>
          <Link href="/cart" className="dm-header-cart">
            <Ic n="bag" />
            <span>سبد خرید</span>
          </Link>
        </div>
      </header>
        <MenuOfflineStatus />

      <section className="dm-cover">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          className="dm-cover-photo"
          src={s.coverImage || `/media/${STORE_PHOTOS[s.id] || "grill"}.webp`}
          alt=""
          fetchPriority="high"
        />
        <div className="dm-cover-shade"></div>
        <div className="dm-cover-content">
          <span className="dm-cover-tag">{s.tagline}</span>
          <h1>{monogram}</h1>
          <p>{s.desc}</p>
          <div className="dm-cover-details">
            <span className="dm-open">
              <i></i>
              {st.open ? "سفارش می‌پذیرد" : "امکان پیش‌سفارش"}
            </span>
            <span>
              <Ic n="star" c="sm" />
              {fa(s.rating)} <small>({fa(s.reviews)} نظر)</small>
            </span>
          </div>
        </div>
        <a href={`tel:${s.phone}`} className="dm-cover-contact">
          <Ic n="phone" c="sm" />
          تماس با {monogram}
        </a>
        <div className="dm-cover-index">
          <span>منوی آنلاین</span>
          <b>{fa(s.products.length)}</b>
          <span>انتخاب برای شما</span>
        </div>
      </section>

      <div className="dm-utility">
        <div className="dm-about">
          <span className="dm-logo">
            <span className={`brand-monogram bm-${s.id}`}>{monogram}</span>
          </span>
          <span>
            <b>{s.name}</b>
            <small>
              <Ic n="clock" c="sm" />
              آماده‌سازی {prepText(s)} <i>•</i> تحویل حضوری رایگان
            </small>
          </span>
        </div>
        <div className="seg" role="tablist" aria-label="روش دریافت">
          <button
            type="button"
            role="tab"
            aria-selected={mode === "delivery"}
            className={mode === "delivery" ? "on" : ""}
            onClick={() => setMode("delivery")}
          >
            <Ic n="truck" />
            ارسال به محل
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={mode === "pickup"}
            className={mode === "pickup" ? "on" : ""}
            onClick={() => setMode("pickup")}
          >
            <Ic n="walk" />
            تحویل حضوری
          </button>
        </div>
        <button type="button" className="dm-info-btn">
          <Ic n="info" c="sm" />
          درباره مجموعه
        </button>
      </div>

      <div className="dm-layout">
        <aside className="dm-sidebar">
          <span className="dm-nav-label">در منو بگردید</span>
          <nav className="dm-tabs">
            {secs.map((sec, i) => (
              <a key={sec.id} href={`#${sec.id}`} className={i === 0 ? "on" : ""}>
                <span>{sec.title}</span>
                <small>{fa(sec.items.length)}</small>
                <Ic n="chevL" c="sm" />
              </a>
            ))}
          </nav>
          <div className="dm-side-note">
            <Ic n="shield" />
            <b>با خیال راحت انتخاب کنید.</b>
            <span>قیمت نهایی پیش از ثبت سفارش نمایش داده می‌شود.</span>
          </div>
          <div className="dm-hours">
            <Ic n="clock" c="sm" />
            <span>
              ساعت پذیرش سفارش<b>{hoursText(s)}</b>
            </span>
          </div>
        </aside>

        <div className="dm-content">
          <div className="dm-editorial">
            <div>
              <span className="dm-overline">به سلیقه‌ی {monogram}</span>
              <h2>از این‌ها شروع کنید.</h2>
            </div>
            <span className="dm-handpick">
              <Ic n="spark" />
              انتخاب‌های محبوب
            </span>
          </div>

          {popItems.length ? (
            <div className="dm-signatures">
              {popItems.map((p) => (
                <article className="signature-card" key={p.id}>
                  <button type="button" className="signature-photo">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img className="media-photo" src={productPhoto(p, s.id) || ""} alt="" loading="lazy" />
                    <span>
                      <Ic n="spark" c="sm" />
                      انتخاب ویژه
                    </span>
                  </button>
                  <div className="signature-body">
                    <button type="button">
                      <h3>{p.name}</h3>
                      <span>{p.desc}</span>
                    </button>
                    <div className="signature-foot">
                      <div>
                        <b className="tnum">{fa(p.price)}</b>
                        <small>تومان</small>
                      </div>
                      <QtyCtl product={p} s={s} />
                    </div>
                  </div>
                </article>
              ))}
            </div>
          ) : null}

          <div className="dm-search-row">
            <h2>همه‌ی منو</h2>
            <label className="dm-search">
              <Ic n="search" c="sm" />
              <input
                type="search"
                placeholder="جست‌وجو در منو و محصولات"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                aria-label="جست‌وجو در منو"
                maxLength={200}
              />
            </label>
          </div>

          <div className="dm-menu-sections">
            {secs.map((sec, i) => {
              const items = filtering ? sec.items.filter(match) : sec.items;
              if (!items.length) return null;
              return (
                <section className="dm-sec" id={sec.id} key={sec.id}>
                  <div className="dm-section-title">
                    <span className="dm-sec-number">{faD(String(i + 1).padStart(2, "0"))}</span>
                    <h2>{sec.title}</h2>
                    <span>{fa(items.length)} انتخاب</span>
                  </div>
                  <div className="dm-items">
                    {items.map((p) => (
                      <Item key={p.id} p={p} s={s} id={`dm-product-${p.id}`} />
                    ))}
                  </div>
                </section>
              );
            })}
          </div>
          <div className="dm-no-results" hidden={anyMatch}>
            <div className="empty">
              <div className="e-ic">
                <Ic n="search" />
              </div>
              <b>این طعم را پیدا نکردیم</b>
              <div style={{ fontSize: 14 }}>نام دیگری را امتحان کنید.</div>
            </div>
          </div>
        </div>
      </div>

      <footer className="dm-foot">
        <span className="dm-footer-word">{monogram}</span>
        <b>{s.name}</b>
        <p>{s.address}</p>
        <a href={`tel:${s.phone}`} dir="ltr">
          {faD(s.phone)}
        </a>
        <div className="dm-powered">
          ساخته‌شده برای یک تجربه بهتر، با <Link href="/">جم</Link>
        </div>
        <small>{s.api ? "منوی دیجیتال جم لایف" : "نسخه نمایشی؛ تصاویر و اطلاعات نمونه هستند."}</small>
      </footer>

      {mine && sum.count > 0 ? (
        <div className="dm-order has">
          <Link href="/cart">
            <span className="cnt tnum">{fa(sum.count)}</span>
            <span className="grow" style={{ textAlign: "start" }}>
              مشاهده سبد خرید
              <small style={{ display: "block", fontWeight: 500, opacity: 0.85, fontSize: 14 }}>{s.name}</small>
            </span>
            <b className="tnum">{tomanT(sum.total)}</b>
          </Link>
        </div>
      ) : (
        <div className="dm-order"></div>
      )}
    </div>
  );
}

export default DigitalMenuPage;
