"use client";

/* تکمیل سفارش — چهار مرحلهٔ دریافت، آدرس، تماس و پرداخت
   نسخهٔ نمایشی: سفارش فقط در localStorage همین مرورگر ثبت می‌شود. */

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Ic } from "@/components/icons";
import { cartSummary, useJam } from "@/lib/state";
import { brandMonogram, deliveryEta, deliveryFee, openState, prepText } from "@/lib/data";
import { enD, fa, fmtTime, tomanT } from "@/lib/format";
import { ApiCheckoutPage } from "@/components/features/api-checkout-page";

const CODES: Record<string, { pct: number; max: number; pickupOnly?: boolean; label: string }> = {
  JAM10: { pct: 10, max: 60000, label: "۱۰٪ تخفیف تا سقف ۶۰ هزار تومان" },
  PICKUP5: { pct: 5, max: 40000, pickupOnly: true, label: "۵٪ تخفیف ویژه تحویل حضوری" },
};

/** بازه‌های زمانی ۳۰ دقیقه‌ای — مطابق مرجع */
function timeSlots(isOpen: (d: Date) => boolean): string[] {
  const out: string[] = [];
  const nowDay = new Date().getDate();
  const d = new Date();
  d.setSeconds(0, 0);
  d.setMinutes(Math.ceil((d.getMinutes() + 45) / 30) * 30);
  for (let i = 0; out.length < 8 && i < 96; i++) {
    if (isOpen(d)) {
      const day = d.getDate() === nowDay ? "امروز" : "فردا";
      out.push(`${day}، ساعت ${fmtTime(d)} تا ${fmtTime(d.getTime() + 30 * 60000)}`);
    }
    d.setTime(d.getTime() + 30 * 60000);
  }
  return out.length ? out : ["اولین زمان بازگشایی"];
}

function DemoCheckoutPage() {
  const router = useRouter();
  const { cart, ready, addrs, addAddress, placeOrder, profile, setProfile, toast } = useJam();
  const cs = cartSummary(cart);
  const s = cs.store;

  const [methodRaw, setMethod] = useState<"delivery" | "pickup">("delivery");
  const [addrId, setAddrId] = useState<string>("");
  const [name, setName] = useState(profile.name);
  const [phone, setPhone] = useState(profile.phone);
  const [when, setWhen] = useState<"now" | "later">("now");
  const [time, setTime] = useState("");
  const [note, setNote] = useState("");
  const [pay, setPay] = useState<"online" | "cash">("online");
  const [codeInput, setCodeInput] = useState("");
  const [codeApplied, setCodeApplied] = useState<string | null>(null);
  const [errors, setErrors] = useState<{ name?: string; phone?: string }>({});
  const [addrForm, setAddrForm] = useState(false);
  const [addrTitle, setAddrTitle] = useState("");
  const [addrText, setAddrText] = useState("");
  const [addrErr, setAddrErr] = useState(false);
  const [gwOpen, setGwOpen] = useState(false);
  const redirected = useRef(false);

  /* فروشگاه پشتیبانی نمی‌کند → اصلاح روش دریافت */
  const method: "delivery" | "pickup" = !s
    ? methodRaw
    : methodRaw === "delivery" && !s.delivery
      ? "pickup"
      : methodRaw === "pickup" && !s.pickup && s.delivery
        ? "delivery"
        : methodRaw;

  const st = useMemo(() => (s ? openState(s) : undefined), [s]);
  const isOpen = (d: Date) => (s ? openState(s, d).open : true);
  const slots = useMemo(() => timeSlots(isOpen), [s?.id]); // eslint-disable-line react-hooks/exhaustive-deps
  const effWhen: "now" | "later" = when === "now" && st?.open ? "now" : "later";

  /* محاسبهٔ مبالغ — مطابق مرجع */
  const sub = cs.items + cs.discount;
  const itemDisc = cs.discount;
  let codeDisc = 0;
  let codeErr = "";
  if (codeApplied) {
    const c = CODES[codeApplied];
    if (c.pickupOnly && method !== "pickup") codeErr = "این کد فقط برای تحویل حضوری است";
    else codeDisc = Math.min(Math.round((cs.items * c.pct) / 100 / 1000) * 1000, c.max);
  }
  const fee = method === "delivery" && s?.delivery ? cs.delivery : 0;
  const total = Math.max(0, cs.items + fee - codeDisc);
  const saveTotal = itemDisc + codeDisc + (method === "pickup" && s?.delivery ? deliveryFee(s) : 0);

  const addr = addrs.find((a) => a.id === addrId) || addrs[0];

  /* آدرس انتخابی معتبر بماند */
  useEffect(() => {
    if (addrs.length && !addrs.some((a) => a.id === addrId)) setAddrId(addrs[0].id);
  }, [addrs, addrId]);

  /* سبد خالی → بازگشت صادقانه به جست‌وجو */
  useEffect(() => {
    if (ready && !cs.lines.length && !redirected.current) {
      redirected.current = true;
      toast("سبد خرید خالی است", "err");
      router.replace("/search");
    }
  }, [ready, cs.lines.length, router, toast]);

  const applyCode = () => {
    const v = codeInput.trim().toUpperCase();
    if (!v) {
      setCodeApplied(null);
      return;
    }
    if (!CODES[v]) {
      toast("کد تخفیف معتبر نیست", "err");
      return;
    }
    if (CODES[v].pickupOnly && method !== "pickup") {
      toast("این کد فقط برای تحویل حضوری است", "err");
      return;
    }
    setCodeApplied(v);
  };

  const saveAddress = () => {
    const t = addrTitle.trim() || "آدرس جدید";
    const a = addrText.trim();
    if (a.length < 6) {
      setAddrErr(true);
      return;
    }
    const created = addAddress({ title: t, text: "جم، " + a.replace(/^جم[،,]?\s*/, "") });
    setAddrId(created.id);
    setAddrForm(false);
    setAddrTitle("");
    setAddrText("");
    setAddrErr(false);
    toast("آدرس جدید ذخیره شد");
  };

  const finish = () => {
    if (!s || !cs.lines.length) return;
    setGwOpen(false);
    const a = addrs.find((x) => x.id === addrId) || addrs[0];
    const whenText = effWhen === "now" ? "در اسرع وقت" : time || slots[0] || "اولین زمان بازگشایی";
    const o = placeOrder({
      sid: s.id,
      mode: method,
      addrText: method === "delivery" ? `${a.title} — ${a.text}` : s.address,
      name: name.trim(),
      phone: enD(phone).trim(),
      when: whenText,
      note,
      pay: pay === "online" ? "online" : "offline",
      code: codeApplied || undefined,
      codeDisc: codeDisc || 0,
      items: cs.lines,
      totals: { items: cs.items, discount: itemDisc + codeDisc, delivery: fee, total },
    });
    redirected.current = true; /* سبد خالی‌شدن پس از ثبت — گارد بازگشت اجرا نشود */
    router.push(`/order/${o.id}?new=1`);
  };

  const submit = () => {
    if (!s || !cs.lines.length) return;
    const E: { name?: string; phone?: string } = {};
    if (name.trim().length < 3) E.name = "نام را کامل وارد کنید";
    if (!/^09\d{9}$/.test(enD(phone).trim())) E.phone = "شماره موبایل باید ۱۱ رقم و با ۰۹ شروع شود";
    setErrors(E);
    setProfile({ name: name.trim(), phone: enD(phone).trim() });
    if (Object.keys(E).length) {
      setTimeout(() => {
        const el = document.querySelector<HTMLElement>(".input.err");
        el?.scrollIntoView({ block: "center" });
        el?.focus();
      }, 30);
      return;
    }
    if (codeErr) {
      toast(codeErr, "err");
      return;
    }
    if (cs.items < s.minOrder) {
      toast("سبد خرید معتبر نیست؛ موجودی، مبلغ و حداقل خرید را بررسی کنید.", "err");
      return;
    }
    if (pay === "online") setGwOpen(true);
    else finish();
  };

  /* حالت خالی (در حال هدایت به /search) */
  if (!s || !cs.lines.length) {
    return (
      <div className="container">
        <div className="page-title"><h1>تکمیل سفارش</h1></div>
        <div className="card">
          <div className="empty">
            <div className="e-ic"><Ic n="bag" /></div>
            <b>سبد خرید شما خالی است</b>
            <div style={{ fontSize: 14 }}>برای ثبت سفارش، ابتدا محصولی به سبد اضافه کنید.</div>
            <div style={{ marginTop: 16 }}>
              <Link href="/" className="btn btn-primary">بازگشت به خانه</Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const nAddr = method === "delivery" ? 2 : 0;
  const stepContact = method === "delivery" ? 3 : 2;
  const stepPay = method === "delivery" ? 4 : 3;

  return (
    <div className="container">
      <div className="crumbs">
        <Link href="/" className="ui-tap-link">خانه</Link>
        <Ic n="chevL" c="sm" />
        <Link href={`/store/${s.id}`} className="ui-tap-link">{s.name}</Link>
        <Ic n="chevL" c="sm" />
        <span>تکمیل سفارش</span>
      </div>

      <div className="page-title">
        <h1>تکمیل سفارش</h1>
        <p className="ux-page-sub">همهٔ هزینه‌ها را بررسی کنید؛ مبلغ دیگری به این جمع اضافه نمی‌شود.</p>
        <ol className="ux-checkout-path">
          <li>۱. دریافت</li>
          <li>۲. اطلاعات تماس</li>
          <li>۳. بررسی و ثبت</li>
        </ol>
      </div>

      <div className="co-layout">
        <aside className="c7-checkout-note">
          <b>پرداخت و سهم‌ها</b>
          <p>با پرداخت آنلاین، سهم فروشنده و کمیسیون پذیرفته‌شدهٔ جم لایف ثبت می‌شود؛ تسویه پس از تحویل و تأیید پذیرندگی است. پرداخت نقدی پورسانت جدا ندارد. پرداخت و تسهیم این فایل شبیه‌سازی‌اند.</p>
        </aside>

        <div>
          {/* ۱ — روش دریافت */}
          <section className="card co-step">
            <h2><span className="n">۱</span>روش دریافت سفارش</h2>
            <div className="opt-grid" role="radiogroup">
              <button
                className={`opt ${method === "pickup" ? "on" : ""}`}
                role="radio"
                aria-checked={method === "pickup"}
                onClick={() => setMethod("pickup")}
                disabled={!s.pickup}
                style={!s.pickup ? { opacity: 0.5 } : undefined}
              >
                <span className="radio" />
                <span className="oi"><Ic n="walk" /></span>
                <span>
                  <b>تحویل حضوری</b>
                  <small>
                    از فروشگاه تحویل بگیرید · آماده در {prepText(s)}
                    <br />
                    <span style={{ color: "var(--brand)", fontWeight: 700 }}>بدون هزینه ارسال</span>
                  </small>
                </span>
              </button>
              <button
                className={`opt ${method === "delivery" ? "on" : ""}`}
                role="radio"
                aria-checked={method === "delivery"}
                onClick={() => setMethod("delivery")}
                disabled={!s.delivery}
                style={!s.delivery ? { opacity: 0.5 } : undefined}
              >
                <span className="radio" />
                <span className="oi"><Ic n="truck" /></span>
                <span>
                  <b>ارسال به محل</b>
                  <small>
                    {s.delivery
                      ? <>
                        با پیک همکار / تاکسی ۱۸۱۶ · حدود {deliveryEta(s)}
                        <br />
                        <span className="tnum">هزینه ارسال: {tomanT(deliveryFee(s))}</span>
                      </>
                      : "این فروشگاه ارسال ندارد"}
                  </small>
                </span>
              </button>
            </div>
            {method === "pickup" && (
              <div className="notice blue" style={{ marginTop: 14 }}>
                <Ic n="pin" />
                <span>
                  <b>آدرس فروشگاه:</b> {s.address} · {fa(s.km)} کیلومتر از شما. پس از آماده شدن سفارش، کد تحویل برایتان نمایش داده می‌شود.
                </span>
              </div>
            )}
          </section>

          {/* ۲ — آدرس تحویل */}
          {method === "delivery" && (
            <section className="card co-step">
              <h2><span className="n">{fa(nAddr)}</span>آدرس تحویل</h2>
              <div className="addr-list">
                {addrs.map((a) => (
                  <button
                    key={a.id}
                    className={`addr-opt ${a.id === addr.id ? "on" : ""}`}
                    onClick={() => setAddrId(a.id)}
                    role="radio"
                    aria-checked={a.id === addr.id}
                  >
                    <span className="oi"><Ic n="home" /></span>
                    <span className="grow">
                      <b style={{ display: "block", fontSize: "14.5px" }}>{a.title}</b>
                      <span className="muted" style={{ fontSize: 14 }}>{a.text}</span>
                    </span>
                    {a.id === addr.id && <Ic n="check" />}
                  </button>
                ))}
                {!addrForm ? (
                  <button className="btn btn-ghost" onClick={() => setAddrForm(true)} style={{ alignSelf: "flex-start" }}>
                    <Ic n="plus" c="sm" />
                    افزودن آدرس جدید
                  </button>
                ) : (
                  <div className="form-grid" style={{ width: "100%" }}>
                    <div className="field">
                      <label htmlFor="na-t">عنوان</label>
                      <input className="input" id="na-t" value={addrTitle} onChange={(e) => setAddrTitle(e.target.value)} placeholder="مثلاً خانه مادر" maxLength={60} />
                    </div>
                    <div className="field full">
                      <label htmlFor="na-a">آدرس</label>
                      <textarea
                        className={`textarea${addrErr ? " err" : ""}`}
                        id="na-a"
                        value={addrText}
                        onChange={(e) => { setAddrText(e.target.value); setAddrErr(false); }}
                        placeholder="محله، خیابان، کوچه"
                        maxLength={300}
                      />
                      {addrErr && <span className="err-msg"><Ic n="alert" c="sm" />آدرس را کامل‌تر وارد کنید</span>}
                    </div>
                    <div className="full row" style={{ gap: 10 }}>
                      <button className="btn btn-primary" onClick={saveAddress}>ذخیره آدرس</button>
                      <button className="btn btn-ghost" onClick={() => { setAddrForm(false); setAddrErr(false); }}>انصراف</button>
                    </div>
                  </div>
                )}
              </div>
            </section>
          )}

          {/* اطلاعات تماس و زمان */}
          <section className="card co-step">
            <h2><span className="n">{fa(stepContact)}</span>اطلاعات تماس و زمان</h2>
            <div className="form-grid">
              <div className="field">
                <label htmlFor="co-name">نام و نام خانوادگی</label>
                <input
                  className={`input${errors.name ? " err" : ""}`}
                  id="co-name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="مثلاً علی رضایی"
                  autoComplete="name"
                  maxLength={120}
                />
                {errors.name && <span className="err-msg"><Ic n="alert" c="sm" />{errors.name}</span>}
              </div>
              <div className="field">
                <label htmlFor="co-phone">شماره موبایل</label>
                <input
                  className={`input input-ltr tnum${errors.phone ? " err" : ""}`}
                  id="co-phone"
                  inputMode="numeric"
                  type="tel"
                  dir="ltr"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                  autoComplete="tel"
                  maxLength={11}
                  aria-label="شماره موبایل ۱۱ رقمی"
                />
                {errors.phone
                  ? <span className="err-msg"><Ic n="alert" c="sm" />{errors.phone}</span>
                  : <span className="hint">در این نسخه، وضعیت را در صفحهٔ پیگیری ببینید؛ پیامک ارسال نمی‌شود.</span>}
              </div>
              <div className="field full">
                <label>زمان {method === "pickup" ? "تحویل" : "ارسال"}</label>
                <div className="seg" style={{ alignSelf: "flex-start" }}>
                  <button
                    className={effWhen === "now" ? "on" : ""}
                    onClick={() => setWhen("now")}
                    disabled={!st?.open}
                    style={!st?.open ? { opacity: 0.5 } : undefined}
                  >
                    <Ic n="zap" />در اسرع وقت
                  </button>
                  <button className={effWhen === "later" ? "on" : ""} onClick={() => setWhen("later")}>
                    <Ic n="calendar" />زمان‌بندی
                  </button>
                </div>
                {effWhen === "later" && (
                  <select className="select" id="co-time" style={{ marginTop: 8, maxWidth: 320 }} value={time} onChange={(e) => setTime(e.target.value)}>
                    {slots.map((x) => <option key={x} value={x}>{x}</option>)}
                  </select>
                )}
              </div>
              <div className="field full">
                <label htmlFor="co-note">توضیحات برای فروشگاه <span className="faint">(اختیاری)</span></label>
                <textarea
                  className="textarea"
                  id="co-note"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="مثلاً: بدون پیاز، زنگ واحد ۲"
                  maxLength={2000}
                />
              </div>
            </div>
          </section>

          {/* روش پرداخت */}
          <section className="card co-step">
            <h2><span className="n">{fa(stepPay)}</span>روش پرداخت</h2>
            <div className="opt-grid" role="radiogroup">
              <button className={`opt ${pay === "online" ? "on" : ""}`} role="radio" aria-checked={pay === "online"} onClick={() => setPay("online")}>
                <span className="radio" />
                <span className="oi"><Ic n="card" /></span>
                <span>
                  <b>پرداخت آنلاین</b>
                  <small>درگاه امن بانکی (شاپرک)</small>
                </span>
              </button>
              <button className={`opt ${pay === "cash" ? "on" : ""}`} role="radio" aria-checked={pay === "cash"} onClick={() => setPay("cash")}>
                <span className="radio" />
                <span className="oi"><Ic n="cash" /></span>
                <span>
                  <b>پرداخت {method === "pickup" ? "در فروشگاه" : "هنگام تحویل"}</b>
                  <small>کارت‌خوان یا نقدی</small>
                </span>
              </button>
            </div>
          </section>
        </div>

        {/* خلاصهٔ سفارش */}
        <aside className="co-summary" style={{ position: "sticky", top: "calc(var(--header-h) + 16px)" }}>
          <div className="card summary">
            <div className="s-store">
              <span className={`lg tone tone-${s.tone}`}>
                <span className={`brand-monogram bm-${s.id}`}>{brandMonogram(s)}</span>
              </span>
              <div className="grow">
                <b>{s.name}</b>
                <div className="faint" style={{ fontSize: 14 }}>
                  {fa(cs.count)} کالا · <Link href={`/store/${s.id}`} className="link">ویرایش سبد</Link>
                </div>
              </div>
            </div>

            <div style={{ padding: "8px 18px", maxHeight: 240, overflow: "auto" }}>
              {cs.lines.map((l) => (
                <div className="sum-row" style={{ color: "var(--ink)" }} key={l.pid}>
                  <span className="ellipsis" style={{ maxWidth: "70%" }}>{fa(l.qty)}× {l.name}</span>
                  <span className="tnum">{tomanT(l.price * l.qty)}</span>
                </div>
              ))}
            </div>

            <div style={{ padding: "12px 18px", borderTop: "1px solid var(--line)" }}>
              <label htmlFor="co-code" style={{ fontSize: 14, fontWeight: 600, color: "var(--ink-2)" }}>کد تخفیف</label>
              <div className="code-row" style={{ marginTop: 6 }}>
                <input className="input" id="co-code" placeholder="JAM10" value={codeInput} onChange={(e) => setCodeInput(e.target.value)} maxLength={120} />
                <button className="btn btn-plain btn-sm" style={{ height: 42 }} onClick={codeApplied ? () => { setCodeApplied(null); setCodeInput(""); } : applyCode}>
                  {codeApplied ? "حذف" : "اعمال"}
                </button>
              </div>
              {codeErr ? (
                <div className="err-msg" style={{ marginTop: 6 }}><Ic n="alert" c="sm" />{codeErr}</div>
              ) : codeApplied ? (
                <div style={{ marginTop: 6, fontSize: 14, color: "var(--brand)" }}><Ic n="check" c="sm" /> {CODES[codeApplied].label}</div>
              ) : (
                <div className="hint" style={{ marginTop: 6 }}>کدهای نمونه: JAM10 · PICKUP5</div>
              )}
            </div>

            <div className="cart-sum">
              <div className="sum-row"><span>جمع اقلام</span><span className="tnum">{tomanT(sub)}</span></div>
              {itemDisc > 0 && (
                <div className="sum-row green"><span>تخفیف محصولات</span><span className="tnum">−{tomanT(itemDisc)}</span></div>
              )}
              <div className="sum-row">
                <span>{method === "pickup" ? "تحویل حضوری" : "هزینه ارسال"}</span>
                <span className="tnum">{fee ? tomanT(fee) : "رایگان"}</span>
              </div>
              {codeDisc > 0 && (
                <div className="sum-row green"><span>کد تخفیف</span><span className="tnum">−{tomanT(codeDisc)}</span></div>
              )}
              <div className="sum-row total"><span>مبلغ قابل پرداخت</span><span className="tnum">{tomanT(total)}</span></div>

              {saveTotal > 0 && (
                <div className="pill green" style={{ marginTop: 10, width: "100%", justifyContent: "center", height: 32 }}>
                  <Ic n="tag" c="sm" />سود شما از این خرید: {tomanT(saveTotal)}
                </div>
              )}

              <button className="btn btn-primary btn-lg btn-block" style={{ marginTop: 14 }} onClick={submit}>
                {pay === "online" ? "پرداخت و ثبت سفارش" : "ثبت سفارش"} <Ic n="arrowL" />
              </button>
              <p className="hint" style={{ textAlign: "center", margin: "10px 0 0" }}>
                با ثبت سفارش، <Link className="link" href="/business#faq">قوانین جم</Link> را می‌پذیرید.
              </p>
            </div>
          </div>
          <div className="ux-demo-note">
            <Ic n="info" c="sm" />
            <span>پرداخت، پیامک و پردازش سفارش در این فایل نمایشی‌اند؛ تراکنش بانکی انجام نمی‌شود.</span>
          </div>
        </aside>
      </div>

      {/* درگاه پرداخت آزمایشی */}
      {gwOpen && (
        <>
          <div className="overlay show" onClick={() => setGwOpen(false)} />
          <div className="modal-wrap" style={{ pointerEvents: "auto" }}>
            <div className="modal show" role="dialog" aria-modal="true" aria-label="پرداخت آزمایشی سفارش">
              <div className="m-head">
                <h3>پرداخت آزمایشی سفارش</h3>
                <button className="icon-btn" aria-label="بستن" onClick={() => setGwOpen(false)}><Ic n="x" /></button>
              </div>
              <div className="m-body">
                <p>این درگاه بانکی نیست و هیچ پولی جابه‌جا نمی‌شود.</p>
                <p>مبلغ سفارش: <b>{tomanT(total)}</b></p>
                <p>فقط با تأیید زیر سفارش در همین مرورگر ثبت می‌شود؛ بستن پنجره یعنی انصراف.</p>
              </div>
              <div className="m-foot">
                <button className="btn btn-primary" onClick={finish}>تأیید پرداخت آزمایشی</button>
                <button className="btn btn-ghost" onClick={() => setGwOpen(false)}>انصراف</button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

/* Real backend stores use a server-authoritative checkout; the legacy demo
   checkout remains available only for demo stores. */
export function CheckoutPage() {
  const { cart } = useJam();
  const cs = cartSummary(cart);
  if (cs.store?.api) return <ApiCheckoutPage store={cs.store} />;
  return <DemoCheckoutPage />;
}
