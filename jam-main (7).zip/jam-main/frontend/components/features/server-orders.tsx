"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Ic } from "@/components/icons";
import { useAuth } from "@/lib/auth";
import { ApiError, apiFetch } from "@/lib/api";
import { useMyOrders, type OrderRow } from "@/lib/commerce";
import { fa, fmtDate, fmtTime, tomanT } from "@/lib/format";

const ACTIVE = ["placed", "accepted", "preparing", "ready", "sent"];
const LABELS: Record<string, { short: string; title: string; cls: string }> = {
  placed: { short: "ثبت شده", title: "سفارش ثبت شد", cls: "blue" },
  accepted: { short: "تأیید شده", title: "فروشگاه سفارش را پذیرفت", cls: "violet" },
  preparing: { short: "در آماده‌سازی", title: "در حال آماده‌سازی", cls: "amber" },
  ready: { short: "آماده تحویل", title: "آمادهٔ تحویل", cls: "green" },
  sent: { short: "ارسال شده", title: "در راه است", cls: "blue" },
  done: { short: "تحویل شده", title: "تحویل شد", cls: "green" },
  rejected: { short: "رد شده", title: "سفارش پذیرفته نشد", cls: "red" },
  canceled: { short: "لغو شده", title: "سفارش لغو شد", cls: "gray" },
  refunded: { short: "مرجوع", title: "سفارش مرجوع شد", cls: "gray" },
};

function StatusPill({ status }: { status: string }) {
  const label = LABELS[status] || { short: status, cls: "gray" };
  return <span className={`pill ${label.cls}`}><span className="dot" />{label.short}</span>;
}

export function ServerOrdersPage() {
  const { ready, isAuthenticated } = useAuth();
  const { orders, loading, error, refresh } = useMyOrders();

  if (!ready || loading) return <div className="container" style={{ minHeight: "40vh" }} />;
  if (!isAuthenticated) {
    return (
      <div className="container" style={{ maxWidth: 880 }}>
        <div className="page-title"><h1>سفارش‌های من</h1></div>
        <div className="card">
          <div className="empty">
            <div className="e-ic"><Ic n="lock" /></div>
            <b>برای دیدن سفارش‌ها وارد شوید</b>
            <div style={{ marginTop: 16 }}><Link href="/login?next=/orders" className="btn btn-primary">ورود</Link></div>
          </div>
        </div>
      </div>
    );
  }

  const active = orders.filter((o) => ACTIVE.includes(o.status));
  const past = orders.filter((o) => !ACTIVE.includes(o.status));
  const row = (o: OrderRow) => (
    <Link key={o.number} href={`/order/${o.number}`} className="order-row">
      <span className="lg tone tone-restaurant"><span className="brand-monogram">{o.business_name.slice(0, 2)}</span></span>
      <div style={{ minWidth: 0 }}>
        <b>{o.business_name}</b>
        <div className="muted ellipsis" style={{ fontSize: 14 }}>
          {o.items.map((item) => `${fa(item.quantity)}× ${item.name}`).join("، ")}
        </div>
        <div className="faint tnum" style={{ fontSize: 14 }}>
          {fmtDate(o.created_at)} · {o.mode === "pickup" ? "تحویل حضوری" : "ارسال"} · {o.number}
        </div>
      </div>
      <div style={{ textAlign: "left", display: "flex", flexDirection: "column", gap: 6, alignItems: "flex-end" }}>
        <StatusPill status={o.status} />
        <b className="tnum">{tomanT(o.total_toman)}</b>
      </div>
    </Link>
  );

  return (
    <div className="container" style={{ maxWidth: 880 }}>
      <div className="page-title"><h1>سفارش‌های من</h1></div>
      {error ? (
        <div className="card"><div className="empty"><b>دریافت سفارش‌ها ناموفق بود</b><div style={{ fontSize: 14 }}>{error}</div><button className="btn btn-soft" onClick={refresh}>تلاش دوباره</button></div></div>
      ) : !orders.length ? (
        <div className="card"><div className="empty"><div className="e-ic"><Ic n="list" /></div><b>هنوز سفارشی ثبت نکرده‌اید</b><div style={{ marginTop: 16 }}><Link href="/" className="btn btn-primary">شروع خرید</Link></div></div></div>
      ) : (
        <>
          {active.length > 0 && <><h2 style={{ fontSize: 16, margin: "20px 0 10px" }}>سفارش‌های فعال</h2><div className="card">{active.map(row)}</div></>}
          {past.length > 0 && <><h2 style={{ fontSize: 16, margin: "24px 0 10px" }}>سفارش‌های قبلی</h2><div className="card">{past.map(row)}</div></>}
        </>
      )}
    </div>
  );
}

export function ServerOrderTracking({ orderId }: { orderId: string }) {
  const { ready, isAuthenticated } = useAuth();
  const [order, setOrder] = useState<OrderRow | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!ready) return;
    if (!isAuthenticated) {
      setLoading(false);
      return;
    }
    let active = true;
    setLoading(true);
    apiFetch<OrderRow>(`/commerce/orders/${encodeURIComponent(orderId)}/`)
      .then((res) => { if (active) setOrder(res); })
      .catch((err) => {
        if (active) setError(err instanceof ApiError && err.status === 404 ? "سفارش پیدا نشد." : err instanceof Error ? err.message : "دریافت سفارش ناموفق بود.");
      })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [ready, isAuthenticated, orderId]);

  if (!ready || loading) return <div className="container" style={{ minHeight: "40vh" }} />;
  if (!isAuthenticated) {
    return (
      <div className="container">
        <div className="card" style={{ marginTop: 32 }}><div className="empty"><b>برای دیدن سفارش وارد شوید</b><div style={{ marginTop: 16 }}><Link href={`/login?next=/order/${encodeURIComponent(orderId)}`} className="btn btn-primary">ورود</Link></div></div></div>
      </div>
    );
  }
  if (error || !order) {
    return (
      <div className="container">
        <div className="card" style={{ marginTop: 32 }}><div className="empty"><div className="e-ic"><Ic n="alert" /></div><b>{error || "سفارش پیدا نشد"}</b><div style={{ marginTop: 16 }}><Link href="/orders" className="btn btn-soft">سفارش‌های من</Link></div></div></div>
      </div>
    );
  }

  const label = LABELS[order.status] || { title: order.status, short: order.status, cls: "gray" };
  const history = order.history || [];

  return (
    <div className="container" style={{ maxWidth: 960 }}>
      <div className="crumbs">
        <Link href="/" className="ui-tap-link">خانه</Link>
        <Ic n="chevL" c="sm" />
        <Link href="/orders" className="ui-tap-link">سفارش‌ها</Link>
        <Ic n="chevL" c="sm" />
        <span className="tnum">{order.number}</span>
      </div>

      <div className="card" style={{ marginTop: 16, overflow: "hidden" }}>
        <div className="track-hero">
          <div>
            <StatusPill status={order.status} />
            <h1 style={{ marginTop: 10 }}>{label.title}</h1>
            <p className="muted" style={{ margin: "6px 0 0", maxWidth: 560, lineHeight: 1.85 }}>
              {order.mode === "pickup" ? "تحویل حضوری" : "ارسال به محل"} · {order.business_name}
            </p>
          </div>
          <div className="big-status tone tone-restaurant" style={{ fontSize: 36 }}>
            <span className="brand-monogram">{order.business_name.slice(0, 2)}</span>
          </div>
        </div>
      </div>

      <div className="co-layout" style={{ gridTemplateColumns: "1fr 340px" }}>
        <div>
          <div className="card">
            <div className="cart-head"><h3>اقلام سفارش</h3><span className="faint tnum" style={{ fontSize: 14 }}>{fa(order.items.reduce((sum, item) => sum + item.quantity, 0))} کالا</span></div>
            <div style={{ padding: "4px 18px" }}>
              {order.items.map((item) => (
                <div className="c-row" key={item.id}>
                  <span className="th tone tone-restaurant" aria-hidden="true"><Ic n="pkg" /></span>
                  <div className="grow"><div className="nm">{item.name}</div><div className="pr tnum">{fa(item.quantity)} × {tomanT(item.unit_price_toman)}</div></div>
                  <b className="tnum" style={{ fontSize: 14 }}>{tomanT(item.unit_price_toman * item.quantity)}</b>
                </div>
              ))}
            </div>
            <div className="cart-sum">
              <div className="sum-row"><span>جمع اقلام</span><span className="tnum">{tomanT(order.subtotal_toman)}</span></div>
              <div className="sum-row"><span>هزینه ارسال</span><span className="tnum">{order.delivery_fee_toman ? tomanT(order.delivery_fee_toman) : "رایگان"}</span></div>
              <div className="sum-row total"><span>مبلغ کل</span><span className="tnum">{tomanT(order.total_toman)}</span></div>
              <p className="hint">{order.payment_method === "online" ? "پرداخت آنلاین" : "پرداخت در محل"} · وضعیت پرداخت: {order.payment_state === "paid" ? "پرداخت‌شده" : "در انتظار پرداخت"}</p>
            </div>
          </div>

          <div className="card pad" style={{ marginTop: 16 }}>
            <b>روند سفارش</b>
            <div className="timeline" role="list" style={{ marginTop: 12 }}>
              {history.map((event) => (
                <div key={`${event.status}-${event.at}`} className="tl done" role="listitem">
                  <span className="b"><Ic n="check" /></span>
                  {LABELS[event.status]?.short || event.status}
                  <div className="faint tnum" style={{ fontWeight: 500, fontSize: 14 }}>{fmtTime(event.at)} · {fmtDate(event.at)}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <aside>
          <div className="card pad">
            <dl className="kv" style={{ margin: 0 }}>
              <dt>فروشگاه</dt><dd>{order.business_name}</dd>
              <dt>کد پیگیری</dt><dd className="tnum">{order.number}</dd>
              <dt>زمان ثبت</dt><dd className="tnum">{fmtTime(order.created_at)} · {fmtDate(order.created_at)}</dd>
              <dt>روش دریافت</dt><dd>{order.mode === "pickup" ? "تحویل حضوری" : "ارسال به محل"}</dd>
              {order.note ? <><dt>توضیحات</dt><dd>{order.note}</dd></> : null}
            </dl>
            <div style={{ marginTop: 18 }}><Link href="/orders" className="btn btn-ghost btn-block">همهٔ سفارش‌ها</Link></div>
          </div>
        </aside>
      </div>
    </div>
  );
}
