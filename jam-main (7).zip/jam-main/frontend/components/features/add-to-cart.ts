"use client";

/* افزودن به سبد با قاعدهٔ مرجع: هر سفارش فقط از یک فروشگاه */
import { useJam } from "@/lib/state";

export function useAddToCart() {
  const { cart, addToCart, clearCart } = useJam();
  return (sid: string, pid: string, qty = 1) => {
    if (cart && cart.sid !== sid && cart.items.length > 0) {
      if (!confirm("هر سفارش فقط از یک فروشگاه ثبت می‌شود. سبد قبلی حذف شود؟")) return;
      clearCart();
    }
    addToCart(sid, pid, qty);
  };
}
