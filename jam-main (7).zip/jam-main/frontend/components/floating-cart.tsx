"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useJam, cartSummary } from "@/lib/state";
import { fa } from "@/lib/format";

/* نوار شناور سبد خرید — در مرجع، فیکس پایین صفحه است و تا قبل از
   انتخاب کالا خالی می‌ماند (#fcart.has در CSS نمایش داده می‌شود). */
export default function FloatingCart() {
  const { cart, ready } = useJam();
  const pathname = usePathname() ?? "/";
  const has = !!cart && cart.items.length > 0;
  if (!ready || !has) return <div className="fcart" id="fcart" />;
  const s = cartSummary(cart);
  const hidden = pathname.startsWith("/m/") || pathname.startsWith("/checkout") || pathname.startsWith("/cart");
  return (
    <div className={`fcart${hidden ? "" : " has"}`} id="fcart">
      <Link href="/cart" className="fcart-link">
        <span className="cnt">{fa(s.count)}</span>
        <span className="grow">
          <b>مشاهده سبد خرید</b>
          <small>{s.store?.name}</small>
        </span>
        <span className="sum">
          {fa(s.total)} <small>تومان</small>
        </span>
      </Link>
    </div>
  );
}
