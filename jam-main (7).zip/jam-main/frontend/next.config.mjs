/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Let /api/* paths pass through to the backend verbatim (Django needs the
  // trailing slash; APPEND_SLASH cannot redirect a POST body).
  skipTrailingSlashRedirect: true,
  images: {
    remotePatterns: [{ protocol: "http", hostname: "localhost" }, { protocol: "https", hostname: "localhost" }],
  },
  // Same-origin /api proxy to the Django backend (documented deployment path:
  // frontend:3000 proxies /api/* to backend via API_INTERNAL_URL).
  async rewrites() {
    const internal = process.env.API_INTERNAL_URL;
    if (!internal) return [];
    return [{ source: "/api/:path*", destination: `${internal.replace(/\/$/, "")}/api/:path*` }];
  },
};

export default nextConfig;
