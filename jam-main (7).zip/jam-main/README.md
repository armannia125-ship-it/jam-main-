# Jam — Phase 1

A local-first foundation for Iranian businesses to publish digital menus. Phase 1 includes OTP authentication, owner-scoped menu management, a Telegram management bot, subscription/payment scaffolding, and a mobile-first public menu PWA. **Shopping carts and customer orders are intentionally out of scope.**

## Stack

- Backend: Python 3.12, Django 5, Django REST Framework, SimpleJWT, PostgreSQL
- Frontend: Next.js 15 App Router, TypeScript, Tailwind CSS, Serwist
- Bot: `python-telegram-bot` v20+
- Infrastructure: Docker Compose, PostgreSQL, Redis

## Quick start (Docker)

1. Copy `.env.example` to `.env` and set a strong `DJANGO_SECRET_KEY`. Add Telegram and ZarinPal credentials only if using those integrations.
2. Start services:

   ```bash
   docker compose up --build
   ```

3. The frontend is at <http://localhost:3000>, API at <http://localhost:8000/api/>, and Django admin at <http://localhost:8000/admin/>.
4. OTP delivery is mocked. With `DJANGO_DEBUG=True`, `/api/auth/request-otp/` returns `dev_otp` in its response. In production connect a real SMS/email provider and disable debug.
5. Create an admin user: `docker compose exec backend python manage.py createsuperuser` (phone is the username field).
6. Optional Telegram bot worker: `docker compose exec backend python manage.py run_telegram_bot`. Set `TELEGRAM_BOT_TOKEN` and `TELEGRAM_BOT_USERNAME` first.

## Local development (without Docker)

- Backend: create a Python 3.11+ virtual environment, install `backend/requirements.txt`, set environment variables from `.env.example`, run `python manage.py migrate` and `python manage.py runserver` from `backend/`.
- Frontend: from `frontend/`, run `npm install` then `npm run dev`. For local frontend development, set `API_INTERNAL_URL=http://localhost:8000`.

## API overview

All API paths are under `/api/`.

| Method | Path | Purpose |
|---|---|---|
| POST | `auth/request-otp/` | Request mock login OTP; JSON `{ "identifier": "+989121234567" }` or `{ "identifier": "owner@example.com" }` |
| POST | `auth/verify-otp/` | Verify `{ "identifier": "...", "code": "123456" }`; returns access/refresh JWTs |
| GET/POST | `businesses/` | List/create businesses owned by the JWT user |
| GET/POST | `menus/` | Manage menus for owned businesses |
| GET/POST | `categories/` | Manage categories for owned menus |
| GET/POST | `products/` | Manage products for owned categories |
| GET | `public/menus/{slug}/` | Public active menu, including available products |
| GET | `subscriptions/products/` | The five-product subscription catalog (public) |
| GET | `subscriptions/mine/` | Legacy subscriptions (historical, offline flow) |
| POST | `subscriptions/purchases/` | Start an online subscription purchase: `{ "product_slug": "gold", "business_id": 1 }` |
| GET | `subscriptions/purchases/<id>/` | Purchase + payment status (owner-scoped) |
| GET | `subscriptions/notifications/` | Subscription expiration notifications (owner-scoped) |
| GET | `admin/overview/` etc. | Platform-admin APIs (server-side `admin` role required) |

See `docs/SUBSCRIPTION_ARCHITECTURE.md`, `docs/ZARINPAL_PAYMENT_INTEGRATION.md`,
`docs/ADMIN_RBAC.md`, `docs/SUBSCRIPTION_NOTIFICATIONS.md`, and
`docs/LEGACY_COMPATIBILITY.md` for the current architecture. The legacy
manual/offline subscription flow (`subscriptions/request/`, `payment-info/`)
is retired and answers `410`; historical records remain intact.
| POST | `bot/telegram/link/` | Create a one-time Telegram account-link URL (JWT required) |

For owner endpoints send `Authorization: Bearer <access>`. CRUD is provided by DRF routers (GET/POST collection, GET/PUT/PATCH/DELETE by id). The bot supports `/start <token>`, `/categories`, `/products`, `/add <category_id> | <name> | <price_toman>`, `/edit <product_id> | <new name> | <new price_toman>`, and `/setprice <product_id> <price_toman>`.

## Configuration and operational notes

- Phone identifiers accept Iranian `09xxxxxxxxx` or `+989xxxxxxxxx` forms and are stored canonically as `+989xxxxxxxxx`.
- OTP challenge expiry and attempt limits are enforced. Configure upstream rate limiting and replace the mock delivery function before launch.
- The public menu is fetched through a same-origin Next.js rewrite and cached by the Serwist service worker for offline viewing after a successful online visit.
- Subscription checkout uses a ZarinPal adapter skeleton with sandbox support. Set `ZARINPAL_MERCHANT_ID`, callback URL, and production/sandbox mode. Never commit production secrets.
- Redis is configured as Django's cache backend; it also supports DRF throttling.
- CORS is permissive only in debug mode. HTTPS, secure cookie/proxy settings, provider integrations, monitoring, backups, and production review are still required.

## Project layout

```text
backend/config/         Django settings and root URLs
backend/accounts/       Custom user, OTP authentication, JWT endpoints
backend/businesses/     Business/menu/category/product APIs
backend/subscriptions/  Plans, subscriptions, checkout API
backend/payments/       Transaction model, gateway interface, ZarinPal adapter
backend/bot/            Telegram linking and menu-management command
frontend/app/           Next.js pages, PWA worker, API rewrite
```

## Create your first public menu

After OTP login, use the returned access token in the Authorization header:

```bash
export TOKEN='your-access-token'
curl -X POST http://localhost:8000/api/businesses/ -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{"name":"Cafe Jam","slug":"cafe-jam"}'
curl -X POST http://localhost:8000/api/menus/ -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{"business":1,"title":"Menu","slug":"cafe-jam-menu"}'
curl -X POST http://localhost:8000/api/categories/ -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{"menu":1,"name":"Drinks"}'
curl -X POST http://localhost:8000/api/products/ -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{"category":1,"name":"Tea","price_toman":50000}'
```

Replace example IDs with those returned by the previous requests. Visit `/m/cafe-jam-menu` on the frontend. Subscription plans can be created in Django admin. Refresh JWTs at `POST /api/auth/refresh/` with `{"refresh":"..."}`. Phone login and email login are independent identities unless both contacts have been securely associated with the same user; this phase does not automatically merge accounts.

### Connect Telegram

Call `POST /api/bot/telegram/link/` with your access token, open the returned `link_url` in a private Telegram chat, then use `/categories`, `/products`, `/add`, `/edit`, or `/setprice`. Start the polling command in a separate terminal; run exactly one polling process per bot token. Links expire after ten minutes and are single-use. Never share them.

### Tests and validation

```bash
cd backend
python manage.py test --settings=config.test_settings
python manage.py check
cd ../frontend
npm run typecheck
npm run build
```

The test-only settings use an in-memory SQLite database so API tests do not require PostgreSQL. Deployment always uses PostgreSQL. Tests cover OTP normalization/replay, inactive accounts, owner isolation, public product visibility, payment callback idempotency, and Toman-to-Rial conversion. Provider requests are mocked in tests.

### PWA verification

Use a production frontend build (`npm run build && npm start`), not `next dev`. Service workers require HTTPS except on localhost. Visit a public menu online, reload once after service-worker activation, then switch the browser to offline mode and revisit the same URL. Public menu data uses network-first caching with a cached offline fallback. Private API responses explicitly use network-only routing. First-ever offline visits and menus never fetched online cannot be served. Manifest icons are bundled locally.

### Scope and production checklist

- All menu prices and plan prices in the domain are **integer Toman**. The ZarinPal v4 adapter converts to **Rial** at its boundary. Confirm currency, endpoint versions, sandbox access, and callback behavior with your merchant account before accepting real payments.
- Payments are integration scaffolding, not an audited billing system: add reconciliation, webhook/abandoned-session handling, refund handling, and operational monitoring before production.
- Subscription records/status are visible, but menu publishing is not gated by subscription in Phase 1. Expired status is computed for API display; no scheduled expiry worker is needed yet.
- The dashboard is intentionally minimal (subscription status); menu authoring is via owner CRUD APIs, Django admin, and Telegram. The account-link API is available for a future dashboard button.
- Development OTPs are exposed **only** in debug responses. The mock delivery function does not send real SMS/email. With debug disabled, real delivery must be integrated for login to work.
- Tokens are stored in browser localStorage for this starter. For production, evaluate HttpOnly cookie/session handling, XSS protection, token revocation, and recovery flows. Do not cache authenticated data.
- Refresh rotation does not blacklist older refresh tokens in this phase. Add token revocation/blacklisting and a real logout endpoint if required.
- Replace `.env` example credentials, export environment variables for local development (Django does not auto-load the root `.env`), restrict allowed hosts/origins, use TLS, and review provider/IP and per-identifier OTP rate limits.

## Production Checklist & Known Limitations

- **JWT Storage**: Tokens are currently stored in `localStorage`. For production, evaluate migrating to HttpOnly Cookies to mitigate XSS risks.
- **OTP Delivery**: SMS and Email delivery are currently mocked. Integrate real providers (e.g., Kavenegar for SMS, SMTP for Email) before going live.
- **Subscription Expiry**: Expiry is currently evaluated lazily on API requests. A scheduled worker (e.g., Celery) is needed for automated state changes if required in the future.
- Dependency ranges and resolved lockfiles are supplied. Docker uses the backend lockfile and `npm ci`; review and update these locks and run dependency/security scans in CI before release. No external providers or Docker deployment are implicitly certified by the included unit tests.

### Local database prerequisites

For development outside Docker, PostgreSQL and Redis must be running and reachable. Override the Docker-only hostnames, for example `POSTGRES_HOST=localhost` and `REDIS_URL=redis://localhost:6379/1`; use credentials matching your local database. Install the backend with `pip install -r requirements.lock.txt` and frontend with `npm ci` for the validated dependency set.

# Phase 5 Status — Integration & CSS (Complete)
- All 15 legacy .ts compile; build passes; CSS verified (no regression); Docker NOT VERIFIED; Playwright unavailable.
- See PHASE5-STRUCTURED-REPORT.md and PHASE5-CSS-VERIFICATION.md.
