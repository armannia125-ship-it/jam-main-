"""JamPlay API URLs.

Included by ``backend/config/urls.py`` under the ``api/games/`` prefix.
Every path is trailing-slash compatible.
"""

from django.urls import path

from . import views

app_name = "games"

urlpatterns = [
    # Profile / catalog / league
    path("profile/", views.ProfileView.as_view(), name="profile"),
    path("catalog/", views.CatalogView.as_view(), name="catalog"),
    path("league/", views.LeagueView.as_view(), name="league"),

    # Phase 2: progression, missions, achievements, rewards
    path("progress/", views.ProgressView.as_view(), name="progress"),
    path("missions/", views.MissionsView.as_view(), name="missions"),
    path("missions/claim/", views.MissionClaimView.as_view(), name="mission-claim"),
    path("achievements/", views.AchievementsView.as_view(), name="achievements"),
    path("daily-gift/", views.DailyGiftView.as_view(), name="daily-gift"),

    # Phase 2: non-multiplayer social
    path("leaderboard/", views.LeaderboardView.as_view(), name="leaderboard"),
    path("friends/", views.FriendsView.as_view(), name="friends"),
    path("friends/search/", views.FriendSearchView.as_view(), name="friend-search"),
    path("friends/request/", views.FriendRequestView.as_view(), name="friend-request"),
    path("friends/respond/", views.FriendRespondView.as_view(), name="friend-respond"),
    path("friends/remove/", views.FriendRemoveView.as_view(), name="friend-remove"),
    path("friends/challenge/", views.FriendChallengeView.as_view(), name="friend-challenge"),

    # Cards & deck
    path("cards/", views.CardsView.as_view(), name="cards"),
    path("cards/upgrade/", views.CardUpgradeView.as_view(), name="card-upgrade"),
    path("deck/", views.DeckView.as_view(), name="deck"),

    # Buildings
    path("buildings/", views.BuildingsView.as_view(), name="buildings"),
    path("buildings/upgrade/", views.BuildingUpgradeView.as_view(), name="building-upgrade"),
    path("buildings/complete/", views.BuildingCompleteView.as_view(), name="building-complete"),

    # Chests
    path("chests/", views.ChestsView.as_view(), name="chests"),
    path("chests/<int:index>/start/", views.ChestStartView.as_view(), name="chest-start"),
    path("chests/<int:index>/claim/", views.ChestClaimView.as_view(), name="chest-claim"),

    # Arena
    path("arena/start/", views.ArenaStartView.as_view(), name="arena-start"),
    path("arena/action/", views.ArenaActionView.as_view(), name="arena-action"),
    path("arena/finish/", views.ArenaFinishView.as_view(), name="arena-finish"),

    # Siege
    path("siege/start/", views.SiegeStartView.as_view(), name="siege-start"),
    path("siege/action/", views.SiegeActionView.as_view(), name="siege-action"),
    path("siege/finish/", views.SiegeFinishView.as_view(), name="siege-finish"),

    # Battle history
    path("battles/", views.BattlesView.as_view(), name="battles"),
]
