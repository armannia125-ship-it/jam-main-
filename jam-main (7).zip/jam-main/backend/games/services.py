"""JamPlay domain services.

All persistence and business rules for the game live here so views stay thin
and every mutation is transactional, ownership-scoped and auditable.

Invariants:
* Balances only change through ``apply_delta`` (which writes a LedgerEntry in
  the same transaction).
* Battle settlement happens once, guarded by a row lock plus the status field.
* Chest and builder transitions are server-timestamp driven; clients only poll.
"""

from __future__ import annotations

import random
import uuid
from datetime import timedelta
from typing import Any

from django.db import transaction
from django.db.models import Q, Sum
from django.utils import timezone

from . import combat, rules as R
from .models import (
    AchievementUnlock,
    Battle,
    Building,
    BuilderJob,
    ChestSlot,
    DeckCard,
    GameEvent,
    GameFriend,
    GameProfile,
    LedgerEntry,
    LevelRecord,
    MissionProgress,
    PlayerCard,
)

# Town hall starts at level 3 so buildings can actually be upgraded in Phase 1.
# Town-hall upgrades above this level require discovery points, and City
# Discovery is out of Phase 1 scope, so they stay gated (documented).
STARTING_TOWN_HALL_LEVEL = 3


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _ledger_reason(value: str) -> str:
    return value


def apply_delta(profile: GameProfile, resource: str, delta: int, reason: str,
                reference: str = "", idempotency_key: str | None = None) -> int | None:
    """Apply a signed resource delta and append the audit entry atomically."""
    with transaction.atomic():
        locked = GameProfile.objects.select_for_update().get(pk=profile.pk)
        current = int(getattr(locked, resource))
        if idempotency_key and LedgerEntry.objects.filter(
            profile=locked, idempotency_key=idempotency_key
        ).exists():
            return None
        new_value = max(0, current + int(delta))
        setattr(locked, resource, new_value)
        locked.save(update_fields=[resource])
        LedgerEntry.objects.create(
            profile=locked,
            resource=resource,
            delta=int(delta),
            balance_after=new_value,
            reason=reason,
            reference=reference,
            idempotency_key=idempotency_key,
        )
        profile.__dict__[resource] = new_value
        return new_value


def spend_coins(profile: GameProfile, amount: int, reason: str, reference: str = "",
                idempotency_key: str | None = None) -> bool:
    if amount <= 0:
        return True
    with transaction.atomic():
        locked = GameProfile.objects.select_for_update().get(pk=profile.pk)
        if locked.coins < amount:
            return False
        apply_delta(locked, "coins", -amount, reason, reference, idempotency_key)
        return True


# ---------------------------------------------------------------------------
# Progression: levels, XP, level-up rewards
# ---------------------------------------------------------------------------


def _record_baseline_levels(profile: GameProfile, level: int) -> None:
    """Record levels already reached without paying retroactive rewards.

    Phase 1 had no level-up reward. Marking existing levels as baseline keeps
    the new 8-gem reward duplicate-safe and avoids inventing a retroactive
    payout for experience earned before Phase 2.
    """
    existing = set(profile.levels.values_list("level", flat=True))
    missing = [lvl for lvl in range(1, level + 1) if lvl not in existing]
    if missing:
        LevelRecord.objects.bulk_create(
            [LevelRecord(profile=profile, level=lvl, reward_gems=0, baseline=True) for lvl in missing],
            ignore_conflicts=True,
        )


def ensure_progression(profile: GameProfile) -> int:
    level = R.level_info(profile.xp)["level"]
    _record_baseline_levels(profile, level)
    return level


def grant_xp(profile: GameProfile, amount: int, reason: str, reference: str = "",
             idempotency_key: str | None = None) -> dict[str, Any]:
    """Apply XP and pay level-up gems exactly once per level."""
    amount = int(amount)
    with transaction.atomic():
        locked = GameProfile.objects.select_for_update().get(pk=profile.pk)
        before = R.level_info(locked.xp)["level"]
        _record_baseline_levels(locked, before)
        if amount <= 0:
            return {"xp": 0, "leveled": [], "level_before": before, "level_after": before}
        if idempotency_key and LedgerEntry.objects.filter(
            profile=locked, idempotency_key=idempotency_key
        ).exists():
            return {"xp": 0, "leveled": [], "level_before": before, "level_after": before, "duplicate": True}
        apply_delta(locked, "xp", amount, reason, reference, idempotency_key)
        after = R.level_info(locked.xp)["level"]
        leveled: list[dict[str, int]] = []
        for level in range(before + 1, after + 1):
            record, created = LevelRecord.objects.get_or_create(
                profile=locked, level=level, defaults={"reward_gems": R.LEVEL_UP_GEMS}
            )
            if created and record.reward_gems:
                apply_delta(
                    locked,
                    "gems",
                    record.reward_gems,
                    LedgerEntry.Reason.LEVEL_UP.value,
                    reference=f"level:{level}",
                    idempotency_key=f"levelup:{locked.id}:{level}",
                )
                leveled.append({"level": level, "gems": record.reward_gems})
        info = R.level_info(locked.xp)
        profile.__dict__.update({k: v for k, v in locked.__dict__.items() if not k.startswith("_")})
        return {
            "xp": amount,
            "leveled": leveled,
            "level_before": before,
            "level_after": after,
            "level": info["level"],
            "xp_in_level": info["xp"],
            "xp_need": info["need"],
        }


def grant_rewards(profile: GameProfile, rewards: dict[str, Any], reason: str,
                  reference: str, idem_prefix: str) -> dict[str, Any]:
    """Grant a reward bundle atomically; every component is idempotent."""
    gained: dict[str, int] = {}
    leveled: list[dict[str, int]] = []
    xp = int(rewards.get("xp") or 0)
    if xp:
        result = grant_xp(profile, xp, reason, reference, f"{idem_prefix}:xp")
        gained["xp"] = xp if not result.get("duplicate") else 0
        leveled = result.get("leveled", [])
    for resource in ("coins", "gems"):
        amount = int(rewards.get(resource) or 0)
        if not amount:
            continue
        new_balance = apply_delta(
            profile, resource, amount, reason, reference, f"{idem_prefix}:{resource}"
        )
        gained[resource] = amount if new_balance is not None else 0
    return {"gained": gained, "leveled": leveled}


# ---------------------------------------------------------------------------
# Events, missions and achievements (server-authoritative)
# ---------------------------------------------------------------------------


def _period_for(daily: bool) -> str:
    return timezone.localdate().isoformat() if daily else MissionProgress.PERMANENT


def _achievement_progress(profile: GameProfile, definition: dict[str, Any]) -> int:
    metric = definition.get("metric")
    if metric == "town_hall_level":
        return _town_hall_level(profile)
    if metric:
        return int(getattr(profile, metric, 0) or 0)
    total = GameEvent.objects.filter(profile=profile, kind=definition["event"]).aggregate(
        total=Sum("amount")
    )["total"]
    return int(total or 0)


def evaluate_achievements(profile: GameProfile) -> list[dict[str, Any]]:
    """Unlock every achievement whose server-side condition is met."""
    unlocked: list[dict[str, Any]] = []
    with transaction.atomic():
        locked = GameProfile.objects.select_for_update().get(pk=profile.pk)
        earned = set(locked.achievements.values_list("achievement_key", flat=True))
        for definition in R.ACHIEVEMENTS:
            if definition["key"] in earned:
                continue
            if _achievement_progress(locked, definition) < definition["target"]:
                continue
            _, created = AchievementUnlock.objects.get_or_create(
                profile=locked,
                achievement_key=definition["key"],
                defaults={"gems_awarded": definition["gems"]},
            )
            if not created:
                continue
            apply_delta(
                locked,
                "gems",
                definition["gems"],
                LedgerEntry.Reason.ACHIEVEMENT_REWARD.value,
                reference=f"achievement:{definition['key']}",
                idempotency_key=f"achievement:{locked.id}:{definition['key']}",
            )
            unlocked.append(
                {
                    "key": definition["key"],
                    "title": definition["title"],
                    "gems": definition["gems"],
                }
            )
        if unlocked:
            profile.__dict__.update(
                {k: v for k, v in locked.__dict__.items() if not k.startswith("_")}
            )
    return unlocked


def record_event(profile: GameProfile, kind: str, reference: str,
                 amount: int = 1, payload: dict[str, Any] | None = None) -> dict[str, Any]:
    """Persist a trusted event once and advance missions/achievements.

    The unique ``(profile, kind, reference)`` row is the idempotency guard, so
    retried settlements or claims cannot double-count progress.
    """
    with transaction.atomic():
        locked = GameProfile.objects.select_for_update().get(pk=profile.pk)
        _, created = GameEvent.objects.get_or_create(
            profile=locked,
            kind=kind,
            reference=reference[:96],
            defaults={"amount": max(1, int(amount)), "payload": payload or {}},
        )
        if not created:
            return {"created": False, "missions": [], "achievements": []}
        touched: list[str] = []
        for mission in R.missions_for_event(kind):
            daily = mission in R.DAILY_MISSIONS
            period = _period_for(daily)
            row, _ = MissionProgress.objects.select_for_update().get_or_create(
                profile=locked, mission_key=mission["key"], period=period
            )
            row.progress = min(mission["target"], row.progress + max(1, int(amount)))
            row.save(update_fields=["progress", "updated_at"])
            touched.append(mission["key"])
        unlocked = evaluate_achievements(locked)
    return {"created": True, "missions": touched, "achievements": unlocked}


def _mission_item(profile: GameProfile, mission: dict[str, Any], daily: bool) -> dict[str, Any]:
    period = _period_for(daily)
    row = MissionProgress.objects.filter(
        profile=profile, mission_key=mission["key"], period=period
    ).first()
    progress = min(mission["target"], row.progress if row else 0)
    claimed = bool(row and row.claimed_at)
    return {
        "key": mission["key"],
        "title": mission["title"],
        "icon": mission.get("icon", "flag"),
        "kind": "daily" if daily else "permanent",
        "progress": progress,
        "target": mission["target"],
        "ready": progress >= mission["target"] and not claimed,
        "claimed": claimed,
        "claimed_at": row.claimed_at if row else None,
        "rewards": mission["rewards"],
        "period": period,
    }


def missions_payload(profile: GameProfile) -> dict[str, Any]:
    daily = [_mission_item(profile, mission, True) for mission in R.DAILY_MISSIONS]
    permanent = [_mission_item(profile, mission, False) for mission in R.PERMANENT_MISSIONS]
    return {
        "date": timezone.localdate().isoformat(),
        "daily": daily,
        "permanent": permanent,
        "daily_claimed": sum(1 for item in daily if item["claimed"]),
        "daily_total": len(daily),
        "permanent_claimed": sum(1 for item in permanent if item["claimed"]),
        "permanent_total": len(permanent),
    }


def claim_mission(profile: GameProfile, mission_key: str) -> dict[str, Any]:
    mission = R.mission_definition(str(mission_key))
    if mission is None:
        return {"ok": False, "code": "mission_not_found", "detail": "این مأموریت وجود ندارد."}
    daily = mission in R.DAILY_MISSIONS
    period = _period_for(daily)
    with transaction.atomic():
        locked = GameProfile.objects.select_for_update().get(pk=profile.pk)
        row = MissionProgress.objects.select_for_update().filter(
            profile=locked, mission_key=mission["key"], period=period
        ).first()
        if row is None or row.progress < mission["target"]:
            return {"ok": False, "code": "mission_incomplete", "detail": "این مأموریت هنوز کامل نشده است."}
        if row.claimed_at:
            return {"ok": False, "code": "mission_claimed", "detail": "پاداش این مأموریت قبلاً دریافت شده است."}
        reference = f"mission:{mission['key']}:{period}"
        result = grant_rewards(
            locked,
            mission["rewards"],
            LedgerEntry.Reason.MISSION_REWARD.value,
            reference,
            f"mission:{locked.id}:{mission['key']}:{period}",
        )
        row.claimed_at = timezone.now()
        row.save(update_fields=["claimed_at", "updated_at"])
        unlocked = evaluate_achievements(locked)
        item = _mission_item(locked, mission, daily)
    return {
        "ok": True,
        "mission": item,
        "rewards": result["gained"],
        "leveled": result["leveled"],
        "achievements": unlocked,
        "profile": profile_payload(locked),
        "missions": missions_payload(locked),
    }


def achievements_payload(profile: GameProfile) -> list[dict[str, Any]]:
    earned = {unlock.achievement_key: unlock for unlock in profile.achievements.all()}
    items: list[dict[str, Any]] = []
    for definition in R.ACHIEVEMENTS:
        unlock = earned.get(definition["key"])
        progress = _achievement_progress(profile, definition)
        items.append(
            {
                "key": definition["key"],
                "title": definition["title"],
                "description": definition["description"],
                "icon": definition.get("icon", "trophy"),
                "target": definition["target"],
                "progress": min(definition["target"], progress),
                "unlocked": bool(unlock),
                "gems": definition["gems"],
                "unlocked_at": unlock.unlocked_at if unlock else None,
            }
        )
    return items


def daily_gift_payload(profile: GameProfile) -> dict[str, Any]:
    th_level = _town_hall_level(profile)
    gift = R.daily_gift(th_level)
    today = timezone.localdate()
    return {
        "available": profile.daily_gift_date != today,
        "date": today.isoformat(),
        "coins": gift["coins"],
        "gems": gift["gems"],
    }


def claim_daily_gift(profile: GameProfile) -> dict[str, Any]:
    today = timezone.localdate()
    with transaction.atomic():
        locked = GameProfile.objects.select_for_update().get(pk=profile.pk)
        if locked.daily_gift_date == today:
            return {"ok": False, "code": "daily_gift_claimed", "detail": "هدیهٔ امروز را گرفته‌ای؛ فردا دوباره سر بزن."}
        reference = f"daily:{locked.id}:{today.isoformat()}"
        result = grant_rewards(
            locked,
            R.daily_gift(_town_hall_level(locked)),
            LedgerEntry.Reason.DAILY_GIFT.value,
            reference,
            reference,
        )
        locked.daily_gift_date = today
        locked.save(update_fields=["daily_gift_date"])
        events = record_event(locked, GameEvent.Kind.DAILY_GIFT, reference)
    return {
        "ok": True,
        "rewards": result["gained"],
        "leveled": result["leveled"],
        "achievements": events["achievements"],
        "daily_gift": daily_gift_payload(locked),
        "profile": profile_payload(locked),
        "missions": missions_payload(locked),
    }


def progress_payload(profile: GameProfile) -> dict[str, Any]:
    profile = GameProfile.objects.get(pk=profile.pk)
    ensure_progression(profile)
    info = R.level_info(profile.xp)
    missions = missions_payload(profile)
    achievements = achievements_payload(profile)
    return {
        "level": info["level"],
        "xp": profile.xp,
        "xp_in_level": info["xp"],
        "xp_need": info["need"],
        "xp_to_next": max(0, info["need"] - info["xp"]),
        "next_level_gems": R.LEVEL_UP_GEMS,
        "level_history": [
            {"level": record.level, "gems": record.reward_gems, "reached_at": record.reached_at}
            for record in profile.levels.order_by("-level")[:12]
        ],
        "stats": {
            "arena_played": profile.arena_played,
            "arena_wins": profile.arena_wins,
            "arena_crowns": profile.arena_crowns,
            "siege_played": profile.siege_played,
            "siege_wins": profile.siege_wins,
            "siege_stars": profile.siege_stars,
            "friendly_played": profile.friendly_played,
            "total_wins": profile.total_wins,
            "trophies": profile.trophies,
            "best_trophies": profile.best_trophies,
            "league": league_payload(profile.trophies),
        },
        "missions": {
            "daily_claimed": missions["daily_claimed"],
            "daily_total": missions["daily_total"],
            "permanent_claimed": missions["permanent_claimed"],
            "permanent_total": missions["permanent_total"],
        },
        "achievements": {
            "unlocked": sum(1 for item in achievements if item["unlocked"]),
            "total": len(achievements),
        },
        "daily_gift": daily_gift_payload(profile),
    }


# ---------------------------------------------------------------------------
# Social: friends, leaderboard
# ---------------------------------------------------------------------------


def _friend_relation(profile: GameProfile, other: GameProfile) -> GameFriend | None:
    return GameFriend.objects.filter(
        Q(requester=profile, addressee=other) | Q(requester=other, addressee=profile)
    ).first()


def _friend_item(other: GameProfile, relation: str) -> dict[str, Any]:
    info = R.level_info(other.xp)
    league = league_payload(other.trophies)
    return {
        "profile_id": other.id,
        "display_name": other.resolved_name(),
        "level": info["level"],
        "trophies": other.trophies,
        "best_trophies": other.best_trophies,
        "league": league["name"],
        "relation": relation,
    }


def friends_payload(profile: GameProfile) -> dict[str, Any]:
    rows = GameFriend.objects.filter(
        Q(requester=profile) | Q(addressee=profile)
    ).select_related("requester", "addressee")
    friends: list[dict[str, Any]] = []
    incoming: list[dict[str, Any]] = []
    outgoing: list[dict[str, Any]] = []
    for row in rows:
        other = row.addressee if row.requester_id == profile.id else row.requester
        if row.status == GameFriend.Status.ACCEPTED:
            friends.append(_friend_item(other, "accepted"))
        elif row.addressee_id == profile.id:
            incoming.append(_friend_item(other, "incoming"))
        else:
            outgoing.append(_friend_item(other, "outgoing"))
    friends.sort(key=lambda item: (-item["trophies"], item["display_name"]))
    return {"friends": friends, "incoming": incoming, "outgoing": outgoing}


def friend_search(profile: GameProfile, query: str) -> dict[str, Any]:
    query = (query or "").strip()
    if len(query) < R.FRIEND_SEARCH_MIN:
        return {"ok": False, "code": "query_too_short", "detail": "برای جست‌وجو دست‌کم دو حرف بنویس."}
    matches = (
        GameProfile.objects.filter(display_name__icontains=query)
        .exclude(pk=profile.pk)
        .exclude(display_name="")
        .order_by("-trophies", "id")[: R.FRIEND_SEARCH_LIMIT]
    )
    results = []
    for candidate in matches:
        relation = _friend_relation(profile, candidate)
        if relation is None:
            label = "none"
        elif relation.status == GameFriend.Status.ACCEPTED:
            label = "accepted"
        elif relation.requester_id == profile.id:
            label = "outgoing"
        else:
            label = "incoming"
        results.append(_friend_item(candidate, label))
    return {"ok": True, "results": results}


def send_friend_request(profile: GameProfile, target_id: int) -> dict[str, Any]:
    target = GameProfile.objects.filter(pk=target_id).first()
    if target is None:
        return {"ok": False, "code": "player_not_found", "detail": "این بازیکن پیدا نشد."}
    if target.pk == profile.pk:
        return {"ok": False, "code": "friend_self", "detail": "نمی‌توانی به خودت درخواست دوستی بفرستی."}
    existing = _friend_relation(profile, target)
    if existing is not None:
        if existing.status == GameFriend.Status.ACCEPTED:
            return {"ok": False, "code": "already_friends", "detail": "شما از قبل دوست هستید."}
        if existing.addressee_id == profile.id:
            return {"ok": False, "code": "friend_request_incoming", "detail": "این بازیکن به تو درخواست داده است؛ آن را بپذیر."}
        return {"ok": False, "code": "friend_request_pending", "detail": "درخواست دوستی قبلاً فرستاده شده است."}
    GameFriend.objects.create(requester=profile, addressee=target)
    return {"ok": True, **friends_payload(profile)}


def respond_friend_request(profile: GameProfile, requester_id: int, accept: bool) -> dict[str, Any]:
    row = GameFriend.objects.filter(
        requester_id=requester_id, addressee=profile, status=GameFriend.Status.PENDING
    ).first()
    if row is None:
        return {"ok": False, "code": "friend_request_not_found", "detail": "درخواست دوستی پیدا نشد."}
    if accept:
        row.status = GameFriend.Status.ACCEPTED
        row.responded_at = timezone.now()
        row.save(update_fields=["status", "responded_at"])
    else:
        row.delete()
    return {"ok": True, **friends_payload(profile)}


def remove_friend(profile: GameProfile, other_id: int) -> dict[str, Any]:
    deleted, _ = GameFriend.objects.filter(
        Q(requester=profile, addressee_id=other_id) | Q(requester_id=other_id, addressee=profile)
    ).delete()
    if not deleted:
        return {"ok": False, "code": "friend_not_found", "detail": "این دوستی پیدا نشد."}
    return {"ok": True, **friends_payload(profile)}


def leaderboard_payload(profile: GameProfile) -> dict[str, Any]:
    top = GameProfile.objects.order_by("-trophies", "-best_trophies", "id")[: R.LEADERBOARD_LIMIT]
    entries = []
    me_rank = GameProfile.objects.filter(trophies__gt=profile.trophies).count() + 1
    for index, item in enumerate(top, start=1):
        entries.append(
            {
                "rank": index,
                "display_name": item.resolved_name(),
                "level": R.level_info(item.xp)["level"],
                "trophies": item.trophies,
                "is_me": item.pk == profile.pk,
            }
        )
    return {
        "entries": entries,
        "me": {
            "rank": me_rank,
            "display_name": profile.resolved_name(),
            "level": R.level_info(profile.xp)["level"],
            "trophies": profile.trophies,
            "is_me": True,
        },
        "total_players": GameProfile.objects.count(),
    }


def update_display_name(profile: GameProfile, name: str) -> dict[str, Any]:
    name = (name or "").strip()
    if not (R.DISPLAY_NAME_MIN <= len(name) <= R.DISPLAY_NAME_MAX):
        return {
            "ok": False,
            "code": "invalid_display_name",
            "detail": f"نام نمایشی باید بین {R.DISPLAY_NAME_MIN} و {R.DISPLAY_NAME_MAX} حرف باشد.",
        }
    profile.display_name = name
    profile.save(update_fields=["display_name"])
    return {"ok": True, "profile": profile_payload(profile)}


# ---------------------------------------------------------------------------
# Profile bootstrap / payloads
# ---------------------------------------------------------------------------


def get_profile(user) -> GameProfile:
    profile, created = GameProfile.objects.get_or_create(user=user)
    if created:
        _bootstrap(profile)
    else:
        _ensure_collection(profile)
    ensure_progression(profile)
    return profile


def _ensure_collection(profile: GameProfile) -> None:
    existing = {c.card_key for c in profile.cards.all()}
    for key in R.STARTER_CARDS:
        if key not in existing:
            PlayerCard.objects.create(profile=profile, card_key=key, level=1, copies=1)
    if profile.deck.count() == 0:
        for slot, key in enumerate(R.STARTER_CARDS[: R.DECK_SIZE]):
            DeckCard.objects.create(profile=profile, slot=slot, card_key=key)


def _bootstrap(profile: GameProfile) -> None:
    _ensure_collection(profile)
    for item in R.BASE_LAYOUT:
        level = STARTING_TOWN_HALL_LEVEL if item["type"] == "th" else 1
        Building.objects.get_or_create(
            profile=profile,
            key=item["key"],
            defaults={
                "building_type": item["type"],
                "grid_x": item["gx"],
                "grid_y": item["gy"],
                "level": level,
            },
        )
    if not ChestSlot.objects.filter(profile=profile).exists():
        for index in range(R.CHEST_SLOTS):
            if index == 0:
                ChestSlot.objects.create(
                    profile=profile, index=index, kind="silver", state=ChestSlot.State.READY
                )
            else:
                ChestSlot.objects.create(
                    profile=profile, index=index, kind="", state=ChestSlot.State.EMPTY
                )
    # Audit the starting grant (only when it is actually the opening balance).
    if not profile.ledger.exists():
        LedgerEntry.objects.create(
            profile=profile,
            resource=LedgerEntry.Resource.COINS.value,
            delta=profile.coins,
            balance_after=profile.coins,
            reason=LedgerEntry.Reason.STARTING_GRANT.value,
            reference="profile_bootstrap",
        )
        LedgerEntry.objects.create(
            profile=profile,
            resource=LedgerEntry.Resource.GEMS.value,
            delta=profile.gems,
            balance_after=profile.gems,
            reason=LedgerEntry.Reason.STARTING_GRANT.value,
            reference="profile_bootstrap",
        )


def league_payload(trophies: int) -> dict[str, Any]:
    index = R.league_index(trophies)
    current = R.LEAGUES[index]
    nxt = R.LEAGUES[index + 1] if index + 1 < len(R.LEAGUES) else None
    if nxt:
        span = max(1, nxt["min"] - current["min"])
        progress = round(min(1.0, max(0.0, (trophies - current["min"]) / span)), 3)
    else:
        progress = 1.0
    return {
        "index": index,
        "name": current["name"],
        "color": current["color"],
        "min": current["min"],
        "next_min": nxt["min"] if nxt else None,
        "next_name": nxt["name"] if nxt else None,
        "progress": progress,
    }


def profile_payload(profile: GameProfile) -> dict[str, Any]:
    profile = GameProfile.objects.get(pk=profile.pk)
    level = R.level_info(profile.xp)
    return {
        "id": profile.id,
        "display_name": profile.resolved_name(),
        "coins": profile.coins,
        "gems": profile.gems,
        "xp": profile.xp,
        "level": level["level"],
        "xp_in_level": level["xp"],
        "xp_need": level["need"],
        "trophies": profile.trophies,
        "best_trophies": profile.best_trophies,
        "league": league_payload(profile.trophies),
        "arena_played": profile.arena_played,
        "arena_wins": profile.arena_wins,
        "arena_crowns": profile.arena_crowns,
        "siege_played": profile.siege_played,
        "siege_wins": profile.siege_wins,
        "siege_stars": profile.siege_stars,
        "friendly_played": profile.friendly_played,
        "total_wins": profile.total_wins,
        "first_battle_done": profile.first_battle_done,
        "level_up_gems": R.LEVEL_UP_GEMS,
        "daily_gift_available": profile.daily_gift_date != timezone.localdate(),
        "town_hall_level": _town_hall_level(profile),
        "started_at": profile.created_at,
    }


def _town_hall_level(profile: GameProfile) -> int:
    th = profile.buildings.filter(key="th").first()
    return th.level if th else 1


# ---------------------------------------------------------------------------
# Cards & deck
# ---------------------------------------------------------------------------


def cards_payload(profile: GameProfile) -> list[dict[str, Any]]:
    owned = {c.card_key: c for c in profile.cards.all()}
    items: list[dict[str, Any]] = []
    for key, base in R.CARDS.items():
        card = owned.get(key)
        level = card.level if card else 0
        items.append(
            {
                "key": key,
                "name": base["name"],
                "art": base["art"],
                "cost": base["cost"],
                "role": base.get("role", ""),
                "description": base.get("description", ""),
                "owned": bool(card),
                "level": level,
                "copies": card.copies if card else 0,
                "max_level": R.CARD_MAX_LEVEL,
                "upgrade_cost": R.card_upgrade_cost(level) if card else 0,
                "upgrade_copies": R.card_upgrade_copies(level) if card else 0,
                "can_upgrade": bool(
                    card
                    and level < R.CARD_MAX_LEVEL
                    and card.copies >= R.card_upgrade_copies(level)
                    and profile.coins >= R.card_upgrade_cost(level)
                ),
                "stats": combat.unit_stats(key, max(1, level)),
            }
        )
    return items


def deck_payload(profile: GameProfile) -> list[dict[str, Any]]:
    owned = {c.card_key: c for c in profile.cards.all()}
    cards = []
    for slot in profile.deck.all().order_by("slot"):
        card = owned.get(slot.card_key)
        base = R.CARDS.get(slot.card_key, {})
        cards.append(
            {
                "slot": slot.slot,
                "key": slot.card_key,
                "name": base.get("name", slot.card_key),
                "art": base.get("art", slot.card_key),
                "cost": base.get("cost", 0),
                "level": card.level if card else 1,
                "owned": bool(card),
            }
        )
    return cards


def set_deck(profile: GameProfile, keys: list[str]) -> dict[str, Any]:
    if not isinstance(keys, list) or len(keys) != R.DECK_SIZE:
        return {"ok": False, "code": "deck_size", "detail": f"دسته باید دقیقاً {R.DECK_SIZE} کارت داشته باشد."}
    if len(set(keys)) != len(keys):
        return {"ok": False, "code": "deck_duplicate", "detail": "هر کارت فقط یک بار در دسته مجاز است."}
    owned = {c.card_key for c in profile.cards.all()}
    missing = [key for key in keys if key not in owned]
    if missing:
        return {"ok": False, "code": "deck_unowned", "detail": "همهٔ کارت‌های دسته باید در مالکیت تو باشند.", "missing": missing}
    with transaction.atomic():
        profile.deck.all().delete()
        DeckCard.objects.bulk_create(
            [DeckCard(profile=profile, slot=i, card_key=key) for i, key in enumerate(keys)]
        )
    return {"ok": True, "deck": deck_payload(profile)}


def upgrade_card(profile: GameProfile, card_key: str) -> dict[str, Any]:
    card = profile.cards.filter(card_key=card_key).first()
    if card is None:
        return {"ok": False, "code": "card_not_owned", "detail": "این کارت را نداری."}
    if card.level >= R.CARD_MAX_LEVEL:
        return {"ok": False, "code": "max_level", "detail": "این کارت به بالاترین سطح رسیده است."}
    need = R.card_upgrade_copies(card.level)
    cost = R.card_upgrade_cost(card.level)
    if card.copies < need:
        return {"ok": False, "code": "copies", "detail": f"{need - card.copies} نسخهٔ دیگر لازم است."}
    if profile.coins < cost:
        return {"ok": False, "code": "insufficient_coins", "detail": "سکهٔ کافی نداری."}
    with transaction.atomic():
        locked = GameProfile.objects.select_for_update().get(pk=profile.pk)
        if not spend_coins(locked, cost, LedgerEntry.Reason.CARD_UPGRADE.value,
                           reference=f"card:{card_key}", idempotency_key=f"card-upg:{profile.id}:{card_key}:{card.level}"):
            return {"ok": False, "code": "insufficient_coins", "detail": "سکهٔ کافی نداری."}
        card.copies -= need
        card.level += 1
        card.save(update_fields=["copies", "level"])
    return {
        "ok": True,
        "card_key": card_key,
        "level": card.level,
        "copies": card.copies,
        "coins": GameProfile.objects.get(pk=profile.pk).coins,
    }


def grant_card(profile: GameProfile, card_key: str) -> PlayerCard:
    card, created = PlayerCard.objects.get_or_create(profile=profile, card_key=card_key)
    if created:
        card.level = 1
        card.copies = 1
    else:
        card.copies = min(999, card.copies + 1)
    card.save()
    return card


# ---------------------------------------------------------------------------
# Buildings & builder
# ---------------------------------------------------------------------------


def _apply_finished_job(profile: GameProfile) -> None:
    job = BuilderJob.objects.filter(profile=profile).first()
    if not job or job.finish_at > timezone.now():
        return
    building = Building.objects.filter(profile=profile, key=job.building_key).first()
    if building:
        cap = R.max_level_for(building.building_type, _town_hall_level(profile))
        building.level = min(building.level + 1, cap)
        building.save(update_fields=["level"])
        record_event(
            profile,
            GameEvent.Kind.BUILDING_UPGRADE,
            f"building:{profile.id}:{building.key}:{building.level}",
            payload={"building": building.key, "level": building.level},
        )
    job.delete()


def sync_builder(profile: GameProfile) -> None:
    with transaction.atomic():
        profile_locked = GameProfile.objects.select_for_update().get(pk=profile.pk)
        _apply_finished_job(profile_locked)


def building_can_upgrade(profile: GameProfile, building: Building) -> dict[str, Any]:
    builder = BuilderJob.objects.filter(profile=profile).first()
    if builder and builder.finish_at > timezone.now():
        return {"ok": False, "code": "builder_busy", "detail": "سازنده مشغول است."}
    try:
        meta = R.BUILDING_TYPES[building.building_type]
    except KeyError:
        return {"ok": False, "code": "invalid_building", "detail": "ساختمان نامعتبر است."}
    if building.building_type in ("chest", "hero"):
        return {"ok": False, "code": "not_upgradable", "detail": "این ساختمان ارتقا نمی‌پذیرد."}
    if building.level >= meta["max_level"]:
        return {"ok": False, "code": "max_level", "detail": "به بالاترین سطح رسیده است."}
    th_level = _town_hall_level(profile)
    if building.building_type != "th" and building.level >= th_level:
        return {"ok": False, "code": "town_hall", "detail": "اول تالار شهر را ارتقا بده."}
    if building.building_type == "th":
        need = R.TOWN_HALL_DP[min(building.level + 1, len(R.TOWN_HALL_DP) - 1)]
        if profile.discovery_points < need:
            return {
                "ok": False,
                "code": "discovery_points",
                "detail": f"{need} امتیاز کشف لازم است (کشف شهر در فاز ۱ فعال نیست).",
            }
    cost = R.upgrade_cost(building.building_type, building.level)
    if profile.coins < cost:
        return {"ok": False, "code": "insufficient_coins", "detail": f"{cost - profile.coins} سکهٔ دیگر لازم است.", "cost": cost}
    return {"ok": True, "cost": cost}


def buildings_payload(profile: GameProfile) -> dict[str, Any]:
    sync_builder(profile)
    profile = GameProfile.objects.get(pk=profile.pk)
    th_level = _town_hall_level(profile)
    builder = BuilderJob.objects.filter(profile=profile).first()
    items = []
    for building in profile.buildings.all().order_by("key"):
        meta = R.BUILDING_TYPES.get(building.building_type, {})
        check = building_can_upgrade(profile, building)
        items.append(
            {
                "key": building.key,
                "type": building.building_type,
                "name": meta.get("name", building.building_type),
                "art": meta.get("art", building.building_type),
                "grid_x": building.grid_x,
                "grid_y": building.grid_y,
                "size": meta.get("size", 2),
                "level": building.level,
                "max_level": meta.get("max_level", 1),
                "effect": meta.get("effect", ""),
                "next_effect": _effect_line(building.building_type, building.level + 1),
                "upgrade_cost": R.upgrade_cost(building.building_type, building.level)
                if check.get("code") not in ("max_level", "not_upgradable")
                else 0,
                "upgrade_seconds": R.upgrade_seconds(building.level),
                "can_upgrade": bool(check.get("ok")),
                "blocked_reason": check.get("detail", ""),
                "blocked_code": check.get("code", ""),
            }
        )
    return {
        "town_hall_level": th_level,
        "discovery_points": profile.discovery_points,
        "buildings": items,
        "builder": {
            "busy": bool(builder),
            "building_key": builder.building_key if builder else None,
            "finish_at": builder.finish_at if builder else None,
            "remaining_seconds": max(0, int((builder.finish_at - timezone.now()).total_seconds()))
            if builder
            else 0,
        },
    }


def _effect_line(building_type: str, level: int) -> str:
    return {
        "th": f"سقف سطح ساختمان‌ها: {level}",
        "vault": f"ظرفیت {R.vault_capacity(level)} سکه",
        "camp": f"{R.camp_rate(level)} سکه در ساعت",
        "mine": f"{R.mine_rate(level)} الماس در ساعت",
        "tower": f"جان برج‌های تو در آوردگاه +{round(2.5 * (level - 1))}٪",
        "bazaar": f"پاداش سکهٔ پیشنهادها +{15 * (level - 1)}٪",
        "fountain": f"تجربهٔ همهٔ فعالیت‌ها +{4 * (level - 1)}٪",
    }.get(building_type, "")


def start_building_upgrade(profile: GameProfile, building_key: str) -> dict[str, Any]:
    with transaction.atomic():
        locked = GameProfile.objects.select_for_update().get(pk=profile.pk)
        _apply_finished_job(locked)
        building = Building.objects.filter(profile=locked, key=building_key).first()
        if building is None:
            return {"ok": False, "code": "building_not_found", "detail": "ساختمان پیدا نشد."}
        check = building_can_upgrade(locked, building)
        if not check.get("ok"):
            return check
        cost = check["cost"]
        if not spend_coins(
            locked, cost, LedgerEntry.Reason.BUILDING_UPGRADE.value,
            reference=f"building:{building_key}",
            idempotency_key=f"bupg:{profile.id}:{building_key}:{building.level}",
        ):
            return {"ok": False, "code": "insufficient_coins", "detail": "سکهٔ کافی نداری."}
        finish_at = timezone.now() + timedelta(seconds=R.upgrade_seconds(building.level))
        BuilderJob.objects.update_or_create(
            profile=locked,
            defaults={"building_key": building_key, "started_at": timezone.now(), "finish_at": finish_at},
        )
    return {
        "ok": True,
        "building_key": building_key,
        "cost": cost,
        "finish_at": finish_at,
        "coins": GameProfile.objects.get(pk=profile.pk).coins,
    }


def complete_building_upgrade(profile: GameProfile, building_key: str) -> dict[str, Any]:
    with transaction.atomic():
        locked = GameProfile.objects.select_for_update().get(pk=profile.pk)
        job = BuilderJob.objects.filter(profile=locked, building_key=building_key).first()
        if job is None:
            return {"ok": False, "code": "no_job", "detail": "ساختاری در حال ارتقا نیست."}
        if job.finish_at > timezone.now():
            return {
                "ok": False,
                "code": "not_ready",
                "detail": "زمان ارتقا تمام نشده است.",
                "remaining_seconds": int((job.finish_at - timezone.now()).total_seconds()),
            }
        _apply_finished_job(locked)
    return {"ok": True, "buildings": buildings_payload(profile)}


# ---------------------------------------------------------------------------
# Chests
# ---------------------------------------------------------------------------


def _sync_chest(slot: ChestSlot) -> ChestSlot:
    if slot.state == ChestSlot.State.OPENING and slot.ready_at and slot.ready_at <= timezone.now():
        slot.state = ChestSlot.State.READY
        slot.save(update_fields=["state"])
    return slot


def chests_payload(profile: GameProfile) -> dict[str, Any]:
    ensure_chest_slots(profile)
    slots = []
    now = timezone.now()
    for slot in ChestSlot.objects.filter(profile=profile).order_by("index"):
        slot = _sync_chest(slot)
        remaining = 0
        if slot.state == ChestSlot.State.OPENING and slot.ready_at:
            remaining = max(0, int((slot.ready_at - now).total_seconds()))
        meta = R.CHEST_TYPES.get(slot.kind, {})
        slots.append(
            {
                "index": slot.index,
                "kind": slot.kind,
                "kind_name": meta.get("name", ""),
                "state": slot.state,
                "ready_at": slot.ready_at,
                "remaining_seconds": remaining,
                "minutes": meta.get("minutes", 0),
                "cards": meta.get("cards", 0),
                "coins_min": meta.get("coins", (0, 0))[0],
                "coins_max": meta.get("coins", (0, 0))[1],
                "gems_min": meta.get("gems", (0, 0))[0] if meta.get("gems") else 0,
                "gems_max": meta.get("gems", (0, 0))[1] if meta.get("gems") else 0,
            }
        )
    return {"slots": slots}


def ensure_chest_slots(profile: GameProfile) -> None:
    existing = set(ChestSlot.objects.filter(profile=profile).values_list("index", flat=True))
    for index in range(R.CHEST_SLOTS):
        if index not in existing:
            ChestSlot.objects.create(profile=profile, index=index, kind="", state=ChestSlot.State.EMPTY)


def award_chest(profile: GameProfile, kind: str) -> int | None:
    ensure_chest_slots(profile)
    slot = ChestSlot.objects.filter(profile=profile, state=ChestSlot.State.EMPTY).order_by("index").first()
    if slot is None:
        return None
    slot.kind = kind
    slot.state = ChestSlot.State.LOCKED
    slot.ready_at = None
    slot.save(update_fields=["kind", "state", "ready_at"])
    return slot.index


def start_chest(profile: GameProfile, index: int) -> dict[str, Any]:
    with transaction.atomic():
        slot = ChestSlot.objects.select_for_update().filter(profile=profile, index=index).first()
        if slot is None:
            return {"ok": False, "code": "slot_missing", "detail": "جایگاه صندوق پیدا نشد."}
        _sync_chest(slot)
        if slot.state == ChestSlot.State.EMPTY:
            return {"ok": False, "code": "empty", "detail": "این جایگاه خالی است."}
        if slot.state == ChestSlot.State.OPENING:
            return {"ok": False, "code": "already_opening", "detail": "این صندوق در حال باز شدن است."}
        if slot.state == ChestSlot.State.READY:
            return {"ok": False, "code": "ready", "detail": "این صندوق آمادهٔ دریافت است."}
        meta = R.CHEST_TYPES.get(slot.kind)
        if not meta:
            return {"ok": False, "code": "invalid_kind", "detail": "نوع صندوق نامعتبر است."}
        slot.state = ChestSlot.State.OPENING
        slot.ready_at = timezone.now() + timedelta(minutes=meta["minutes"])
        slot.save(update_fields=["state", "ready_at"])
    return {"ok": True, "chests": chests_payload(profile)}


def claim_chest(profile: GameProfile, index: int) -> dict[str, Any]:
    with transaction.atomic():
        slot = ChestSlot.objects.select_for_update().filter(profile=profile, index=index).first()
        if slot is None:
            return {"ok": False, "code": "slot_missing", "detail": "جایگاه صندوق پیدا نشد."}
        _sync_chest(slot)
        if slot.state != ChestSlot.State.READY:
            return {"ok": False, "code": "not_ready", "detail": "این صندوق آمادهٔ دریافت نیست."}
        meta = R.CHEST_TYPES.get(slot.kind)
        if not meta:
            return {"ok": False, "code": "invalid_kind", "detail": "نوع صندوق نامعتبر است."}
        rng = random.Random(f"{profile.id}:{index}:{slot.kind}:{slot.pk}")
        coin_low, coin_high = meta["coins"]
        coins = rng.randint(coin_low, coin_high)
        gems = 0
        if meta.get("gems"):
            gems = rng.randint(meta["gems"][0], meta["gems"][1])
        card_pool = list(R.STARTER_CARDS)
        cards = [rng.choice(card_pool) for _ in range(3 if slot.kind == "silver" else 5)]
        kind = slot.kind
        claim_ref = uuid.uuid4().hex
        # Consume the chest before granting anything (idempotent claim). The
        # row lock plus the state transition is the real idempotency guard; the
        # per-claim token keeps ledger keys unique across repeated slot reuse.
        slot.state = ChestSlot.State.EMPTY
        slot.kind = ""
        slot.ready_at = None
        slot.save(update_fields=["state", "kind", "ready_at"])

        apply_delta(profile, "coins", coins, LedgerEntry.Reason.CHEST_REWARD.value,
                    reference=f"chest:{index}:{kind}", idempotency_key=f"chest:{slot.pk}:{claim_ref}:coins")
        if gems:
            apply_delta(profile, "gems", gems, LedgerEntry.Reason.CHEST_REWARD.value,
                        reference=f"chest:{index}:{kind}", idempotency_key=f"chest:{slot.pk}:{claim_ref}:gems")
        for card_key in cards:
            if card_key in R.CARDS:
                grant_card(profile, card_key)
    return {
        "ok": True,
        "kind": kind,
        "rewards": {"coins": coins, "gems": gems, "cards": cards},
        "chests": chests_payload(profile),
        "profile": profile_payload(profile),
    }


# ---------------------------------------------------------------------------
# Battles
# ---------------------------------------------------------------------------


def _opponent(profile: GameProfile, seed: int) -> dict[str, Any]:
    rng = random.Random(seed)
    league = R.league_index(profile.trophies)
    return {
        "name": rng.choice(R.OPPONENT_NAMES),
        "league": league,
        "league_name": R.LEAGUES[league]["name"],
        "card_level": R.foe_card_level(profile.trophies),
    }


def _deck_levels(profile: GameProfile) -> tuple[list[str], dict[str, int]]:
    owned = {c.card_key: c.level for c in profile.cards.all()}
    deck = [d.card_key for d in profile.deck.all().order_by("slot")]
    if len(deck) != R.DECK_SIZE:
        deck = list(R.STARTER_CARDS[: R.DECK_SIZE])
    return deck, {key: owned.get(key, 1) for key in deck}


def battle_payload(battle: Battle) -> dict[str, Any]:
    return {
        "battle_key": battle.key,
        "mode": battle.mode,
        "status": battle.status,
        "difficulty": battle.difficulty,
        "opponent": battle.opponent_name,
        "friendly": battle.friendly,
        "snapshot": combat.snapshot(battle.state or {}),
        "rewards": battle.rewards or {},
        "result": battle.result,
    }


def start_arena(profile: GameProfile) -> dict[str, Any]:
    deck, levels = _deck_levels(profile)
    if not profile.first_battle_done:
        profile.first_battle_done = True
        profile.save(update_fields=["first_battle_done"])
    seed = random.randint(1, 2**31 - 1)
    difficulty = R.battle_difficulty(profile.trophies, not profile.total_wins)
    opponent = _opponent(profile, seed)
    state = combat.arena_new(deck, levels, seed, difficulty, opponent)
    battle = Battle.objects.create(
        profile=profile,
        mode=Battle.Mode.ARENA,
        status=Battle.Status.ACTIVE,
        seed=seed,
        config={"deck": deck, "levels": levels, "difficulty": difficulty},
        state=state,
        last_tick=0,
        opponent_name=opponent["name"],
        difficulty=difficulty,
    )
    return {"ok": True, "battle": battle_payload(battle)}


def start_siege(profile: GameProfile) -> dict[str, Any]:
    _, levels = _deck_levels(profile)
    th_level = _town_hall_level(profile)
    seed = random.randint(1, 2**31 - 1)
    opponent = _opponent(profile, seed)
    state = combat.siege_new(levels, th_level, seed, opponent)
    battle = Battle.objects.create(
        profile=profile,
        mode=Battle.Mode.SIEGE,
        status=Battle.Status.ACTIVE,
        seed=seed,
        config={"levels": levels, "th_level": th_level},
        state=state,
        last_tick=0,
        opponent_name=opponent["name"],
        difficulty="normal",
    )
    return {"ok": True, "battle": battle_payload(battle)}


def friend_challenge(profile: GameProfile, friend_profile: GameProfile) -> dict[str, Any]:
    """Start a non-real-time friendly arena battle against an accepted friend.

    The opponent is the friend's persisted identity (name, league, card level).
    No trophies, coins or chests are at stake; the prototype pays a flat XP
    reward. Excluded multiplayer infrastructure is not required: the battle is
    a normal server-simulated arena.
    """
    relation = _friend_relation(profile, friend_profile)
    if relation is None or relation.status != GameFriend.Status.ACCEPTED:
        return {"ok": False, "code": "not_friends", "detail": "چالش دوستانه فقط با دوستان تأییدشده ممکن است."}
    deck, levels = _deck_levels(profile)
    seed = random.randint(1, 2**31 - 1)
    league = league_payload(friend_profile.trophies)
    opponent = {
        "name": friend_profile.resolved_name(),
        "league": league["index"],
        "league_name": league["name"],
        "card_level": R.foe_card_level(friend_profile.trophies),
    }
    state = combat.arena_new(deck, levels, seed, "normal", opponent)
    battle = Battle.objects.create(
        profile=profile,
        mode=Battle.Mode.ARENA,
        status=Battle.Status.ACTIVE,
        seed=seed,
        config={"deck": deck, "levels": levels, "friendly": True, "friend_profile_id": friend_profile.id},
        state=state,
        last_tick=0,
        opponent_name=opponent["name"],
        difficulty="normal",
        friendly=True,
    )
    return {"ok": True, "battle": battle_payload(battle)}


def _locked_battle(profile: GameProfile, battle_key: str) -> Battle | None:
    return (
        Battle.objects.select_for_update()
        .filter(key=battle_key, profile=profile)
        .first()
    )


def arena_action(profile: GameProfile, battle_key: str, elapsed: float,
                 index: int | None = None, x: float | None = None,
                 y: float | None = None) -> dict[str, Any]:
    with transaction.atomic():
        battle = _locked_battle(profile, battle_key)
        if battle is None:
            return {"ok": False, "code": "battle_not_found", "detail": "نبرد پیدا نشد."}
        if battle.status != Battle.Status.ACTIVE:
            return {"ok": False, "code": "battle_not_active", "detail": "این نبرد فعال نیست.", "battle": battle_payload(battle)}
        if battle.mode != Battle.Mode.ARENA:
            return {"ok": False, "code": "wrong_mode", "detail": "حالت نبرد نامعتبر است."}
        state = battle.state
        target = min(max(0.0, float(elapsed or 0)), float(state.get("limit", R.ARENA_LIMIT)))
        combat.step(state, target)
        deploy_error = None
        if index is not None and x is not None and y is not None and not state.get("ended"):
            result = combat.arena_deploy(state, int(index), float(x), float(y))
            if not result.get("ok"):
                deploy_error = result
        if state.get("ended") and battle.status == Battle.Status.ACTIVE:
            # Settlement is explicit via finish; keep the battle active so the
            # client still receives the finished snapshot and results screen.
            pass
        battle.state = state
        battle.last_tick = int(float(state.get("t", 0)) / combat.DT)
        battle.save(update_fields=["state", "last_tick"])
    payload: dict[str, Any] = {"ok": True, "battle": battle_payload(battle)}
    if deploy_error:
        payload["deploy_error"] = deploy_error
    return payload


def siege_action(profile: GameProfile, battle_key: str, elapsed: float,
                 index: int | None = None, gx: float | None = None,
                 gy: float | None = None) -> dict[str, Any]:
    with transaction.atomic():
        battle = _locked_battle(profile, battle_key)
        if battle is None:
            return {"ok": False, "code": "battle_not_found", "detail": "نبرد پیدا نشد."}
        if battle.status != Battle.Status.ACTIVE:
            return {"ok": False, "code": "battle_not_active", "detail": "این نبرد فعال نیست.", "battle": battle_payload(battle)}
        if battle.mode != Battle.Mode.SIEGE:
            return {"ok": False, "code": "wrong_mode", "detail": "حالت نبرد نامعتبر است."}
        state = battle.state
        target = min(max(0.0, float(elapsed or 0)), float(state.get("limit", R.SIEGE_LIMIT)))
        combat.step(state, target)
        deploy_error = None
        if index is not None and gx is not None and gy is not None and not state.get("ended"):
            result = combat.siege_deploy(state, int(index), float(gx), float(gy))
            if not result.get("ok"):
                deploy_error = result
        battle.state = state
        battle.last_tick = int(float(state.get("t", 0)) / combat.DT)
        battle.save(update_fields=["state", "last_tick"])
    payload: dict[str, Any] = {"ok": True, "battle": battle_payload(battle)}
    if deploy_error:
        payload["deploy_error"] = deploy_error
    return payload


def finish_battle(profile: GameProfile, battle_key: str) -> dict[str, Any]:
    with transaction.atomic():
        battle = _locked_battle(profile, battle_key)
        if battle is None:
            return {"ok": False, "code": "battle_not_found", "detail": "نبرد پیدا نشد."}
        if battle.status == Battle.Status.SETTLED:
            return {
                "ok": True,
                "already_settled": True,
                "battle": battle_payload(battle),
                "rewards": battle.rewards or {},
                "profile": profile_payload(profile),
                "chests": chests_payload(profile),
            }
        if battle.status != Battle.Status.ACTIVE:
            return {"ok": False, "code": "battle_not_active", "detail": "این نبرد فعال نیست."}

        state = battle.state
        combat.finalize(state)
        result = state.get("result") or "loss"
        mode = battle.mode
        score = int(state.get("crowns", {}).get("p", 0)) if mode == Battle.Mode.ARENA else int(state.get("stars", 0))
        destruction = int(state.get("destruction", 0))

        locked = GameProfile.objects.select_for_update().get(pk=profile.pk)
        trophies_before = locked.trophies
        league_before = league_payload(trophies_before)
        difficulty = battle.difficulty or "normal"

        if battle.friendly:
            xp_result = grant_xp(
                locked,
                R.FRIENDLY_BATTLE_XP,
                LedgerEntry.Reason.BATTLE_REWARD.value,
                reference=f"battle:{battle.key}",
                idempotency_key=f"battle:{battle.key}:xp",
            )
            locked.friendly_played += 1
            locked.save(update_fields=["friendly_played"])
            events = record_event(
                locked,
                GameEvent.Kind.FRIENDLY_BATTLE,
                f"battle:{battle.key}",
                payload={"result": result, "mode": "arena"},
            )
            rewards = {
                "coins": 0,
                "xp": R.FRIENDLY_BATTLE_XP,
                "trophies": 0,
                "trophies_before": trophies_before,
                "trophies_after": trophies_before,
                "league_before": league_before["name"],
                "league_after": league_before["name"],
                "promoted": False,
                "demoted": False,
                "chest": None,
                "score": score,
                "destruction": destruction,
                "result": result,
                "mode": "arena",
                "friendly": True,
                "level_up": xp_result.get("leveled", []),
                "achievements": events["achievements"],
            }
            battle.state = state
            battle.status = Battle.Status.SETTLED
            battle.result = result
            battle.score = score
            battle.destruction = destruction
            battle.rewards = rewards
            battle.settled_at = timezone.now()
            battle.save()
            return {
                "ok": True,
                "battle": battle_payload(battle),
                "rewards": rewards,
                "profile": profile_payload(profile),
                "chests": chests_payload(profile),
            }

        if mode == Battle.Mode.ARENA:
            base = R.arena_rewards(result, score, trophies_before)
        else:
            loot = 450 + (1 + league_before["index"]) * 220
            base = R.siege_rewards(score, destruction, loot, result)
        coins = int(base["coins"])
        xp = int(base["xp"])
        delta = R.trophy_delta(result, "siege" if mode == Battle.Mode.SIEGE else "arena", score)
        new_trophies = max(0, trophies_before + delta)

        apply_delta(locked, "coins", coins, LedgerEntry.Reason.BATTLE_REWARD.value,
                    reference=f"battle:{battle.key}", idempotency_key=f"battle:{battle.key}:coins")
        xp_result = grant_xp(
            locked,
            xp,
            LedgerEntry.Reason.BATTLE_REWARD.value,
            reference=f"battle:{battle.key}",
            idempotency_key=f"battle:{battle.key}:xp",
        )
        if delta:
            apply_delta(locked, "trophies", delta, LedgerEntry.Reason.BATTLE_TROPHY.value,
                        reference=f"battle:{battle.key}", idempotency_key=f"battle:{battle.key}:trophies")

        locked.best_trophies = max(locked.best_trophies, new_trophies)
        if mode == Battle.Mode.ARENA:
            locked.arena_played += 1
            locked.arena_crowns += score
            if result == "win":
                locked.arena_wins += 1
                locked.total_wins += 1
        else:
            locked.siege_played += 1
            locked.siege_stars += score
            if result == "win":
                locked.siege_wins += 1
                locked.total_wins += 1
        locked.save()

        chest_awarded = None
        chest_kind = None
        if result == "win":
            chest_kind = R.chest_kind_for("siege" if mode == Battle.Mode.SIEGE else "arena", score, locked.total_wins)
            chest_index = award_chest(locked, chest_kind)
            if chest_index is not None:
                chest_awarded = {"index": chest_index, "kind": chest_kind}

        event_kinds = [GameEvent.Kind.BATTLE_COMPLETED]
        if result == "win":
            event_kinds.append(GameEvent.Kind.BATTLE_WIN)
        if mode == Battle.Mode.SIEGE:
            event_kinds.append(GameEvent.Kind.SIEGE_BATTLE)
            if result == "win":
                event_kinds.append(GameEvent.Kind.SIEGE_WIN)
        else:
            event_kinds.append(GameEvent.Kind.ARENA_BATTLE)
        unlocked: list[dict[str, Any]] = []
        for kind in event_kinds:
            events = record_event(
                locked,
                kind,
                f"battle:{battle.key}",
                payload={"result": result, "mode": mode, "score": score},
            )
            unlocked.extend(events["achievements"])

        league_after = league_payload(new_trophies)
        rewards = {
            "coins": coins,
            "xp": xp,
            "trophies": delta,
            "trophies_before": trophies_before,
            "trophies_after": new_trophies,
            "league_before": league_before["name"],
            "league_after": league_after["name"],
            "promoted": league_after["index"] > league_before["index"],
            "demoted": league_after["index"] < league_before["index"],
            "chest": chest_awarded,
            "score": score,
            "destruction": destruction,
            "result": result,
            "mode": "siege" if mode == Battle.Mode.SIEGE else "arena",
            "friendly": False,
            "level_up": xp_result.get("leveled", []),
            "achievements": unlocked,
        }
        battle.state = state
        battle.status = Battle.Status.SETTLED
        battle.result = result
        battle.score = score
        battle.destruction = destruction
        battle.rewards = rewards
        battle.settled_at = timezone.now()
        battle.save()

    return {
        "ok": True,
        "battle": battle_payload(battle),
        "rewards": rewards,
        "profile": profile_payload(profile),
        "chests": chests_payload(profile),
    }


def battles_payload(profile: GameProfile, limit: int = 12) -> list[dict[str, Any]]:
    battles = Battle.objects.filter(profile=profile).order_by("-created_at")[:limit]
    return [
        {
            "key": b.key,
            "mode": b.mode,
            "status": b.status,
            "result": b.result,
            "score": b.score,
            "destruction": b.destruction,
            "opponent": b.opponent_name,
            "friendly": b.friendly,
            "created_at": b.created_at,
            "rewards": b.rewards or {},
        }
        for b in battles
    ]
