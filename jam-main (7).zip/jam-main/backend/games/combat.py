"""Deterministic server-authoritative JamPlay combat engine.

The engine is pure Python: no Django, database, HTTP, wall-clock or browser
dependency. A battle's entire mutable state is a JSON-serialisable dict, so it
can be persisted in ``Battle.state`` and advanced by the server between client
inputs. The server is the only authority; clients receive snapshots and send
intents (deploy card at x/y, sync to elapsed time).

Mechanics mirror the JamPlay prototype (``jam-life.html``, ``CombatSession``):
elixir 5 start / 10 cap with 0.58/s regen and 1.15/s from 90s; 3 towers per
side (1900 HP princess, 3200 HP king); 180s + 60s overtime; crowns 1 per
princess tower and 3 for a destroyed king; siege 150s on a 22x22 grid with
wall ring, 310 HP walls and destruction-based stars.
"""

from __future__ import annotations

import hashlib
import math
from typing import Any

from . import rules as R

DT = 0.05
MAX_STEPS = 14000


# ---------------------------------------------------------------------------
# Deterministic pseudo-randomness (no global RNG state)
# ---------------------------------------------------------------------------


def _rand(seed: int, tick: int, salt: int = 0) -> float:
    payload = f"{seed}:{tick}:{salt}".encode("utf-8")
    digest = hashlib.sha256(payload).digest()
    return int.from_bytes(digest[:4], "big") / 2.0**32


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _next_id(state: dict[str, Any], prefix: str = "e") -> str:
    state["seq"] = int(state.get("seq", 0)) + 1
    return f"{prefix}{state['seq']}"


def _add_fx(state: dict[str, Any], fx_type: str, x: float, y: float, radius: float,
            team: int | None = None, ttl: float = 0.5, art: str = "") -> None:
    state.setdefault("fx", []).append(
        {"type": fx_type, "x": x, "y": y, "r": radius, "team": team, "ttl": ttl, "max": ttl, "art": art}
    )
    if len(state["fx"]) > 60:
        state["fx"] = state["fx"][-60:]


# ---------------------------------------------------------------------------
# Unit statistics
# ---------------------------------------------------------------------------


def unit_stats(card_key: str, level: int = 1) -> dict[str, Any]:
    base = R.CARDS.get(card_key)
    if not base:
        return {"cost": 0, "hp": 0, "dmg": 0, "rate": 1.0, "speed": 30.0, "range": 0.0, "count": 1}
    mul = 1 + 0.1 * (max(1, level) - 1)
    return {
        "cost": base.get("cost", 0),
        "hp": base.get("hp", 0) * mul,
        "dmg": base.get("dmg", 0) * mul,
        "rate": base.get("rate", 0.9),
        "speed": base.get("speed", 30.0),
        "range": base.get("range", 0.0),
        "count": base.get("count", 1),
        "splash": base.get("splash", 0.0),
        "buildings": bool(base.get("buildings")),
        "spell": bool(base.get("spell")),
        "radius": base.get("radius", 0.0),
        "heal": base.get("heal", 0.0),
        "freeze": base.get("freeze", 0.0),
        "art": base.get("art", card_key),
    }


# ---------------------------------------------------------------------------
# Arena
# ---------------------------------------------------------------------------

ARENA_W = R.ARENA_WIDTH
ARENA_H = R.ARENA_HEIGHT
ARENA_LIMIT = R.ARENA_LIMIT
ARENA_OVERTIME_SECONDS = R.ARENA_OVERTIME
RIVER_TOP = R.RIVER_TOP
RIVER_BOTTOM = R.RIVER_BOTTOM
BRIDGE_XS = R.BRIDGE_XS
BRIDGE_HALF = R.BRIDGE_HALF_WIDTH

_PRINCESS = [(150.0, 682.0), (450.0, 682.0)]
_KING = (300.0, 779.0)


def _new_tower(state: dict[str, Any], team: int, x: float, y: float, king: bool,
               factor: float = 1.0) -> dict[str, Any]:
    hp = (R.BUILDING_HP["th"] if king else 1900) * factor
    return {
        "id": _next_id(state, "t"),
        "team": team,
        "king": king,
        "x": x,
        "y": y,
        "hp": hp,
        "max_hp": hp,
        "dmg": (74.0 if king else 65.0) * factor,
        "range": 175.0 if king else 185.0,
        "rate": 1.05 if king else 0.95,
        "cd": 0.3,
        "hit": 0.0,
        "freeze": 0.0,
        "radius": 38.0 if king else 32.0,
    }


def arena_new(deck: list[str], levels: dict[str, int], seed: int,
              difficulty: str = "normal", opponent: dict[str, Any] | None = None) -> dict[str, Any]:
    """Create a fresh arena battle state."""
    deck = list(deck)[: R.DECK_SIZE]
    state: dict[str, Any] = {
        "mode": "arena",
        "seed": int(seed),
        "difficulty": difficulty,
        "opponent": opponent or {},
        "t": 0.0,
        "limit": ARENA_LIMIT,
        "overtime": False,
        "ended": False,
        "winner": None,
        "result": "",
        "reason": "",
        "seq": 0,
        "elixir": 5.0,
        "ai_elixir": 5.0,
        "deck": deck,
        "levels": {k: int(levels.get(k, 1)) for k in deck},
        "hand": deck[: R.HAND_SIZE],
        "queue": deck[R.HAND_SIZE:],
        "ai_hand": list(R.STARTER_CARDS[: R.HAND_SIZE]),
        "ai_queue": list(R.STARTER_CARDS[R.HAND_SIZE:]),
        "ai_wait": 2.0,
        "towers": [],
        "units": [],
        "fx": [],
        "log": [],
    }
    factor = 0.85 if difficulty == "easy" else 1.12 if difficulty == "hard" else 1.0
    for i, (px, py) in enumerate(_PRINCESS):
        state["towers"].append(_new_tower(state, 0, px, py, False))
    state["towers"].append(_new_tower(state, 0, _KING[0], _KING[1], True))

    mirrored = [(150.0, 900.0 - 682.0), (450.0, 900.0 - 682.0)]
    for mx, my in mirrored:
        state["towers"].append(_new_tower(state, 1, mx, my, False, factor))
    state["towers"].append(_new_tower(state, 1, _KING[0], 900.0 - _KING[1], True, factor))
    return state


def _tower_by_id(state: dict[str, Any], tid: str) -> dict[str, Any] | None:
    for tower in state["towers"]:
        if tower["id"] == tid:
            return tower
    return None


def arena_crowns(state: dict[str, Any], team: int) -> int:
    other = 1 - team
    king = next((t for t in state["towers"] if t["team"] == other and t["king"]), None)
    if king is not None and king["hp"] <= 0:
        return 3
    return sum(1 for t in state["towers"] if t["team"] == other and not t["king"] and t["hp"] <= 0)


def arena_min_y(state: dict[str, Any], x: float) -> float:
    left = x < 300
    open_lane = any(
        t["team"] == 1 and not t["king"] and (t["x"] < 300) == left and t["hp"] <= 0
        for t in state["towers"]
    )
    return 300.0 if open_lane else 478.0


def _arena_elixir_rate(state: dict[str, Any]) -> float:
    return R.ELIXIR_RATE_DOUBLE if (state["t"] >= 90 or state["overtime"]) else R.ELIXIR_RATE


def _spawn_arena_unit(state: dict[str, Any], card_key: str, team: int, x: float, y: float,
                      level: int = 1) -> None:
    stats = unit_stats(card_key, level)
    count = int(stats["count"]) or 1
    for i in range(count):
        angle = (i / max(1, count)) * math.pi * 2
        spread = 19.0 if count > 1 else 0.0
        state["units"].append(
            {
                "id": _next_id(state),
                "kind": "unit",
                "team": team,
                "k": card_key,
                "x": _clamp(x + math.cos(angle) * spread, 35, 565),
                "y": _clamp(y + math.sin(angle) * spread, 45, 850),
                "hp": stats["hp"],
                "max_hp": stats["hp"],
                "dmg": stats["dmg"],
                "rate": stats["rate"],
                "cd": 0.25,
                "speed": stats["speed"],
                "range": stats["range"],
                "splash": stats["splash"],
                "buildings": stats["buildings"],
                "freeze": 0.0,
                "hit": 0.0,
                "lane": 150.0 if x < 300 else 450.0,
            }
        )


def _cast_arena_spell(state: dict[str, Any], card_key: str, team: int, x: float, y: float,
                      level: int = 1) -> None:
    stats = unit_stats(card_key, level)
    radius = float(stats["radius"] or 80)
    for unit in state["units"]:
        if unit["hp"] <= 0:
            continue
        if math.hypot(unit["x"] - x, unit["y"] - y) > radius:
            continue
        if stats["heal"]:
            if unit["team"] == team:
                unit["hp"] = min(unit["max_hp"], unit["hp"] + stats["heal"])
            continue
        if unit["team"] == team:
            continue
        unit["hp"] = max(0.0, unit["hp"] - stats["dmg"])
        unit["hit"] = 0.2
        if stats["freeze"]:
            unit["freeze"] = max(unit["freeze"], stats["freeze"])
    for tower in state["towers"]:
        if tower["hp"] <= 0 or tower["team"] == team:
            continue
        if math.hypot(tower["x"] - x, tower["y"] - y) > radius:
            continue
        if stats["dmg"]:
            tower["hp"] = max(0.0, tower["hp"] - stats["dmg"] * 0.4)
        if stats["freeze"]:
            tower["freeze"] = max(tower["freeze"], stats["freeze"] * 0.8)
    _add_fx(
        state,
        "heal" if stats["heal"] else "frost" if stats["freeze"] else "spell",
        x,
        y,
        radius,
        team,
        1.0,
        stats["art"],
    )


def _fail(code: str, detail: str) -> dict[str, Any]:
    return {"ok": False, "error": code, "code": code, "detail": detail}


def arena_deploy(state: dict[str, Any], index: int, x: float, y: float) -> dict[str, Any]:
    """Validate and execute a player deployment. Server-authoritative."""
    if state.get("ended"):
        return _fail("battle_ended", "این نبرد تمام شده است.")
    hand = state.get("hand") or []
    if index < 0 or index >= len(hand):
        return _fail("invalid_card", "کارت نامعتبر است.")
    card_key = hand[index]
    level = int(state.get("levels", {}).get(card_key, 1))
    stats = unit_stats(card_key, level)
    if state["elixir"] + 1e-9 < stats["cost"]:
        return _fail("not_enough_elixir", "اکسیر کافی نیست؛ کمی صبر کن.")

    x = float(x)
    y = float(y)
    if not (30 <= x <= 570 and 45 <= y <= 850):
        return _fail("out_of_bounds", "داخل میدان هدف‌گیری کن.")

    if not stats["spell"]:
        if y < arena_min_y(state, x):
            return _fail("own_half_only", "نیرو فقط در نیمهٔ خودی مستقر می‌شود؛ با افتادن برج حریف، همان مسیر باز می‌شود.")
        if RIVER_TOP < y < RIVER_BOTTOM and not any(abs(x - bx) <= BRIDGE_HALF for bx in BRIDGE_XS):
            return _fail("river", "روی رودخانه نمی‌شود؛ روی پل هدف بگیر.")
        if y < 490 and not any(abs(x - bx) <= BRIDGE_HALF for bx in BRIDGE_XS):
            return _fail("bridge_only", "عبور فقط از روی پل ممکن است.")
        if sum(1 for u in state["units"] if u["team"] == 0 and u["hp"] > 0) >= R.MAX_UNITS_PER_SIDE:
            return _fail("field_full", "میدان شلوغ است؛ کمی صبر کن.")

    state["elixir"] = max(0.0, state["elixir"] - stats["cost"])
    if stats["spell"]:
        _cast_arena_spell(state, card_key, 0, x, y, level)
    else:
        _spawn_arena_unit(state, card_key, 0, x, y, level)
        _add_fx(state, "spawn", x, y, 28.0, 0, 0.5)

    # Cycle the player's hand.
    queue = state.get("queue") or []
    if queue:
        state["hand"][index] = queue.pop(0)
        queue.append(card_key)
        state["queue"] = queue
    else:
        state["hand"][index] = card_key
    return {"ok": True}


def _arena_ai(state: dict[str, Any]) -> None:
    if state.get("ended"):
        return
    if sum(1 for u in state["units"] if u["team"] == 1 and u["hp"] > 0) >= 60:
        return
    affordable = [
        (key, i)
        for i, key in enumerate(state["ai_hand"])
        if unit_stats(key, 1)["cost"] <= state["ai_elixir"]
    ]
    if not affordable:
        return
    threats = [u for u in state["units"] if u["team"] == 0 and u["hp"] > 0 and u["y"] < 465]
    average = None
    if threats:
        average = (
            sum(u["x"] for u in threats) / len(threats),
            sum(u["y"] for u in threats) / len(threats),
        )
    difficulty = state.get("difficulty", "normal")
    choice: tuple[str, int] | None = None
    if len(threats) >= 3:
        choice = next((v for v in affordable if v[0] in ("meteor", "mage", "frost")), None)
    if choice is None and any(u.get("buildings") for u in threats):
        choice = next((v for v in affordable if v[0] in ("scouts", "guard")), None)
    if choice is None:
        roll = _rand(state["seed"], int(state["t"] * 20), len(affordable))
        pick = int(roll * len(affordable)) % len(affordable)
        if difficulty == "easy":
            pick = 0
        choice = affordable[pick]

    card_key, hand_index = choice
    stats = unit_stats(card_key, 1)
    if stats["spell"]:
        if stats["heal"]:
            wounded = next(
                (u for u in state["units"] if u["team"] == 1 and u["hp"] < u["max_hp"] * 0.65),
                None,
            )
            if wounded is None:
                return
            x, y = wounded["x"], wounded["y"]
        elif average:
            x, y = average
        else:
            towers = [t for t in state["towers"] if t["team"] == 0 and t["hp"] > 0 and not t["king"]]
            if state["ai_elixir"] < 8 or not towers:
                return
            target = min(towers, key=lambda t: t["hp"])
            x, y = target["x"], target["y"]
        _cast_arena_spell(state, card_key, 1, x, y, 1)
    else:
        weak = [t for t in state["towers"] if t["team"] == 0 and not t["king"] and t["hp"] > 0]
        weak.sort(key=lambda t: t["hp"])
        if average:
            lane = 150.0 if average[0] < 300 else 450.0
        elif weak:
            lane = weak[0]["x"]
        else:
            lane = 150.0 if _rand(state["seed"], int(state["t"] * 20), 7) < 0.5 else 450.0
        x = lane + (_rand(state["seed"], int(state["t"] * 20), 3) * 44 - 22)
        y = _clamp(average[1] - 65, 235, 390) if average else (315.0 if stats["buildings"] else 250.0)
        _spawn_arena_unit(state, card_key, 1, x, y, 1)

    state["ai_elixir"] = max(0.0, state["ai_elixir"] - stats["cost"])
    queue = state.get("ai_queue") or []
    if queue:
        state["ai_hand"][hand_index] = queue.pop(0)
        queue.append(card_key)
        state["ai_queue"] = queue
    else:
        state["ai_hand"][hand_index] = card_key


def _fire(attacker: dict[str, Any], target: dict[str, Any], dmg: float) -> None:
    attacker["hit"] = 0.18
    target["hp"] = max(0.0, target["hp"] - dmg)
    target["hit"] = 0.2


def _arena_tick(state: dict[str, Any]) -> None:
    dt = DT
    rate = _arena_elixir_rate(state)
    state["elixir"] = min(R.ELIXIR_MAX, state["elixir"] + dt * rate)
    ai_rate = rate * (0.85 if state.get("difficulty") == "easy" else 1.0)
    state["ai_elixir"] = min(R.ELIXIR_MAX, state["ai_elixir"] + dt * ai_rate)

    state["ai_wait"] = float(state.get("ai_wait", 1.5)) - dt
    if state["ai_wait"] <= 0:
        _arena_ai(state)
        difficulty = state.get("difficulty", "normal")
        state["ai_wait"] = 2.3 if difficulty == "easy" else 1.0 if difficulty == "hard" else 1.5

    for tower in state["towers"]:
        tower["cd"] = max(0.0, tower["cd"] - dt)
        tower["freeze"] = max(0.0, tower["freeze"] - dt)
        tower["hit"] = max(0.0, tower["hit"] - dt)
        if tower["hp"] <= 0 or tower["freeze"] > 0:
            continue
        if tower["king"] and tower["hp"] == tower["max_hp"]:
            if not any(t["team"] == tower["team"] and not t["king"] and t["hp"] <= 0 for t in state["towers"]):
                continue
        candidates = [
            u for u in state["units"]
            if u["team"] != tower["team"] and u["hp"] > 0
            and math.hypot(u["x"] - tower["x"], u["y"] - tower["y"]) < tower["range"]
        ]
        if not candidates or tower["cd"] > 0:
            continue
        target = min(candidates, key=lambda u: math.hypot(u["x"] - tower["x"], u["y"] - tower["y"]))
        _fire(tower, target, tower["dmg"])
        tower["cd"] = tower["rate"]

    for unit in list(state["units"]):
        unit["hit"] = max(0.0, unit["hit"] - dt)
        unit["freeze"] = max(0.0, unit["freeze"] - dt)
        unit["cd"] = max(0.0, unit["cd"] - dt)
        if unit["hp"] <= 0 or unit["freeze"] > 0:
            continue

        enemies = [
            u for u in state["units"]
            if u["team"] != unit["team"] and u["hp"] > 0
            and math.hypot(u["x"] - unit["x"], u["y"] - unit["y"]) < 170
        ]
        target: dict[str, Any] | None = None
        if not unit["buildings"] and enemies:
            target = min(enemies, key=lambda u: math.hypot(u["x"] - unit["x"], u["y"] - unit["y"]))
        if target is None:
            towers = [t for t in state["towers"] if t["team"] != unit["team"] and t["hp"] > 0]
            if towers:
                target = min(
                    towers,
                    key=lambda t: math.hypot(t["x"] - unit["x"], t["y"] - unit["y"])
                    + (70 if t["king"] else 0),
                )
        if target is None:
            continue
        unit["target"] = target["id"]

        dist = math.hypot(target["x"] - unit["x"], target["y"] - unit["y"])
        reach = unit["range"] + (target.get("radius") or 16)
        if dist <= reach:
            if unit["cd"] <= 0:
                _fire(unit, target, unit["dmg"])
                unit["cd"] = unit["rate"]
                if unit["splash"] and target.get("kind") == "unit":
                    for other in state["units"]:
                        if other is target or other["team"] == unit["team"] or other["hp"] <= 0:
                            continue
                        if math.hypot(
                            other["x"] - target["x"], other["y"] - target["y"]
                        ) < unit["splash"]:
                            other["hp"] = max(0.0, other["hp"] - unit["dmg"] * 0.45)
            continue

        tx, ty = target["x"], target["y"]
        opposite = (unit["y"] < 440 and target["y"] > 460) or (unit["y"] > 460 and target["y"] < 440)
        if opposite:
            bridge = unit["lane"]
            tx = bridge
            ty = 405.0 if unit["y"] > 450 else 495.0
            if abs(unit["x"] - bridge) > 35 and abs(unit["y"] - 450) < 95:
                ty = 530.0 if unit["y"] > 450 else 370.0
        dx, dy = tx - unit["x"], ty - unit["y"]
        dist_to_step = math.hypot(dx, dy)
        if dist_to_step >= 1:
            nx = unit["x"] + (dx / dist_to_step) * unit["speed"] * dt
            ny = unit["y"] + (dy / dist_to_step) * unit["speed"] * dt
            if RIVER_TOP < ny < RIVER_BOTTOM and not any(abs(nx - bx) <= BRIDGE_HALF for bx in BRIDGE_XS):
                unit["x"] += math.copysign(unit["speed"] * dt, unit["lane"] - unit["x"])
            else:
                unit["x"] = _clamp(nx, 32, 568)
                unit["y"] = _clamp(ny, 40, 855)

    # Soft separation so stacks remain readable.
    alive = [u for u in state["units"] if u["hp"] > 0]
    for i, a in enumerate(alive):
        for b in alive[i + 1 :]:
            if a["team"] != b["team"]:
                continue
            dx, dy = a["x"] - b["x"], a["y"] - b["y"]
            dist = math.hypot(dx, dy)
            if 0 < dist < 21:
                a["x"] += (dx / dist) * dt * 14
                a["y"] += (dy / dist) * dt * 14

    for fx in state.get("fx", []):
        fx["ttl"] -= dt
    state["fx"] = [fx for fx in state.get("fx", []) if fx["ttl"] > 0]
    state["units"] = [u for u in state["units"] if u["hp"] > 0]

    enemy_king = next((t for t in state["towers"] if t["team"] == 1 and t["king"]), None)
    player_king = next((t for t in state["towers"] if t["team"] == 0 and t["king"]), None)
    if (enemy_king and enemy_king["hp"] <= 0) or (player_king and player_king["hp"] <= 0):
        _finalize_arena(state, "king")
    elif state["overtime"] and arena_crowns(state, 0) != arena_crowns(state, 1):
        _finalize_arena(state, "overtime")


def _finalize_arena(state: dict[str, Any], reason: str) -> None:
    if state.get("ended"):
        return
    crowns_p = arena_crowns(state, 0)
    crowns_e = arena_crowns(state, 1)
    enemy_king = next((t for t in state["towers"] if t["team"] == 1 and t["king"]), None)
    player_king = next((t for t in state["towers"] if t["team"] == 0 and t["king"]), None)
    if enemy_king and enemy_king["hp"] <= 0:
        result = "win"
    elif player_king and player_king["hp"] <= 0:
        result = "loss"
    elif crowns_p != crowns_e:
        result = "win" if crowns_p > crowns_e else "loss"
    else:
        p_ratio = sum(max(0.0, t["hp"]) / t["max_hp"] for t in state["towers"] if t["team"] == 0)
        e_ratio = sum(max(0.0, t["hp"]) / t["max_hp"] for t in state["towers"] if t["team"] == 1)
        if abs(p_ratio - e_ratio) < 0.015:
            result = "draw"
        else:
            result = "win" if p_ratio > e_ratio else "loss"
    state["ended"] = True
    state["reason"] = reason
    state["result"] = result
    state["winner"] = result
    state["crowns"] = {"p": crowns_p, "e": crowns_e}


def arena_step(state: dict[str, Any], until: float) -> None:
    if state.get("ended"):
        return
    limit = float(state.get("limit", ARENA_LIMIT))
    target = min(max(float(until), state["t"]), limit)
    steps = 0
    while state["t"] + 1e-9 < target and not state.get("ended") and steps < MAX_STEPS:
        _arena_tick(state)
        state["t"] = round(state["t"] + DT, 3)
        steps += 1
    if state.get("ended"):
        return
    if state["t"] >= limit - 1e-9:
        crowns_p = arena_crowns(state, 0)
        crowns_e = arena_crowns(state, 1)
        if not state["overtime"] and crowns_p == crowns_e:
            state["overtime"] = True
            state["limit"] = limit + ARENA_OVERTIME_SECONDS
            _add_fx(state, "phase", 300, 450, 0, None, 1.0)
        else:
            _finalize_arena(state, "time")


# ---------------------------------------------------------------------------
# Siege
# ---------------------------------------------------------------------------

SIEGE_LIMIT = R.SIEGE_LIMIT
_SIEGE_SIZES = {key: value["size"] for key, value in R.BUILDING_TYPES.items()}
_SIEGE_HP = dict(R.BUILDING_HP)


def siege_army(levels: dict[str, int], th_level: int) -> list[dict[str, Any]]:
    bonus = max(0, (int(th_level) - 1) // 2)
    return [
        {"k": item["key"], "n": int(item["count"]) + bonus, "count": int(item["count"]) + bonus}
        for item in R.ARENA_ARMY
    ]


def siege_new(levels: dict[str, int], th_level: int, seed: int,
              opponent: dict[str, Any] | None = None) -> dict[str, Any]:
    state: dict[str, Any] = {
        "mode": "siege",
        "seed": int(seed),
        "opponent": opponent or {},
        "t": 0.0,
        "limit": SIEGE_LIMIT,
        "ended": False,
        "winner": None,
        "result": "",
        "reason": "",
        "seq": 0,
        "levels": {k: int(levels.get(k, 1)) for k in R.CARDS},
        "army": siege_army(levels, th_level),
        "buildings": [],
        "walls": [],
        "units": [],
        "fx": [],
        "garrison_timer": 9.0,
        "destruction": 0,
        "stars": 0,
    }
    # Enemy base mirrors the prototype's generated opponent layout.
    for item in R.BASE_LAYOUT:
        if item["type"] in ("hero", "chest"):
            continue
        size = _SIEGE_SIZES[item["type"]]
        hp = _SIEGE_HP.get(item["type"], R.BUILDING_DEFAULT_HP)
        state["buildings"].append(
            {
                "id": _next_id(state, "b"),
                "t": item["type"],
                "key": item["key"],
                "gx": item["gx"],
                "gy": item["gy"],
                "s": size,
                "x": item["gx"] + size / 2,
                "y": item["gy"] + size / 2,
                "hp": hp,
                "max_hp": hp,
                "dmg": 68.0,
                "range": 6.8 if item["type"] == "tower" else 0.0,
                "rate": 1.0,
                "cd": 0.4,
            }
        )
    seen: set[tuple[int, int]] = set()
    for i in range(3, 20):
        for gx, gy in ((i, 3), (i, 19), (3, i), (19, i)):
            if (gx == 19 and 10 <= gy <= 11) or (gy == 19 and 10 <= gx <= 11):
                continue
            if (gx, gy) in seen:
                continue
            seen.add((gx, gy))
            state["walls"].append(
                {
                    "id": _next_id(state, "w"),
                    "gx": gx,
                    "gy": gy,
                    "x": gx + 0.5,
                    "y": gy + 0.5,
                    "hp": 310.0,
                    "max_hp": 310.0,
                }
            )
    return state


def _spawn_siege_unit(state: dict[str, Any], card_key: str, team: int, x: float, y: float,
                      level: int = 1) -> None:
    stats = unit_stats(card_key, level)
    count = stats["count"] if team == 0 else 1
    for i in range(int(count) or 1):
        state["units"].append(
            {
                "id": _next_id(state),
                "kind": "unit",
                "team": team,
                "k": card_key,
                "x": _clamp(x + (_rand(state["seed"], int(state["t"] * 20), i) - 0.5) * 0.24, 0.3, 21.7),
                "y": _clamp(y + (_rand(state["seed"], int(state["t"] * 20) + 5, i) - 0.5) * 0.24, 0.3, 21.7),
                "hp": stats["hp"] * (0.65 if team == 1 else 1.0),
                "max_hp": stats["hp"] * (0.65 if team == 1 else 1.0),
                "dmg": stats["dmg"] * (0.7 if team == 1 else 1.0),
                "rate": stats["rate"],
                "cd": 0.2,
                "speed": stats["speed"] / 53.0,
                "range": stats["range"] / 42.0,
                "splash": stats["splash"] / 42.0,
                "buildings": stats["buildings"],
                "hit": 0.0,
                "path": [],
                "repath": 0.0,
                "target_id": "",
            }
        )


def siege_deploy(state: dict[str, Any], index: int, gx: float, gy: float) -> dict[str, Any]:
    if state.get("ended"):
        return _fail("battle_ended", "این نبرد تمام شده است.")
    army = state.get("army") or []
    if index < 0 or index >= len(army):
        return _fail("invalid_card", "نیرو نامعتبر است.")
    if army[index]["count"] <= 0:
        return _fail("no_reserves", "این نوع نیرو تمام شده است.")
    gx, gy = float(gx), float(gy)
    if not (0 <= gx <= 22 and 0 <= gy <= 22):
        return _fail("out_of_bounds", "روی زمین میدان بزن.")
    if 3 <= gx <= 19 and 3 <= gy <= 19:
        return _fail("outside_walls", "استقرار فقط در حاشیهٔ بیرون دیوار مجاز است.")
    gx = _clamp(gx, 0.5, 21.5)
    gy = _clamp(gy, 0.5, 21.5)
    army[index]["count"] -= 1
    _spawn_siege_unit(state, army[index]["k"], 0, gx, gy)
    _add_fx(state, "spawn", gx, gy, 0.8, 0, 0.5)
    return {"ok": True}


def _siege_blocks(state: dict[str, Any]) -> set[tuple[int, int]]:
    return {(w["gx"], w["gy"]) for w in state["walls"] if w["hp"] > 0}


def _bfs_path(blocks: set[tuple[int, int]], start: tuple[int, int],
              goal: tuple[int, int], size: int = 22) -> list[tuple[int, int]]:
    if start == goal:
        return []
    frontier = [start]
    came: dict[tuple[int, int], tuple[int, int] | None] = {start: None}
    while frontier:
        current = frontier.pop(0)
        if current == goal:
            path: list[tuple[int, int]] = []
            node: tuple[int, int] | None = current
            while node and node != start:
                path.append(node)
                node = came[node]
            path.reverse()
            return path
        cx, cy = current
        for nx, ny in ((cx + 1, cy), (cx - 1, cy), (cx, cy + 1), (cx, cy - 1)):
            if nx < 0 or ny < 0 or nx >= size or ny >= size:
                continue
            if (nx, ny) in blocks or (nx, ny) in came:
                continue
            came[(nx, ny)] = current
            frontier.append((nx, ny))
    return []


def _siege_tick(state: dict[str, Any]) -> None:
    dt = DT
    state["garrison_timer"] = float(state.get("garrison_timer", 9.0)) - dt
    camp = next((b for b in state["buildings"] if b["t"] == "camp"), None)
    if camp and camp["hp"] > 0 and state["garrison_timer"] <= 0:
        if sum(1 for u in state["units"] if u["team"] == 1) < 4:
            _spawn_siege_unit(state, "guard", 1, camp["x"], camp["y"] + camp["s"] / 2 + 0.6)
        state["garrison_timer"] = 13.0

    for b in state["buildings"]:
        b["cd"] = max(0.0, b["cd"] - dt)
        b["hit"] = max(0.0, b.get("hit", 0.0) - dt)
        if b["hp"] <= 0 or not b["range"]:
            continue
        candidates = [
            u for u in state["units"]
            if u["team"] == 0 and u["hp"] > 0
            and math.hypot(u["x"] - b["x"], u["y"] - b["y"]) < b["range"]
        ]
        if not candidates or b["cd"] > 0:
            continue
        target = min(candidates, key=lambda u: math.hypot(u["x"] - b["x"], u["y"] - b["y"]))
        _fire(b, target, b["dmg"])
        b["cd"] = b["rate"]

    blocks = _siege_blocks(state)
    for unit in list(state["units"]):
        unit["hit"] = max(0.0, unit["hit"] - dt)
        unit["cd"] = max(0.0, unit["cd"] - dt)
        unit["repath"] = float(unit.get("repath", 0.0)) - dt
        if unit["hp"] <= 0:
            continue

        if unit["team"] == 1:
            targets = [u for u in state["units"] if u["team"] == 0 and u["hp"] > 0]
            if not targets:
                continue
            target = min(targets, key=lambda u: math.hypot(u["x"] - unit["x"], u["y"] - unit["y"]))
            dist = math.hypot(target["x"] - unit["x"], target["y"] - unit["y"])
            if dist <= unit["range"] + 0.3:
                if unit["cd"] <= 0:
                    _fire(unit, target, unit["dmg"])
                    unit["cd"] = unit["rate"]
            else:
                dx, dy = target["x"] - unit["x"], target["y"] - unit["y"]
                d = math.hypot(dx, dy)
                if d > 0.02:
                    step = min(d, unit["speed"] * dt)
                    unit["x"] = _clamp(unit["x"] + dx / d * step, 0.3, 21.7)
                    unit["y"] = _clamp(unit["y"] + dy / d * step, 0.3, 21.7)
            continue

        threats = []
        if not unit["buildings"]:
            threats = [
                u for u in state["units"]
                if u["team"] == 1 and u["hp"] > 0
                and math.hypot(u["x"] - unit["x"], u["y"] - unit["y"]) < 3.3
            ]
        target = None
        if threats:
            target = min(threats, key=lambda u: math.hypot(u["x"] - unit["x"], u["y"] - unit["y"]))
        else:
            alive = [b for b in state["buildings"] if b["hp"] > 0]
            if not alive:
                continue
            target = min(
                alive,
                key=lambda b: math.hypot(b["x"] - unit["x"], b["y"] - unit["y"])
                - (1.5 if unit["buildings"] and b["t"] == "tower" else 0),
            )
        unit["target"] = target["id"]
        dist = math.hypot(target["x"] - unit["x"], target["y"] - unit["y"])
        reach = unit["range"] + (target.get("s", 0) * 0.55 if target.get("s") else 0.3)
        if dist <= reach:
            if unit["cd"] <= 0:
                _fire(unit, target, unit["dmg"])
                unit["cd"] = unit["rate"]
                if unit["splash"]:
                    for other in state["buildings"]:
                        if other is target or other["hp"] <= 0:
                            continue
                        if math.hypot(other["x"] - target["x"], other["y"] - target["y"]) < unit["splash"]:
                            other["hp"] = max(0.0, other["hp"] - unit["dmg"] * 0.45)
            continue

        if unit.get("target_id") != target["id"] or unit.get("repath", 0) <= 0 or not unit.get("path"):
            start = (int(unit["x"]), int(unit["y"]))
            goal = (min(21, max(0, int(target["x"]))), min(21, max(0, int(target["y"]))))
            unit["path"] = [list(cell) for cell in _bfs_path(blocks, start, goal)]
            unit["target_id"] = target["id"]
            unit["repath"] = 2.2

        path = unit.get("path") or []
        step_cell = path[0] if path else None
        if step_cell is not None:
            wall = next(
                (w for w in state["walls"] if w["hp"] > 0 and w["gx"] == step_cell[0] and w["gy"] == step_cell[1]),
                None,
            )
            if wall and math.hypot(wall["x"] - unit["x"], wall["y"] - unit["y"]) <= max(1.3, unit["range"]):
                if unit["cd"] <= 0:
                    _fire(unit, wall, unit["dmg"])
                    unit["cd"] = unit["rate"]
                continue
            wx, wy = step_cell[0] + 0.5, step_cell[1] + 0.5
            d = math.hypot(wx - unit["x"], wy - unit["y"])
            if d < 0.13:
                path.pop(0)
            else:
                step = min(d, unit["speed"] * dt)
                unit["x"] = _clamp(unit["x"] + (wx - unit["x"]) / d * step, 0.3, 21.7)
                unit["y"] = _clamp(unit["y"] + (wy - unit["y"]) / d * step, 0.3, 21.7)
        else:
            d = math.hypot(target["x"] - unit["x"], target["y"] - unit["y"])
            if d > 0.02:
                step = min(d, unit["speed"] * dt)
                unit["x"] = _clamp(unit["x"] + (target["x"] - unit["x"]) / d * step, 0.3, 21.7)
                unit["y"] = _clamp(unit["y"] + (target["y"] - unit["y"]) / d * step, 0.3, 21.7)

    for fx in state.get("fx", []):
        fx["ttl"] -= dt
    state["fx"] = [fx for fx in state.get("fx", []) if fx["ttl"] > 0]
    state["units"] = [u for u in state["units"] if u["hp"] > 0]
    _siege_progress(state)

    all_down = all(b["hp"] <= 0 for b in state["buildings"])
    exhausted = all(a["count"] <= 0 for a in state["army"]) and not any(
        u["team"] == 0 and u["hp"] > 0 for u in state["units"]
    )
    if all_down:
        _finalize_siege(state, "complete")
    elif exhausted:
        _finalize_siege(state, "army")


def _siege_progress(state: dict[str, Any]) -> None:
    buildings = state["buildings"]
    destroyed = sum(1 for b in buildings if b["hp"] <= 0)
    state["destruction"] = round(100 * destroyed / max(1, len(buildings)))
    th = next((b for b in buildings if b["t"] == "th"), None)
    state["stars"] = (
        (1 if state["destruction"] >= 50 else 0)
        + (1 if th and th["hp"] <= 0 else 0)
        + (1 if state["destruction"] >= 100 else 0)
    )


def _finalize_siege(state: dict[str, Any], reason: str) -> None:
    if state.get("ended"):
        return
    _siege_progress(state)
    state["ended"] = True
    state["reason"] = reason
    state["result"] = "win" if state["stars"] > 0 else "loss"
    state["winner"] = state["result"]


def siege_step(state: dict[str, Any], until: float) -> None:
    if state.get("ended"):
        return
    limit = float(state.get("limit", SIEGE_LIMIT))
    target = min(max(float(until), state["t"]), limit)
    steps = 0
    while state["t"] + 1e-9 < target and not state.get("ended") and steps < MAX_STEPS:
        _siege_tick(state)
        state["t"] = round(state["t"] + DT, 3)
        steps += 1
    if not state.get("ended") and state["t"] >= limit - 1e-9:
        _finalize_siege(state, "time")


# ---------------------------------------------------------------------------
# Advancing a persisted battle
# ---------------------------------------------------------------------------


def step(state: dict[str, Any], until: float) -> None:
    if state.get("mode") == "arena":
        arena_step(state, until)
    else:
        siege_step(state, until)


def finalize(state: dict[str, Any]) -> None:
    """Force the battle to its authoritative end."""
    if state.get("ended"):
        return
    if state.get("mode") == "arena":
        arena_step(state, float(state.get("limit", ARENA_LIMIT)))
        if not state.get("ended"):
            _finalize_arena(state, "time")
    else:
        siege_step(state, float(state.get("limit", SIEGE_LIMIT)))
        if not state.get("ended"):
            _finalize_siege(state, "time")


# ---------------------------------------------------------------------------
# Snapshots sent to the client
# ---------------------------------------------------------------------------


def snapshot(state: dict[str, Any]) -> dict[str, Any]:
    towers = [
        {
            "id": t["id"],
            "team": t["team"],
            "king": t["king"],
            "x": round(t["x"], 1),
            "y": round(t["y"], 1),
            "hp": max(0, round(t["hp"])),
            "max_hp": round(t["max_hp"]),
            "radius": t["radius"],
        }
        for t in state.get("towers", [])
    ]
    units = [
        {
            "id": u["id"],
            "team": u["team"],
            "k": u["k"],
            "x": round(u["x"], 1),
            "y": round(u["y"], 1),
            "hp": max(0, round(u["hp"])),
            "max_hp": round(u["max_hp"]),
            "freeze": round(u.get("freeze", 0.0), 2),
            "hit": round(u.get("hit", 0.0), 2),
            "target": u.get("target"),
            "path": [list(step) for step in (u.get("path") or [])[:16]],
        }
        for u in state.get("units", [])
        if u["hp"] > 0
    ]
    base: dict[str, Any] = {
        "mode": state.get("mode"),
        "t": round(float(state.get("t", 0.0)), 2),
        "limit": round(float(state.get("limit", 0.0)), 2),
        "overtime": bool(state.get("overtime", False)),
        "ended": bool(state.get("ended", False)),
        "result": state.get("result", ""),
        "reason": state.get("reason", ""),
        "units": units,
        "fx": [
            {"type": f["type"], "x": round(f["x"], 1), "y": round(f["y"], 1),
             "r": f["r"], "team": f["team"], "ttl": round(f["ttl"], 2), "max": f["max"]}
            for f in state.get("fx", [])
        ],
    }
    if state.get("mode") == "arena":
        base.update(
            {
                "elixir": round(float(state.get("elixir", 0.0)), 2),
                "hand": list(state.get("hand", [])),
                "hand_levels": [int(state.get("levels", {}).get(k, 1)) for k in state.get("hand", [])],
                "deck": list(state.get("deck", [])),
                "towers": towers,
                "crowns": {
                    "p": arena_crowns(state, 0),
                    "e": arena_crowns(state, 1),
                },
                "opponent": state.get("opponent", {}),
            }
        )
    else:
        base.update(
            {
                "buildings": [
                    {
                        "id": b["id"],
                        "t": b["t"],
                        "x": b["x"],
                        "y": b["y"],
                        "s": b["s"],
                        "hp": max(0, round(b["hp"])),
                        "max_hp": round(b["max_hp"]),
                        "hit": round(b.get("hit", 0.0), 2),
                    }
                    for b in state.get("buildings", [])
                ],
                "walls": [
                    {
                        "id": w["id"],
                        "gx": w["gx"],
                        "gy": w["gy"],
                        "hp": max(0, round(w["hp"])),
                        "max_hp": round(w["max_hp"]),
                    }
                    for w in state.get("walls", [])
                ],
                "army": [{"k": a["k"], "count": a["count"]} for a in state.get("army", [])],
                "destruction": int(state.get("destruction", 0)),
                "stars": int(state.get("stars", 0)),
                "opponent": state.get("opponent", {}),
            }
        )
    return base
