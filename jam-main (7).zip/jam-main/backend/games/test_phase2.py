"""JamPlay Phase 2 tests: progression, missions, achievements, rewards, social.

Every mutation is exercised through the API where the behaviour is user-facing,
and through services where a trusted server-side event has to be simulated.
"""

from __future__ import annotations

import threading
import unittest
from unittest import mock

from django.contrib.auth import get_user_model
from django.db import connection, connections
from django.test import TransactionTestCase
from django.utils import timezone
from rest_framework.test import APITestCase

from . import rules as R
from .models import (
    AchievementUnlock,
    Battle,
    GameEvent,
    GameFriend,
    GameProfile,
    LedgerEntry,
    LevelRecord,
    MissionProgress,
)
from .services import (
    claim_daily_gift,
    claim_mission,
    evaluate_achievements,
    get_profile,
    grant_xp,
    record_event,
)

User = get_user_model()

PROFILE = "/api/games/profile/"
PROGRESS = "/api/games/progress/"
MISSIONS = "/api/games/missions/"
MISSION_CLAIM = "/api/games/missions/claim/"
ACHIEVEMENTS = "/api/games/achievements/"
DAILY_GIFT = "/api/games/daily-gift/"
LEADERBOARD = "/api/games/leaderboard/"
FRIENDS = "/api/games/friends/"
FRIEND_SEARCH = "/api/games/friends/search/"
FRIEND_REQUEST = "/api/games/friends/request/"
FRIEND_RESPOND = "/api/games/friends/respond/"
FRIEND_REMOVE = "/api/games/friends/remove/"
FRIEND_CHALLENGE = "/api/games/friends/challenge/"
ARENA_START = "/api/games/arena/start/"
ARENA_FINISH = "/api/games/arena/finish/"
SIEGE_START = "/api/games/siege/start/"
SIEGE_FINISH = "/api/games/siege/finish/"


def force_end(key: str, result: str = "win", score: int = 3) -> Battle:
    battle = Battle.objects.get(key=key)
    state = battle.state
    state["ended"] = True
    state["result"] = result
    if battle.mode == Battle.Mode.ARENA:
        state["crowns"] = {"p": score, "e": 0}
        for tower in state["towers"]:
            if tower["team"] == 1:
                tower["hp"] = 0
    else:
        state["stars"] = score
        state["destruction"] = 100
        for building in state["buildings"]:
            building["hp"] = 0
    battle.state = state
    battle.save(update_fields=["state"])
    return battle


class Phase2Base(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(phone="+989120000101", password="secret123")
        self.client.force_authenticate(user=self.user)
        self.client.get(PROFILE)
        self.profile = GameProfile.objects.get(user=self.user)

    def other_user(self, phone="+989120000102", display_name="ساتر"):
        other = User.objects.create_user(phone=phone, password="secret123")
        session = self.client
        session.force_authenticate(user=other)
        session.get(PROFILE)
        session.force_authenticate(user=self.user)
        profile = GameProfile.objects.get(user=other)
        if display_name:
            profile.display_name = display_name
            profile.save(update_fields=["display_name"])
        return profile

    def arena_win(self, result: str = "win", score: int = 3):
        start = self.client.post(ARENA_START, {}, format="json")
        self.assertEqual(start.status_code, 201, start.data)
        battle = force_end(start.data["battle"]["battle_key"], result=result, score=score)
        finish = self.client.post(ARENA_FINISH, {"battle_key": battle.key}, format="json")
        self.assertEqual(finish.status_code, 200, finish.data)
        return finish


# ---------------------------------------------------------------------------
# Progression
# ---------------------------------------------------------------------------


class ProgressionServiceTests(Phase2Base):
    def test_bootstrap_records_baseline_level_without_reward(self):
        self.assertEqual(LevelRecord.objects.filter(profile=self.profile).count(), 1)
        record = LevelRecord.objects.get(profile=self.profile, level=1)
        self.assertTrue(record.baseline)
        self.assertEqual(record.reward_gems, 0)
        self.assertEqual(GameProfile.objects.get(pk=self.profile.pk).gems, R.STARTING_GEMS)

    def test_xp_crossing_a_level_pays_gems_once(self):
        result = grant_xp(self.profile, 125, LedgerEntry.Reason.BATTLE_REWARD.value,
                          reference="test:level", idempotency_key="test:level:xp")
        self.assertEqual(result["level_before"], 1)
        self.assertEqual(result["level_after"], 2)
        self.assertEqual(result["leveled"], [{"level": 2, "gems": R.LEVEL_UP_GEMS}])
        profile = GameProfile.objects.get(pk=self.profile.pk)
        self.assertEqual(profile.xp, 125)
        self.assertEqual(profile.gems, R.STARTING_GEMS + R.LEVEL_UP_GEMS)
        self.assertEqual(
            LedgerEntry.objects.filter(profile=profile, reason=LedgerEntry.Reason.LEVEL_UP.value).count(), 1
        )

        again = grant_xp(self.profile, 125, LedgerEntry.Reason.BATTLE_REWARD.value,
                         reference="test:level", idempotency_key="test:level:xp")
        self.assertTrue(again.get("duplicate"))
        profile = GameProfile.objects.get(pk=self.profile.pk)
        self.assertEqual(profile.xp, 125)
        self.assertEqual(profile.gems, R.STARTING_GEMS + R.LEVEL_UP_GEMS)

    def test_multiple_levels_pay_each_level(self):
        result = grant_xp(self.profile, 120 + 210 + 300, LedgerEntry.Reason.BATTLE_REWARD.value)
        self.assertEqual(result["level_after"], 4)
        self.assertEqual([item["level"] for item in result["leveled"]], [2, 3, 4])
        profile = GameProfile.objects.get(pk=self.profile.pk)
        self.assertEqual(profile.gems, R.STARTING_GEMS + 3 * R.LEVEL_UP_GEMS)

    def test_pre_existing_xp_is_baseline_not_retro_paid(self):
        LevelRecord.objects.filter(profile=self.profile).delete()
        GameProfile.objects.filter(pk=self.profile.pk).update(xp=1000)
        profile = get_profile(self.user)
        self.assertEqual(profile.gems, R.STARTING_GEMS)
        self.assertEqual(
            LevelRecord.objects.filter(profile=profile, baseline=True).count(),
            R.level_info(1000)["level"],
        )
        result = grant_xp(profile, 400, LedgerEntry.Reason.BATTLE_REWARD.value)
        self.assertEqual(result["leveled"], [{"level": 5, "gems": R.LEVEL_UP_GEMS}])
        self.assertEqual(
            GameProfile.objects.get(pk=profile.pk).gems, R.STARTING_GEMS + R.LEVEL_UP_GEMS
        )

    def test_progress_endpoint_reports_level_and_history(self):
        grant_xp(self.profile, 150, LedgerEntry.Reason.BATTLE_REWARD.value)
        response = self.client.get(PROGRESS)
        self.assertEqual(response.status_code, 200, response.data)
        self.assertEqual(response.data["level"], 2)
        self.assertEqual(response.data["xp"], 150)
        self.assertEqual(response.data["xp_in_level"], 30)
        self.assertEqual(response.data["xp_need"], R.xp_need(2))
        self.assertEqual(response.data["xp_to_next"], R.xp_need(2) - 30)
        self.assertEqual(response.data["next_level_gems"], R.LEVEL_UP_GEMS)
        self.assertEqual(response.data["level_history"][0]["level"], 2)
        self.assertIn("stats", response.data)
        self.assertEqual(response.data["stats"]["best_trophies"], 0)

    def test_display_name_can_be_updated_and_validated(self):
        response = self.client.patch(PROFILE, {"display_name": "کاوه"}, format="json")
        self.assertEqual(response.status_code, 200, response.data)
        self.assertEqual(response.data["profile"]["display_name"], "کاوه")
        bad = self.client.patch(PROFILE, {"display_name": "x"}, format="json")
        self.assertEqual(bad.status_code, 400)
        self.assertEqual(bad.data["code"], "invalid_display_name")


# ---------------------------------------------------------------------------
# Daily gift
# ---------------------------------------------------------------------------


class DailyGiftTests(Phase2Base):
    def test_claim_once_per_local_day(self):
        coins_before = GameProfile.objects.get(pk=self.profile.pk).coins
        gems_before = GameProfile.objects.get(pk=self.profile.pk).gems
        expected = R.daily_gift(3)
        response = self.client.post(DAILY_GIFT, {}, format="json")
        self.assertEqual(response.status_code, 200, response.data)
        self.assertEqual(response.data["rewards"]["coins"], expected["coins"])
        self.assertEqual(response.data["rewards"]["gems"], expected["gems"])
        profile = GameProfile.objects.get(pk=self.profile.pk)
        self.assertEqual(profile.coins, coins_before + expected["coins"])
        self.assertEqual(profile.gems, gems_before + expected["gems"])
        self.assertEqual(profile.daily_gift_date, timezone.localdate())
        self.assertFalse(response.data["daily_gift"]["available"])

        again = self.client.post(DAILY_GIFT, {}, format="json")
        self.assertEqual(again.status_code, 400)
        self.assertEqual(again.data["code"], "daily_gift_claimed")
        self.assertEqual(GameProfile.objects.get(pk=self.profile.pk).coins, profile.coins)

    def test_rollback_leaves_no_partial_gift(self):
        coins_before = GameProfile.objects.get(pk=self.profile.pk).coins
        with mock.patch("games.services.record_event", side_effect=RuntimeError("boom")):
            with self.assertRaises(RuntimeError):
                claim_daily_gift(self.profile)
        profile = GameProfile.objects.get(pk=self.profile.pk)
        self.assertEqual(profile.coins, coins_before)
        self.assertIsNone(profile.daily_gift_date)
        self.assertFalse(
            LedgerEntry.objects.filter(profile=profile, reason=LedgerEntry.Reason.DAILY_GIFT.value).exists()
        )

    def test_gift_advances_daily_mission(self):
        self.client.post(DAILY_GIFT, {}, format="json")
        response = self.client.get(MISSIONS)
        daily = {item["key"]: item for item in response.data["daily"]}
        self.assertEqual(daily["jd3"]["progress"], 1)
        self.assertTrue(daily["jd3"]["ready"])


# ---------------------------------------------------------------------------
# Missions
# ---------------------------------------------------------------------------


class MissionTests(Phase2Base):
    def test_catalog_and_empty_progress(self):
        response = self.client.get(MISSIONS)
        self.assertEqual(response.status_code, 200, response.data)
        self.assertEqual(len(response.data["daily"]), len(R.DAILY_MISSIONS))
        self.assertEqual(len(response.data["permanent"]), len(R.PERMANENT_MISSIONS))
        self.assertEqual(response.data["daily_claimed"], 0)
        self.assertTrue(all(item["progress"] == 0 for item in response.data["daily"]))
        self.assertTrue(all(not item["claimed"] for item in response.data["permanent"]))

    def test_arena_win_progresses_battle_missions(self):
        self.arena_win()
        response = self.client.get(MISSIONS)
        daily = {item["key"]: item for item in response.data["daily"]}
        permanent = {item["key"]: item for item in response.data["permanent"]}
        self.assertTrue(daily["jd2"]["ready"])
        self.assertTrue(permanent["jm-battle"]["claimed"] is False)
        self.assertEqual(permanent["jm-battle"]["progress"], 1)
        self.assertFalse(permanent["jm-siege"]["ready"])

    def test_siege_win_progresses_siege_mission(self):
        start = self.client.post(SIEGE_START, {}, format="json")
        self.assertEqual(start.status_code, 201)
        force_end(start.data["battle"]["battle_key"])
        finish = self.client.post(SIEGE_FINISH, {"battle_key": start.data["battle"]["battle_key"]}, format="json")
        self.assertEqual(finish.status_code, 200, finish.data)
        response = self.client.get(MISSIONS)
        permanent = {item["key"]: item for item in response.data["permanent"]}
        self.assertTrue(permanent["jm-siege"]["ready"])

    def test_claim_requires_completion_and_pays_once(self):
        incomplete = self.client.post(MISSION_CLAIM, {"mission_key": "jd2"}, format="json")
        self.assertEqual(incomplete.status_code, 400)
        self.assertEqual(incomplete.data["code"], "mission_incomplete")

        self.arena_win()
        coins_before = GameProfile.objects.get(pk=self.profile.pk).coins
        claim = self.client.post(MISSION_CLAIM, {"mission_key": "jd2"}, format="json")
        self.assertEqual(claim.status_code, 200, claim.data)
        self.assertTrue(claim.data["mission"]["claimed"])
        self.assertEqual(claim.data["rewards"]["coins"], R.DAILY_MISSIONS[0]["rewards"]["coins"])
        self.assertEqual(
            GameProfile.objects.get(pk=self.profile.pk).coins,
            coins_before + R.DAILY_MISSIONS[0]["rewards"]["coins"],
        )

        again = self.client.post(MISSION_CLAIM, {"mission_key": "jd2"}, format="json")
        self.assertEqual(again.status_code, 400)
        self.assertEqual(again.data["code"], "mission_claimed")
        self.assertEqual(
            LedgerEntry.objects.filter(
                profile=self.profile, reason=LedgerEntry.Reason.MISSION_REWARD.value, reference__startswith="mission:jd2"
            ).count(),
            2,  # coins + xp
        )

    def test_unknown_mission_and_empty_key_rejected(self):
        self.assertEqual(
            self.client.post(MISSION_CLAIM, {"mission_key": "nope"}, format="json").data["code"],
            "mission_not_found",
        )
        self.assertEqual(
            self.client.post(MISSION_CLAIM, {}, format="json").data["code"], "mission_key_required"
        )

    def test_claim_rolls_back_on_failure(self):
        self.arena_win()
        with mock.patch("games.services.evaluate_achievements", side_effect=RuntimeError("boom")):
            with self.assertRaises(RuntimeError):
                claim_mission(GameProfile.objects.get(pk=self.profile.pk), "jd2")
        row = MissionProgress.objects.filter(profile=self.profile, mission_key="jd2").first()
        self.assertIsNotNone(row)
        self.assertIsNone(row.claimed_at)
        self.assertFalse(
            LedgerEntry.objects.filter(
                profile=self.profile, reason=LedgerEntry.Reason.MISSION_REWARD.value
            ).exists()
        )

    def test_daily_progress_is_period_scoped(self):
        MissionProgress.objects.create(
            profile=self.profile,
            mission_key="jd2",
            period="2020-01-01",
            progress=1,
            claimed_at=timezone.now(),
        )
        response = self.client.get(MISSIONS)
        daily = {item["key"]: item for item in response.data["daily"]}
        self.assertEqual(daily["jd2"]["progress"], 0)
        self.assertFalse(daily["jd2"]["claimed"])
        self.assertEqual(response.data["daily_claimed"], 0)

    def test_permanent_progress_survives_daily_reset(self):
        self.arena_win()
        # A new local day only affects daily period lookups.
        MissionProgress.objects.create(
            profile=self.profile,
            mission_key="jd2",
            period="1999-12-31",
            progress=1,
            claimed_at=timezone.now(),
        )
        response = self.client.get(MISSIONS)
        permanent = {item["key"]: item for item in response.data["permanent"]}
        self.assertEqual(permanent["jm-battle"]["progress"], 1)


# ---------------------------------------------------------------------------
# Achievements and events
# ---------------------------------------------------------------------------


class AchievementTests(Phase2Base):
    def test_achievement_catalog_exposes_progress(self):
        response = self.client.get(ACHIEVEMENTS)
        self.assertEqual(response.status_code, 200, response.data)
        keys = {item["key"] for item in response.data["achievements"]}
        self.assertEqual(keys, {item["key"] for item in R.ACHIEVEMENTS})
        win3 = next(item for item in response.data["achievements"] if item["key"] == "win3")
        self.assertEqual(win3["progress"], 0)
        self.assertFalse(win3["unlocked"])

    def test_three_wins_unlock_once_with_gems(self):
        for _ in range(3):
            self.arena_win()
        profile = GameProfile.objects.get(pk=self.profile.pk)
        self.assertEqual(profile.total_wins, 3)
        unlock = AchievementUnlock.objects.get(profile=profile, achievement_key="win3")
        self.assertEqual(unlock.gems_awarded, 10)
        self.assertEqual(
            LedgerEntry.objects.filter(
                profile=profile, reason=LedgerEntry.Reason.ACHIEVEMENT_REWARD.value
            ).count(),
            1,
        )
        # Re-evaluating never re-unlocks or re-pays an earned achievement.
        evaluate_achievements(profile)
        self.assertEqual(AchievementUnlock.objects.filter(profile=profile).count(), 1)
        self.assertEqual(
            LedgerEntry.objects.filter(
                profile=profile, reason=LedgerEntry.Reason.ACHIEVEMENT_REWARD.value
            ).count(),
            1,
        )

    def test_league_achievement_uses_persisted_best_trophies(self):
        GameProfile.objects.filter(pk=self.profile.pk).update(best_trophies=200)
        unlocked = evaluate_achievements(GameProfile.objects.get(pk=self.profile.pk))
        self.assertEqual([item["key"] for item in unlocked], ["league"])
        self.assertTrue(AchievementUnlock.objects.filter(profile=self.profile, achievement_key="league").exists())

    def test_duplicate_event_reference_does_not_double_progress(self):
        first = record_event(self.profile, GameEvent.Kind.BATTLE_WIN, "battle:same")
        second = record_event(self.profile, GameEvent.Kind.BATTLE_WIN, "battle:same")
        self.assertTrue(first["created"])
        self.assertFalse(second["created"])
        self.assertEqual(GameEvent.objects.filter(profile=self.profile, kind="battle_win").count(), 1)
        row = MissionProgress.objects.get(profile=self.profile, mission_key="jd2", period=timezone.localdate().isoformat())
        self.assertEqual(row.progress, 1)

    def test_achievement_is_not_client_supplied(self):
        response = self.client.post(ACHIEVEMENTS, {"key": "win3", "unlocked": True}, format="json")
        self.assertEqual(response.status_code, 405)
        self.assertFalse(AchievementUnlock.objects.filter(profile=self.profile).exists())


# ---------------------------------------------------------------------------
# Rewards round-trip through battle settlement
# ---------------------------------------------------------------------------


class BattleProgressionTests(Phase2Base):
    def test_settlement_reports_level_up_and_achievements(self):
        GameProfile.objects.filter(pk=self.profile.pk).update(xp=100)
        response = self.arena_win()
        self.assertEqual(response.data["rewards"]["xp"], 70)
        self.assertEqual(
            [item["level"] for item in response.data["rewards"]["level_up"]], [2]
        )
        self.assertEqual(response.data["profile"]["level"], 2)
        self.assertEqual(
            GameProfile.objects.get(pk=self.profile.pk).gems,
            R.STARTING_GEMS + R.LEVEL_UP_GEMS,
        )

    def test_retried_settlement_does_not_grant_second_time(self):
        response = self.arena_win()
        profile = GameProfile.objects.get(pk=self.profile.pk)
        with mock.patch("games.services.record_event", wraps=record_event) as spy:
            again = self.client.post(
                ARENA_FINISH, {"battle_key": response.data["battle"]["battle_key"]}, format="json"
            )
        self.assertEqual(again.status_code, 200)
        self.assertTrue(again.data["already_settled"])
        self.assertEqual(GameProfile.objects.get(pk=self.profile.pk).xp, profile.xp)
        self.assertEqual(
            GameEvent.objects.filter(profile=profile, reference__startswith="battle:").count(), 3
        )
        self.assertFalse(spy.called)


# ---------------------------------------------------------------------------
# Social
# ---------------------------------------------------------------------------


class FriendTests(Phase2Base):
    def test_search_requires_two_characters_and_only_display_names(self):
        self.other_user(display_name="ساترِ کاشف")
        short = self.client.post(FRIEND_SEARCH, {"q": "س"}, format="json")
        self.assertEqual(short.status_code, 400)
        self.assertEqual(short.data["code"], "query_too_short")

        found = self.client.post(FRIEND_SEARCH, {"q": "ساتر"}, format="json")
        self.assertEqual(found.status_code, 200, found.data)
        self.assertEqual(len(found.data["results"]), 1)
        item = found.data["results"][0]
        self.assertEqual(item["display_name"], "ساترِ کاشف")
        self.assertEqual(item["relation"], "none")
        self.assertNotIn("phone", item)
        self.assertNotIn("user", item)

        phone_search = self.client.post(FRIEND_SEARCH, {"q": "+98912"}, format="json")
        self.assertEqual(phone_search.data["results"], [])

    def test_request_accept_remove_flow(self):
        friend = self.other_user(display_name="ساتر")
        request = self.client.post(FRIEND_REQUEST, {"profile_id": friend.id}, format="json")
        self.assertEqual(request.status_code, 201, request.data)
        self.assertEqual(len(request.data["outgoing"]), 1)

        duplicate = self.client.post(FRIEND_REQUEST, {"profile_id": friend.id}, format="json")
        self.assertEqual(duplicate.status_code, 400)
        self.assertEqual(duplicate.data["code"], "friend_request_pending")
        self_request = self.client.post(FRIEND_REQUEST, {"profile_id": self.profile.id}, format="json")
        self.assertEqual(self_request.data["code"], "friend_self")

        # Accept from the addressee's session.
        self.client.force_authenticate(user=friend.user)
        incoming = self.client.get(FRIENDS)
        self.assertEqual(len(incoming.data["incoming"]), 1)
        accept = self.client.post(
            FRIEND_RESPOND, {"profile_id": self.profile.id, "accept": True}, format="json"
        )
        self.assertEqual(accept.status_code, 200, accept.data)
        self.assertEqual(len(accept.data["friends"]), 1)
        self.assertEqual(GameFriend.objects.filter(status="accepted").count(), 1)

        self.client.force_authenticate(user=self.user)
        mine = self.client.get(FRIENDS)
        self.assertEqual(mine.data["friends"][0]["profile_id"], friend.id)
        removed = self.client.post(FRIEND_REMOVE, {"profile_id": friend.id}, format="json")
        self.assertEqual(removed.status_code, 200)
        self.assertEqual(GameFriend.objects.count(), 0)

    def test_rejecting_a_request_removes_it(self):
        friend = self.other_user(display_name="ساتر")
        self.client.post(FRIEND_REQUEST, {"profile_id": friend.id}, format="json")
        self.client.force_authenticate(user=friend.user)
        reject = self.client.post(
            FRIEND_RESPOND, {"profile_id": self.profile.id, "accept": False}, format="json"
        )
        self.assertEqual(reject.status_code, 200)
        self.assertEqual(GameFriend.objects.count(), 0)

    def test_responding_to_missing_request_is_404_like_error(self):
        response = self.client.post(FRIEND_RESPOND, {"profile_id": 99999, "accept": True}, format="json")
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data["code"], "friend_request_not_found")

    def test_friendly_challenge_requires_accepted_friend(self):
        stranger = self.other_user(display_name="غریبه")
        denied = self.client.post(FRIEND_CHALLENGE, {"profile_id": stranger.id}, format="json")
        self.assertEqual(denied.status_code, 400)
        self.assertEqual(denied.data["code"], "not_friends")

    def test_friendly_battle_pays_xp_without_trophies_or_chest(self):
        friend = self.other_user(display_name="ساتر")
        GameProfile.objects.filter(pk=friend.pk).update(trophies=320, best_trophies=320)
        self.client.post(FRIEND_REQUEST, {"profile_id": friend.id}, format="json")
        self.client.force_authenticate(user=friend.user)
        self.client.post(FRIEND_RESPOND, {"profile_id": self.profile.id, "accept": True}, format="json")
        self.client.force_authenticate(user=self.user)

        xp_before = GameProfile.objects.get(pk=self.profile.pk).xp
        start = self.client.post(FRIEND_CHALLENGE, {"profile_id": friend.id}, format="json")
        self.assertEqual(start.status_code, 201, start.data)
        battle = start.data["battle"]
        self.assertTrue(battle["friendly"])
        self.assertEqual(battle["opponent"], "ساتر")

        force_end(battle["battle_key"])
        finish = self.client.post(ARENA_FINISH, {"battle_key": battle["battle_key"]}, format="json")
        self.assertEqual(finish.status_code, 200, finish.data)
        rewards = finish.data["rewards"]
        self.assertTrue(rewards["friendly"])
        self.assertEqual(rewards["xp"], R.FRIENDLY_BATTLE_XP)
        self.assertEqual(rewards["trophies"], 0)
        self.assertIsNone(rewards["chest"])

        profile = GameProfile.objects.get(pk=self.profile.pk)
        self.assertEqual(profile.xp, xp_before + R.FRIENDLY_BATTLE_XP)
        self.assertEqual(profile.trophies, 0)
        self.assertEqual(profile.friendly_played, 1)
        self.assertEqual(profile.arena_played, 0)

        missions = self.client.get(MISSIONS).data
        daily = {item["key"]: item for item in missions["daily"]}
        permanent = {item["key"]: item for item in missions["permanent"]}
        self.assertTrue(daily["jd4"]["ready"])
        self.assertTrue(permanent["jm-friendly"]["ready"])

    def test_leaderboard_exposes_no_private_fields(self):
        self.other_user(display_name="ساتر")
        response = self.client.get(LEADERBOARD)
        self.assertEqual(response.status_code, 200, response.data)
        self.assertGreaterEqual(len(response.data["entries"]), 1)
        first = response.data["entries"][0]
        self.assertEqual(
            set(first), {"rank", "display_name", "level", "trophies", "is_me"}
        )
        self.assertTrue(any(item["is_me"] for item in response.data["entries"]))
        self.assertEqual(response.data["me"]["rank"], 1)

    def test_social_endpoints_require_authentication(self):
        self.client.force_authenticate(user=None)
        for path in (FRIENDS, LEADERBOARD, MISSIONS, ACHIEVEMENTS, PROGRESS):
            self.assertEqual(self.client.get(path).status_code, 401, path)


# ---------------------------------------------------------------------------
# Journeys
# ---------------------------------------------------------------------------


class Phase2JourneyTests(Phase2Base):
    def test_progression_and_mission_journey_persists(self):
        # Complete qualifying activity (a battle win), then reload.
        self.arena_win()
        profile = self.client.get(PROFILE).data
        self.assertGreater(profile["xp"], 0)

        progress = self.client.get(PROGRESS).data
        self.assertEqual(progress["stats"]["arena_wins"], 1)

        missions = self.client.get(MISSIONS).data
        ready = next(item for item in missions["daily"] if item["key"] == "jd2")
        self.assertTrue(ready["ready"])

        claim = self.client.post(MISSION_CLAIM, {"mission_key": "jd2"}, format="json")
        self.assertEqual(claim.status_code, 200, claim.data)

        reload = self.client.get(MISSIONS).data
        claimed = next(item for item in reload["daily"] if item["key"] == "jd2")
        self.assertTrue(claimed["claimed"])
        self.assertFalse(claimed["ready"])

        balances = self.client.get(PROFILE).data
        self.assertEqual(balances["coins"], claim.data["profile"]["coins"])

    def test_achievement_journey_unlock_and_reload(self):
        wins = 0
        while wins < 3:
            self.arena_win()
            wins += 1
        achievements = self.client.get(ACHIEVEMENTS).data["achievements"]
        win3 = next(item for item in achievements if item["key"] == "win3")
        self.assertTrue(win3["unlocked"])
        self.assertEqual(win3["progress"], 3)
        self.assertIsNotNone(win3["unlocked_at"])

        reload = self.client.get(ACHIEVEMENTS).data["achievements"]
        self.assertTrue(next(item for item in reload if item["key"] == "win3")["unlocked"])
        self.assertEqual(AchievementUnlock.objects.filter(profile=self.profile).count(), 1)


@unittest.skipUnless(connection.vendor == "postgresql", "PostgreSQL-only concurrency test")
class MissionConcurrencyTests(TransactionTestCase):
    """Two parallel claims must pay exactly one reward (requires PostgreSQL)."""

    def test_concurrent_mission_claim_pays_once(self):
        user = User.objects.create_user(phone="+989120000902", password="secret123")
        profile = get_profile(user)
        record_event(profile, GameEvent.Kind.BATTLE_WIN, "battle:race")

        barrier = threading.Barrier(2)
        results: list[dict] = []
        errors: list[BaseException] = []

        def worker() -> None:
            try:
                barrier.wait(timeout=10)
                results.append(claim_mission(GameProfile.objects.get(pk=profile.pk), "jd2"))
            except BaseException as exc:  # noqa: BLE001 - asserted below
                errors.append(exc)
            finally:
                connections.close_all()

        threads = [threading.Thread(target=worker) for _ in range(2)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(timeout=20)

        self.assertEqual(errors, [])
        self.assertEqual(len(results), 2)
        self.assertEqual(sum(1 for item in results if item.get("ok")), 1)
        self.assertEqual(
            sum(1 for item in results if item.get("code") == "mission_claimed"), 1
        )
        self.assertEqual(
            LedgerEntry.objects.filter(
                profile=profile, reason=LedgerEntry.Reason.MISSION_REWARD.value
            ).count(),
            2,  # coins + xp once
        )


class Phase2LedgerTests(Phase2Base):
    def test_ledger_sum_matches_wallet_after_phase2_rewards(self):
        self.arena_win()
        self.client.post(DAILY_GIFT, {}, format="json")
        self.client.post(MISSION_CLAIM, {"mission_key": "jd2"}, format="json")
        profile = GameProfile.objects.get(pk=self.profile.pk)
        for resource in (LedgerEntry.Resource.COINS.value, LedgerEntry.Resource.GEMS.value):
            total = sum(
                LedgerEntry.objects.filter(profile=profile, resource=resource).values_list(
                    "delta", flat=True
                )
            )
            self.assertEqual(total, getattr(profile, resource), resource)
        self.assertGreaterEqual(profile.gems, R.STARTING_GEMS)
