"""Read-only serializers for JamPlay admin/reference use.

The player-facing API builds explicit payloads in ``games.services`` so the
response shape stays stable; these serializers exist for tooling and tests.
"""

from rest_framework import serializers

from .models import Battle, Building, ChestSlot, LedgerEntry, PlayerCard


class PlayerCardSerializer(serializers.ModelSerializer):
    class Meta:
        model = PlayerCard
        fields = ["card_key", "level", "copies"]
        read_only_fields = fields


class BuildingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Building
        fields = ["key", "building_type", "grid_x", "grid_y", "level"]
        read_only_fields = fields


class ChestSlotSerializer(serializers.ModelSerializer):
    class Meta:
        model = ChestSlot
        fields = ["index", "kind", "state", "ready_at"]
        read_only_fields = fields


class BattleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Battle
        fields = [
            "key", "mode", "status", "result", "score", "destruction",
            "rewards", "opponent_name", "difficulty", "created_at", "settled_at",
        ]
        read_only_fields = fields


class LedgerEntrySerializer(serializers.ModelSerializer):
    class Meta:
        model = LedgerEntry
        fields = [
            "resource", "delta", "balance_after", "reason", "reference",
            "idempotency_key", "created_at",
        ]
        read_only_fields = fields
