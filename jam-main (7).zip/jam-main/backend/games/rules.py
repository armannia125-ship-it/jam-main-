"""JamPlay game rules.

Every number the UI shows and the combat engine uses lives here. This module is
pure data + pure functions: it has no Django, database, HTTP or presentation
dependency so the domain can be simulated and unit-tested in isolation.

The catalog mirrors the JamPlay reference prototype (``jam-life.html``,
``window.GAMES``): card costs/stats, building effects, chest tables, leagues,
XP curve and the battle reward formulas.
"""

from __future__ import annotations

import math

ENGINE_VERSION = "jamplay-engine-1"

# ---------------------------------------------------------------------------
# Arena / siege constants
# ---------------------------------------------------------------------------

ARENA_WIDTH = 600.0
ARENA_HEIGHT = 900.0
ARENA_LIMIT = 180.0
ARENA_OVERTIME = 60.0
SIEGE_WIDTH = 960.0
SIEGE_LIMIT = 150.0
SIM_DT = 0.05
MAX_SIM_STEPS = 12000  # hard ceiling: 600 simulated seconds

ELIXIR_MAX = 10.0
ELIXIR_RATE = 0.58
ELIXIR_RATE_DOUBLE = 1.15
ELIXIR_DOUBLE_AT = 90.0
RIVER_TOP = 426.0
RIVER_BOTTOM = 474.0
BRIDGE_XS = (150.0, 450.0)
BRIDGE_HALF_WIDTH = 34.0
ARENA_MIN_X = 30.0
ARENA_MAX_X = 570.0
ARENA_MIN_Y = 45.0
ARENA_MAX_Y = 850.0
MAX_UNITS_PER_SIDE = 65

DECK_SIZE = 8
HAND_SIZE = 4
CARD_MAX_LEVEL = 6
CARD_UPGRADE_COPIES = (0, 2, 4, 10, 20, 50)
CARD_UPGRADE_COSTS = (0, 50, 150, 400, 1000, 2000)

# ---------------------------------------------------------------------------
# Cards
# ---------------------------------------------------------------------------

CARDS: dict[str, dict] = {
    "guard": {
        "name": "نگهبان سنگی",
        "art": "guard",
        "cost": 3,
        "hp": 720,
        "dmg": 100,
        "rate": 0.9,
        "speed": 42.0,
        "range": 27.0,
        "count": 1,
        "role": "خط مقدم",
        "description": "تعادل بین جان و ضربه؛ مناسب حفاظت از تیراندازها.",
    },
    "archer": {
        "name": "کمانداران جنگل",
        "art": "archer",
        "cost": 3,
        "hp": 210,
        "dmg": 48,
        "rate": 1.0,
        "speed": 39.0,
        "range": 145.0,
        "count": 2,
        "role": "دوربرد",
        "description": "دو کماندار؛ پشت نیروهای مقاوم نگهشان دار.",
    },
    "golem": {
        "name": "غول خزه‌ای",
        "art": "golem",
        "cost": 5,
        "hp": 1850,
        "dmg": 145,
        "rate": 1.5,
        "speed": 24.0,
        "range": 30.0,
        "count": 1,
        "buildings": True,
        "role": "تانک / ساختمان‌زن",
        "description": "جان زیاد و حرکت آهسته؛ مستقیم سراغ ساختمان‌ها می‌رود.",
    },
    "mage": {
        "name": "جادوگر توفان",
        "art": "mage",
        "cost": 4,
        "hp": 390,
        "dmg": 90,
        "rate": 1.25,
        "speed": 36.0,
        "range": 130.0,
        "count": 1,
        "splash": 52.0,
        "role": "آسیب منطقه‌ای",
        "description": "ضربهٔ زنجیره‌ای برای مقابله با نیروهای گروهی.",
    },
    "meteor": {
        "name": "شهاب آتشین",
        "art": "meteor",
        "cost": 4,
        "spell": True,
        "radius": 88.0,
        "dmg": 340,
        "role": "طلسم هجومی",
        "description": "آسیب منطقه‌ای؛ آسیب آن به برج‌ها ۴۰٪ است.",
    },
    "ballista": {
        "name": "بالستای سیار",
        "art": "ballista",
        "cost": 5,
        "hp": 510,
        "dmg": 170,
        "rate": 1.7,
        "speed": 24.0,
        "range": 190.0,
        "count": 1,
        "buildings": True,
        "role": "محاصره / دوربرد",
        "description": "از فاصلهٔ دور به ساختمان‌ها شلیک می‌کند؛ نیازمند محافظ است.",
    },
    "scouts": {
        "name": "پیشاهنگان",
        "art": "scouts",
        "cost": 2,
        "hp": 155,
        "dmg": 42,
        "rate": 0.7,
        "speed": 65.0,
        "range": 24.0,
        "count": 3,
        "role": "گروهی / سریع",
        "description": "سه گروه سبک؛ در برابر حمله‌های منطقه‌ای آسیب‌پذیرند.",
    },
    "frost": {
        "name": "انجماد",
        "art": "frost",
        "cost": 2,
        "spell": True,
        "radius": 95.0,
        "dmg": 25,
        "freeze": 3.2,
        "role": "طلسم کنترلی",
        "description": "دشمنان داخل محدوده را موقتاً متوقف می‌کند.",
    },
    "sentinel": {
        "name": "پاسدار آهنین",
        "art": "guard",
        "cost": 4,
        "hp": 1150,
        "dmg": 80,
        "rate": 1.0,
        "speed": 31.0,
        "range": 29.0,
        "count": 1,
        "role": "دفاع مقاوم",
        "description": "نیروی دفاعی پرجان برای متوقف کردن پیشروی دشمن.",
    },
    "spark": {
        "name": "جرقه‌زن",
        "art": "mage",
        "cost": 2,
        "hp": 190,
        "dmg": 62,
        "rate": 1.15,
        "speed": 48.0,
        "range": 115.0,
        "count": 1,
        "role": "پشتیبان سبک",
        "description": "دوربرد ارزان برای چرخش سریع‌تر دستهٔ کارت.",
    },
    "volley": {
        "name": "باران تیر",
        "art": "archer",
        "cost": 3,
        "spell": True,
        "radius": 115.0,
        "dmg": 200,
        "role": "طلسم منطقه‌ای",
        "description": "محدودهٔ بزرگ؛ مؤثر علیه کمانداران و پیشاهنگ‌ها.",
    },
    "heal": {
        "name": "چشمهٔ احیا",
        "art": "frost",
        "cost": 3,
        "spell": True,
        "radius": 100.0,
        "heal": 350,
        "role": "طلسم حمایتی",
        "description": "بخشی از جان نیروهای خودی را بازیابی می‌کند؛ روی برج اثر ندارد.",
    },
}

STARTER_CARDS = ("guard", "archer", "golem", "mage", "meteor", "ballista", "scouts", "frost")
# Unlocked by city discovery in the prototype. City Discovery is deferred, so
# these four variants are defined but not obtainable in Phase 1.
CITY_UNLOCKED_CARDS = ("sentinel", "spark", "volley", "heal")

ARENA_ARMY = (
    {"key": "guard", "count": 12},
    {"key": "archer", "count": 8},
    {"key": "golem", "count": 3},
    {"key": "mage", "count": 4},
)

# ---------------------------------------------------------------------------
# Buildings
# ---------------------------------------------------------------------------

BUILDING_TYPES: dict[str, dict] = {
    "th": {
        "name": "تالار شهر",
        "size": 4,
        "max_level": 8,
        "base_cost": 500,
        "effect": "سقف سطح بقیهٔ ساختمان‌ها. ارتقا فقط با امتیاز کشف باز می‌شود.",
        "art": "th",
    },
    "vault": {"name": "خزانهٔ طلا", "size": 3, "max_level": 8, "base_cost": 250, "effect": "ظرفیت نگه‌داری سکه.", "art": "vault"},
    "camp": {"name": "کاروانسرای تجارت", "size": 4, "max_level": 8, "base_cost": 300, "effect": "تولید سکه در هر ساعت.", "art": "camp"},
    "mine": {"name": "معدن الماس", "size": 3, "max_level": 6, "base_cost": 420, "effect": "تولید آرام الماس.", "art": "mine"},
    "tower": {"name": "برج نگهبان", "size": 2, "max_level": 8, "base_cost": 320, "effect": "جان برج‌های تو در آوردگاه.", "art": "tower"},
    "bazaar": {"name": "بازارچهٔ همکاران", "size": 3, "max_level": 5, "base_cost": 380, "effect": "پاداش سکهٔ پیشنهادهای کسب‌وکارهای همکار.", "art": "bazaar"},
    "fountain": {"name": "حوض باغ", "size": 2, "max_level": 5, "base_cost": 220, "effect": "پاداش تجربه از همهٔ فعالیت‌ها.", "art": "fountain"},
    "chest": {"name": "گنج روزانه", "size": 2, "max_level": 1, "base_cost": 0, "effect": "هر روز یک هدیهٔ رایگان.", "art": "chest"},
    "hero": {"name": "کاشف", "size": 1, "max_level": 1, "base_cost": 0, "effect": "شخصیت تو در پایگاه.", "art": "hero"},
}

# Fixed layout from the prototype; placement is not player-editable in Phase 1.
BASE_LAYOUT = (
    {"key": "th", "type": "th", "gx": 9, "gy": 9},
    {"key": "vault", "type": "vault", "gx": 4, "gy": 9},
    {"key": "camp", "type": "camp", "gx": 14, "gy": 9},
    {"key": "mine", "type": "mine", "gx": 14, "gy": 4},
    {"key": "tw1", "type": "tower", "gx": 4, "gy": 4},
    {"key": "tw2", "type": "tower", "gx": 16, "gy": 15},
    {"key": "bazaar", "type": "bazaar", "gx": 9, "gy": 15},
    {"key": "fountain", "type": "fountain", "gx": 9, "gy": 5},
    {"key": "chest", "type": "chest", "gx": 5, "gy": 15},
    {"key": "hero", "type": "hero", "gx": 13, "gy": 15},
)

# Discovery points required to reach town-hall level n.
TOWN_HALL_DP = (0, 0, 20, 50, 90, 140, 200, 270, 350)

# Building HP used when the player's base is the siege target (defensive copy).
BUILDING_HP = {
    "th": 2200,
    "tower": 1250,
    "vault": 1100,
    "camp": 1150,
    "mine": 950,
    "bazaar": 850,
    "fountain": 650,
}
BUILDING_DEFAULT_HP = 900


def building_key_for_type(building_type: str) -> str:
    for item in BASE_LAYOUT:
        if item["type"] == building_type:
            return item["key"]
    return building_type


def upgrade_cost(building_type: str, level: int) -> int:
    base = BUILDING_TYPES[building_type]["base_cost"]
    return int(round(base * (1.75 ** (level - 1)) / 10.0) * 10)


def upgrade_seconds(level: int) -> int:
    return int(20 * (level ** 2))


def max_level_for(building_type: str, town_hall_level: int) -> int:
    cap = BUILDING_TYPES[building_type]["max_level"]
    if building_type == "th":
        return cap
    return min(cap, town_hall_level)


# ---------------------------------------------------------------------------
# Chests, leagues, progression
# ---------------------------------------------------------------------------

CHEST_SLOTS = 4
CHEST_TYPES: dict[str, dict] = {
    "silver": {"name": "صندوق نقره", "minutes": 3, "coins": (60, 120), "cards": 6, "gems": None},
    "gold": {"name": "صندوق طلا", "minutes": 10, "coins": (180, 320), "cards": 14, "gems": (2, 5)},
}

LEAGUES = (
    {"min": 0, "name": "دروازهٔ دولت", "color": "#9fb6c9"},
    {"min": 200, "name": "باغ چهل‌ستون", "color": "#5cc46a"},
    {"min": 500, "name": "پل خواجو", "color": "#34c7c0"},
    {"min": 900, "name": "میدان نقش جهان", "color": "#f2b53a"},
    {"min": 1400, "name": "ایوان عالی‌قاپو", "color": "#ff8f4a"},
    {"min": 2000, "name": "گنبد شیخ لطف‌الله", "color": "#e07cf0"},
)

OPPONENT_NAMES = (
    "آرش‌اصفهانی", "مهسا.کاشف", "رها_جلفا", "سپهرِ‌چهارباغ", "نیلوفر", "کیانِ‌پل",
    "دارا", "پرنیا", "بردیا.زاینده", "ترانه", "کاوه", "یاسمن", "سارا", "امیرحسین",
)

STARTING_COINS = 500
STARTING_GEMS = 30

# ---------------------------------------------------------------------------
# Phase 2: progression, missions, achievements, social
# ---------------------------------------------------------------------------

# Prototype ``grant``: each new player level pays 8 gems.
LEVEL_UP_GEMS = 8
DAILY_GIFT_GEMS = 3

DISPLAY_NAME_MIN = 2
DISPLAY_NAME_MAX = 20
FRIEND_SEARCH_MIN = 2
FRIEND_SEARCH_LIMIT = 10
LEADERBOARD_LIMIT = 20

DAILY_MISSIONS: tuple[dict, ...] = (
    {
        "key": "jd2",
        "title": "در آرنا یا محاصره پیروز شو",
        "icon": "swords",
        "event": "battle_win",
        "target": 1,
        "rewards": {"xp": 40, "coins": 200},
    },
    {
        "key": "jd3",
        "title": "هدیهٔ روزانه را دریافت کن",
        "icon": "gift",
        "event": "daily_gift",
        "target": 1,
        "rewards": {"xp": 20, "gems": 2},
    },
    {
        "key": "jd4",
        "title": "یک نبرد دوستانه را تمام کن",
        "icon": "users",
        "event": "friendly_battle",
        "target": 1,
        "rewards": {"xp": 25, "coins": 60},
    },
)

PERMANENT_MISSIONS: tuple[dict, ...] = (
    {
        "key": "jm-battle",
        "title": "اولین نبرد آرنا را کامل کن",
        "icon": "cards",
        "event": "arena_battle",
        "target": 1,
        "rewards": {"xp": 30, "coins": 80},
    },
    {
        "key": "jm-build",
        "title": "یک ساختمان را ارتقا بده",
        "icon": "hammer",
        "event": "building_upgrade",
        "target": 1,
        "rewards": {"xp": 50, "coins": 120},
    },
    {
        "key": "jm-friendly",
        "title": "یک چالش دوستانه را کامل کن",
        "icon": "users",
        "event": "friendly_battle",
        "target": 1,
        "rewards": {"xp": 35, "coins": 100},
    },
    {
        "key": "jm-siege",
        "title": "در یک محاصره پیروز شو",
        "icon": "swords",
        "event": "siege_win",
        "target": 1,
        "rewards": {"xp": 60, "coins": 160, "gems": 3},
    },
)

# Prototype ``BADGES``, limited to conditions this build can actually observe.
# ``first``/``city10``/``local`` depend on excluded City Discovery or an
# unapproved Commerce→Games event contract (see PHASE2_FEATURE_INVENTORY.md).
ACHIEVEMENTS: tuple[dict, ...] = (
    {
        "key": "win3",
        "title": "جنگاور",
        "description": "۳ پیروزی در آرنا یا محاصره",
        "icon": "swords",
        "event": "battle_win",
        "target": 3,
        "gems": 10,
    },
    {
        "key": "league",
        "title": "قهرمان لیگ",
        "description": "رسیدن به ۲۰۰ جام",
        "icon": "trophy",
        "metric": "best_trophies",
        "target": 200,
        "gems": 10,
    },
    {
        "key": "th4",
        "title": "معمار",
        "description": "تالار شهر سطح ۴",
        "icon": "castle",
        "metric": "town_hall_level",
        "target": 4,
        "gems": 10,
    },
)

FRIENDLY_BATTLE_XP = 15


def mission_definition(key: str, daily: bool | None = None) -> dict | None:
    """Resolve a mission definition, optionally constrained to daily/permanent."""
    pools = ()
    if daily is None:
        pools = (DAILY_MISSIONS, PERMANENT_MISSIONS)
    elif daily:
        pools = (DAILY_MISSIONS,)
    else:
        pools = (PERMANENT_MISSIONS,)
    for pool in pools:
        for mission in pool:
            if mission["key"] == key:
                return mission
    return None


def missions_for_event(kind: str) -> list[dict]:
    """Daily + permanent missions whose objective is driven by ``kind``."""
    return [
        mission
        for mission in (*DAILY_MISSIONS, *PERMANENT_MISSIONS)
        if mission["event"] == kind
    ]


def achievement_definition(key: str) -> dict | None:
    for achievement in ACHIEVEMENTS:
        if achievement["key"] == key:
            return achievement
    return None


def league_index(trophies: int) -> int:
    index = 0
    for i, league in enumerate(LEAGUES):
        if trophies >= league["min"]:
            index = i
    return index


def league_floor(trophies: int) -> int:
    return LEAGUES[league_index(trophies)]["min"]


def xp_need(level: int) -> int:
    return 120 + (level - 1) * 90


def level_info(total_xp: int) -> dict:
    level, remaining = 1, max(0, int(total_xp))
    while remaining >= xp_need(level) and level < 999:
        remaining -= xp_need(level)
        level += 1
    return {"level": level, "xp": remaining, "need": xp_need(level)}


def card_multiplier(level: int) -> float:
    return 1 + 0.1 * (max(1, level) - 1)


def card_upgrade_cost(level: int) -> int:
    if level >= CARD_MAX_LEVEL:
        return 0
    return CARD_UPGRADE_COSTS[level]


def card_upgrade_copies(level: int) -> int:
    if level >= CARD_MAX_LEVEL:
        return 0
    return CARD_UPGRADE_COPIES[level]


def vault_capacity(vault_level: int) -> int:
    return 2000 * max(1, vault_level)


def camp_rate(camp_level: int) -> int:
    return 240 * max(1, camp_level)


def camp_capacity(camp_level: int) -> int:
    return camp_rate(camp_level) * 2


def mine_rate(mine_level: int) -> int:
    return 3 * max(1, mine_level)


def mine_capacity(mine_level: int) -> int:
    return mine_rate(mine_level) * 3


def gems_for_seconds(seconds: float) -> int:
    return max(1, math.ceil(seconds / 60.0))


def foe_card_level(trophies: int) -> int:
    return min(CARD_MAX_LEVEL, max(1, 1 + trophies // 300))


def battle_difficulty(trophies: int, first_battle: bool) -> str:
    if first_battle or trophies < 80:
        return "easy"
    if trophies >= 900:
        return "hard"
    return "normal"


def opponent_factor(trophies: int, first_battle: bool) -> float:
    if first_battle:
        return 0.85
    return 1 + 0.04 * league_index(trophies)


def arena_rewards(result: str, crowns: int, trophies: int) -> dict:
    """Reward table from the prototype's ``combatEnded``."""
    league = league_index(trophies)
    if result == "win":
        coins = 90 + 30 * crowns + 10 * league
    elif result == "draw":
        coins = 50
    else:
        coins = 25
    xp = 40 + crowns * 10 if result == "win" else 15
    return {"coins": coins, "xp": xp}


def siege_rewards(stars: int, destruction: int, loot: int, result: str) -> dict:
    coins = int(round(loot * destruction / 100.0 / 10.0) * 10)
    xp = 40 + stars * 10 if result == "win" else 15
    return {"coins": coins, "xp": xp}


def trophy_delta(result: str, mode: str, score: int) -> int:
    if result == "win":
        return score * 9 if mode == "siege" else 29
    if result == "draw":
        return 0
    return -10 if mode == "siege" else -16


def chest_kind_for(mode: str, score: int, win_count: int) -> str:
    if (mode == "siege" and score >= 3) or win_count % 4 == 0:
        return "gold"
    return "silver"


def daily_gift(th_level: int) -> dict:
    return {"coins": 150 + 40 * max(1, th_level), "gems": 3}


# ---------------------------------------------------------------------------
# Catalog serialisation for the API/UI
# ---------------------------------------------------------------------------

def catalog() -> dict:
    return {
        "engine_version": ENGINE_VERSION,
        "cards": [
            {"key": key, **value} for key, value in CARDS.items()
        ],
        "starter_cards": list(STARTER_CARDS),
        "army": list(ARENA_ARMY),
        "buildings": [
            {"type": key, **value, "hp": BUILDING_HP.get(key, BUILDING_DEFAULT_HP)}
            for key, value in BUILDING_TYPES.items()
        ],
        "base_layout": list(BASE_LAYOUT),
        "town_hall_dp": list(TOWN_HALL_DP),
        "chests": [{"key": key, **value} for key, value in CHEST_TYPES.items()],
        "leagues": list(LEAGUES),
        "rules": {
            "deck_size": DECK_SIZE,
            "hand_size": HAND_SIZE,
            "card_max_level": CARD_MAX_LEVEL,
            "card_upgrade_copies": list(CARD_UPGRADE_COPIES),
            "card_upgrade_costs": list(CARD_UPGRADE_COSTS),
            "arena_limit": ARENA_LIMIT,
            "siege_limit": SIEGE_LIMIT,
            "sim_dt": SIM_DT,
            "elixir_max": ELIXIR_MAX,
            "city_discovery_enabled": False,
        },
    }
