import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

DEBUG = os.getenv("DJANGO_DEBUG", "False").lower() == "true"
SECRET_KEY = os.getenv("DJANGO_SECRET_KEY", "unsafe-development-key-change-me" if DEBUG else "")

if not SECRET_KEY:
    from django.core.exceptions import ImproperlyConfigured
    raise ImproperlyConfigured("DJANGO_SECRET_KEY must be set when DEBUG is false.")

OTPY_API_KEY = os.getenv("OTPY_API_KEY", "")

if not OTPY_API_KEY and not DEBUG:
    from django.core.exceptions import ImproperlyConfigured
    raise ImproperlyConfigured("OTPY_API_KEY must be set when DEBUG is false.")

ALLOWED_HOSTS = [host.strip() for host in os.getenv("DJANGO_ALLOWED_HOSTS", "localhost,127.0.0.1").split(",") if host.strip()]

# Absolute public origin of the customer-facing frontend (for example
# https://jam.example). QR codes and other server-generated public links must be
# built from this value, never from the incoming request Host/X-Forwarded-Host.
# It is validated at use time; when it is missing or invalid the affected
# endpoint fails closed instead of falling back to localhost or an internal host.
PUBLIC_FRONTEND_URL = os.getenv("PUBLIC_FRONTEND_URL", "").strip()

# HTTPS/security settings are explicit so a production deployment cannot
# silently run with insecure cookies. TLS termination and the proxy trust flag
# remain deployment decisions documented in PRODUCTION_DEPLOYMENT_READINESS.md.

def _env_bool(name, default=False):
    return os.getenv(name, str(default)).strip().lower() == "true"

SECURE_SSL_REDIRECT = _env_bool("DJANGO_SECURE_SSL_REDIRECT", False)
SESSION_COOKIE_SECURE = _env_bool("DJANGO_SESSION_COOKIE_SECURE", not DEBUG)
CSRF_COOKIE_SECURE = _env_bool("DJANGO_CSRF_COOKIE_SECURE", not DEBUG)
SECURE_HSTS_SECONDS = int(os.getenv("DJANGO_SECURE_HSTS_SECONDS", "0"))
SECURE_HSTS_INCLUDE_SUBDOMAINS = _env_bool("DJANGO_SECURE_HSTS_INCLUDE_SUBDOMAINS", False)
SECURE_HSTS_PRELOAD = _env_bool("DJANGO_SECURE_HSTS_PRELOAD", False)
if _env_bool("DJANGO_TRUST_PROXY_SSL", False):
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")

INSTALLED_APPS = [
    "django.contrib.admin", "django.contrib.auth", "django.contrib.contenttypes",
    "django.contrib.sessions", "django.contrib.messages", "django.contrib.staticfiles",
    "corsheaders", "rest_framework", "rest_framework_simplejwt",
    "accounts", "businesses", "subscriptions", "payments",
    "cart", "bot", "commerce",
    "games",
]

MIDDLEWARE = [
    "corsheaders.middleware.CorsMiddleware",
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "config.urls"
TEMPLATES = [{
    "BACKEND": "django.template.backends.django.DjangoTemplates",
    "DIRS": [], "APP_DIRS": True,
    "OPTIONS": {"context_processors": [
        "django.template.context_processors.debug", "django.template.context_processors.request",
        "django.contrib.auth.context_processors.auth", "django.contrib.messages.context_processors.messages",
    ]},
}]

WSGI_APPLICATION = "config.wsgi.application"
ASGI_APPLICATION = "config.asgi.application"

DATABASES = {"default": {
    "ENGINE": "django.db.backends.postgresql",
    "NAME": os.getenv("POSTGRES_DB", "jam"),
    "USER": os.getenv("POSTGRES_USER", "jam"),
    "PASSWORD": os.getenv("POSTGRES_PASSWORD", "jam-local-password"),
    "HOST": os.getenv("POSTGRES_HOST", "localhost"),
    "PORT": os.getenv("POSTGRES_PORT", "5432"),
    "CONN_MAX_AGE": 60,
}}

AUTH_USER_MODEL = "accounts.User"
AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

LANGUAGE_CODE = "fa-ir"
TIME_ZONE = "Asia/Tehran"
USE_I18N = True
USE_TZ = True

STATIC_URL = "static/"
STATIC_ROOT = BASE_DIR / "staticfiles"
MEDIA_URL = "/media/"
MEDIA_ROOT = BASE_DIR / "media"

# Default to filesystem storage for media files
DEFAULT_FILE_STORAGE_BACKEND = os.getenv("DEFAULT_FILE_STORAGE_BACKEND", "django.core.files.storage.FileSystemStorage")

# S3-compatible storage configuration (optional)
S3_BUCKET_NAME = os.getenv("AWS_STORAGE_BUCKET_NAME", "")
S3_AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID", "")
S3_AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY", "")
S3_AWS_STORAGE_BUCKET_NAME = os.getenv("AWS_STORAGE_BUCKET_NAME", "")
S3_AWS_ENDPOINT_URL = os.getenv("AWS_S3_ENDPOINT_URL", "")
S3_AWS_REGION_NAME = os.getenv("AWS_S3_REGION_NAME", "")
S3_AWS_CUSTOM_DOMAIN = os.getenv("AWS_S3_CUSTOM_DOMAIN", "")
S3_AWS_DEFAULT_ACL = os.getenv("AWS_DEFAULT_ACL", "")

# Determine whether S3-compatible storage is explicitly requested.
# The canonical switch is DEFAULT_FILE_STORAGE_BACKEND. When it points to a
# non-filesystem backend, all required S3 credentials must be present; otherwise
# the application fails closed with a clear error.
_S3_requested = DEFAULT_FILE_STORAGE_BACKEND != "django.core.files.storage.FileSystemStorage"
_S3_credentials_present = bool(
    S3_BUCKET_NAME
    and S3_AWS_ACCESS_KEY_ID
    and S3_AWS_SECRET_ACCESS_KEY
)

if _S3_requested and not _S3_credentials_present:
    from django.core.exceptions import ImproperlyConfigured
    raise ImproperlyConfigured(
        "DEFAULT_FILE_STORAGE_BACKEND is set to a non-filesystem backend, "
        "but AWS_STORAGE_BUCKET_NAME, AWS_ACCESS_KEY_ID, and AWS_SECRET_ACCESS_KEY "
        "are not all set. Provide all three S3 credentials or revert "
        "DEFAULT_FILE_STORAGE_BACKEND to django.core.files.storage.FileSystemStorage."
    )

if _S3_requested and _S3_credentials_present:
    try:
        # Django passes only OPTIONS to the storage backend. django-storages
        # 1.14.x expects lowercase constructor keyword arguments, so these
        # must live under OPTIONS; top-level keys are silently ignored.
        STORAGES = {
            "default": {
                "BACKEND": "storages.backends.s3boto3.S3Boto3Storage",
                "OPTIONS": {
                    "bucket_name": S3_AWS_STORAGE_BUCKET_NAME or S3_BUCKET_NAME,
                    "access_key": S3_AWS_ACCESS_KEY_ID,
                    "secret_key": S3_AWS_SECRET_ACCESS_KEY,
                    "endpoint_url": S3_AWS_ENDPOINT_URL or None,
                    "region_name": S3_AWS_REGION_NAME or None,
                    "custom_domain": S3_AWS_CUSTOM_DOMAIN or None,
                    "default_acl": S3_AWS_DEFAULT_ACL or None,
                },
            },
            "staticfiles": {"BACKEND": "whitenoise.storage.CompressedManifestStaticFilesStorage"},
        }
    except ImportError:
        STORAGES = {
            "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
            "staticfiles": {"BACKEND": "whitenoise.storage.CompressedManifestStaticFilesStorage"},
        }
else:
    STORAGES = {
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {"BACKEND": "whitenoise.storage.CompressedManifestStaticFilesStorage"},
    }

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": ["rest_framework_simplejwt.authentication.JWTAuthentication"],
    "DEFAULT_PERMISSION_CLASSES": ["rest_framework.permissions.IsAuthenticated"],
    "DEFAULT_THROTTLE_CLASSES": [
        "rest_framework.throttling.AnonRateThrottle", "rest_framework.throttling.UserRateThrottle",
    ],
    "DEFAULT_THROTTLE_RATES": {
        "anon": "100/hour", "user": "1000/hour", "otp": "5/hour", "bot": "30/hour",
    },
}

from datetime import timedelta
SIMPLE_JWT = {
    "ACCESS_TOKEN_LIFETIME": timedelta(minutes=30),
    "REFRESH_TOKEN_LIFETIME": timedelta(days=7),
    "ROTATE_REFRESH_TOKENS": True,
    "AUTH_HEADER_TYPES": ("Bearer",),
}

REDIS_URL = os.getenv("REDIS_URL", "")
# Deployed environments require a Redis-backed cache. Local development may
# fall back to LocMemCache. Readiness uses this flag so a successful
# LocMemCache operation is never reported as external Redis connectivity.
CACHE_REQUIRE_REDIS = _env_bool("CACHE_REQUIRE_REDIS", not DEBUG)
if REDIS_URL:
    CACHES = {"default": {"BACKEND": "django_redis.cache.RedisCache", "LOCATION": REDIS_URL,
                        "OPTIONS": {"CLIENT_CLASS": "django_redis.client.DefaultClient"}}}
else:
    CACHES = {"default": {"BACKEND": "django.core.cache.backends.locmem.LocMemCache", "LOCATION": "jam-local"}}

CORS_ALLOW_ALL_ORIGINS = DEBUG
CORS_ALLOWED_ORIGINS = ["http://localhost:3000"]
CSRF_TRUSTED_ORIGINS = [origin.strip() for origin in os.getenv("DJANGO_CSRF_TRUSTED_ORIGINS", "").split(",") if origin.strip()]
EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_BOT_USERNAME = os.getenv("TELEGRAM_BOT_USERNAME", "")

# Server-to-server credential used only by the trusted operator bot. It must
# never be exposed through NEXT_PUBLIC_* variables.

ZARINPAL_MERCHANT_ID = os.getenv("ZARINPAL_MERCHANT_ID", "")
ZARINPAL_SANDBOX = os.getenv("ZARINPAL_SANDBOX", str(DEBUG)).lower() == "true"
ZARINPAL_CALLBACK_URL = os.getenv("ZARINPAL_CALLBACK_URL", "http://localhost:8000/api/payments/zarinpal/callback/")

# Commerce / club configuration. Simulated payments are opt-in and never
# represent provider-confirmed money.
CLUB_PURCHASE_CODE_TTL_SECONDS = int(os.getenv("CLUB_PURCHASE_CODE_TTL_SECONDS", "300"))
CLUB_PURCHASE_CODE_DAILY_LIMIT = int(os.getenv("CLUB_PURCHASE_CODE_DAILY_LIMIT", "5"))
COMMERCE_ALLOW_SIMULATED_PAYMENTS = (
    os.getenv("COMMERCE_ALLOW_SIMULATED_PAYMENTS", "false").lower() == "true"
)
COMMERCE_ORDER_ONLINE_PAYMENTS_ENABLED = (
    os.getenv("COMMERCE_ORDER_ONLINE_PAYMENTS_ENABLED", "false").lower() == "true"
)