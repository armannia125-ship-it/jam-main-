import os

os.environ.setdefault("DJANGO_SECRET_KEY", "concurrency-test-only")
os.environ.setdefault("OTPY_API_KEY", "concurrency-test-only")

from .settings import *  # noqa: F401,F403,E402

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": os.environ.get("PGTEST_NAME", "jam_concurrency"),
        "USER": os.environ.get("PGTEST_USER", "postgres"),
        "PASSWORD": os.environ.get("PGTEST_PASSWORD", ""),
        "HOST": os.environ.get("PGTEST_HOST", "127.0.0.1"),
        "PORT": os.environ.get("PGTEST_PORT", "55432"),
        "CONN_MAX_AGE": 0,
    }
}
CACHES = {"default": {"BACKEND": "django.core.cache.backends.locmem.LocMemCache"}}
PASSWORD_HASHERS = ["django.contrib.auth.hashers.MD5PasswordHasher"]
DEBUG = True
ALLOWED_HOSTS = ["127.0.0.1", "localhost", "testserver"]
COMMERCE_ALLOW_SIMULATED_PAYMENTS = True
COMMERCE_ORDER_ONLINE_PAYMENTS_ENABLED = True
