from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path
from config.health import LiveView, ReadyView
from payments.views import ZarinPalCallbackView

urlpatterns = [
    path("api/health/live/", LiveView.as_view(), name="health-live"),
    path("api/health/ready/", ReadyView.as_view(), name="health-ready"),
    path("admin/", admin.site.urls),
    path("api/auth/", include("accounts.urls")),
    path("api/admin/", include("accounts.admin_urls")),
    path("api/cart/", include("cart.urls")),
    path("api/", include("businesses.urls")),
    path("api/subscriptions/", include("subscriptions.urls")),
    path("api/commerce/", include("commerce.urls")),
    path("api/games/", include("games.urls")),
    path("api/bot/", include("bot.urls")),
    path("api/payments/zarinpal/callback/", ZarinPalCallbackView.as_view(), name="zarinpal-callback"),
]

if settings.DEBUG:
    # Only for local development; production serves media through the
    # deployment's static/media layer.
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
