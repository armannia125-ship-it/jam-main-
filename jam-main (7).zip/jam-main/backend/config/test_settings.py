import os

from django.core.exceptions import ImproperlyConfigured

os.environ.setdefault("DJANGO_SECRET_KEY", "test-only-secret-key-that-is-never-used-in-production")
os.environ.setdefault("OTPY_API_KEY", "test-otpy-key-for-diagnostic-testing")
from .settings import *

if os.getenv("TEST_DB_ENGINE", "sqlite").lower() in {"postgres", "postgresql"}:
    # PostgreSQL verification is deliberately local-only. The explicit guard
    # prevents a mistaken test run from targeting an external database.
    _test_host = os.getenv("POSTGRES_HOST", "localhost")
    if _test_host not in {"localhost", "127.0.0.1"}:
        raise ImproperlyConfigured(
            "PostgreSQL test settings require a local POSTGRES_HOST; refusing external host."
        )
    _test_db = os.getenv("POSTGRES_TEST_DB_NAME", "test_jam_postlegacy")
    if not _test_db.startswith("test_"):
        raise ImproperlyConfigured(
            "POSTGRES_TEST_DB_NAME must start with 'test_' to protect non-test databases."
        )
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.postgresql",
            "NAME": os.getenv("POSTGRES_DB", "jam"),
            "USER": os.getenv("POSTGRES_USER", "jam"),
            "PASSWORD": os.getenv("POSTGRES_PASSWORD", "jam-local-password"),
            "HOST": _test_host,
            "PORT": os.getenv("POSTGRES_PORT", "5432"),
            "TEST": {"NAME": _test_db},
        }
    }
else:
    DATABASES = {"default": {"ENGINE": "django.db.backends.sqlite3", "NAME": ":memory:"}}
CACHES = {"default": {"BACKEND": "django.core.cache.backends.locmem.LocMemCache"}}
# Tests use the in-memory cache deliberately; readiness logic is exercised
# explicitly through override_settings in config/tests.py.
CACHE_REQUIRE_REDIS = False
PASSWORD_HASHERS = ["django.contrib.auth.hashers.MD5PasswordHasher"]
DEBUG = True
COMMERCE_ALLOW_SIMULATED_PAYMENTS = True
COMMERCE_ORDER_ONLINE_PAYMENTS_ENABLED = True

# Deterministic public origin for server-generated links (QR codes). Individual
# tests override this to assert fail-closed behavior.
PUBLIC_FRONTEND_URL = "https://jam.test"

MIDDLEWARE = [m for m in MIDDLEWARE if m != "whitenoise.middleware.WhiteNoiseMiddleware"]
