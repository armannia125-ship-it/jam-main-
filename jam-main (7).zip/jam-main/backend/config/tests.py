from unittest.mock import patch

from django.test import TestCase, override_settings

from config.health import LiveView, ReadyView, cache_status

LOCMEM_CACHES = {
    "default": {
        "BACKEND": "django.core.cache.backends.locmem.LocMemCache",
        "LOCATION": "jam-health-test",
    }
}
REDIS_CACHES = {
    "default": {
        "BACKEND": "django_redis.cache.RedisCache",
        "LOCATION": "redis://127.0.0.1:6399/0",
        "OPTIONS": {"CLIENT_CLASS": "django_redis.client.DefaultClient"},
    }
}


class HealthEndpointTests(TestCase):
    def test_liveness_returns_ok(self):
        response = self.client.get("/api/health/live/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"status": "live"})

    def test_readiness_returns_ok_when_dependencies_are_available(self):
        response = self.client.get("/api/health/ready/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["status"], "ready")

    def test_health_checks_bypass_api_throttles(self):
        self.assertEqual(LiveView.throttle_classes, [])
        self.assertEqual(ReadyView.throttle_classes, [])

    def test_repeated_health_checks_are_not_rate_limited(self):
        for _ in range(150):
            response = self.client.get("/api/health/ready/")
            self.assertEqual(response.status_code, 200)


class CacheStatusTests(TestCase):
    def test_locmem_is_accepted_only_as_the_local_debug_fallback(self):
        with override_settings(
            DEBUG=True, REDIS_URL="", CACHE_REQUIRE_REDIS=False, CACHES=LOCMEM_CACHES
        ):
            self.assertEqual(cache_status(), "ok")

    def test_locmem_is_rejected_outside_the_local_fallback(self):
        with override_settings(
            DEBUG=False, REDIS_URL="", CACHE_REQUIRE_REDIS=True, CACHES=LOCMEM_CACHES
        ):
            self.assertEqual(cache_status(), "unavailable")

    def test_redis_backend_without_redis_url_is_rejected(self):
        with override_settings(DEBUG=False, REDIS_URL="", CACHES=REDIS_CACHES):
            with patch("config.health.cache") as fake_cache:
                self.assertEqual(cache_status(), "unavailable")
                fake_cache.set.assert_not_called()

    def test_redis_backend_with_readback_is_accepted(self):
        with override_settings(
            DEBUG=False,
            REDIS_URL="redis://127.0.0.1:6399/0",
            CACHES=REDIS_CACHES,
        ):
            with patch("config.health.cache") as fake_cache:
                fake_cache.get.return_value = "ok"
                self.assertEqual(cache_status(), "ok")
                fake_cache.set.assert_called_once()

    def test_redis_backend_connection_failure_is_rejected(self):
        with override_settings(
            DEBUG=False,
            REDIS_URL="redis://127.0.0.1:6399/0",
            CACHES=REDIS_CACHES,
        ):
            with patch("config.health.cache") as fake_cache:
                fake_cache.set.side_effect = ConnectionError("redis unreachable")
                self.assertEqual(cache_status(), "unavailable")

    def test_readiness_reports_locmem_fallback_as_unavailable_in_staging(self):
        with override_settings(
            DEBUG=False, REDIS_URL="", CACHE_REQUIRE_REDIS=True, CACHES=LOCMEM_CACHES
        ):
            response = self.client.get("/api/health/ready/")
        self.assertEqual(response.status_code, 503)
        self.assertEqual(response.json()["status"], "not_ready")
        self.assertEqual(response.json()["checks"]["database"], "ok")
        self.assertEqual(response.json()["checks"]["cache"], "unavailable")
        self.assertEqual(set(response.json()["checks"]), {"database", "cache"})
