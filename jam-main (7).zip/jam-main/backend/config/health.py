from django.conf import settings
from django.core.cache import cache
from django.db import connection
from rest_framework import permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

REDIS_CACHE_BACKEND = "django_redis.cache.RedisCache"


def cache_status():
    """Return ``"ok"`` only when the configured cache is usable.

    A Redis-backed cache must be reachable and readable. LocMemCache is
    accepted only when ``CACHE_REQUIRE_REDIS`` is disabled (the local
    development fallback); it is never evidence that an external Redis
    instance is reachable, so it is reported as unavailable otherwise.

    The caller only receives a status string; the Redis URL and credentials
    are never returned or logged.
    """
    backend = settings.CACHES.get("default", {}).get("BACKEND", "")
    redis_url = getattr(settings, "REDIS_URL", "")
    require_redis = getattr(settings, "CACHE_REQUIRE_REDIS", not settings.DEBUG)
    redis_backed = backend == REDIS_CACHE_BACKEND

    if redis_backed:
        if not redis_url:
            return "unavailable"
    elif require_redis:
        # A non-Redis backend is only acceptable as the local fallback.
        return "unavailable"

    try:
        cache.set("jam-healthcheck", "ok", timeout=5)
        if cache.get("jam-healthcheck") != "ok":
            return "unavailable"
    except Exception:
        return "unavailable"
    return "ok"


class LiveView(APIView):
    """Process-level liveness only. No dependency checks."""

    permission_classes = [permissions.AllowAny]
    authentication_classes = []
    # Container health checks run far more often than the anonymous API rate
    # limit and must never be throttled into a false unhealthy state.
    throttle_classes = []

    def get(self, request):
        return Response({"status": "live"})


class ReadyView(APIView):
    """Readiness: verify PostgreSQL and the configured cache backend."""

    permission_classes = [permissions.AllowAny]
    authentication_classes = []
    throttle_classes = []

    def get(self, request):
        checks = {"database": "ok", "cache": "ok"}
        healthy = True
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT 1")
                cursor.fetchone()
        except Exception:
            checks["database"] = "unavailable"
            healthy = False
        checks["cache"] = cache_status()
        if checks["cache"] != "ok":
            healthy = False
        return Response(
            {"status": "ready" if healthy else "not_ready", "checks": checks},
            status=status.HTTP_200_OK if healthy else status.HTTP_503_SERVICE_UNAVAILABLE,
        )
