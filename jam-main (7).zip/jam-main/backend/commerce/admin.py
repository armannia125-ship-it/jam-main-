from django.contrib import admin

from .models import (
    AdCampaign,
    AgreementAcceptance,
    AgreementVersion,
    Campaign,
    ClubOffer,
    ClubVisit,
    CommissionEntry,
    CommissionRateChange,
    InPersonPurchase,
    Invoice,
    LaunchConfig,
    Order,
    OrderItem,
    OrderStatusEvent,
    PurchaseCode,
    SettlementAccount,
    SettlementEntry,
    SettlementReversal,
    StoreConfig,
)


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ("number", "business", "customer", "status", "payment_method", "payment_state", "total_toman")
    list_filter = ("status", "payment_method", "payment_state")
    search_fields = ("number", "business__name", "customer__phone")
    inlines = [OrderItemInline]


@admin.register(StoreConfig)
class StoreConfigAdmin(admin.ModelAdmin):
    list_display = ("business", "commission_rate", "monthly_fee_toman", "delivery_fee_toman", "updated_at")


@admin.register(PurchaseCode)
class PurchaseCodeAdmin(admin.ModelAdmin):
    list_display = ("business", "customer", "code_hint", "status", "issued_at", "expires_at")
    list_filter = ("status",)
    readonly_fields = ("code_hash",)


@admin.register(InPersonPurchase)
class InPersonPurchaseAdmin(admin.ModelAdmin):
    list_display = ("business", "customer", "status", "purchase_date", "confirmed_at")
    list_filter = ("status", "purchase_date")


admin.site.register(
    [
        AgreementVersion,
        AgreementAcceptance,
        ClubOffer,
        ClubVisit,
        CommissionEntry,
        CommissionRateChange,
        Invoice,
        Campaign,
        AdCampaign,
        LaunchConfig,
        SettlementAccount,
        SettlementEntry,
        SettlementReversal,
        OrderStatusEvent,
    ]
)
