from datetime import date, timedelta
from decimal import Decimal

from django.db import IntegrityError, transaction
from django.test import TestCase, override_settings
from django.utils import timezone
from rest_framework.test import APIClient

from accounts.models import User
from businesses.models import Business, Category, Menu, Product
from subscriptions.models import (
    SubscriptionEntitlement,
    SubscriptionProduct,
    SubscriptionPurchase,
)

from . import services
from .models import (
    AgreementAcceptance,
    AgreementVersion,
    ClubOffer,
    CommissionEntry,
    InPersonPurchase,
    Invoice,
    Order,
    PurchaseCode,
    SettlementAccount,
    SettlementEntry,
    StoreConfig,
)


def make_store(owner, name="Store", slug="store"):
    business = Business.objects.create(owner=owner, name=name, slug=slug)
    menu = Menu.objects.create(business=business, title="Menu", slug=f"{slug}-menu")
    category = Category.objects.create(menu=menu, name="Food")
    product = Product.objects.create(category=category, name="Kebab", price_toman=200000)
    return business, product


def activate_club(business, plan_monthly=350000):
    StoreConfig.objects.update_or_create(business=business, defaults={"monthly_fee_toman": plan_monthly})
    agreement, _ = AgreementVersion.objects.get_or_create(
        kind=AgreementVersion.Kind.CLUB,
        version="JL-2026-01",
        defaults={"body": "test terms"},
    )
    AgreementAcceptance.objects.create(
        business=business,
        user=business.owner,
        kind=AgreementVersion.Kind.CLUB,
        version=agreement,
        accepted_name="Owner Name",
    )
    product, _ = SubscriptionProduct.objects.get_or_create(
        slug="seller_club",
        defaults={
            "name": "Seller Club",
            "category": SubscriptionProduct.Category.CLUB,
            "price_toman": 350000,
            "duration_days": 30,
            "max_products": None,
            "sort_order": 60,
        },
    )
    purchase = SubscriptionPurchase.objects.create(
        user=business.owner,
        business=business,
        product=product,
        price_toman=product.price_toman,
        status=SubscriptionPurchase.Status.PAID,
    )
    SubscriptionEntitlement.objects.create(
        user=business.owner,
        business=business,
        entitlement_type=SubscriptionEntitlement.Type.CLUB,
        product=product,
        purchase=purchase,
        starts_at=timezone.now() - timedelta(days=1),
        ends_at=timezone.now() + timedelta(days=10),
        status=SubscriptionEntitlement.Status.ACTIVE,
    )


class CommerceModelTests(TestCase):
    def setUp(self):
        self.owner = User.objects.create_user(phone="09120000001")
        self.business, self.product = make_store(self.owner)

    def test_seeded_terms_versions_exist(self):
        self.assertTrue(AgreementVersion.objects.filter(kind="club").exists())
        self.assertTrue(AgreementVersion.objects.filter(kind="seller").exists())

    def test_commission_entry_is_one_per_order(self):
        order = Order.objects.create(business=self.business, customer=self.owner, total_toman=100)
        CommissionEntry.objects.create(business=self.business, order=order, rate=5, base_toman=100, amount_toman=5)
        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                CommissionEntry.objects.create(
                    business=self.business, order=order, rate=5, base_toman=100, amount_toman=5
                )

    def test_one_confirmed_purchase_per_customer_per_day(self):
        activate_club(self.business)
        code1, _ = services.issue_purchase_code(self.business, self.owner)
        purchase = InPersonPurchase.objects.create(
            business=self.business, customer=self.owner, code=code1,
            confirmed_by=self.owner, purchase_date=timezone.localdate(),
        )
        self.assertEqual(purchase.status, InPersonPurchase.Status.CONFIRMED)
        code2 = PurchaseCode.objects.create(
            business=self.business, customer=self.owner, code_hash="second-hash", code_hint="BBBB",
            issued_on=timezone.localdate(), expires_at=timezone.now() + timedelta(minutes=5),
        )
        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                InPersonPurchase.objects.create(
                    business=self.business, customer=self.owner, code=code2,
                    confirmed_by=self.owner, purchase_date=timezone.localdate(),
                )

    def test_order_requires_matching_store_products(self):
        other_business, _ = make_store(self.owner, "Other", "other")
        with self.assertRaises(services.CommerceError):
            services.create_order(
                business=other_business,
                customer=self.owner,
                items=[{"product_id": self.product.id, "quantity": 1}],
                address_text="Somewhere",
            )


class MembershipAndTermsTests(TestCase):
    def setUp(self):
        self.owner = User.objects.create_user(phone="09120000002")
        self.business, _ = make_store(self.owner, "Club", "club")
        self.other = User.objects.create_user(phone="09120000003")
        self.other_business, _ = make_store(self.other, "Other", "other")

    def test_acceptance_history_is_not_overwritten(self):
        services.accept_agreement(self.business, self.owner, "club", "First Name")
        AgreementVersion.objects.create(kind="club", version="JL-2026-02", body="v2")
        services.accept_agreement(self.business, self.owner, "club", "Second Name")
        self.assertEqual(AgreementAcceptance.objects.filter(business=self.business, kind="club").count(), 2)
        self.assertEqual(
            AgreementAcceptance.objects.filter(business=self.business).order_by("created_at").first().accepted_name,
            "First Name",
        )

    def test_owner_cannot_manage_other_store(self):
        client = APIClient()
        client.force_authenticate(self.owner)
        response = client.get(f"/api/commerce/businesses/{self.other_business.pk}/club/")
        self.assertEqual(response.status_code, 404)

    def test_unauthenticated_seller_endpoint_rejected(self):
        response = APIClient().get(f"/api/commerce/businesses/{self.business.pk}/revenue/")
        self.assertIn(response.status_code, (401, 403))


class PurchaseCodeTests(TestCase):
    def setUp(self):
        self.owner = User.objects.create_user(phone="09120000010")
        self.customer = User.objects.create_user(phone="09120000011")
        self.business, _ = make_store(self.owner, "Shop", "shop")
        self.other_business, _ = make_store(self.owner, "Shop2", "shop2")
        activate_club(self.business)
        activate_club(self.other_business)

    def test_code_is_hashed_and_usable_once(self):
        code, raw = services.issue_purchase_code(self.business, self.customer)
        self.assertEqual(len(code.code_hash), 64)
        self.assertNotEqual(code.code_hash, raw)
        purchase, created, already = services.confirm_purchase_code(self.business, raw, self.owner)
        self.assertTrue(created)
        self.assertFalse(already)
        again, created2, already2 = services.confirm_purchase_code(self.business, raw, self.owner)
        self.assertFalse(created2)
        self.assertTrue(already2)
        self.assertEqual(again.pk, purchase.pk)

    def test_expired_code_cannot_be_confirmed(self):
        code, raw = services.issue_purchase_code(self.business, self.customer)
        with self.assertRaises(services.CommerceError) as ctx:
            services.confirm_purchase_code(
                self.business, raw, self.owner, moment=code.expires_at + timedelta(seconds=1)
            )
        self.assertEqual(ctx.exception.code, "code_expired")

    def test_wrong_store_cannot_use_code(self):
        code, raw = services.issue_purchase_code(self.business, self.customer)
        with self.assertRaises(services.CommerceError) as ctx:
            services.validate_purchase_code(self.other_business, raw)
        self.assertEqual(ctx.exception.code, "code_not_found")
        with self.assertRaises(services.CommerceError):
            services.confirm_purchase_code(self.other_business, raw, self.owner)

    def test_daily_limit(self):
        services.issue_purchase_code(self.business, self.customer)
        # Each reissue revokes the previous code; seed multiple rows directly.
        for _ in range(services.CODE_DAILY_LIMIT):
            PurchaseCode.objects.create(
                business=self.business, customer=self.customer, code_hash=f"hash-{_}-{self.customer.pk}",
                code_hint="AAAA", issued_on=timezone.localdate(),
                expires_at=timezone.now() + timedelta(minutes=5),
            )
        with self.assertRaises(services.CommerceError) as ctx:
            services.issue_purchase_code(self.business, self.customer)
        self.assertEqual(ctx.exception.code, "daily_limit_reached")

    def test_cannot_issue_without_club_entitlement(self):
        SubscriptionEntitlement.objects.filter(business=self.other_business).delete()
        with self.assertRaises(services.CommerceError) as ctx:
            services.issue_purchase_code(self.other_business, self.customer)
        self.assertEqual(ctx.exception.code, "club_inactive")

    def test_customer_cannot_see_other_customers_purchases(self):
        other_customer = User.objects.create_user(phone="09120000012")
        code, raw = services.issue_purchase_code(self.business, self.customer)
        services.confirm_purchase_code(self.business, raw, self.owner)
        client = APIClient()
        client.force_authenticate(other_customer)
        response = client.get("/api/commerce/club/purchases/mine/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["results"], [])

    def test_repeat_daily_purchase_is_rejected(self):
        code, raw = services.issue_purchase_code(self.business, self.customer)
        services.confirm_purchase_code(self.business, raw, self.owner)
        with self.assertRaises(services.CommerceError) as ctx:
            services.issue_purchase_code(self.business, self.customer)
        self.assertEqual(ctx.exception.code, "daily_purchase_done")

    def test_metrics_count_visits_codes_and_confirmed_purchases(self):
        services.record_visit(self.business, self.customer)
        code, raw = services.issue_purchase_code(self.business, self.customer)
        services.confirm_purchase_code(self.business, raw, self.owner)
        metrics = services.club_metrics(self.business)
        self.assertEqual(metrics["visits"], 1)
        self.assertEqual(metrics["codes_issued"], 1)
        self.assertEqual(metrics["purchases_confirmed"], 1)

    def test_returning_customer_needs_confirmed_purchases_on_two_days(self):
        code, raw = services.issue_purchase_code(self.business, self.customer)
        purchase, _, _ = services.confirm_purchase_code(self.business, raw, self.owner)
        InPersonPurchase.objects.filter(pk=purchase.pk).update(purchase_date=date(2026, 1, 1))
        code2, raw2 = services.issue_purchase_code(
            self.business, self.customer, moment=timezone.now() + timedelta(days=1)
        )
        services.confirm_purchase_code(
            self.business, raw2, self.owner, moment=timezone.now() + timedelta(days=1)
        )
        self.assertEqual(services.club_metrics(self.business)["returning_customers"], 1)

    def test_perk_is_snapshotted_on_purchase(self):
        ClubOffer.objects.create(business=self.business, text="Free tea")
        code, raw = services.issue_purchase_code(self.business, self.customer)
        purchase, _, _ = services.confirm_purchase_code(self.business, raw, self.owner)
        ClubOffer.objects.filter(business=self.business).update(text="Changed later")
        purchase.refresh_from_db()
        self.assertEqual(purchase.perk_snapshot, "Free tea")

    def test_revoked_purchase_cannot_be_reconfirmed(self):
        code, raw = services.issue_purchase_code(self.business, self.customer)
        purchase, _, _ = services.confirm_purchase_code(self.business, raw, self.owner)
        services.revoke_purchase(purchase, self.owner)
        with self.assertRaises(services.CommerceError):
            services.confirm_purchase_code(self.business, raw, self.owner)


class OrderFinanceTests(TestCase):
    def setUp(self):
        self.owner = User.objects.create_user(phone="09120000020")
        self.customer = User.objects.create_user(phone="09120000021")
        self.business, self.product = make_store(self.owner, "Finance", "finance")
        StoreConfig.objects.update_or_create(
            business=self.business,
            defaults={"commission_rate": Decimal("10.00"), "delivery_fee_toman": 50000},
        )

    def _order(self, online=True, **kwargs):
        order, _ = services.create_order(
            business=self.business,
            customer=self.customer,
            items=[{"product_id": self.product.id, "quantity": 2}],
            payment_method=Order.PaymentMethod.ONLINE if online else Order.PaymentMethod.OFFLINE,
            mode=Order.Mode.DELIVERY,
            address_text="Jam street",
            **kwargs,
        )
        return order

    def test_server_calculates_totals(self):
        order = self._order()
        self.assertEqual(order.subtotal_toman, 400000)
        self.assertEqual(order.delivery_fee_toman, 50000)
        self.assertEqual(order.total_toman, 450000)

    def test_commission_excludes_delivery(self):
        order = self._order()
        services.mark_order_paid(order, self.owner)
        services.transition_order(order, Order.Status.ACCEPTED, self.owner)
        services.transition_order(order, Order.Status.PREPARING, self.owner)
        services.transition_order(order, Order.Status.SENT, self.owner)
        services.transition_order(order, Order.Status.DONE, self.owner)
        order.refresh_from_db()
        self.assertEqual(order.commission_base_toman, 400000)
        self.assertEqual(order.commission_amount_toman, 40000)

    def test_rate_change_does_not_alter_historical_order(self):
        order = self._order()
        services.update_config(self.business, commission_rate=Decimal("25.00"))
        order.refresh_from_db()
        self.assertEqual(order.commission_rate, Decimal("10.00"))

    def test_offline_order_has_no_commission(self):
        order = self._order(online=False)
        services.transition_order(order, Order.Status.ACCEPTED, self.owner)
        services.transition_order(order, Order.Status.PREPARING, self.owner)
        services.transition_order(order, Order.Status.SENT, self.owner)
        services.transition_order(order, Order.Status.DONE, self.owner)
        order.refresh_from_db()
        self.assertIsNone(order.commission_locked_at)
        self.assertFalse(CommissionEntry.objects.filter(order=order).exists())

    def test_settlement_requires_provider_before_eligible(self):
        order = self._order()
        services.mark_order_paid(order, self.owner)
        for status in (Order.Status.ACCEPTED, Order.Status.PREPARING, Order.Status.SENT, Order.Status.DONE):
            services.transition_order(order, status, self.owner)
        entry = SettlementEntry.objects.get(order=order)
        self.assertEqual(entry.status, SettlementEntry.Status.AWAITING_ONBOARDING)
        self.assertIsNone(entry.paid_at)

    def test_reversal_creates_audit_rows(self):
        order = self._order()
        order, _ = services.mark_order_paid(order, self.owner)
        for status in (Order.Status.ACCEPTED, Order.Status.PREPARING, Order.Status.SENT, Order.Status.DONE):
            order, _ = services.transition_order(order, status, self.owner)
        entry = SettlementEntry.objects.get(order=order)
        SettlementAccount.objects.create(
            business=self.business, legal_name="Owner", iban="IR000000000000000000000000",
            iban_checksum_valid=True, provider_status=SettlementAccount.ProviderStatus.VERIFIED,
        )
        AgreementAcceptance.objects.create(
            business=self.business, user=self.owner, kind="seller",
            version=AgreementVersion.objects.get(kind="seller", version="JL-2026-01"),
            accepted_name="Owner Name",
        )
        services._settlement_ready(order)
        entry.refresh_from_db()
        self.assertEqual(entry.status, SettlementEntry.Status.ELIGIBLE)
        services.transition_order(order, Order.Status.REFUNDED, self.owner)
        entry.refresh_from_db()
        self.assertEqual(entry.status, SettlementEntry.Status.REVERSED)
        self.assertEqual(entry.reversals.count(), 2)
        self.assertEqual(entry.commission_toman, 40000)

    def test_invalid_status_transition_rejected(self):
        order = self._order()
        with self.assertRaises(services.CommerceError) as ctx:
            services.transition_order(order, Order.Status.DONE, self.owner)
        self.assertEqual(ctx.exception.code, "invalid_transition")

    def test_order_idempotency_key_prevents_duplicates(self):
        order1, created1 = services.create_order(
            business=self.business, customer=self.customer,
            items=[{"product_id": self.product.id, "quantity": 1}],
            mode=Order.Mode.DELIVERY, address_text="Jam street", idempotency_key="abc-123",
        )
        order2, created2 = services.create_order(
            business=self.business, customer=self.customer,
            items=[{"product_id": self.product.id, "quantity": 1}],
            mode=Order.Mode.DELIVERY, address_text="Jam street", idempotency_key="abc-123",
        )
        self.assertTrue(created1)
        self.assertFalse(created2)
        self.assertEqual(order1.pk, order2.pk)

    def test_same_idempotency_key_from_another_customer_is_not_shared(self):
        other_customer = User.objects.create_user(phone="09120000022")
        order1, _ = services.create_order(
            business=self.business, customer=self.customer,
            items=[{"product_id": self.product.id, "quantity": 1}],
            mode=Order.Mode.DELIVERY, address_text="Jam street", idempotency_key="shared-key",
        )
        order2, created2 = services.create_order(
            business=self.business, customer=other_customer,
            items=[{"product_id": self.product.id, "quantity": 1}],
            mode=Order.Mode.DELIVERY, address_text="Jam street", idempotency_key="shared-key",
        )
        self.assertTrue(created2)
        self.assertNotEqual(order1.pk, order2.pk)
        self.assertEqual(order2.customer, other_customer)

    def test_iban_checksum(self):
        self.assertFalse(services.iban_is_valid("IR000000000000000000000000"))
        self.assertFalse(services.iban_is_valid("IR123"))
        # Example valid Iranian IBAN structure (mod-97).
        self.assertTrue(services.iban_is_valid("IR062960000000100324200001"))


class APIEndpointTests(TestCase):
    def setUp(self):
        self.owner = User.objects.create_user(phone="09120000030")
        self.other = User.objects.create_user(phone="09120000031")
        self.customer = User.objects.create_user(phone="09120000032")
        self.business, self.product = make_store(self.owner, "API Store", "api-store")
        activate_club(self.business)
        self.other_business, _ = make_store(self.other, "Other Store", "other-store")
        self.client = APIClient()
        self.client.force_authenticate(self.owner)

    def test_owned_business_list_scoped(self):
        response = self.client.get("/api/commerce/businesses/")
        self.assertEqual(response.status_code, 200)
        ids = [row["id"] for row in response.json()["results"]]
        self.assertEqual(ids, [self.business.pk])

    def test_club_status_is_entitlement_based(self):
        fresh_business, _ = make_store(self.owner, "Fresh", "fresh-store")
        response = self.client.get(f"/api/commerce/businesses/{fresh_business.pk}/club/")
        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.json()["membership"]["is_active"])
        active = self.client.get(f"/api/commerce/businesses/{self.business.pk}/club/")
        self.assertTrue(active.json()["membership"]["is_active"])

    def test_revenue_endpoint_returns_server_summary(self):
        response = self.client.get(f"/api/commerce/businesses/{self.business.pk}/revenue/")
        self.assertEqual(response.status_code, 200)
        body = response.json()
        self.assertIn("summary", body)
        self.assertEqual(body["summary"]["commission_earned_toman"], 0)

    def test_config_update_creates_history(self):
        response = self.client.patch(
            f"/api/commerce/businesses/{self.business.pk}/revenue/config/",
            {"commission_rate": "8.50"},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        detail = self.client.get(f"/api/commerce/businesses/{self.business.pk}/revenue/")
        self.assertEqual(detail.json()["commission_history"][0]["rate"], "8.50")

    def test_settlement_onboarding_rejects_bad_iban(self):
        response = self.client.put(
            f"/api/commerce/businesses/{self.business.pk}/settlement/onboarding/",
            {"legal_name": "Owner", "iban": "IR123"},
            format="json",
        )
        self.assertEqual(response.status_code, 400)

    def test_settlement_onboarding_valid_iban_not_marked_verified(self):
        response = self.client.put(
            f"/api/commerce/businesses/{self.business.pk}/settlement/onboarding/",
            {"legal_name": "Owner", "iban": "IR062960000000100324200001"},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["iban_checksum_valid"])
        self.assertEqual(response.json()["provider_status"], "unconfigured")
        self.assertIsNone(response.json()["provider_verified_at"])

    def _activate_publication(self, business):
        product = SubscriptionProduct.objects.get(slug="basic")
        purchase = SubscriptionPurchase.objects.create(
            user=business.owner,
            business=business,
            product=product,
            price_toman=product.price_toman,
            status=SubscriptionPurchase.Status.PAID,
        )
        now = timezone.now()
        SubscriptionEntitlement.objects.create(
            user=business.owner,
            business=business,
            entitlement_type=SubscriptionEntitlement.Type.MENU,
            product=product,
            purchase=purchase,
            starts_at=now - timedelta(days=1),
            ends_at=now + timedelta(days=10),
            status=SubscriptionEntitlement.Status.ACTIVE,
        )

    def test_public_store_directory_requires_active_subscription(self):
        response = APIClient().get("/api/commerce/public/stores/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["results"], [])
        self._activate_publication(self.business)
        response = APIClient().get("/api/commerce/public/stores/")
        self.assertEqual(response.status_code, 200)
        rows = response.json()["results"]
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["menu_slug"], "api-store-menu")
        self.assertNotIn("owner", rows[0])
        self.assertNotIn("config", rows[0])
        self.assertEqual(rows[0]["products_count"], 1)

    def test_quote_returns_server_totals_without_creating_order(self):
        client = APIClient()
        client.force_authenticate(self.customer)
        response = client.post(
            "/api/commerce/orders/quote/",
            {
                "business_id": self.business.pk,
                "items": [{"product_id": self.product.id, "quantity": 2}],
                "mode": "delivery",
            },
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        body = response.json()
        self.assertEqual(body["subtotal_toman"], 400000)
        self.assertEqual(body["total_toman"], 400000)
        self.assertEqual(body["items"][0]["unit_price_toman"], 200000)
        self.assertFalse(Order.objects.exists())

    def test_quote_merges_duplicate_product_lines(self):
        client = APIClient()
        client.force_authenticate(self.customer)
        response = client.post(
            "/api/commerce/orders/quote/",
            {
                "business_id": self.business.pk,
                "items": [
                    {"product_id": self.product.id, "quantity": 1},
                    {"product_id": self.product.id, "quantity": 2},
                ],
                "mode": "pickup",
            },
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.json()["items"]), 1)
        self.assertEqual(response.json()["items"][0]["quantity"], 3)
        self.assertEqual(response.json()["subtotal_toman"], 600000)

    def test_quote_ignores_client_prices_and_rejects_unavailable_product(self):
        client = APIClient()
        client.force_authenticate(self.customer)
        self.product.is_available = False
        self.product.save(update_fields=["is_available"])
        response = client.post(
            "/api/commerce/orders/quote/",
            {
                "business_id": self.business.pk,
                "items": [{"product_id": self.product.id, "quantity": 1, "unit_price_toman": 1}],
                "mode": "pickup",
            },
            format="json",
        )
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json()["code"], "product_unavailable")

    @override_settings(COMMERCE_ORDER_ONLINE_PAYMENTS_ENABLED=False)
    def test_online_order_rejected_when_provider_flow_is_disabled(self):
        client = APIClient()
        client.force_authenticate(self.customer)
        response = client.post(
            "/api/commerce/orders/",
            {
                "business_id": self.business.pk,
                "items": [{"product_id": self.product.id, "quantity": 1}],
                "mode": "pickup",
                "payment_method": "online",
            },
            format="json",
        )
        self.assertEqual(response.status_code, 503)
        self.assertEqual(response.json()["code"], "online_payment_unavailable")
        self.assertFalse(Order.objects.exists())

    def test_quote_requires_authentication(self):
        response = APIClient().post(
            "/api/commerce/orders/quote/",
            {"business_id": self.business.pk, "items": [{"product_id": self.product.id}]},
            format="json",
        )
        self.assertEqual(response.status_code, 401)

    def test_public_club_list_hides_private_fields(self):
        response = APIClient().get("/api/commerce/public/club/stores/")
        self.assertEqual(response.status_code, 200)
        row = response.json()["results"][0]
        self.assertEqual(set(row.keys()), {"id", "name", "slug", "description", "logo", "offer"})

    def test_cross_store_order_access_denied(self):
        client = APIClient()
        client.force_authenticate(self.customer)
        create = client.post(
            "/api/commerce/orders/",
            {
                "business_id": self.business.pk,
                "items": [{"product_id": self.product.id, "quantity": 1}],
                "mode": "delivery",
                "address_text": "Jam",
            },
            format="json",
        )
        self.assertEqual(create.status_code, 201)
        number = create.json()["order"]["number"]
        stranger = APIClient()
        stranger.force_authenticate(self.other)
        response = stranger.get(f"/api/commerce/orders/{number}/")
        self.assertEqual(response.status_code, 404)

    def test_order_item_price_comes_from_database(self):
        client = APIClient()
        client.force_authenticate(self.customer)
        response = client.post(
            "/api/commerce/orders/",
            {
                "business_id": self.business.pk,
                "items": [{"product_id": self.product.id, "quantity": 3, "unit_price": 1}],
                "mode": "pickup",
            },
            format="json",
        )
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json()["order"]["subtotal_toman"], 600000)

    def test_inactive_product_cannot_be_ordered(self):
        self.product.is_available = False
        self.product.save()
        client = APIClient()
        client.force_authenticate(self.customer)
        response = client.post(
            "/api/commerce/orders/",
            {"business_id": self.business.pk, "items": [{"product_id": self.product.id}], "mode": "pickup"},
            format="json",
        )
        self.assertEqual(response.status_code, 409)

    def test_seller_confirm_code_endpoint(self):
        code, raw = services.issue_purchase_code(self.business, self.customer)
        validate = self.client.post(
            f"/api/commerce/businesses/{self.business.pk}/purchase-codes/validate/",
            {"code": raw}, format="json",
        )
        self.assertEqual(validate.status_code, 200)
        self.assertEqual(validate.json()["state"], "valid")
        confirm = self.client.post(
            f"/api/commerce/businesses/{self.business.pk}/purchase-codes/confirm/",
            {"code": raw}, format="json",
        )
        self.assertEqual(confirm.status_code, 201)
        repeat = self.client.post(
            f"/api/commerce/businesses/{self.business.pk}/purchase-codes/confirm/",
            {"code": raw}, format="json",
        )
        self.assertEqual(repeat.status_code, 200)
        self.assertTrue(repeat.json()["already_confirmed"])

    def test_other_seller_cannot_confirm_own_store_code(self):
        code, raw = services.issue_purchase_code(self.business, self.customer)
        client = APIClient()
        client.force_authenticate(self.other)
        response = client.post(
            f"/api/commerce/businesses/{self.business.pk}/purchase-codes/confirm/",
            {"code": raw}, format="json",
        )
        self.assertEqual(response.status_code, 404)

    def test_metrics_scoped_to_owned_store(self):
        services.record_visit(self.business, self.customer)
        response = self.client.get(f"/api/commerce/businesses/{self.business.pk}/metrics/")
        self.assertEqual(response.json()["visits"], 1)
        forbidden = self.client.get(f"/api/commerce/businesses/{self.other_business.pk}/metrics/")
        self.assertEqual(forbidden.status_code, 404)
