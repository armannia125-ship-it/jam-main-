from django.urls import path

from . import views

app_name = "commerce"

urlpatterns = [
    # Seller store list / public club directory
    path("businesses/", views.OwnedBusinessListView.as_view(), name="owned-businesses"),
    path("public/club/stores/", views.PublicClubStoresView.as_view(), name="public-club-stores"),
    path("public/stores/", views.PublicStoreDirectoryView.as_view(), name="public-stores"),

    # Revenue
    path("businesses/<int:business_id>/revenue/", views.RevenueView.as_view(), name="revenue"),
    path("businesses/<int:business_id>/revenue/config/", views.RevenueConfigView.as_view(), name="revenue-config"),
    path("businesses/<int:business_id>/invoices/", views.InvoiceListView.as_view(), name="invoices"),
    path("businesses/<int:business_id>/campaigns/", views.CampaignListView.as_view(), name="campaigns"),
    path(
        "businesses/<int:business_id>/campaigns/<int:campaign_id>/toggle/",
        views.CampaignToggleView.as_view(),
        name="campaign-toggle",
    ),
    path("businesses/<int:business_id>/ads/", views.AdListView.as_view(), name="ads"),
    path("businesses/<int:business_id>/ads/<int:ad_id>/toggle/", views.AdToggleView.as_view(), name="ad-toggle"),
    path("businesses/<int:business_id>/launch/", views.LaunchView.as_view(), name="launch"),

    # Club
    path("businesses/<int:business_id>/club/", views.ClubView.as_view(), name="club"),
    path("businesses/<int:business_id>/club/terms/", views.ClubAcceptTermsView.as_view(), name="club-terms"),
    path("businesses/<int:business_id>/club/offer/", views.ClubOfferView.as_view(), name="club-offer"),

    # Metrics and settlement
    path("businesses/<int:business_id>/metrics/", views.MetricsView.as_view(), name="metrics"),
    path("businesses/<int:business_id>/settlement/", views.SettlementView.as_view(), name="settlement"),
    path(
        "businesses/<int:business_id>/settlement/onboarding/",
        views.SettlementAccountView.as_view(),
        name="settlement-onboarding",
    ),
    path(
        "businesses/<int:business_id>/settlement/ledger/<int:entry_id>/reverse/",
        views.SettlementReverseView.as_view(),
        name="settlement-reverse",
    ),

    # Agreements
    path("businesses/<int:business_id>/agreements/", views.AgreementsView.as_view(), name="agreements"),
    path(
        "businesses/<int:business_id>/agreements/accept/",
        views.AgreementAcceptView.as_view(),
        name="agreement-accept",
    ),

    # Orders
    path("orders/", views.OrderCreateView.as_view(), name="order-create"),
    path("orders/quote/", views.OrderQuoteView.as_view(), name="order-quote"),
    path("orders/mine/", views.MyOrdersView.as_view(), name="my-orders"),
    path("orders/<str:number>/", views.OrderDetailView.as_view(), name="order-detail"),
    path("businesses/<int:business_id>/orders/", views.BusinessOrdersView.as_view(), name="business-orders"),
    path(
        "businesses/<int:business_id>/orders/<str:number>/status/",
        views.OrderStatusView.as_view(),
        name="order-status",
    ),
    path(
        "businesses/<int:business_id>/orders/<str:number>/simulate-payment/",
        views.OrderSimulatePaymentView.as_view(),
        name="order-simulate-payment",
    ),

    # Customer visit / purchase codes
    path("club/businesses/<int:business_id>/visit/", views.VisitCreateView.as_view(), name="visit"),
    path("club/businesses/<int:business_id>/codes/", views.CustomerCodeView.as_view(), name="customer-codes"),
    path("club/purchases/mine/", views.MyPurchasesView.as_view(), name="my-purchases"),

    # Seller in-person operations
    path(
        "businesses/<int:business_id>/purchase-codes/validate/",
        views.SellerValidateCodeView.as_view(),
        name="purchase-code-validate",
    ),
    path(
        "businesses/<int:business_id>/purchase-codes/confirm/",
        views.SellerConfirmCodeView.as_view(),
        name="purchase-code-confirm",
    ),
    path(
        "businesses/<int:business_id>/purchases/",
        views.SellerPurchaseListView.as_view(),
        name="seller-purchases",
    ),
    path(
        "businesses/<int:business_id>/purchases/<int:purchase_id>/revoke/",
        views.SellerRevokePurchaseView.as_view(),
        name="seller-purchase-revoke",
    ),
]
