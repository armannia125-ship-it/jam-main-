"""REST endpoints for revenue, club, visits, in-person purchases, metrics,
settlement and orders.

Every seller endpoint resolves the business through ``owner=request.user`` so
cross-store access simply 404s. Customer endpoints never expose other
customers' records.
"""

from datetime import date, timedelta

from django.conf import settings
from django.db import transaction
from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework import status
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView

from businesses.models import Business

from . import services
from .models import (
    AgreementAcceptance,
    AgreementVersion,
    Campaign,
    ClubOffer,
    InPersonPurchase,
    Invoice,
    Order,
    PurchaseCode,
    SettlementAccount,
    SettlementEntry,
    StoreConfig,
)
from .serializers import (
    AcceptAgreementSerializer,
    AcceptanceSerializer,
    AdCreateSerializer,
    AdSerializer,
    AgreementVersionSerializer,
    CampaignCreateSerializer,
    CampaignSerializer,
    ClubOfferSerializer,
    CodeLookupSerializer,
    ConfigUpdateSerializer,
    InPersonPurchaseSerializer,
    InvoiceCreateSerializer,
    InvoiceSerializer,
    IssueCodeSerializer,
    LaunchSerializer,
    OfferUpdateSerializer,
    OrderCreateSerializer,
    OrderQuoteSerializer,
    PurchaseCodeSerializer,
    SettlementAccountInputSerializer,
    SettlementAccountSerializer,
    SettlementEntrySerializer,
    StoreConfigSerializer,
    order_payload,
)


def _club_status(business):
    """Compatibility payload for the seller panel, derived from CLUB entitlements."""
    from subscriptions.entitlements import current_entitlements
    from subscriptions.models import SubscriptionEntitlement

    entitlement = current_entitlements(
        business, SubscriptionEntitlement.Type.CLUB
    ).order_by("-ends_at").first()
    acceptance = services.latest_acceptance(business, AgreementVersion.Kind.CLUB)
    return {
        "status": "active" if entitlement else "inactive",
        "is_active": bool(entitlement),
        "trial_used": False,
        "trial_started_at": None,
        "trial_ends_at": None,
        "starts_at": entitlement.starts_at if entitlement else None,
        "ends_at": entitlement.ends_at if entitlement else None,
        "terms_version": acceptance.version.version if acceptance else None,
    }


class CommerceBaseView(APIView):
    def handle_error(self, exc):
        return Response({"detail": exc.detail, "code": exc.code}, status=exc.status_code)

    def owned_business(self, request, business_id):
        return get_object_or_404(Business, pk=business_id, owner=request.user)


def _parse_date(value):
    if not value:
        return None
    try:
        return date.fromisoformat(value)
    except ValueError:
        return None


class OwnedBusinessListView(CommerceBaseView):
    """Seller's businesses with club/revenue state."""

    def get(self, request):
        businesses = Business.objects.filter(owner=request.user).order_by("name")
        data = []
        for business in businesses:
            config = services.config_for(business)
            offer = getattr(business, "club_offer", None)
            data.append({
                "id": business.pk,
                "name": business.name,
                "slug": business.slug,
                "description": business.description,
                "logo": request.build_absolute_uri(business.logo.url) if business.logo else None,
                "club": {
                    **_club_status(business),
                    "offer": offer.text if offer else "",
                },
                "config": StoreConfigSerializer(config).data,
            })
        return Response({"results": data})


class PublicClubStoresView(CommerceBaseView):
    permission_classes = [AllowAny]
    authentication_classes = []

    def get(self, request):
        return Response({"results": services.public_club_stores()})


class PublicStoreDirectoryView(CommerceBaseView):
    """Public catalog directory used by the production storefront."""

    permission_classes = [AllowAny]
    authentication_classes = []

    def get(self, request):
        return Response({"results": services.public_store_directory()})


class RevenueView(CommerceBaseView):
    def get(self, request, business_id):
        business = self.owned_business(request, business_id)
        config = services.config_for(business)
        invoices = Invoice.objects.filter(business=business).order_by("-created_at", "-id")
        campaigns = Campaign.objects.filter(business=business).order_by("-created_at", "-id")
        launch = services.launch_config_for(business)
        ad_rows = business.ads.all().order_by("-created_at", "-id")
        return Response({
            "business": {"id": business.pk, "name": business.name, "slug": business.slug},
            "config": StoreConfigSerializer(config).data,
            "summary": services.revenue_summary(business),
            "invoices": InvoiceSerializer(invoices, many=True).data,
            "campaigns": CampaignSerializer(campaigns, many=True).data,
            "ads": AdSerializer(ad_rows, many=True).data,
            "launch": {"area": launch.area, "category": launch.category},
            "commission_history": [
                {
                    "id": change.id,
                    "rate": str(change.rate),
                    "basis": change.basis,
                    "note": change.note,
                    "created_at": change.created_at,
                }
                for change in business.commission_changes.all()[:50]
            ],
        })


class RevenueConfigView(CommerceBaseView):
    def patch(self, request, business_id):
        business = self.owned_business(request, business_id)
        serializer = ConfigUpdateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            config = services.update_config(
                business, changed_by=request.user, **serializer.validated_data
            )
        except services.CommerceError as exc:
            return self.handle_error(exc)
        return Response(StoreConfigSerializer(config).data)

    def put(self, request, business_id):
        return self.patch(request, business_id)


class InvoiceListView(CommerceBaseView):
    def get(self, request, business_id):
        business = self.owned_business(request, business_id)
        rows = Invoice.objects.filter(business=business).order_by("-created_at", "-id")
        return Response({"results": InvoiceSerializer(rows, many=True).data})

    def post(self, request, business_id):
        business = self.owned_business(request, business_id)
        serializer = InvoiceCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        acceptance = None
        if data.get("terms_acceptance_id"):
            acceptance = AgreementAcceptance.objects.filter(
                pk=data["terms_acceptance_id"], business=business, user=request.user
            ).first()
            if acceptance is None:
                return Response({"detail": "Acceptance not found.", "code": "acceptance_not_found"}, status=404)
        invoice = services.create_invoice(
            business, request.user,
            kind=data["kind"], title=data["title"], amount_toman=data["amount_toman"],
            terms_acceptance=acceptance,
        )
        return Response(InvoiceSerializer(invoice).data, status=status.HTTP_201_CREATED)


class CampaignListView(CommerceBaseView):
    def get(self, request, business_id):
        business = self.owned_business(request, business_id)
        rows = Campaign.objects.filter(business=business)
        return Response({"results": CampaignSerializer(rows, many=True).data})

    def post(self, request, business_id):
        business = self.owned_business(request, business_id)
        serializer = CampaignCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            campaign = services.create_campaign(business, serializer.validated_data)
        except services.CommerceError as exc:
            return self.handle_error(exc)
        return Response(CampaignSerializer(campaign).data, status=status.HTTP_201_CREATED)


class CampaignToggleView(CommerceBaseView):
    def post(self, request, business_id, campaign_id):
        business = self.owned_business(request, business_id)
        campaign = get_object_or_404(Campaign, pk=campaign_id, business=business)
        with transaction.atomic():
            campaign = Campaign.objects.select_for_update().get(pk=campaign.pk)
            if not campaign.is_active:
                campaign.is_active = True
                campaign.is_funded = True
                campaign.starts_at = timezone.now()
                campaign.ends_at = timezone.now() + timedelta(days=campaign.days)
            else:
                campaign.is_active = False
            campaign.save()
        return Response(CampaignSerializer(campaign).data)


class AdListView(CommerceBaseView):
    def get(self, request, business_id):
        business = self.owned_business(request, business_id)
        return Response({"results": AdSerializer(business.ads.all(), many=True).data})

    def post(self, request, business_id):
        business = self.owned_business(request, business_id)
        serializer = AdCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            ad = services.create_ad(business, serializer.validated_data)
        except services.CommerceError as exc:
            return self.handle_error(exc)
        return Response(AdSerializer(ad).data, status=status.HTTP_201_CREATED)


class AdToggleView(CommerceBaseView):
    def post(self, request, business_id, ad_id):
        business = self.owned_business(request, business_id)
        ad = get_object_or_404(business.ads, pk=ad_id)
        ad.is_active = not ad.is_active
        ad.ends_at = timezone.now() + timedelta(days=ad.days) if ad.is_active else ad.ends_at
        ad.save(update_fields=["is_active", "ends_at"])
        return Response(AdSerializer(ad).data)


class LaunchView(CommerceBaseView):
    def get(self, request, business_id):
        business = self.owned_business(request, business_id)
        launch = services.launch_config_for(business)
        return Response({"area": launch.area, "category": launch.category})

    def patch(self, request, business_id):
        business = self.owned_business(request, business_id)
        serializer = LaunchSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        launch = services.launch_config_for(business)
        launch.area = serializer.validated_data["area"].strip()[:80]
        launch.category = serializer.validated_data["category"].strip()[:40]
        launch.save()
        return Response({"area": launch.area, "category": launch.category})


class ClubView(CommerceBaseView):
    def get(self, request, business_id):
        business = self.owned_business(request, business_id)
        version = services.current_agreement(AgreementVersion.Kind.CLUB)
        if version is None:
            version = services.agreement_body(business, AgreementVersion.Kind.CLUB)
        offer = getattr(business, "club_offer", None)
        acceptance = services.latest_acceptance(business, AgreementVersion.Kind.CLUB)
        return Response({
            "membership": _club_status(business),
            "terms": AgreementVersionSerializer(version).data,
            "offer": ClubOfferSerializer(offer).data if offer else {"text": "", "is_active": True, "updated_at": None},
            "acceptance": AcceptanceSerializer(acceptance).data if acceptance else None,
            "trial_days": 0,
        })


class ClubAcceptTermsView(CommerceBaseView):
    def post(self, request, business_id):
        business = self.owned_business(request, business_id)
        serializer = AcceptAgreementSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        try:
            acceptance = services.accept_agreement(
                business, request.user, data["kind"], data["accepted_name"],
                version_id=data.get("version_id"),
            )
        except services.CommerceError as exc:
            return self.handle_error(exc)
        return Response(AcceptanceSerializer(acceptance).data, status=status.HTTP_201_CREATED)


class ClubOfferView(CommerceBaseView):
    def put(self, request, business_id):
        business = self.owned_business(request, business_id)
        serializer = OfferUpdateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        offer, _ = ClubOffer.objects.update_or_create(
            business=business,
            defaults={
                "text": serializer.validated_data["text"].strip()[:150],
                "is_active": serializer.validated_data["is_active"],
            },
        )
        return Response(ClubOfferSerializer(offer).data)


class MetricsView(CommerceBaseView):
    def get(self, request, business_id):
        business = self.owned_business(request, business_id)
        start_raw = request.query_params.get("start")
        end_raw = request.query_params.get("end")
        start, end = _parse_date(start_raw), _parse_date(end_raw)
        if (start_raw and not start) or (end_raw and not end):
            return Response({"detail": "Dates must be YYYY-MM-DD.", "code": "invalid_date"}, status=400)
        if start and end and start > end:
            return Response({"detail": "start must be before end.", "code": "invalid_range"}, status=400)
        return Response(services.club_metrics(business, start=start, end=end))


class SettlementView(CommerceBaseView):
    def get(self, request, business_id):
        business = self.owned_business(request, business_id)
        account = getattr(business, "settlement_account", None)
        entries = SettlementEntry.objects.filter(business=business).select_related("order").prefetch_related("reversals")
        seller_acceptance = services.latest_acceptance(business, AgreementVersion.Kind.SELLER)
        return Response({
            "account": SettlementAccountSerializer(account).data if account else None,
            "ledger": SettlementEntrySerializer(entries, many=True).data,
            "seller_agreement_accepted": bool(seller_acceptance),
            "real_settlement_available": False,
            "detail": "No payout provider is connected. Statuses are internal records only.",
        })


class SettlementAccountView(CommerceBaseView):
    def put(self, request, business_id):
        business = self.owned_business(request, business_id)
        serializer = SettlementAccountInputSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            account = services.save_settlement_account(
                business, serializer.validated_data["legal_name"], serializer.validated_data["iban"]
            )
        except services.CommerceError as exc:
            return self.handle_error(exc)
        return Response(SettlementAccountSerializer(account).data)


class SettlementReverseView(CommerceBaseView):
    def post(self, request, business_id, entry_id):
        business = self.owned_business(request, business_id)
        entry = get_object_or_404(SettlementEntry, pk=entry_id, business=business)
        reason = (request.data.get("reason") or "Manual reversal request").strip()[:200]
        with transaction.atomic():
            entry = SettlementEntry.objects.select_for_update().select_related("order").get(pk=entry.pk)
            order = entry.order
            if order.status == Order.Status.DONE and order.payment_state == Order.PaymentState.PAID:
                try:
                    services.transition_order(order, Order.Status.REFUNDED, request.user)
                except services.CommerceError as exc:
                    return self.handle_error(exc)
            else:
                return Response(
                    {"detail": "Only a delivered, paid order can be reversed.", "code": "not_reversible"},
                    status=409,
                )
        entry.refresh_from_db()
        return Response(SettlementEntrySerializer(entry).data)


class AgreementsView(CommerceBaseView):
    def get(self, request, business_id):
        business = self.owned_business(request, business_id)
        kind = request.query_params.get("kind")
        versions = AgreementVersion.objects.filter(effective_at__lte=timezone.now())
        acceptances = AgreementAcceptance.objects.filter(business=business)
        if kind:
            versions = versions.filter(kind=kind)
            acceptances = acceptances.filter(kind=kind)
        return Response({
            "versions": AgreementVersionSerializer(versions, many=True).data,
            "acceptances": AcceptanceSerializer(acceptances, many=True).data,
        })


class AgreementAcceptView(CommerceBaseView):
    def post(self, request, business_id):
        business = self.owned_business(request, business_id)
        serializer = AcceptAgreementSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        try:
            acceptance = services.accept_agreement(
                business, request.user, data["kind"], data["accepted_name"], version_id=data.get("version_id")
            )
        except services.CommerceError as exc:
            return self.handle_error(exc)
        return Response(AcceptanceSerializer(acceptance).data, status=status.HTTP_201_CREATED)


# ---------------------------------------------------------------------------
# Orders
# ---------------------------------------------------------------------------

class OrderQuoteView(CommerceBaseView):
    """Authoritative cart preview before order creation."""

    def post(self, request):
        serializer = OrderQuoteSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        business = Business.objects.filter(pk=data["business_id"], owner__is_active=True).first()
        if business is None:
            return Response({"detail": "Store not found.", "code": "business_not_found"}, status=404)
        items = [
            {"product_id": item["product_id"], "quantity": item["quantity"]}
            for item in data["items"]
        ]
        try:
            quote = services.quote_order(business=business, items=items, mode=data["mode"])
        except services.CommerceError as exc:
            return self.handle_error(exc)
        return Response(quote)


class OrderCreateView(CommerceBaseView):
    def post(self, request):
        serializer = OrderCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        business = Business.objects.filter(pk=data["business_id"], owner__is_active=True).first()
        if business is None:
            return Response({"detail": "Store not found.", "code": "business_not_found"}, status=404)
        items = [
            {"product_id": item["product_id"], "quantity": item["quantity"]}
            for item in data["items"]
        ]
        try:
            order, created = services.create_order(
                business=business,
                customer=request.user,
                items=items,
                mode=data["mode"],
                payment_method=data["payment_method"],
                customer_name=data.get("customer_name", ""),
                customer_phone=data.get("customer_phone", ""),
                address_text=data.get("address_text", ""),
                note=data.get("note", ""),
                preferred_time=data.get("preferred_time", ""),
                idempotency_key=data.get("idempotency_key", ""),
            )
        except services.CommerceError as exc:
            return self.handle_error(exc)
        return Response(
            {"created": created, "order": order_payload(order)},
            status=status.HTTP_201_CREATED if created else status.HTTP_200_OK,
        )


class MyOrdersView(CommerceBaseView):
    def get(self, request):
        orders = Order.objects.filter(customer=request.user).select_related("business").prefetch_related(
            "items", "status_events"
        )
        return Response({"results": [order_payload(o) for o in orders]})


class OrderDetailView(CommerceBaseView):
    def get(self, request, number):
        order = Order.objects.select_related("business", "customer").prefetch_related(
            "items", "status_events"
        ).filter(number=number).first()
        if order is None:
            return Response({"detail": "Order not found.", "code": "order_not_found"}, status=404)
        if order.customer_id != request.user.id and order.business.owner_id != request.user.id:
            return Response({"detail": "Order not found.", "code": "order_not_found"}, status=404)
        return Response(order_payload(order, include_customer=order.business.owner_id == request.user.id))


class BusinessOrdersView(CommerceBaseView):
    def get(self, request, business_id):
        business = self.owned_business(request, business_id)
        orders = Order.objects.filter(business=business).select_related("business", "customer").prefetch_related(
            "items", "status_events"
        )
        return Response({"results": [order_payload(o, include_customer=True) for o in orders]})


class OrderStatusView(CommerceBaseView):
    def post(self, request, business_id, number):
        business = self.owned_business(request, business_id)
        order = get_object_or_404(Order, number=number, business=business)
        new_status = (request.data.get("status") or "").strip()
        try:
            order, changed = services.transition_order(order, new_status, request.user)
        except services.CommerceError as exc:
            return self.handle_error(exc)
        return Response({"changed": changed, "order": order_payload(order, include_customer=True)})


class OrderSimulatePaymentView(CommerceBaseView):
    """Seller-only explicit simulation; never a provider confirmation."""

    def post(self, request, business_id, number):
        business = self.owned_business(request, business_id)
        order = get_object_or_404(Order, number=number, business=business)
        if not getattr(settings, "COMMERCE_ALLOW_SIMULATED_PAYMENTS", False):
            return Response(
                {"detail": "Simulated payments are disabled.", "code": "payments_disabled"}, status=503
            )
        try:
            order, changed = services.mark_order_paid(order, request.user)
        except services.CommerceError as exc:
            return self.handle_error(exc)
        return Response({
            "changed": changed,
            "simulation": True,
            "detail": "Simulated payment only; no provider confirmation.",
            "order": order_payload(order, include_customer=True),
        })


# ---------------------------------------------------------------------------
# Customer visit / purchase codes
# ---------------------------------------------------------------------------

def _customer_business(business_id):
    return Business.objects.filter(pk=business_id, owner__is_active=True).first()


class VisitCreateView(CommerceBaseView):
    def post(self, request, business_id):
        business = _customer_business(business_id)
        if business is None:
            return Response({"detail": "Store not found.", "code": "business_not_found"}, status=404)
        from subscriptions.entitlements import club_access

        if not club_access(business):
            return Response({"detail": "Store is not an active club member.", "code": "club_inactive"}, status=409)
        visit, created = services.record_visit(business, request.user)
        return Response({
            "created": created,
            "visit": {"business_id": business.pk, "visited_on": visit.visited_on, "at": visit.created_at},
        }, status=status.HTTP_201_CREATED if created else status.HTTP_200_OK)


class CustomerCodeView(CommerceBaseView):
    def get(self, request, business_id):
        business = _customer_business(business_id)
        if business is None:
            return Response({"detail": "Store not found.", "code": "business_not_found"}, status=404)
        code = PurchaseCode.objects.filter(
            business=business, customer=request.user, status=PurchaseCode.Status.ISSUED,
            expires_at__gt=timezone.now(),
        ).first()
        if code is None:
            return Response({"code": None})
        # Raw code is never persisted; only metadata is returned here.
        return Response({"code": PurchaseCodeSerializer().to_representation(code)})

    def post(self, request, business_id):
        business = _customer_business(business_id)
        if business is None:
            return Response({"detail": "Store not found.", "code": "business_not_found"}, status=404)
        try:
            code, raw = services.issue_purchase_code(business, request.user)
        except services.CommerceError as exc:
            return self.handle_error(exc)
        return Response({
            "code": raw,
            "id": code.pk,
            "issued_at": code.issued_at,
            "expires_at": code.expires_at,
            "ttl_seconds": services.CODE_TTL_SECONDS,
            "store": {"id": business.pk, "name": business.name},
        }, status=status.HTTP_201_CREATED)


class MyPurchasesView(CommerceBaseView):
    def get(self, request):
        purchases = InPersonPurchase.objects.filter(customer=request.user).select_related(
            "business", "code", "customer"
        )
        return Response({
            "results": [
                {
                    **InPersonPurchaseSerializer().to_representation(p),
                    "business_id": p.business_id,
                    "business_name": p.business.name,
                }
                for p in purchases
            ]
        })


# ---------------------------------------------------------------------------
# Seller in-person operations
# ---------------------------------------------------------------------------

class SellerValidateCodeView(CommerceBaseView):
    def post(self, request, business_id):
        business = self.owned_business(request, business_id)
        serializer = CodeLookupSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            code, state = services.validate_purchase_code(business, serializer.validated_data["code"])
        except services.CommerceError as exc:
            return self.handle_error(exc)
        return Response({
            "state": state["state"],
            "code_hint": code.code_hint,
            "issued_at": code.issued_at,
            "expires_at": code.expires_at,
            "customer_label": services._masked_customer(code.customer),
            "already_confirmed": code.status == PurchaseCode.Status.CONFIRMED,
        })


class SellerConfirmCodeView(CommerceBaseView):
    def post(self, request, business_id):
        business = self.owned_business(request, business_id)
        serializer = CodeLookupSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            purchase, created, already = services.confirm_purchase_code(
                business, serializer.validated_data["code"], request.user
            )
        except services.CommerceError as exc:
            return self.handle_error(exc)
        return Response({
            "created": created,
            "already_confirmed": already,
            "purchase": InPersonPurchaseSerializer().to_representation(purchase),
        }, status=status.HTTP_201_CREATED if created and not already else status.HTTP_200_OK)


class SellerPurchaseListView(CommerceBaseView):
    def get(self, request, business_id):
        business = self.owned_business(request, business_id)
        purchases = InPersonPurchase.objects.filter(business=business).select_related(
            "customer", "code"
        ).order_by("-confirmed_at", "-id")
        return Response({"results": [
            InPersonPurchaseSerializer().to_representation(p) for p in purchases
        ]})


class SellerRevokePurchaseView(CommerceBaseView):
    def post(self, request, business_id, purchase_id):
        business = self.owned_business(request, business_id)
        purchase = get_object_or_404(InPersonPurchase, pk=purchase_id, business=business)
        purchase, changed = services.revoke_purchase(purchase, request.user)
        return Response({
            "changed": changed,
            "purchase": InPersonPurchaseSerializer().to_representation(purchase),
        })
