from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("commerce", "0003_remove_order_unique_order_idempotency_per_business_and_more"),
    ]

    operations = [
        migrations.DeleteModel(name="ClubMembershipEvent"),
        migrations.DeleteModel(name="ClubMembership"),
    ]
