from django.db import migrations


SELLER_BODY = (
    "شرایط همکاری فروشنده: کمیسیون فقط از بهای کالا پس از تخفیف محاسبه می‌شود و هزینهٔ ارسال "
    "مشمول کمیسیون نیست. نرخ هر سفارش هنگام ثبت ثابت می‌ماند و تغییر نرخ، سفارش‌های قبلی را "
    "تغییر نمی‌دهد. تسویه بدون اتصال ارائه‌دهندهٔ پرداخت انجام نمی‌شود. این متن نمونه است و پیش از "
    "عرضه باید بررسی حقوقی شود."
)

CLUB_BODY = (
    "باشگاه مشتریان حضوری جم لایف: کد خرید یک‌بارمصرف و کوتاه‌عمر است و فقط پس از تأیید فروشنده "
    "به خرید ثبت‌شده تبدیل می‌شود. اسکن یا صدور کد به‌تنهایی خرید نیست. هر مشتری در هر فروشگاه "
    "حداکثر یک خرید پاداش‌دار در روز دارد. اشتراک فروشنده پولی است ولی مشتری برای دریافت کد "
    "نیازی به اشتراک ندارد. این متن نمونه است و پیش از عرضه باید بررسی حقوقی شود."
)


def seed(apps, schema_editor):
    AgreementVersion = apps.get_model("commerce", "AgreementVersion")
    AgreementVersion.objects.get_or_create(
        kind="seller", version="JL-2026-01", defaults={"body": SELLER_BODY}
    )
    AgreementVersion.objects.get_or_create(
        kind="club", version="JL-2026-01", defaults={"body": CLUB_BODY}
    )


def unseed(apps, schema_editor):
    AgreementVersion = apps.get_model("commerce", "AgreementVersion")
    AgreementVersion.objects.filter(version="JL-2026-01", kind__in=["seller", "club"]).delete()


class Migration(migrations.Migration):
    dependencies = [("commerce", "0001_initial")]
    operations = [migrations.RunPython(seed, unseed)]
