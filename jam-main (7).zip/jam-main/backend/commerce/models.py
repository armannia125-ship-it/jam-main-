"""Commerce domain: revenue configuration, orders, club membership, visits,
one-time purchase codes, in-person purchases, settlement ledger and agreements.

Money is stored as integer Toman and percentages as Decimal. Commission is
always computed from the goods subtotal only; delivery is never commissioned.
"""

import secrets
from decimal import Decimal

from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.db.models import Q
from django.utils import timezone

from businesses.models import Business

MONEY_PLACES = 0
RATE_PLACES = 2


def new_order_number():
    """Human-readable, collision-resistant order number."""
    return "JM" + secrets.token_hex(4).upper()


class StoreConfig(models.Model):
    """Store-scoped pricing and commission configuration.

    Changing this record never rewrites commission already snapshotted on an
    order or in the commission ledger.
    """

    business = models.OneToOneField(Business, on_delete=models.CASCADE, related_name="store_config")
    commission_rate = models.DecimalField(
        max_digits=5,
        decimal_places=RATE_PLACES,
        default=Decimal("5.00"),
        validators=[MinValueValidator(Decimal("0")), MaxValueValidator(Decimal("30"))],
    )
    setup_fee_toman = models.PositiveBigIntegerField(default=500000)
    monthly_fee_toman = models.PositiveBigIntegerField(default=350000)
    delivery_fee_toman = models.PositiveBigIntegerField(default=0)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.business} config ({self.commission_rate}%)"


class CommissionRateChange(models.Model):
    """Append-only history of commission configuration changes."""

    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="commission_changes")
    rate = models.DecimalField(max_digits=5, decimal_places=RATE_PLACES)
    basis = models.CharField(max_length=32, default="goods_only")
    note = models.CharField(max_length=200, blank=True)
    changed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="commission_changes"
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        indexes = [models.Index(fields=["business", "-created_at"])]

    def __str__(self):
        return f"{self.business} {self.rate}% @ {self.created_at:%Y-%m-%d}"


class Order(models.Model):
    class Status(models.TextChoices):
        PLACED = "placed", "Placed"
        ACCEPTED = "accepted", "Accepted"
        PREPARING = "preparing", "Preparing"
        READY = "ready", "Ready for pickup"
        SENT = "sent", "Sent"
        DONE = "done", "Delivered"
        REJECTED = "rejected", "Rejected"
        CANCELED = "canceled", "Canceled"
        REFUNDED = "refunded", "Refunded"

    class Mode(models.TextChoices):
        DELIVERY = "delivery", "Delivery"
        PICKUP = "pickup", "Pickup"

    class PaymentMethod(models.TextChoices):
        ONLINE = "online", "Online"
        OFFLINE = "offline", "Pay in store"

    class PaymentState(models.TextChoices):
        PENDING = "pending", "Pending"
        PAID = "paid", "Paid"
        REFUNDED = "refunded", "Refunded"

    number = models.CharField(max_length=24, unique=True, default=new_order_number, editable=False)
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="orders")
    customer = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="orders"
    )
    mode = models.CharField(max_length=10, choices=Mode.choices, default=Mode.DELIVERY)
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.PLACED)
    payment_method = models.CharField(max_length=10, choices=PaymentMethod.choices, default=PaymentMethod.OFFLINE)
    payment_state = models.CharField(max_length=10, choices=PaymentState.choices, default=PaymentState.PENDING)
    subtotal_toman = models.PositiveBigIntegerField(default=0)
    discount_toman = models.PositiveBigIntegerField(default=0)
    delivery_fee_toman = models.PositiveBigIntegerField(default=0)
    total_toman = models.PositiveBigIntegerField(default=0)
    # Commission snapshot. Null until the order reaches its financial state.
    commission_rate = models.DecimalField(max_digits=5, decimal_places=RATE_PLACES, null=True, blank=True)
    commission_base_toman = models.PositiveBigIntegerField(null=True, blank=True)
    commission_amount_toman = models.PositiveBigIntegerField(null=True, blank=True)
    commission_locked_at = models.DateTimeField(null=True, blank=True)
    customer_name = models.CharField(max_length=120, blank=True)
    customer_phone = models.CharField(max_length=20, blank=True)
    address_text = models.TextField(blank=True)
    note = models.TextField(blank=True)
    preferred_time = models.CharField(max_length=80, blank=True)
    idempotency_key = models.CharField(max_length=64, blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        indexes = [
            models.Index(fields=["business", "-created_at"]),
            models.Index(fields=["customer", "-created_at"]),
            models.Index(fields=["business", "status"]),
        ]
        constraints = [
            models.UniqueConstraint(
                fields=["business", "customer", "idempotency_key"],
                condition=~Q(idempotency_key=""),
                name="unique_order_idempotency_per_customer",
            )
        ]

    def __str__(self):
        return f"{self.number} ({self.status})"

    @property
    def goods_total(self):
        """Amount commission is calculated on: goods after discount, excluding delivery."""
        return max(0, int(self.subtotal_toman) - int(self.discount_toman))


class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey(
        "businesses.Product", on_delete=models.SET_NULL, null=True, blank=True, related_name="order_items"
    )
    name = models.CharField(max_length=160)
    unit_price_toman = models.PositiveBigIntegerField()
    quantity = models.PositiveIntegerField(default=1, validators=[MinValueValidator(1), MaxValueValidator(99)])

    class Meta:
        constraints = [models.CheckConstraint(condition=Q(quantity__gte=1), name="order_item_quantity_gte_1")]

    @property
    def line_total_toman(self):
        return int(self.unit_price_toman) * int(self.quantity)

    def __str__(self):
        return f"{self.name} x{self.quantity}"


class OrderStatusEvent(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="status_events")
    status = models.CharField(max_length=12, choices=Order.Status.choices)
    actor = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="order_status_events"
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["created_at", "id"]


class CommissionEntry(models.Model):
    """Immutable snapshot of the commission applied to one order."""

    order = models.OneToOneField(Order, on_delete=models.CASCADE, related_name="commission_entry")
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="commission_entries")
    rate = models.DecimalField(max_digits=5, decimal_places=RATE_PLACES)
    basis = models.CharField(max_length=32, default="goods_only")
    base_toman = models.PositiveBigIntegerField()
    amount_toman = models.PositiveBigIntegerField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        indexes = [models.Index(fields=["business", "-created_at"])]


class SettlementAccount(models.Model):
    """Seller-supplied settlement details. Never implies bank verification."""

    class ProviderStatus(models.TextChoices):
        UNCONFIGURED = "unconfigured", "No provider connected"
        PENDING_REVIEW = "pending_review", "Awaiting provider review"
        VERIFIED = "verified", "Verified by provider"

    business = models.OneToOneField(Business, on_delete=models.CASCADE, related_name="settlement_account")
    legal_name = models.CharField(max_length=120)
    iban = models.CharField(max_length=26)
    iban_checksum_valid = models.BooleanField(default=False)
    provider_status = models.CharField(
        max_length=20, choices=ProviderStatus.choices, default=ProviderStatus.UNCONFIGURED
    )
    provider_verified_at = models.DateTimeField(null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.business} settlement account"


class SettlementEntry(models.Model):
    """Auditable split for one online order. Real payouts are not implemented."""

    class Status(models.TextChoices):
        PENDING_PAYMENT = "pending_payment", "Pending payment"
        AWAITING_DELIVERY = "awaiting_delivery", "Awaiting delivery"
        AWAITING_ONBOARDING = "awaiting_onboarding", "Awaiting onboarding"
        ELIGIBLE = "eligible", "Eligible (not paid)"
        REVERSED = "reversed", "Reversed"
        FAILED = "failed", "Failed"

    order = models.OneToOneField(Order, on_delete=models.CASCADE, related_name="settlement_entry")
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="settlement_entries")
    goods_toman = models.PositiveBigIntegerField()
    delivery_toman = models.PositiveBigIntegerField(default=0)
    gross_toman = models.PositiveBigIntegerField()
    commission_toman = models.PositiveBigIntegerField()
    net_payable_toman = models.PositiveBigIntegerField()
    rate = models.DecimalField(max_digits=5, decimal_places=RATE_PLACES)
    status = models.CharField(max_length=24, choices=Status.choices, default=Status.PENDING_PAYMENT)
    paid_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        indexes = [models.Index(fields=["business", "status"])]


class SettlementReversal(models.Model):
    """Refund/reversal record; historical settlement rows are never edited away."""

    settlement = models.ForeignKey(SettlementEntry, on_delete=models.PROTECT, related_name="reversals")
    amount_toman = models.PositiveBigIntegerField()
    reason = models.CharField(max_length=200)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="settlement_reversals"
    )
    created_at = models.DateTimeField(auto_now_add=True)


class AgreementVersion(models.Model):
    """Versioned terms. Changing terms appends a new version; history is kept."""

    class Kind(models.TextChoices):
        SELLER = "seller", "Seller cooperation terms"
        CLUB = "club", "Club membership terms"

    kind = models.CharField(max_length=16, choices=Kind.choices)
    version = models.CharField(max_length=32)
    body = models.TextField()
    effective_at = models.DateTimeField(default=timezone.now)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-effective_at", "-id"]
        constraints = [
            models.UniqueConstraint(fields=["kind", "version"], name="unique_agreement_kind_version")
        ]

    def __str__(self):
        return f"{self.kind} {self.version}"


class AgreementAcceptance(models.Model):
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="agreement_acceptances")
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="agreement_acceptances"
    )
    kind = models.CharField(max_length=16, choices=AgreementVersion.Kind.choices)
    version = models.ForeignKey(AgreementVersion, on_delete=models.PROTECT, related_name="acceptances")
    accepted_name = models.CharField(max_length=120)
    rate_snapshot = models.DecimalField(max_digits=5, decimal_places=RATE_PLACES, null=True, blank=True)
    monthly_snapshot = models.PositiveBigIntegerField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        indexes = [models.Index(fields=["business", "kind", "-created_at"])]
        constraints = [
            models.UniqueConstraint(
                fields=["business", "kind", "version", "user"], name="unique_acceptance_per_version_user"
            )
        ]


class ClubOffer(models.Model):
    business = models.OneToOneField(Business, on_delete=models.CASCADE, related_name="club_offer")
    text = models.CharField(max_length=150, blank=True)
    is_active = models.BooleanField(default=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.business} offer"


class ClubVisit(models.Model):
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="club_visits")
    customer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="club_visits")
    visited_on = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        constraints = [
            models.UniqueConstraint(fields=["business", "customer", "visited_on"], name="unique_visit_per_day")
        ]
        indexes = [models.Index(fields=["business", "visited_on"])]


class PurchaseCode(models.Model):
    """Server-issued, one-time, store-scoped purchase code.

    Only a SHA-256 hash of the code is stored. The raw code is returned once to
    the customer and never persisted.
    """

    class Status(models.TextChoices):
        ISSUED = "issued", "Issued"
        CONFIRMED = "confirmed", "Confirmed"
        REVOKED = "revoked", "Revoked"
        EXPIRED = "expired", "Expired"

    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="purchase_codes")
    customer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="purchase_codes")
    code_hash = models.CharField(max_length=64, unique=True)
    code_hint = models.CharField(max_length=8)
    issued_on = models.DateField()
    issued_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.ISSUED)

    class Meta:
        ordering = ["-issued_at", "-id"]
        indexes = [
            models.Index(fields=["business", "customer", "-issued_at"]),
            models.Index(fields=["business", "status"]),
        ]

    def is_usable(self, moment=None):
        moment = moment or timezone.now()
        return self.status == self.Status.ISSUED and self.expires_at > moment


class InPersonPurchase(models.Model):
    class Status(models.TextChoices):
        CONFIRMED = "confirmed", "Confirmed"
        REVOKED = "revoked", "Revoked"

    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="in_person_purchases")
    customer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="in_person_purchases")
    code = models.OneToOneField(PurchaseCode, on_delete=models.PROTECT, related_name="purchase")
    confirmed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="confirmed_purchases"
    )
    confirmed_at = models.DateTimeField(auto_now_add=True)
    purchase_date = models.DateField()
    perk_snapshot = models.CharField(max_length=150, blank=True)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.CONFIRMED)
    revoked_at = models.DateTimeField(null=True, blank=True)
    revoked_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="revoked_purchases",
    )

    class Meta:
        ordering = ["-confirmed_at", "-id"]
        indexes = [models.Index(fields=["business", "purchase_date"])]
        constraints = [
            models.UniqueConstraint(
                fields=["business", "customer", "purchase_date"],
                condition=Q(status="confirmed"),
                name="one_confirmed_purchase_per_customer_day",
            )
        ]


class Campaign(models.Model):
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="campaigns")
    title = models.CharField(max_length=120)
    budget_toman = models.PositiveBigIntegerField()
    discount_pct = models.PositiveSmallIntegerField()
    cap_toman = models.PositiveBigIntegerField()
    min_purchase_toman = models.PositiveBigIntegerField()
    days = models.PositiveSmallIntegerField()
    seller_share_pct = models.PositiveSmallIntegerField(default=70)
    platform_share_pct = models.PositiveSmallIntegerField(default=20)
    brand_share_pct = models.PositiveSmallIntegerField(default=10)
    service_fee_toman = models.PositiveBigIntegerField(default=0)
    is_active = models.BooleanField(default=False)
    is_funded = models.BooleanField(default=False)
    starts_at = models.DateTimeField(null=True, blank=True)
    ends_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        indexes = [models.Index(fields=["business", "is_active"])]

    def __str__(self):
        return self.title


class AdCampaign(models.Model):
    class Placement(models.TextChoices):
        HOME = "home", "Home"
        MISSION = "mission", "Mission"

    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="ads")
    title = models.CharField(max_length=120)
    placement = models.CharField(max_length=10, choices=Placement.choices, default=Placement.HOME)
    budget_toman = models.PositiveBigIntegerField()
    days = models.PositiveSmallIntegerField()
    is_active = models.BooleanField(default=False)
    ends_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at", "-id"]


class Invoice(models.Model):
    class Kind(models.TextChoices):
        SETUP = "setup", "Setup"
        AD = "ad", "Advertising"
        CAMPAIGN = "campaign", "Campaign"

    class Status(models.TextChoices):
        PENDING = "pending", "Pending"
        SIMULATED_PAID = "simulated_paid", "Simulated payment only"
        PAID = "paid", "Paid (provider confirmed)"
        CANCELED = "canceled", "Canceled"

    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="invoices")
    kind = models.CharField(max_length=16, choices=Kind.choices, default=Kind.SETUP)
    title = models.CharField(max_length=160)
    amount_toman = models.PositiveBigIntegerField()
    status = models.CharField(max_length=16, choices=Status.choices, default=Status.PENDING)
    terms_acceptance = models.ForeignKey(
        AgreementAcceptance, on_delete=models.SET_NULL, null=True, blank=True, related_name="invoices"
    )
    provider_reference = models.CharField(max_length=120, blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)
    paid_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        indexes = [models.Index(fields=["business", "status"])]


class LaunchConfig(models.Model):
    business = models.OneToOneField(Business, on_delete=models.CASCADE, related_name="launch_config")
    area = models.CharField(max_length=80, blank=True)
    category = models.CharField(max_length=40, blank=True)
    updated_at = models.DateTimeField(auto_now=True)
