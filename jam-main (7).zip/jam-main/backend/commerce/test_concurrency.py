"""PostgreSQL-only concurrency checks.

These tests use real threads and separate database connections. They are
skipped on SQLite because SQLite serializes writers and cannot demonstrate
row-lock or unique-constraint behavior.
"""

import threading
import unittest
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.db import close_old_connections, connection
from django.test import TransactionTestCase
from django.utils import timezone

from . import services
from .models import (
    AgreementVersion,
    ClubVisit,
    InPersonPurchase,
    Order,
    OrderStatusEvent,
    PurchaseCode,
    StoreConfig,
)
from .tests import activate_club, make_store

User = get_user_model()


def _run_parallel(workers):
    barrier = threading.Barrier(len(workers))

    def wrapped(index):
        close_old_connections()
        try:
            barrier.wait(timeout=10)
            return ("ok", workers[index]())
        except Exception as exc:  # expected domain errors are data
            return ("error", type(exc).__name__, getattr(exc, "code", ""), str(exc))
        finally:
            connection.close()

    with ThreadPoolExecutor(max_workers=len(workers)) as pool:
        return list(pool.map(wrapped, range(len(workers))))


@unittest.skipUnless(connection.vendor == "postgresql", "PostgreSQL-only concurrency tests")
class CommerceConcurrencyTests(TransactionTestCase):
    reset_sequences = True

    def setUp(self):
        self.owner = User.objects.create_user(phone="09129990001")
        self.customer = User.objects.create_user(phone="09129990002")
        self.other_customer = User.objects.create_user(phone="09129990003")
        # TransactionTestCase flush removes migration-seeded agreement rows.
        AgreementVersion.objects.get_or_create(
            kind="club", version="JL-2026-01", defaults={"body": "concurrency test terms"}
        )
        self.business, self.product = make_store(self.owner, "Concurrency", "concurrency")
        StoreConfig.objects.update_or_create(
            business=self.business, defaults={"delivery_fee_toman": 50000}
        )
        activate_club(self.business)

    def _order_kwargs(self, customer=None, key="race-key"):
        return {
            "business": self.business,
            "customer": customer or self.customer,
            "items": [{"product_id": self.product.id, "quantity": 1}],
            "mode": Order.Mode.DELIVERY,
            "address_text": "Jam street",
            "idempotency_key": key,
        }

    def test_concurrent_same_idempotency_key_creates_one_order(self):
        outcomes = _run_parallel([
            lambda: services.create_order(**self._order_kwargs())[0].pk for _ in range(8)
        ])
        successes = [v for kind, *rest in outcomes if kind == "ok" for v in rest]
        self.assertEqual(len(successes), 8, outcomes)
        self.assertEqual(len(set(successes)), 1, outcomes)
        self.assertEqual(Order.objects.count(), 1)
        self.assertEqual(Order.objects.get().items.count(), 1)

    def test_concurrent_same_key_different_customers_are_isolated(self):
        outcomes = _run_parallel([
            lambda i=i: services.create_order(**self._order_kwargs(
                customer=self.customer if i % 2 == 0 else self.other_customer
            ))[0].pk for i in range(6)
        ])
        self.assertTrue(all(kind == "ok" for kind, *rest in outcomes), outcomes)
        self.assertEqual(Order.objects.count(), 2)
        self.assertEqual(Order.objects.filter(customer=self.customer).count(), 1)
        self.assertEqual(Order.objects.filter(customer=self.other_customer).count(), 1)

    def test_concurrent_status_updates_produce_one_transition(self):
        order, _ = services.create_order(**self._order_kwargs(key="status-key"))

        def accept():
            _, changed = services.transition_order(order, Order.Status.ACCEPTED, self.owner)
            return changed

        outcomes = _run_parallel([accept for _ in range(8)])
        self.assertTrue(all(kind == "ok" for kind, *rest in outcomes), outcomes)
        self.assertEqual(sum(v for kind, *rest in outcomes if kind == "ok" for v in rest), 1)
        order.refresh_from_db()
        self.assertEqual(order.status, Order.Status.ACCEPTED)
        self.assertEqual(OrderStatusEvent.objects.filter(order=order, status="accepted").count(), 1)

    def test_concurrent_conflicting_transitions_do_not_both_apply(self):
        order, _ = services.create_order(**self._order_kwargs(key="conflict-key"))

        def transition(status):
            try:
                _, changed = services.transition_order(order, status, self.owner)
                return "changed" if changed else "noop"
            except services.CommerceError as exc:
                return f"rejected:{exc.code}"

        outcomes = _run_parallel([
            lambda: transition(Order.Status.ACCEPTED),
            lambda: transition(Order.Status.DONE),
        ])
        order.refresh_from_db()
        self.assertIn(order.status, (Order.Status.ACCEPTED, Order.Status.PLACED))
        applied = [v for kind, v in outcomes if kind == "ok" and v == "changed"]
        self.assertEqual(len(applied), 1, outcomes)
        self.assertEqual(OrderStatusEvent.objects.filter(order=order).exclude(status="placed").count(), 1)

    def test_concurrent_purchase_code_confirmation_creates_one_purchase(self):
        _, raw = services.issue_purchase_code(self.business, self.customer)

        def confirm():
            purchase, created, already = services.confirm_purchase_code(
                self.business, raw, self.owner
            )
            return {"pk": purchase.pk, "created": created, "already": already}

        outcomes = _run_parallel([confirm for _ in range(8)])
        self.assertTrue(all(kind == "ok" for kind, *rest in outcomes), outcomes)
        pks = {v["pk"] for kind, *rest in outcomes if kind == "ok" for v in rest}
        self.assertEqual(len(pks), 1)
        self.assertEqual(InPersonPurchase.objects.count(), 1)
        self.assertEqual(PurchaseCode.objects.get().status, PurchaseCode.Status.CONFIRMED)

    def test_concurrent_issuance_respects_daily_limit_and_single_active_code(self):
        outcomes = _run_parallel([
            lambda: services.issue_purchase_code(self.business, self.customer)[0].pk
            for _ in range(8)
        ])
        success = [v for kind, *rest in outcomes if kind == "ok" for v in rest]
        errors = [rest for kind, *rest in outcomes if kind == "error"]
        self.assertEqual(len(success), 5, outcomes)
        self.assertEqual(len(errors), 3, outcomes)
        self.assertTrue(all(err[1] == "daily_limit_reached" for err in errors), errors)
        self.assertEqual(PurchaseCode.objects.count(), 5)
        self.assertEqual(
            PurchaseCode.objects.filter(status=PurchaseCode.Status.ISSUED).count(), 1
        )

    def test_concurrent_visit_recording_creates_one_row(self):
        outcomes = _run_parallel([
            lambda: services.record_visit(self.business, self.customer)[1] for _ in range(8)
        ])
        self.assertTrue(all(kind == "ok" for kind, *rest in outcomes), outcomes)
        self.assertEqual(sum(v for kind, *rest in outcomes if kind == "ok" for v in rest), 1)
        self.assertEqual(ClubVisit.objects.filter(business=self.business, customer=self.customer).count(), 1)

    def test_concurrent_payment_confirmation_is_idempotent(self):
        order, _ = services.create_order(
            **self._order_kwargs(key="payment-key"),
            payment_method=Order.PaymentMethod.ONLINE,
        )

        def pay():
            _, changed = services.mark_order_paid(order, self.owner)
            return changed

        outcomes = _run_parallel([pay for _ in range(8)])
        self.assertTrue(all(kind == "ok" for kind, *rest in outcomes), outcomes)
        self.assertEqual(sum(v for kind, *rest in outcomes if kind == "ok" for v in rest), 1)
        order.refresh_from_db()
        self.assertEqual(order.payment_state, Order.PaymentState.PAID)
        from .models import CommissionEntry, SettlementEntry

        self.assertEqual(SettlementEntry.objects.filter(order=order).count(), 1)
        self.assertEqual(CommissionEntry.objects.filter(order=order).count(), 0)

    def test_code_expiry_during_confirmation(self):
        _, raw = services.issue_purchase_code(
            self.business, self.customer, moment=timezone.now() - timedelta(seconds=400)
        )
        with self.assertRaises(services.CommerceError) as ctx:
            services.confirm_purchase_code(self.business, raw, self.owner)
        self.assertEqual(ctx.exception.code, "code_expired")
        self.assertEqual(InPersonPurchase.objects.count(), 0)

    def test_revoked_code_cannot_be_confirmed(self):
        code, raw = services.issue_purchase_code(self.business, self.customer)
        PurchaseCode.objects.filter(pk=code.pk).update(status=PurchaseCode.Status.REVOKED)
        with self.assertRaises(services.CommerceError) as ctx:
            services.confirm_purchase_code(self.business, raw, self.owner)
        self.assertEqual(ctx.exception.code, "code_revoked")
        self.assertEqual(InPersonPurchase.objects.count(), 0)
