"""Business rules for commerce, club, purchase codes, settlement and orders.

All money calculations use Decimal. Client-supplied prices, totals, rates,
ownership and expiry are never trusted.
"""

import hashlib
import secrets
from datetime import timedelta
from decimal import Decimal, ROUND_HALF_UP

from django.conf import settings
from django.db import IntegrityError, transaction
from django.db.models import Count, Sum
from django.utils import timezone

from businesses.models import Business, Menu, Product
from subscriptions.models import SubscriptionEntitlement

from .models import (
    AdCampaign,
    AgreementAcceptance,
    AgreementVersion,
    Campaign,
    ClubOffer,
    ClubVisit,
    CommissionEntry,
    CommissionRateChange,
    InPersonPurchase,
    Invoice,
    LaunchConfig,
    Order,
    OrderItem,
    OrderStatusEvent,
    PurchaseCode,
    SettlementAccount,
    SettlementEntry,
    SettlementReversal,
    StoreConfig,
)

CODE_TTL_SECONDS = int(getattr(settings, "CLUB_PURCHASE_CODE_TTL_SECONDS", 300))
CODE_DAILY_LIMIT = int(getattr(settings, "CLUB_PURCHASE_CODE_DAILY_LIMIT", 5))

ALLOWED_TRANSITIONS = {
    Order.Status.PLACED: {Order.Status.ACCEPTED, Order.Status.REJECTED, Order.Status.CANCELED},
    Order.Status.ACCEPTED: {Order.Status.PREPARING, Order.Status.REJECTED, Order.Status.CANCELED},
    Order.Status.PREPARING: {Order.Status.READY, Order.Status.SENT, Order.Status.CANCELED},
    Order.Status.READY: {Order.Status.DONE, Order.Status.CANCELED},
    Order.Status.SENT: {Order.Status.DONE},
    Order.Status.DONE: {Order.Status.REFUNDED},
    Order.Status.REJECTED: set(),
    Order.Status.CANCELED: set(),
    Order.Status.REFUNDED: set(),
}


class CommerceError(Exception):
    """Domain error carrying an HTTP status and a stable error code."""

    def __init__(self, detail, code="invalid", status_code=400):
        super().__init__(detail)
        self.detail = detail
        self.code = code
        self.status_code = status_code


def money(value):
    return Decimal(value).quantize(Decimal("1"), rounding=ROUND_HALF_UP)


def config_for(business):
    """Return the store financial configuration, creating documented defaults."""
    config, _ = StoreConfig.objects.get_or_create(business=business)
    return config


def update_config(business, *, commission_rate=None, setup_fee_toman=None, monthly_fee_toman=None,
                  delivery_fee_toman=None, changed_by=None, note=""):
    with transaction.atomic():
        config = StoreConfig.objects.select_for_update().filter(business=business).first()
        if config is None:
            config = StoreConfig.objects.create(business=business)
        old_rate = config.commission_rate
        if commission_rate is not None:
            rate = Decimal(str(commission_rate))
            if rate < 0 or rate > 30:
                raise CommerceError("Commission rate must be between 0 and 30.", "invalid_rate")
            config.commission_rate = rate.quantize(Decimal("0.01"))
        if setup_fee_toman is not None:
            config.setup_fee_toman = int(setup_fee_toman)
        if monthly_fee_toman is not None:
            config.monthly_fee_toman = int(monthly_fee_toman)
        if delivery_fee_toman is not None:
            config.delivery_fee_toman = int(delivery_fee_toman)
        config.save()
        if config.commission_rate != old_rate:
            CommissionRateChange.objects.create(
                business=business,
                rate=config.commission_rate,
                basis="goods_only",
                note=note[:200],
                changed_by=changed_by,
            )
    return config


def current_agreement(kind):
    return AgreementVersion.objects.filter(kind=kind, effective_at__lte=timezone.now()).order_by(
        "-effective_at", "-id"
    ).first()


def agreement_body(business, kind):
    version = current_agreement(kind)
    if version:
        return version
    config = config_for(business)
    if kind == AgreementVersion.Kind.CLUB:
        body = (
            f"باشگاه مشتریان حضوری جم لایف. اشتراک ماهانه {config.monthly_fee_toman} تومان؛ "
            "ثبت خرید حضوری پورسانت آنلاین ندارد. کد خرید یک‌بارمصرف است و پس از تأیید فروشنده "
            "به خرید ثبت‌شده تبدیل می‌شود. این متن نمونه است و پیش از عرضه باید بررسی حقوقی شود."
        )
    else:
        body = (
            f"شرایط همکاری فروشنده: کمیسیون {config.commission_rate}٪ فقط از بهای کالا پس از تخفیف "
            "محاسبه می‌شود؛ هزینهٔ ارسال مشمول کمیسیون نیست. نرخ هر سفارش هنگام ثبت ثابت می‌ماند. "
            "تسویه بدون اتصال ارائه‌دهندهٔ پرداخت انجام نمی‌شود. این متن نمونه است."
        )
    version, _ = AgreementVersion.objects.get_or_create(
        kind=kind, version="JL-2026-01", defaults={"body": body}
    )
    return version


def accept_agreement(business, user, kind, accepted_name, version_id=None):
    if kind not in AgreementVersion.Kind.values:
        raise CommerceError("Unknown agreement kind.", "invalid_kind")
    name = (accepted_name or "").strip()
    if len(name) < 3:
        raise CommerceError("Accepted name is required.", "invalid_name")
    version = current_agreement(kind)
    if version_id is not None:
        version = AgreementVersion.objects.filter(pk=version_id, kind=kind).first()
        if version is None:
            raise CommerceError("Agreement version not found.", "version_not_found", 404)
    if version is None:
        version = agreement_body(business, kind)
    config = config_for(business)
    acceptance, _ = AgreementAcceptance.objects.get_or_create(
        business=business,
        user=user,
        kind=kind,
        version=version,
        defaults={
            "accepted_name": name,
            "rate_snapshot": config.commission_rate if kind == AgreementVersion.Kind.SELLER else None,
            "monthly_snapshot": config.monthly_fee_toman,
        },
    )
    return acceptance


def latest_acceptance(business, kind):
    return AgreementAcceptance.objects.filter(business=business, kind=kind).order_by("-created_at", "-id").first()


def log_event(business, event, **detail):
    """Legacy club event log removed with ClubMembership."""
    return None


def create_invoice(business, user, *, kind, title, amount_toman, terms_acceptance=None):
    if int(amount_toman) <= 0:
        raise CommerceError("Invoice amount must be positive.", "invalid_amount")
    return Invoice.objects.create(
        business=business,
        kind=kind,
        title=title[:160],
        amount_toman=int(amount_toman),
        terms_acceptance=terms_acceptance,
    )


# ---------------------------------------------------------------------------
# Orders and commission
# ---------------------------------------------------------------------------

def _resolve_order_items(business, items):
    if not isinstance(items, list) or not items:
        raise CommerceError("At least one order item is required.", "items_required")
    product_ids = []
    for item in items:
        try:
            product_ids.append(int(item.get("product_id")))
        except (TypeError, ValueError):
            raise CommerceError("Each item needs a valid product_id.", "invalid_product")
    products = {
        p.id: p
        for p in Product.objects.select_related("category__menu__business").filter(id__in=product_ids)
    }
    lines = []
    seen = {}
    for item in items:
        product = products.get(int(item["product_id"]))
        try:
            quantity = int(item.get("quantity", 1))
        except (TypeError, ValueError):
            raise CommerceError("Quantity must be an integer.", "invalid_quantity")
        if product is None:
            raise CommerceError("A product in the cart no longer exists.", "product_not_found", 404)
        if product.category.menu.business_id != business.id:
            raise CommerceError("All products must belong to the store.", "cross_store_item", 400)
        if not product.category.menu.is_active or not product.is_available:
            raise CommerceError(f"{product.name} is not available.", "product_unavailable", 409)
        if quantity < 1 or quantity > 99:
            raise CommerceError("Quantity must be between 1 and 99.", "invalid_quantity")
        if product.pk in seen:
            combined = seen[product.pk][1] + quantity
            if combined > 99:
                raise CommerceError("Quantity must be between 1 and 99.", "invalid_quantity")
            seen[product.pk] = (product, combined)
        else:
            seen[product.pk] = (product, quantity)
            lines.append(product.pk)
    return [seen[product_id] for product_id in lines]


def quote_order(*, business, items, mode=Order.Mode.DELIVERY):
    """Validate a cart and return authoritative totals without creating an order.

    Uses the same item resolver and StoreConfig as create_order so the
    preview cannot diverge from the amount later persisted on the order.
    """
    if mode not in Order.Mode.values:
        raise CommerceError("Unknown delivery mode.", "invalid_mode")
    lines = _resolve_order_items(business, items)
    config = config_for(business)
    subtotal = sum(int(product.price_toman) * quantity for product, quantity in lines)
    delivery_fee = int(config.delivery_fee_toman) if mode == Order.Mode.DELIVERY else 0
    return {
        "mode": mode,
        "subtotal_toman": subtotal,
        "discount_toman": 0,
        "delivery_fee_toman": delivery_fee,
        "total_toman": subtotal + delivery_fee,
        "items": [
            {
                "product_id": product.pk,
                "name": product.name,
                "unit_price_toman": int(product.price_toman),
                "quantity": quantity,
                "line_total_toman": int(product.price_toman) * quantity,
            }
            for product, quantity in lines
        ],
    }


def public_store_directory():
    """Public-safe directory of stores with an active, published menu.

    Reuses the exact visibility rules of the public menu endpoint: active menu,
    active owner and a current active subscription. Only public catalog fields
    and the public delivery fee are exposed.
    """
    now = timezone.now()
    menus = (
        Menu.objects.filter(
            is_active=True,
            business__owner__is_active=True,
        )
        .filter(
            business__subscription_entitlements__entitlement_type=SubscriptionEntitlement.Type.MENU,
            business__subscription_entitlements__status=SubscriptionEntitlement.Status.ACTIVE,
            business__subscription_entitlements__starts_at__lte=now,
            business__subscription_entitlements__ends_at__gt=now,
        )
        .select_related("business")
        .prefetch_related("categories__products")
        .distinct()
        .order_by("business__name", "id")
    )
    rows = []
    for menu in menus:
        config = config_for(menu.business)
        products = [
            product
            for category in menu.categories.all()
            for product in category.products.all()
            if product.is_available
        ]
        rows.append(
            {
                "id": menu.business_id,
                "name": menu.business.name,
                "slug": menu.business.slug,
                "description": menu.business.description,
                "logo": menu.business.logo.url if menu.business.logo else None,
                "menu_slug": menu.slug,
                "menu_title": menu.title,
                "delivery_fee_toman": int(config.delivery_fee_toman),
                "products_count": len(products),
                "categories": [category.name for category in menu.categories.all()],
            }
        )
    return rows


def create_order(*, business, customer, items, mode=Order.Mode.DELIVERY, payment_method=Order.PaymentMethod.OFFLINE,
                 customer_name="", customer_phone="", address_text="", note="", preferred_time="",
                 idempotency_key=""):
    if payment_method not in Order.PaymentMethod.values:
        raise CommerceError("Unknown payment method.", "invalid_payment_method")
    if payment_method == Order.PaymentMethod.ONLINE and not getattr(
        settings, "COMMERCE_ORDER_ONLINE_PAYMENTS_ENABLED", False
    ):
        raise CommerceError(
            "Online order payment is not configured. Choose pay in store/delivery.",
            "online_payment_unavailable",
            503,
        )
    if mode not in Order.Mode.values:
        raise CommerceError("Unknown delivery mode.", "invalid_mode")
    if mode == Order.Mode.DELIVERY and not address_text.strip():
        raise CommerceError("Delivery address is required for delivery orders.", "address_required")

    key = (idempotency_key or "").strip()[:64]
    with transaction.atomic():
        if key:
            existing = Order.objects.select_for_update().filter(
                business=business, customer=customer, idempotency_key=key
            ).first()
            if existing:
                return existing, False

        lines = _resolve_order_items(business, items)
        config = config_for(business)
        subtotal = sum(int(product.price_toman) * quantity for product, quantity in lines)
        delivery_fee = int(config.delivery_fee_toman) if mode == Order.Mode.DELIVERY else 0
        total = subtotal + delivery_fee

        try:
            # Savepoint so a concurrent duplicate does not break the outer
            # transaction; the partial unique constraint remains authoritative.
            with transaction.atomic():
                order = Order.objects.create(
                    business=business,
                    customer=customer,
                    mode=mode,
                    payment_method=payment_method,
                    payment_state=Order.PaymentState.PENDING,
                    subtotal_toman=subtotal,
                    discount_toman=0,
                    delivery_fee_toman=delivery_fee,
                    total_toman=total,
                    customer_name=customer_name[:120],
                    customer_phone=customer_phone[:20],
                    address_text=address_text.strip(),
                    note=note[:1000],
                    preferred_time=preferred_time[:80],
                    idempotency_key=key,
                )
                OrderItem.objects.bulk_create([
                    OrderItem(order=order, product=product, name=product.name[:160],
                              unit_price_toman=int(product.price_toman), quantity=quantity)
                    for product, quantity in lines
                ])
                OrderStatusEvent.objects.create(order=order, status=order.status, actor=customer)
                # Freeze the applicable rate at order creation. Later configuration
                # changes cannot alter this order's commission.
                if payment_method == Order.PaymentMethod.ONLINE:
                    order.commission_rate = config.commission_rate
                    order.save(update_fields=["commission_rate"])
                    SettlementEntry.objects.create(
                        order=order,
                        business=business,
                        goods_toman=order.goods_total,
                        delivery_toman=delivery_fee,
                        gross_toman=total,
                        commission_toman=money(Decimal(order.goods_total) * config.commission_rate / Decimal("100")),
                        net_payable_toman=total - int(money(Decimal(order.goods_total) * config.commission_rate / Decimal("100"))),
                        rate=config.commission_rate,
                        status=SettlementEntry.Status.PENDING_PAYMENT,
                    )
        except IntegrityError:
            existing = Order.objects.filter(
                business=business, customer=customer, idempotency_key=key
            ).first()
            if existing:
                return existing, False
            raise
    return order, True


def _lock_commission(order):
    if order.commission_locked_at is not None:
        return
    if order.payment_method != Order.PaymentMethod.ONLINE:
        return
    if order.payment_state != Order.PaymentState.PAID:
        return
    rate = order.commission_rate
    if rate is None:
        rate = config_for(order.business).commission_rate
    base = order.goods_total
    amount = money(Decimal(base) * Decimal(rate) / Decimal("100"))
    order.commission_rate = rate
    order.commission_base_toman = base
    order.commission_amount_toman = int(amount)
    order.commission_locked_at = timezone.now()
    order.save(update_fields=[
        "commission_rate", "commission_base_toman", "commission_amount_toman", "commission_locked_at",
    ])
    CommissionEntry.objects.get_or_create(
        order=order,
        defaults={
            "business": order.business,
            "rate": rate,
            "basis": "goods_only",
            "base_toman": base,
            "amount_toman": int(amount),
        },
    )


def _settlement_ready(order):
    entry = getattr(order, "settlement_entry", None)
    if entry is None:
        return
    if order.status in (Order.Status.CANCELED, Order.Status.REJECTED):
        if entry.status not in (SettlementEntry.Status.REVERSED, SettlementEntry.Status.FAILED):
            entry.status = SettlementEntry.Status.FAILED
            entry.save(update_fields=["status", "updated_at"])
        return
    if order.status == Order.Status.REFUNDED:
        _reverse_settlement(order, reason="Order refunded", actor=None)
        return
    if entry.status in (SettlementEntry.Status.REVERSED, SettlementEntry.Status.FAILED):
        return
    if order.payment_state != Order.PaymentState.PAID:
        new_status = SettlementEntry.Status.PENDING_PAYMENT
    elif order.status != Order.Status.DONE:
        new_status = SettlementEntry.Status.AWAITING_DELIVERY
    else:
        account = SettlementAccount.objects.filter(business_id=order.business_id).first()
        acceptance = latest_acceptance(order.business, AgreementVersion.Kind.SELLER)
        provider_ok = bool(account and account.provider_status == SettlementAccount.ProviderStatus.VERIFIED)
        if account is None or acceptance is None or not provider_ok:
            new_status = SettlementEntry.Status.AWAITING_ONBOARDING
        else:
            new_status = SettlementEntry.Status.ELIGIBLE
    if entry.status != new_status:
        entry.status = new_status
        entry.save(update_fields=["status", "updated_at"])


def _reverse_settlement(order, reason, actor):
    entry = getattr(order, "settlement_entry", None)
    if entry is None or entry.status == SettlementEntry.Status.REVERSED:
        return
    entry.status = SettlementEntry.Status.REVERSED
    entry.save(update_fields=["status", "updated_at"])
    SettlementReversal.objects.create(
        settlement=entry, amount_toman=entry.commission_toman,
        reason=("commission reversal: " + reason)[:200], created_by=actor,
    )
    SettlementReversal.objects.create(
        settlement=entry, amount_toman=entry.net_payable_toman,
        reason=("seller net reversal: " + reason)[:200], created_by=actor,
    )


def transition_order(order, new_status, actor, *, note=""):
    if new_status not in Order.Status.values:
        raise CommerceError("Unknown order status.", "invalid_status")
    with transaction.atomic():
        order = Order.objects.select_for_update().get(pk=order.pk)
        if new_status == order.status:
            return order, False
        allowed = ALLOWED_TRANSITIONS.get(order.status, set())
        if new_status not in allowed:
            raise CommerceError(
                f"Cannot change order from {order.status} to {new_status}.", "invalid_transition", 409
            )
        if new_status == Order.Status.REFUNDED:
            if order.payment_state != Order.PaymentState.PAID:
                raise CommerceError("Only a paid order can be refunded.", "not_paid", 409)
            order.payment_state = Order.PaymentState.REFUNDED
        order.status = new_status
        order.save(update_fields=["status", "payment_state", "updated_at"])
        OrderStatusEvent.objects.create(order=order, status=new_status, actor=actor)
        if new_status == Order.Status.DONE:
            _lock_commission(order)
        _settlement_ready(order)
    return order, True


def mark_order_paid(order, actor=None):
    with transaction.atomic():
        order = Order.objects.select_for_update().get(pk=order.pk)
        if order.payment_state == Order.PaymentState.PAID:
            return order, False
        if order.payment_method != Order.PaymentMethod.ONLINE:
            raise CommerceError("Offline orders are paid in store.", "offline_order", 409)
        order.payment_state = Order.PaymentState.PAID
        order.save(update_fields=["payment_state", "updated_at"])
        if order.status == Order.Status.DONE:
            _lock_commission(order)
        _settlement_ready(order)
    return order, True


# ---------------------------------------------------------------------------
# Visits and purchase codes
# ---------------------------------------------------------------------------

def _hash_code(code):
    return hashlib.sha256(code.encode("utf-8")).hexdigest()


def record_visit(business, customer, moment=None):
    moment = moment or timezone.now()
    try:
        with transaction.atomic():
            visit, created = ClubVisit.objects.get_or_create(
                business=business, customer=customer, visited_on=timezone.localdate(moment)
            )
    except IntegrityError:
        # A concurrent request inserted the same unique visit first.
        visit = ClubVisit.objects.get(
            business=business, customer=customer, visited_on=timezone.localdate(moment)
        )
        created = False
    if created:
        log_event(business, "visit_recorded", customer_id=customer.pk)
    return visit, created


def issue_purchase_code(business, customer, moment=None):
    moment = moment or timezone.now()
    from subscriptions.entitlements import club_access

    if not club_access(business, moment):
        raise CommerceError("Store club membership is not active.", "club_inactive", 409)

    today = timezone.localdate(moment)
    with transaction.atomic():
        # Serialize issuance per customer so concurrent requests cannot both
        # pass the daily-limit check or leave two active codes behind.
        customer.__class__.objects.select_for_update().get(pk=customer.pk)
        confirmed_today = InPersonPurchase.objects.filter(
            business=business, customer=customer, purchase_date=today,
            status=InPersonPurchase.Status.CONFIRMED,
        ).exists()
        if confirmed_today:
            raise CommerceError(
                "A rewarded purchase is already confirmed for today.", "daily_purchase_done", 409
            )
        issued_today = PurchaseCode.objects.filter(
            business=business, customer=customer, issued_on=today
        ).count()
        if issued_today >= CODE_DAILY_LIMIT:
            raise CommerceError("Daily purchase-code limit reached.", "daily_limit_reached", 429)

        # One active code per customer/store. Reissuing replaces the previous
        # code so that only a single code can ever be valid.
        PurchaseCode.objects.select_for_update().filter(
            business=business, customer=customer, status=PurchaseCode.Status.ISSUED
        ).update(status=PurchaseCode.Status.REVOKED)

        raw = None
        for _ in range(5):
            candidate = "JL" + secrets.token_hex(6).upper()
            if not PurchaseCode.objects.filter(code_hash=_hash_code(candidate)).exists():
                raw = candidate
                break
        if raw is None:
            raise CommerceError("Could not generate a unique code.", "code_generation_failed", 500)

        code = PurchaseCode.objects.create(
            business=business,
            customer=customer,
            code_hash=_hash_code(raw),
            code_hint=raw[-4:],
            issued_on=today,
            expires_at=moment + timedelta(seconds=CODE_TTL_SECONDS),
        )
        log_event(business, "purchase_code_issued", code_id=code.pk, customer_id=customer.pk)
    return code, raw


def validate_purchase_code(business, raw_code, moment=None):
    moment = moment or timezone.now()
    code = PurchaseCode.objects.select_related("customer").filter(
        business=business, code_hash=_hash_code((raw_code or "").strip().upper())
    ).first()
    if code is None:
        raise CommerceError("Code not found for this store.", "code_not_found", 404)
    if code.status == PurchaseCode.Status.CONFIRMED:
        return code, {"state": "already_confirmed"}
    if code.status == PurchaseCode.Status.REVOKED:
        raise CommerceError("Code has been revoked.", "code_revoked", 409)
    if not code.is_usable(moment):
        raise CommerceError("Code has expired.", "code_expired", 410)
    return code, {"state": "valid"}


def _masked_customer(user):
    label = user.phone or user.email or f"user-{user.pk}"
    if "@" in label:
        local, _, domain = label.partition("@")
        return f"{local[:2]}***@{domain}"
    return f"{label[:5]}***{label[-2:]}"


def confirm_purchase_code(business, raw_code, seller, moment=None):
    """Atomically confirm one code exactly once.

    Repeated confirmation of the same code by the same store returns the
    existing purchase with ``already_confirmed=True`` instead of creating a
    duplicate, keeping the operation idempotent.
    """
    moment = moment or timezone.now()
    digest = _hash_code((raw_code or "").strip().upper())
    try:
        with transaction.atomic():
            code = PurchaseCode.objects.select_for_update().select_related("customer").filter(
                business=business, code_hash=digest
            ).first()
            if code is None:
                raise CommerceError("Code not found for this store.", "code_not_found", 404)
            existing = InPersonPurchase.objects.filter(code=code).first()
            if existing:
                if existing.status == InPersonPurchase.Status.CONFIRMED:
                    return existing, False, True
                raise CommerceError("Code has been revoked.", "code_revoked", 409)
            if code.status == PurchaseCode.Status.REVOKED:
                raise CommerceError("Code has been revoked.", "code_revoked", 409)
            if code.status == PurchaseCode.Status.EXPIRED or code.expires_at <= moment:
                code.status = PurchaseCode.Status.EXPIRED
                code.save(update_fields=["status"])
                raise CommerceError("Code has expired.", "code_expired", 410)
            if code.status != PurchaseCode.Status.ISSUED:
                raise CommerceError("Code is not usable.", "code_unusable", 409)
            from subscriptions.entitlements import club_access

            if not club_access(business, moment):
                raise CommerceError("Store club membership is not active.", "club_inactive", 409)

            today = timezone.localdate(moment)
            if InPersonPurchase.objects.filter(
                business=business, customer=code.customer, purchase_date=today,
                status=InPersonPurchase.Status.CONFIRMED,
            ).exists():
                raise CommerceError(
                    "A rewarded purchase is already confirmed for today.", "daily_purchase_done", 409
                )
            offer = getattr(business, "club_offer", None)
            purchase = InPersonPurchase.objects.create(
                business=business,
                customer=code.customer,
                code=code,
                confirmed_by=seller,
                purchase_date=today,
                perk_snapshot=(offer.text if offer and offer.is_active else "")[:150],
            )
            code.status = PurchaseCode.Status.CONFIRMED
            code.save(update_fields=["status"])
            log_event(business, "purchase_confirmed", purchase_id=purchase.pk, code_id=code.pk)
            return purchase, True, False
    except IntegrityError:
        # The partial unique constraint enforces one confirmed purchase per
        # customer per store per day even under concurrency.
        existing = InPersonPurchase.objects.filter(
            business=business, code__code_hash=digest
        ).first()
        if existing:
            return existing, False, True
        raise CommerceError(
            "A rewarded purchase is already confirmed for today.", "daily_purchase_done", 409
        )


def revoke_purchase(purchase, seller):
    with transaction.atomic():
        purchase = InPersonPurchase.objects.select_for_update().get(pk=purchase.pk)
        if purchase.status == InPersonPurchase.Status.REVOKED:
            return purchase, False
        purchase.status = InPersonPurchase.Status.REVOKED
        purchase.revoked_at = timezone.now()
        purchase.revoked_by = seller
        purchase.save(update_fields=["status", "revoked_at", "revoked_by"])
        PurchaseCode.objects.filter(pk=purchase.code_id).update(status=PurchaseCode.Status.REVOKED)
        log_event(purchase.business, "purchase_revoked", purchase_id=purchase.pk)
    return purchase, True


def club_metrics(business, start=None, end=None):
    visits = ClubVisit.objects.filter(business=business)
    codes = PurchaseCode.objects.filter(business=business)
    purchases = InPersonPurchase.objects.filter(business=business, status=InPersonPurchase.Status.CONFIRMED)
    if start:
        visits = visits.filter(visited_on__gte=start)
        codes = codes.filter(issued_on__gte=start)
        purchases = purchases.filter(purchase_date__gte=start)
    if end:
        visits = visits.filter(visited_on__lte=end)
        codes = codes.filter(issued_on__lte=end)
        purchases = purchases.filter(purchase_date__lte=end)

    returning = (
        purchases.values("customer_id")
        .annotate(days=Count("purchase_date", distinct=True))
        .filter(days__gt=1)
        .count()
    )
    return {
        "visits": visits.count(),
        "codes_issued": codes.count(),
        "purchases_confirmed": purchases.count(),
        "returning_customers": returning,
        "unique_customers": purchases.values("customer_id").distinct().count(),
    }


def revenue_summary(business):
    """Aggregate server-side financial figures for the revenue dashboard."""
    entries = SettlementEntry.objects.filter(business=business)
    paid_invoices = Invoice.objects.filter(
        business=business, status__in=[Invoice.Status.SIMULATED_PAID, Invoice.Status.PAID]
    )
    delivered = Order.objects.filter(
        business=business, status=Order.Status.DONE, payment_method=Order.PaymentMethod.ONLINE
    )
    commission = CommissionEntry.objects.filter(business=business).aggregate(total=Sum("amount_toman"))["total"] or 0
    return {
        "commission_earned_toman": int(commission),
        "invoices_paid_toman": int(paid_invoices.aggregate(total=Sum("amount_toman"))["total"] or 0),
        "commissionable_orders": delivered.count(),
        "settlement_eligible_toman": int(
            entries.filter(status=SettlementEntry.Status.ELIGIBLE).aggregate(total=Sum("net_payable_toman"))[
                "total"
            ]
            or 0
        ),
        "settlement_pending_toman": int(
            entries.filter(
                status__in=[
                    SettlementEntry.Status.PENDING_PAYMENT,
                    SettlementEntry.Status.AWAITING_DELIVERY,
                    SettlementEntry.Status.AWAITING_ONBOARDING,
                ]
            ).aggregate(total=Sum("net_payable_toman"))["total"]
            or 0
        ),
    }


def _digits(value):
    return "".join(ch for ch in (value or "") if ch.isdigit())


def iban_is_valid(raw):
    """Check Iranian IBAN structure and mod-97 checksum.

    A checksum is not proof of account ownership and must never be presented
    as bank verification.
    """
    value = (raw or "").replace(" ", "").replace("-", "").upper()
    if len(value) != 26 or not value.startswith("IR"):
        return False
    if len(_digits(value[2:])) != 24:
        return False
    rearranged = value[4:] + "1827" + value[2:4]
    remainder = 0
    for ch in rearranged:
        remainder = (remainder * 10 + int(ch)) % 97
    return remainder == 1


def save_settlement_account(business, legal_name, iban):
    name = (legal_name or "").strip()
    normalized = (iban or "").replace(" ", "").replace("-", "").upper()
    if len(name) < 3:
        raise CommerceError("Legal name is required.", "invalid_legal_name")
    if not iban_is_valid(normalized):
        raise CommerceError("IBAN structure or checksum is invalid.", "invalid_iban")
    account, _ = SettlementAccount.objects.update_or_create(
        business=business,
        defaults={
            "legal_name": name[:120],
            "iban": normalized,
            "iban_checksum_valid": True,
            # Deliberately not verified: no provider integration exists.
            "provider_status": SettlementAccount.ProviderStatus.UNCONFIGURED,
            "provider_verified_at": None,
        },
    )
    return account


def campaign_validation(title, budget, pct, cap, minimum, days, seller, platform, brand):
    if not title or len(title) < 3:
        raise CommerceError("Campaign title is required.", "invalid_title")
    if pct not in (5, 10, 15):
        raise CommerceError("Discount percentage must be 5, 10 or 15.", "invalid_pct")
    if int(seller) + int(platform) + int(brand) != 100:
        raise CommerceError("Shares must add up to 100%.", "invalid_shares")
    if int(budget) <= 0 or int(budget) < int(cap):
        raise CommerceError("Budget must be at least the per-code cap.", "invalid_budget")
    if int(cap) > (int(minimum) * int(pct)) / 100:
        raise CommerceError("Cap cannot exceed minimum purchase × discount percentage.", "invalid_cap")
    if not (1 <= int(days) <= 90):
        raise CommerceError("Campaign duration must be 1-90 days.", "invalid_days")


def create_campaign(business, data):
    campaign_validation(
        data.get("title", ""), data.get("budget_toman", 0), data.get("discount_pct", 0),
        data.get("cap_toman", 0), data.get("min_purchase_toman", 0), data.get("days", 0),
        data.get("seller_share_pct", 0), data.get("platform_share_pct", 0), data.get("brand_share_pct", 0),
    )
    return Campaign.objects.create(
        business=business,
        title=data["title"][:120],
        budget_toman=int(data["budget_toman"]),
        discount_pct=int(data["discount_pct"]),
        cap_toman=int(data["cap_toman"]),
        min_purchase_toman=int(data["min_purchase_toman"]),
        days=int(data["days"]),
        seller_share_pct=int(data["seller_share_pct"]),
        platform_share_pct=int(data["platform_share_pct"]),
        brand_share_pct=int(data["brand_share_pct"]),
        service_fee_toman=int(data.get("service_fee_toman", 0)),
    )


def create_ad(business, data):
    title = (data.get("title") or "").strip()
    placement = data.get("placement", AdCampaign.Placement.HOME)
    if len(title) < 3:
        raise CommerceError("Ad title is required.", "invalid_title")
    if placement not in AdCampaign.Placement.values:
        raise CommerceError("Unknown ad placement.", "invalid_placement")
    if int(data.get("budget_toman", 0)) <= 0:
        raise CommerceError("Ad budget must be positive.", "invalid_budget")
    if not (1 <= int(data.get("days", 0)) <= 90):
        raise CommerceError("Ad duration must be 1-90 days.", "invalid_days")
    return AdCampaign.objects.create(
        business=business,
        title=title[:120],
        placement=placement,
        budget_toman=int(data["budget_toman"]),
        days=int(data["days"]),
    )


def launch_config_for(business):
    config, _ = LaunchConfig.objects.get_or_create(business=business)
    return config


def public_club_stores():
    """Active club stores with only public-safe fields.

    Only a current CLUB entitlement grants Seller Club visibility.
    """
    now = timezone.now()
    businesses = Business.objects.filter(
        owner__is_active=True,
        subscription_entitlements__entitlement_type=SubscriptionEntitlement.Type.CLUB,
        subscription_entitlements__status=SubscriptionEntitlement.Status.ACTIVE,
        subscription_entitlements__starts_at__lte=now,
        subscription_entitlements__ends_at__gt=now,
    ).distinct().select_related("club_offer")
    result = []
    for business in businesses:
        offer = getattr(business, "club_offer", None)
        result.append(
            {
                "id": business.pk,
                "name": business.name,
                "slug": business.slug,
                "description": business.description,
                "logo": business.logo.url if business.logo else None,
                "offer": offer.text if offer and offer.is_active else "",
            }
        )
    return result
