"""Input validation and output serialization for commerce endpoints."""

from rest_framework import serializers

from .models import (
    AdCampaign,
    AgreementAcceptance,
    AgreementVersion,
    Campaign,
    ClubOffer,
    InPersonPurchase,
    Invoice,
    Order,
    PurchaseCode,
    SettlementAccount,
    SettlementEntry,
    SettlementReversal,
    StoreConfig,
)


class StoreConfigSerializer(serializers.ModelSerializer):
    class Meta:
        model = StoreConfig
        fields = [
            "commission_rate", "setup_fee_toman", "monthly_fee_toman", "delivery_fee_toman", "updated_at",
        ]
        read_only_fields = ["updated_at"]


class ConfigUpdateSerializer(serializers.Serializer):
    commission_rate = serializers.DecimalField(max_digits=5, decimal_places=2, required=False)
    setup_fee_toman = serializers.IntegerField(min_value=0, required=False)
    monthly_fee_toman = serializers.IntegerField(min_value=0, required=False)
    delivery_fee_toman = serializers.IntegerField(min_value=0, required=False)
    note = serializers.CharField(max_length=200, required=False, allow_blank=True)


class OrderItemInputSerializer(serializers.Serializer):
    product_id = serializers.IntegerField(min_value=1)
    quantity = serializers.IntegerField(min_value=1, max_value=99, default=1)


class OrderQuoteSerializer(serializers.Serializer):
    business_id = serializers.IntegerField(min_value=1)
    items = OrderItemInputSerializer(many=True)
    mode = serializers.ChoiceField(choices=Order.Mode.choices, default=Order.Mode.DELIVERY)


class OrderCreateSerializer(serializers.Serializer):
    business_id = serializers.IntegerField(min_value=1)
    items = OrderItemInputSerializer(many=True)
    mode = serializers.ChoiceField(choices=Order.Mode.choices, default=Order.Mode.DELIVERY)
    payment_method = serializers.ChoiceField(choices=Order.PaymentMethod.choices, default=Order.PaymentMethod.OFFLINE)
    customer_name = serializers.CharField(max_length=120, required=False, allow_blank=True)
    customer_phone = serializers.CharField(max_length=20, required=False, allow_blank=True)
    address_text = serializers.CharField(max_length=1000, required=False, allow_blank=True)
    note = serializers.CharField(max_length=1000, required=False, allow_blank=True)
    preferred_time = serializers.CharField(max_length=80, required=False, allow_blank=True)
    idempotency_key = serializers.CharField(max_length=64, required=False, allow_blank=True)


class OrderItemSerializer(serializers.Serializer):
    def to_representation(self, instance):
        return {
            "id": instance.id,
            "product_id": instance.product_id,
            "name": instance.name,
            "unit_price_toman": instance.unit_price_toman,
            "quantity": instance.quantity,
            "line_total_toman": instance.line_total_toman,
        }


def order_payload(order, include_customer=False):
    data = {
        "number": order.number,
        "business_id": order.business_id,
        "business_name": order.business.name,
        "business_slug": order.business.slug,
        "mode": order.mode,
        "status": order.status,
        "payment_method": order.payment_method,
        "payment_state": order.payment_state,
        "subtotal_toman": order.subtotal_toman,
        "discount_toman": order.discount_toman,
        "delivery_fee_toman": order.delivery_fee_toman,
        "total_toman": order.total_toman,
        "goods_total_toman": order.goods_total,
        "commission_rate": str(order.commission_rate) if order.commission_rate is not None else None,
        "commission_amount_toman": order.commission_amount_toman,
        "note": order.note,
        "preferred_time": order.preferred_time,
        "created_at": order.created_at,
        "updated_at": order.updated_at,
        "items": OrderItemSerializer(order.items.select_related("product"), many=True).data,
        "history": [
            {"status": event.status, "at": event.created_at}
            for event in order.status_events.all()
        ],
    }
    if include_customer:
        data["customer"] = {
            "id": order.customer_id,
            "name": order.customer_name,
            "phone": order.customer_phone,
        }
        data["address_text"] = order.address_text
    return data


class AgreementVersionSerializer(serializers.ModelSerializer):
    class Meta:
        model = AgreementVersion
        fields = ["id", "kind", "version", "body", "effective_at"]


class AcceptanceSerializer(serializers.ModelSerializer):
    version_label = serializers.CharField(source="version.version", read_only=True)

    class Meta:
        model = AgreementAcceptance
        fields = [
            "id", "kind", "version_id", "version_label", "accepted_name", "rate_snapshot",
            "monthly_snapshot", "created_at",
        ]


class AcceptAgreementSerializer(serializers.Serializer):
    kind = serializers.ChoiceField(choices=AgreementVersion.Kind.choices)
    accepted_name = serializers.CharField(min_length=3, max_length=120)
    version_id = serializers.IntegerField(min_value=1, required=False)


class ClubOfferSerializer(serializers.ModelSerializer):
    class Meta:
        model = ClubOffer
        fields = ["text", "is_active", "updated_at"]


class OfferUpdateSerializer(serializers.Serializer):
    text = serializers.CharField(max_length=150, allow_blank=True)
    is_active = serializers.BooleanField(default=True)


class VisitCreateSerializer(serializers.Serializer):
    pass


class IssueCodeSerializer(serializers.Serializer):
    pass


class CodeLookupSerializer(serializers.Serializer):
    code = serializers.CharField(min_length=4, max_length=40)


class PurchaseCodeSerializer(serializers.Serializer):
    def to_representation(self, code):
        return {
            "id": code.id,
            "code_hint": code.code_hint,
            "status": code.status,
            "issued_at": code.issued_at,
            "expires_at": code.expires_at,
        }


class InPersonPurchaseSerializer(serializers.Serializer):
    def to_representation(self, purchase):
        return {
            "id": purchase.id,
            "code_hint": purchase.code.code_hint,
            "status": purchase.status,
            "confirmed_at": purchase.confirmed_at,
            "revoked_at": purchase.revoked_at,
            "perk": purchase.perk_snapshot,
            "customer_label": _masked(purchase.customer),
        }


def _masked(user):
    label = user.phone or user.email or f"user-{user.pk}"
    if "@" in label:
        local, _, domain = label.partition("@")
        return f"{local[:2]}***@{domain}"
    return f"{label[:5]}***{label[-2:]}"


class SettlementAccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = SettlementAccount
        fields = [
            "legal_name", "iban", "iban_checksum_valid", "provider_status",
            "provider_verified_at", "updated_at",
        ]


class SettlementAccountInputSerializer(serializers.Serializer):
    legal_name = serializers.CharField(min_length=3, max_length=120)
    iban = serializers.CharField(min_length=20, max_length=40)


class SettlementEntrySerializer(serializers.ModelSerializer):
    order_number = serializers.CharField(source="order.number", read_only=True)
    reversals = serializers.SerializerMethodField()

    class Meta:
        model = SettlementEntry
        fields = [
            "id", "order_number", "goods_toman", "delivery_toman", "gross_toman",
            "commission_toman", "net_payable_toman", "rate", "status", "paid_at",
            "created_at", "updated_at", "reversals",
        ]

    def get_reversals(self, entry):
        return [
            {"id": r.id, "amount_toman": r.amount_toman, "reason": r.reason, "created_at": r.created_at}
            for r in entry.reversals.all()
        ]


class InvoiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Invoice
        fields = [
            "id", "kind", "title", "amount_toman", "status", "provider_reference",
            "terms_acceptance", "created_at", "paid_at",
        ]


class InvoiceCreateSerializer(serializers.Serializer):
    kind = serializers.ChoiceField(choices=Invoice.Kind.choices)
    title = serializers.CharField(min_length=3, max_length=160)
    amount_toman = serializers.IntegerField(min_value=1)
    terms_acceptance_id = serializers.IntegerField(min_value=1, required=False)


class CampaignSerializer(serializers.ModelSerializer):
    class Meta:
        model = Campaign
        fields = [
            "id", "title", "budget_toman", "discount_pct", "cap_toman", "min_purchase_toman",
            "days", "seller_share_pct", "platform_share_pct", "brand_share_pct",
            "service_fee_toman", "is_active", "is_funded", "starts_at", "ends_at", "created_at",
        ]


class CampaignCreateSerializer(serializers.Serializer):
    title = serializers.CharField(min_length=3, max_length=120)
    budget_toman = serializers.IntegerField(min_value=1)
    discount_pct = serializers.IntegerField()
    cap_toman = serializers.IntegerField(min_value=1)
    min_purchase_toman = serializers.IntegerField(min_value=1)
    days = serializers.IntegerField(min_value=1, max_value=90)
    seller_share_pct = serializers.IntegerField(min_value=0, max_value=100)
    platform_share_pct = serializers.IntegerField(min_value=0, max_value=100)
    brand_share_pct = serializers.IntegerField(min_value=0, max_value=100)
    service_fee_toman = serializers.IntegerField(min_value=0, default=0)


class AdSerializer(serializers.ModelSerializer):
    class Meta:
        model = AdCampaign
        fields = ["id", "title", "placement", "budget_toman", "days", "is_active", "ends_at", "created_at"]


class AdCreateSerializer(serializers.Serializer):
    title = serializers.CharField(min_length=3, max_length=120)
    placement = serializers.ChoiceField(choices=AdCampaign.Placement.choices, default=AdCampaign.Placement.HOME)
    budget_toman = serializers.IntegerField(min_value=1)
    days = serializers.IntegerField(min_value=1, max_value=90)


class LaunchSerializer(serializers.Serializer):
    area = serializers.CharField(max_length=80, allow_blank=True)
    category = serializers.CharField(max_length=40, allow_blank=True)
