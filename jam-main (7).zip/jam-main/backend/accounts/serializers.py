from django.core.validators import validate_email
from rest_framework import serializers
from .models import normalize_phone

class OTPRequestSerializer(serializers.Serializer):
    identifier = serializers.CharField(max_length=254)

    def validate_identifier(self, value):
        value = value.strip()
        if "@" in value:
            try:
                validate_email(value)
            except Exception as exc:
                raise serializers.ValidationError("Enter a valid email or Iranian mobile number.") from exc
            return value.lower()
        try:
            return normalize_phone(value)
        except Exception as exc:
            raise serializers.ValidationError(exc.message) from exc

class OTPVerifySerializer(OTPRequestSerializer):
    code = serializers.RegexField(r"^\d{6}$", write_only=True)
