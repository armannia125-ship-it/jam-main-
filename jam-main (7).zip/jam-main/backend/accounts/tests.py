import json
from unittest.mock import patch, MagicMock
from django.test import TestCase, override_settings, tag
from rest_framework.test import APITestCase
from django.core.cache import cache
from django.contrib.auth import get_user_model

from datetime import timedelta
from django.utils import timezone

User = get_user_model()


class PasswordConfigurationTests(TestCase):
    def test_create_superuser_with_password_uses_valid_validator_config(self):
        user = User.objects.create_superuser(
            phone="09120000999", password="Runtime-Admin-Password-123"
        )
        self.assertTrue(user.is_staff)
        self.assertTrue(user.is_superuser)
        self.assertTrue(user.check_password("Runtime-Admin-Password-123"))


def _make_user(phone="+989121234567"):
    user = User.objects.create(phone=phone)
    user.set_unusable_password()
    user.save()
    return user


def _make_challenge(identifier="+989121234567", code_hash="abc123", expires_at=None, attempts=0, consumed_at=None):
    from .models import OTPChallenge
    if expires_at is None:
        expires_at = timezone.now() + timezone.timedelta(hours=1)
    challenge = OTPChallenge.objects.create(
        identifier=identifier,
        code_hash=code_hash,
        expires_at=expires_at,
        attempts=attempts,
        consumed_at=consumed_at,
    )
    return challenge


@override_settings(DEBUG=True, ALLOWED_HOSTS=["testserver", "127.0.0.1", "localhost"])
class OTPTests(APITestCase):
    def setUp(self):
        cache.clear()
        # Reset throttle state - delete specific cache keys used by AnonRateThrottle
        from django.core.cache import cache as _cache
        _cache.delete("throttle_otp_127.0.0.1")
        _cache.delete("throttle_otp::127.0.0.1")

    @patch("accounts.views._send_via_otpy")
    def test_phone_otp_verification_success(self, mock_send):
        # Mock OTPy send success
        mock_send.return_value = {"request_id": "req-123", "ttl_seconds": 300, "free": True}

        user = _make_user()
        result = self.client.post("/api/auth/request-otp/", {"identifier": "+989121234567"}, format="json")
        self.assertEqual(result.status_code, 200)

        # Mock OTPy verify success
        with patch("accounts.views._verify_via_otpy", return_value=True):
            result = self.client.post("/api/auth/verify-otp/", {"identifier": "+989121234567", "code": "123456"}, format="json")
        self.assertEqual(result.status_code, 200)
        self.assertIn("access", result.data)
        self.assertIn("refresh", result.data)
        self.assertIn("user", result.data)
        user = User.objects.get(phone="+989121234567")
        self.assertFalse(user.has_usable_password())

    @patch("accounts.views._send_via_otpy")
    def test_phone_otp_verification_invalid_code(self, mock_send):
        # Mock OTPy send success
        mock_send.return_value = {"request_id": "req-123", "ttl_seconds": 300, "free": True}

        user = _make_user()
        result = self.client.post("/api/auth/request-otp/", {"identifier": "+989121234567"}, format="json")
        self.assertEqual(result.status_code, 200)

        # Mock OTPy verify failure
        with patch("accounts.views._verify_via_otpy", return_value=False):
            result = self.client.post("/api/auth/verify-otp/", {"identifier": "+989121234567", "code": "000000"}, format="json")
        self.assertEqual(result.status_code, 400)
        self.assertNotIn("access", result.data)

    @patch("accounts.views._send_via_otpy")
    def test_phone_otp_verification_too_many_attempts(self, mock_send):
        # Mock OTPy send success
        mock_send.return_value = {"request_id": "req-123", "ttl_seconds": 300, "free": True}

        user = _make_user()
        result = self.client.post("/api/auth/request-otp/", {"identifier": "+989121234567"}, format="json")
        self.assertEqual(result.status_code, 200)

        # Mock OTPy verify failure multiple times (throttling may trigger before 5)
        with patch("accounts.views._verify_via_otpy", return_value=False):
            for _ in range(8):
                result = self.client.post("/api/auth/verify-otp/", {"identifier": "+989121234567", "code": "000000"}, format="json")
        # After too many attempts, should get either 400 or 429 (throttling)
        self.assertIn(result.status_code, [400, 429])

    @patch("accounts.views._send_via_otpy")
    def test_phone_otp_verification_user_not_found_after_fail(self, mock_send):
        # Mock OTPy send success
        mock_send.return_value = {"request_id": "req-123", "ttl_seconds": 300, "free": True}

        # Create user with different phone
        user = _make_user(phone="+989123456789")
        user.set_unusable_password()
        user.save()

        result = self.client.post("/api/auth/request-otp/", {"identifier": "+989123456789"}, format="json")
        self.assertEqual(result.status_code, 200)

        # Mock OTPy verify failure - should return 400 (invalid code), not 404
        with patch("accounts.views._verify_via_otpy", return_value=False):
            result = self.client.post("/api/auth/verify-otp/", {"identifier": "+989123456789", "code": "123456"}, format="json")
        # When verification fails, view returns 400
        self.assertEqual(result.status_code, 400)

    @patch("accounts.views._send_via_otpy")
    @patch("accounts.views._verify_via_otpy", return_value=False)
    def test_invalid_otp(self, mock_verify, mock_send):
        # Mock OTPy send success
        mock_send.return_value = {"request_id": "req-123", "ttl_seconds": 300, "free": True}

        # Create user first so verify-otp finds a registered user
        user = _make_user()
        user.set_unusable_password()
        user.save()

        result = self.client.post("/api/auth/request-otp/", {"identifier": "+989121234567"}, format="json")
        self.assertEqual(result.status_code, 200)
        # Mock OTPy verify failure (invalid code) - now returns 400 because user exists
        result = self.client.post("/api/auth/verify-otp/", {"identifier": "+989121234567", "code": "123456"}, format="json")
        self.assertEqual(result.status_code, 400)
        self.assertEqual(result.data["detail"], "Invalid or expired verification code.")

    @patch("accounts.views._send_via_otpy")
    @patch("accounts.views._verify_via_otpy", return_value=False)
    def test_verify_otp_not_registered_phone(self, mock_verify, mock_send):
        # Mock OTPy send success
        mock_send.return_value = {"request_id": "req-123", "ttl_seconds": 300, "free": True}

        # No user exists for this phone - verify-otp now returns 404 before calling provider
        result = self.client.post("/api/auth/request-otp/", {"identifier": "+989999999999"}, format="json")
        self.assertEqual(result.status_code, 200)
        # Unregistered phone → 404 (not 400) because user lookup happens before provider call
        result = self.client.post("/api/auth/verify-otp/", {"identifier": "+989999999999", "code": "123456"}, format="json")
        self.assertEqual(result.status_code, 404)
        self.assertEqual(result.data["detail"], "This phone number is not registered. Please sign up first.")

    @patch("accounts.views._send_via_otpy")
    def test_jwt_response_fields(self, mock_send):
        # Mock OTPy send success
        mock_send.return_value = {"request_id": "req-123", "ttl_seconds": 300, "free": True}

        user = _make_user()
        result = self.client.post("/api/auth/request-otp/", {"identifier": "+989121234567"}, format="json")
        self.assertEqual(result.status_code, 200)

        with patch("accounts.views._verify_via_otpy", return_value=True):
            result = self.client.post("/api/auth/verify-otp/", {"identifier": "+989121234567", "code": "123456"}, format="json")
        self.assertEqual(result.status_code, 200)
        self.assertIn("access", result.data)
        self.assertIn("refresh", result.data)
        self.assertIn("user", result.data)
        user = result.data["user"]
        self.assertIn("id", user)
        self.assertIn("phone", user)
        self.assertIn("email", user)

    @patch("accounts.views._send_via_otpy")
    def test_invalid_phone_format(self, mock_send):
        result = self.client.post("/api/auth/request-otp/", {"identifier": "123"}, format="json")
        self.assertEqual(result.status_code, 400)

    @patch("accounts.views._send_via_otpy")
    def test_otp_provider_unavailable(self, mock_send):
        # Mock OTPy send failure (connection error)
        mock_send.return_value = {"error": "Connection refused", "status_code": None}

        result = self.client.post("/api/auth/request-otp/", {"identifier": "+989121234567"}, format="json")
        # Should fail closed - not report success when provider is down
        self.assertIn(result.status_code, [502, 503])

    @patch("accounts.views._send_via_otpy")
    def test_otp_provider_unauthorized(self, mock_send):
        # Mock OTPy send failure (401 unauthorized)
        mock_send.return_value = {"error": "Invalid API key", "status_code": 401}

        result = self.client.post("/api/auth/request-otp/", {"identifier": "+989121234567"}, format="json")
        # Should return 503 with proper error message
        self.assertEqual(result.status_code, 503)
        self.assertEqual(result.data["detail"], "Invalid OTP provider credentials.")

    @patch("accounts.views._verify_via_otpy")
    @override_settings(DEBUG=True)
    def test_verify_otp_bypass_throttle_in_debug(self, mock_verify):
        # Mock OTPy verify success
        mock_verify.return_value = True

        # Also mock OTPy send success
        with patch("accounts.views._send_via_otpy") as mock_send:
            mock_send.return_value = {"request_id": "req-123", "ttl_seconds": 300, "free": True}

            # Create user first
            user = _make_user()
            user.set_unusable_password()
            user.save()

            # Make many requests to exceed the 5/hour throttle
            for _ in range(10):
                result = self.client.post("/api/auth/request-otp/", {"identifier": "+989121234567"}, format="json")
            # In DEBUG, throttle is bypassed so should still get 200
            self.assertEqual(result.status_code, 200)

    @patch("accounts.views._send_via_otpy")
    @override_settings(DEBUG=False)
    def test_verify_otp_throttle_enforced_in_production(self, mock_send):
        # Mock OTPy send success
        mock_send.return_value = {"request_id": "req-123", "ttl_seconds": 300, "free": True}

        # Create user first
        user = _make_user()
        user.set_unusable_password()
        user.save()

        # Make many requests to exceed the 5/hour throttle
        for _ in range(10):
            result = self.client.post("/api/auth/request-otp/", {"identifier": "+989121234567"}, format="json")
        # In production (DEBUG=False), throttle should return 429
        self.assertEqual(result.status_code, 429)

    @patch("accounts.views._verify_via_otpy")
    @override_settings(DEBUG=True)
    def test_verify_otp_missing_challenge(self, mock_verify):
        # No challenge exists for this identifier
        mock_verify.return_value = True

        # Create user first so verify-otp doesn't return 404 before checking challenge
        user = _make_user()
        user.set_unusable_password()
        user.save()

        result = self.client.post("/api/auth/verify-otp/", {"identifier": "+989121234567", "code": "123456"}, format="json")
        # No pending challenge → 400 (user exists but no challenge)
        self.assertEqual(result.status_code, 400)
        self.assertEqual(result.data["detail"], "No pending verification code.")

    @patch("accounts.views._verify_via_otpy")
    @override_settings(DEBUG=True)
    def test_verify_otp_expired_challenge(self, mock_verify):
        from django.utils import timezone
        from datetime import timedelta
        from .models import OTPChallenge
        user = _make_user()
        user.set_unusable_password()
        user.save()
        challenge = _make_challenge(expires_at=timezone.now() - timedelta(hours=1))
        challenge.save()

        mock_verify.return_value = True

        result = self.client.post("/api/auth/verify-otp/", {"identifier": "+989121234567", "code": "123456"}, format="json")
        # Expired challenge (even if OTPy would accept) → 400
        self.assertEqual(result.status_code, 400)
        self.assertEqual(result.data["detail"], "No pending verification code.")

    @patch("accounts.views._verify_via_otpy")
    @override_settings(DEBUG=True)
    def test_verify_otp_consumed_challenge(self, mock_verify):
        from django.utils import timezone
        from datetime import timedelta
        from .models import OTPChallenge
        user = _make_user()
        user.set_unusable_password()
        user.save()
        challenge = _make_challenge(consumed_at=timezone.now())
        challenge.save()

        mock_verify.return_value = True

        result = self.client.post("/api/auth/verify-otp/", {"identifier": "+989121234567", "code": "123456"}, format="json")
        # Consumed challenge → 400
        self.assertEqual(result.status_code, 400)
        self.assertEqual(result.data["detail"], "No pending verification code.")

    @patch("accounts.views._verify_via_otpy")
    @override_settings(DEBUG=True)
    def test_verify_otp_attempt_limit_exceeded(self, mock_verify):
        from django.utils import timezone
        from datetime import timedelta
        from .models import OTPChallenge
        user = _make_user()
        user.set_unusable_password()
        user.save()
        challenge = _make_challenge(attempts=5)
        challenge.save()

        mock_verify.return_value = True

        result = self.client.post("/api/auth/verify-otp/", {"identifier": "+989121234567", "code": "123456"}, format="json")
        # attempts >= 5 → 400 (no pending verification code)
        self.assertEqual(result.status_code, 400)
        self.assertEqual(result.data["detail"], "No pending verification code.")

    @patch("accounts.views._verify_via_otpy")
    @override_settings(DEBUG=True)
    def test_verify_otp_invalid_code_otpy_returns_false(self, mock_verify):
        # First create a valid challenge so the lookup succeeds
        from django.utils import timezone
        from datetime import timedelta
        from .models import OTPChallenge
        user = _make_user()
        user.set_unusable_password()
        user.save()
        _make_challenge(expires_at=timezone.now() + timedelta(hours=1))

        # OTPy returns verified=False with invalid code
        mock_verify.return_value = False

        result = self.client.post("/api/auth/verify-otp/", {"identifier": "+989121234567", "code": "000000"}, format="json")
        # OTPy says invalid → 400
        self.assertEqual(result.status_code, 400)
        self.assertEqual(result.data["detail"], "Invalid or expired verification code.")

    @patch("accounts.views._verify_via_otpy")
    @override_settings(DEBUG=True)
    def test_verify_otp_success_with_valid_code(self, mock_verify):
        # OTPy returns verified=True with valid code
        mock_verify.return_value = True

        # Create user first with phone matching the identifier
        user = _make_user(phone="+989121234567")
        user.set_unusable_password()
        user.save()

        # Create a valid challenge for this user
        _make_challenge(identifier="+989121234567", expires_at=timezone.now() + timezone.timedelta(hours=1))

        result = self.client.post("/api/auth/verify-otp/", {"identifier": "+989121234567", "code": "123456"}, format="json")
        # OTPy verifies → JWT issued
        self.assertEqual(result.status_code, 200)
        self.assertIn("access", result.data)
        self.assertIn("refresh", result.data)
        self.assertIn("user", result.data)
        self.assertIn("phone", result.data["user"])

    @patch("accounts.views._verify_via_otpy")
    @override_settings(DEBUG=True)
    def test_verify_otp_phone_vs_normalized_number_consistency(self, mock_verify):
        # Test that phone number normalization is consistent between request and verification
        mock_verify.return_value = {"verified": True}

        # Create user with properly normalized phone matching the test number
        # 09215383398 normalizes to +989215383398
        user = _make_user(phone="+989215383398")
        user.set_unusable_password()
        user.save()
        # Create challenge with the normalized identifier
        _make_challenge(identifier="+989215383398")

        # Request with leading zero gets normalized to +98 format
        # 09215383398 → +989215383398 which matches user phone
        result = self.client.post("/api/auth/verify-otp/", {"identifier": "09215383398", "code": "123456"}, format="json")
        # Should work: 09215383398 normalizes to +989215383398 which matches user
        self.assertEqual(result.status_code, 200)
        self.assertIn("access", result.data)

    @patch("accounts.views._verify_via_otpy")
    @override_settings(DEBUG=True)
    def test_verify_otp_wrong_number_format_rejected(self, mock_verify):
        # Request with invalid phone format is rejected by serializer before OTPy call
        mock_verify.return_value = {"verified": True}

        result = self.client.post("/api/auth/verify-otp/", {"identifier": "12345", "code": "123456"}, format="json")
        # Invalid phone format → 400 from serializer
        self.assertEqual(result.status_code, 400)

    @patch("accounts.views._verify_via_otpy")
    @patch("accounts.views._send_via_otpy")
    @override_settings(DEBUG=False)
    def test_verify_otp_production_throttle_then_success(self, mock_send, mock_verify):
        # In production, requests should be throttled after the limit
        mock_send.return_value = {"request_id": "req-123", "ttl_seconds": 300, "free": True}
        mock_verify.return_value = True

        user = _make_user()
        user.set_unusable_password()
        user.save()

        # Make many requests - the throttle should eventually be enforced
        results = []
        for _ in range(10):
            result = self.client.post("/api/auth/request-otp/", {"identifier": "+989121234567"}, format="json")
            results.append(result.status_code)
            # Stop early if throttle is enforced
            if result.status_code == 429:
                break

        # Verify that the throttle was enforced at some point during the 10 requests
        # (the exact request that gets 429 may vary due to test infrastructure cache state)
        self.assertIn(429, results)

    @patch("accounts.views._verify_via_otpy")
    @patch("accounts.views._send_via_otpy")
    @override_settings(DEBUG=False)
    def test_verify_otp_production_throttle_with_429_provider(self, mock_send, mock_verify):
        # In production with OTPy returning 429, that should take precedence
        mock_send.return_value = {"error": "Too many requests", "status_code": 429}
        mock_verify.return_value = True

        user = _make_user()
        user.set_unusable_password()
        user.save()

        result = self.client.post("/api/auth/request-otp/", {"identifier": "+989121234567"}, format="json")
        # Provider 429 → 429, even in production
        self.assertEqual(result.status_code, 429)
        self.assertEqual(result.data["detail"], "Too many requests to OTP provider.")

    @patch("accounts.views._send_via_otpy")
    def test_verify_otp_provider_429(self, mock_send):
        # Mock OTPy send returning 429
        mock_send.return_value = {"error": "Too many requests", "status_code": 429}

        result = self.client.post("/api/auth/request-otp/", {"identifier": "+989121234567"}, format="json")
        # Provider 429 should be reported as 429
        self.assertEqual(result.status_code, 429)
        self.assertEqual(result.data["detail"], "Too many requests to OTP provider.")


@override_settings(DEBUG=True, ALLOWED_HOSTS=["testserver", "127.0.0.1", "localhost"])
class SignupTests(APITestCase):
    def setUp(self):
        cache.clear()
        from django.core.cache import cache as _cache
        _cache.delete("throttle_otp_127.0.0.1")
        _cache.delete("throttle_otp::127.0.0.1")

    def test_signup_url_accepts_both_with_and_without_trailing_slash(self):
        # Both URL forms must resolve to SignupView (compatibility fix for browser URL normalisation)
        from django.urls import resolve
        from .views import SignupView
        resolved_with_slash = resolve("/api/auth/signup/")
        self.assertEqual(resolved_with_slash.func.view_class, SignupView)
        resolved_without_slash = resolve("/api/auth/signup")
        self.assertEqual(resolved_without_slash.func.view_class, SignupView)

    @patch("accounts.views._verify_via_otpy")
    def test_signup_creates_user(self, mock_verify):
        # Mock OTPy verification success
        mock_verify.return_value = True

        # No user exists yet — test with trailing slash
        result = self.client.post("/api/auth/signup/", {"identifier": "+989123456789", "code": "123456"}, format="json")
        self.assertEqual(result.status_code, 201)
        self.assertIn("access", result.data)
        self.assertIn("refresh", result.data)
        self.assertIn("verified", result.data)
        self.assertTrue(result.data["verified"])
        user = User.objects.get(phone="+989123456789")
        self.assertFalse(user.has_usable_password())
        # Also test without trailing slash — same result
        result2 = self.client.post("/api/auth/signup", {"identifier": "+989123456790", "code": "123456"}, format="json")
        self.assertEqual(result2.status_code, 201)
        self.assertIn("access", result2.data)
        self.assertIn("refresh", result2.data)
        self.assertIn("verified", result2.data)
        self.assertTrue(result2.data["verified"])
        user2 = User.objects.get(phone="+989123456790")
        self.assertFalse(user2.has_usable_password())

    def test_signup_duplicate_phone_rejected(self):
        # Create existing user
        user = _make_user(phone="+989123456789")
        user.set_unusable_password()
        user.save()

        result = self.client.post("/api/auth/signup/", {"identifier": "+989123456789"}, format="json")
        self.assertEqual(result.status_code, 400)
        self.assertEqual(result.data["detail"], "This phone number is already registered. Please log in.")

    def test_signup_invalid_phone_format_rejected(self):
        result = self.client.post("/api/auth/signup/", {"identifier": "123"}, format="json")
        self.assertEqual(result.status_code, 400)

    def test_signup_email_not_supported(self):
        result = self.client.post("/api/auth/signup/", {"identifier": "test@example.com"}, format="json")
        self.assertEqual(result.status_code, 400)
        self.assertEqual(result.data["detail"], "Email sign-up is not available. Please use a phone number.")

    @patch("accounts.views._verify_via_otpy")
    def test_signup_with_invalid_otp_rejected(self, mock_verify):
        # Mock OTPy verification failure
        mock_verify.return_value = False
        result = self.client.post("/api/auth/signup/", {"identifier": "+989123456789", "code": "000000"}, format="json")
        self.assertEqual(result.status_code, 400)
        self.assertEqual(result.data["detail"], "Invalid or expired verification code.")

    @patch("accounts.views._verify_via_otpy")
    def test_signup_with_transport_error_rejected(self, mock_verify):
        # Mock OTPy transport error
        mock_verify.return_value = None
        result = self.client.post("/api/auth/signup/", {"identifier": "+989123456789", "code": "123456"}, format="json")
        self.assertEqual(result.status_code, 502)
        self.assertEqual(result.data["detail"], "OTP verification service is temporarily unavailable.")

    @patch("accounts.views._verify_via_otpy")
    def test_signup_existing_phone_with_valid_otp_still_rejected(self, mock_verify):
        # Create existing user first
        user = _make_user(phone="+989123456789")
        user.set_unusable_password()
        user.save()
        # Even with valid OTP, existing phone should be rejected
        mock_verify.return_value = True
        result = self.client.post("/api/auth/signup/", {"identifier": "+989123456789", "code": "123456"}, format="json")
        self.assertEqual(result.status_code, 400)
        self.assertEqual(result.data["detail"], "This phone number is already registered. Please log in.")

    @patch("accounts.views._verify_via_otpy")
    def test_signup_new_phone_with_valid_otp_creates_account(self, mock_verify):
        # Mock OTPy verification success
        mock_verify.return_value = True
        # No user exists yet
        result = self.client.post("/api/auth/signup/", {"identifier": "+989123456789", "code": "123456"}, format="json")
        self.assertEqual(result.status_code, 201)
        self.assertIn("access", result.data)
        self.assertIn("refresh", result.data)
        self.assertIn("verified", result.data)
        self.assertTrue(result.data["verified"])
        user = User.objects.get(phone="+989123456789")
        self.assertFalse(user.has_usable_password())

    @patch("accounts.views._verify_via_otpy")
    @patch("accounts.views._send_via_otpy")
    def test_login_with_unregistered_phone_still_rejected(self, mock_send, mock_verify):
        # Verify that login with unregistered phone still returns 404
        # Set up: first request OTP, then verify with unregistered phone
        mock_send.return_value = {"request_id": "req-123", "ttl_seconds": 300, "free": True}
        mock_verify.return_value = True

        # Request OTP first (creates challenge)
        result = self.client.post("/api/auth/request-otp/", {"identifier": "+989999999999"}, format="json")
        self.assertEqual(result.status_code, 200)

        # Now verify with the code - OTPy verifies successfully but user not registered
        result = self.client.post("/api/auth/verify-otp/", {"identifier": "+989999999999", "code": "123456"}, format="json")
        # OTPy verified but user doesn't exist → 404
        self.assertEqual(result.status_code, 404)
        self.assertEqual(result.data["detail"], "This phone number is not registered. Please sign up first.")

    @patch("accounts.views._verify_via_otpy")
    @patch("accounts.views._send_via_otpy")
    def test_verify_otp_unregistered_phone_no_provider_call(self, mock_send, mock_verify):
        # Confirm that unregistered identifiers do NOT trigger provider verification
        # in VerifyOTPView (avoids unnecessary provider calls and potential
        # single-use code consumption).
        mock_send.return_value = {"request_id": "req-123", "ttl_seconds": 300, "free": True}

        # Request OTP first (creates challenge for unregistered phone)
        result = self.client.post("/api/auth/request-otp/", {"identifier": "+989999999999"}, format="json")
        self.assertEqual(result.status_code, 200)

        # Verify with unregistered phone - should return 404 WITHOUT calling provider
        result = self.client.post("/api/auth/verify-otp/", {"identifier": "+989999999999", "code": "123456"}, format="json")
        self.assertEqual(result.status_code, 404)
        self.assertEqual(result.data["detail"], "This phone number is not registered. Please sign up first.")
        # Provider should NOT have been called
        mock_verify.assert_not_called()

    @patch("accounts.views._verify_via_otpy")
    @patch("accounts.views._send_via_otpy")
    def test_verify_otp_registered_phone_still_requires_provider_verification(self, mock_send, mock_verify):
        # Confirm that registered identifiers still require successful provider
        # verification before JWT issuance.
        mock_send.return_value = {"request_id": "req-123", "ttl_seconds": 300, "free": True}
        mock_verify.return_value = True

        # Create registered user
        user = _make_user(phone="+989121234567")
        user.set_unusable_password()
        user.save()

        # Request OTP
        result = self.client.post("/api/auth/request-otp/", {"identifier": "+989121234567"}, format="json")
        self.assertEqual(result.status_code, 200)

        # Verify with valid code - provider MUST be called and succeed
        result = self.client.post("/api/auth/verify-otp/", {"identifier": "+989121234567", "code": "123456"}, format="json")
        self.assertEqual(result.status_code, 200)
        self.assertIn("access", result.data)
        self.assertIn("refresh", result.data)
        # Provider was called
        mock_verify.assert_called_once_with("+989121234567", "123456")

    @patch("accounts.views._verify_via_otpy")
    @patch("accounts.views._send_via_otpy")
    def test_verify_otp_registered_phone_invalid_code_still_rejected(self, mock_send, mock_verify):
        # Confirm that registered users with invalid codes are still rejected
        mock_send.return_value = {"request_id": "req-123", "ttl_seconds": 300, "free": True}
        mock_verify.return_value = False

        # Create registered user
        user = _make_user(phone="+989121234567")
        user.set_unusable_password()
        user.save()

        # Request OTP
        result = self.client.post("/api/auth/request-otp/", {"identifier": "+989121234567"}, format="json")
        self.assertEqual(result.status_code, 200)

        # Verify with invalid code - should be rejected
        result = self.client.post("/api/auth/verify-otp/", {"identifier": "+989121234567", "code": "000000"}, format="json")
        self.assertEqual(result.status_code, 400)
        self.assertEqual(result.data["detail"], "Invalid or expired verification code.")
        # Provider was called (to verify the code)
        mock_verify.assert_called_once()

    @patch("accounts.views._verify_via_otpy")
    def test_signup_still_performs_own_provider_verification(self, mock_verify):
        # Confirm that SignupView independently verifies the OTP with the provider
        # (does not trust any prior verification from VerifyOTPView).
        mock_verify.return_value = True

        # Signup with valid code - should verify with provider and create account
        result = self.client.post("/api/auth/signup/", {"identifier": "+989123456789", "code": "123456"}, format="json")
        self.assertEqual(result.status_code, 201)
        self.assertIn("access", result.data)
        self.assertIn("refresh", result.data)
        self.assertTrue(result.data["verified"])
        # Provider was called by signup
        mock_verify.assert_called_once_with("+989123456789", "123456")

    @patch("accounts.views._verify_via_otpy")
    def test_signup_still_rejects_invalid_otp(self, mock_verify):
        # Confirm that SignupView rejects invalid OTP independent of VerifyOTPView
        mock_verify.return_value = False

        result = self.client.post("/api/auth/signup/", {"identifier": "+989123456789", "code": "000000"}, format="json")
        self.assertEqual(result.status_code, 400)
        self.assertEqual(result.data["detail"], "Invalid or expired verification code.")
        mock_verify.assert_called_once()

    @patch("accounts.views._verify_via_otpy")
    @patch("accounts.views._send_via_otpy")
    def test_verify_otp_challenge_edge_cases_still_rejected(self, mock_send, mock_verify):
        # Confirm that expired, consumed, and exhausted challenges are still rejected
        # regardless of user registration status or provider verification result.
        mock_send.return_value = {"request_id": "req-123", "ttl_seconds": 300, "free": True}
        mock_verify.return_value = True

        # Create registered user
        user = _make_user(phone="+989121234567")
        user.set_unusable_password()
        user.save()

        # Test expired challenge
        from datetime import timedelta
        _make_challenge(identifier="+989121234567", expires_at=timezone.now() - timedelta(hours=1))
        result = self.client.post("/api/auth/verify-otp/", {"identifier": "+989121234567", "code": "123456"}, format="json")
        self.assertEqual(result.status_code, 400)
        self.assertEqual(result.data["detail"], "No pending verification code.")
        mock_verify.assert_not_called()

        # Test consumed challenge
        _make_challenge(identifier="+989121234567", consumed_at=timezone.now())
        result = self.client.post("/api/auth/verify-otp/", {"identifier": "+989121234567", "code": "123456"}, format="json")
        self.assertEqual(result.status_code, 400)
        self.assertEqual(result.data["detail"], "No pending verification code.")
        mock_verify.assert_not_called()

        # Test exhausted challenge
        _make_challenge(identifier="+989121234567", attempts=5)
        result = self.client.post("/api/auth/verify-otp/", {"identifier": "+989121234567", "code": "123456"}, format="json")
        self.assertEqual(result.status_code, 400)
        self.assertEqual(result.data["detail"], "No pending verification code.")
        mock_verify.assert_not_called()


@override_settings(DEBUG=True, ALLOWED_HOSTS=["testserver", "127.0.0.1", "localhost"])
class OTPyResponseParsingTests(APITestCase):
    """Tests for _sanitize_otpy_response diagnostic helper.

    These tests verify that the sanitized diagnostic category is correct
    for various provider response shapes, without leaking sensitive data.
    """

    def test_sanitize_verified_true(self):
        from accounts.views import _sanitize_otpy_response
        result = _sanitize_otpy_response({"verified": True, "request_id": "abc"})
        self.assertEqual(result, "verified-true")

    def test_sanitize_missing_verified_key(self):
        from accounts.views import _sanitize_otpy_response
        # Provider returned 200 but without verified key
        result = _sanitize_otpy_response({"success": True, "message": "ok"})
        self.assertEqual(result, "provider-200-no-verified-true")

    def test_sanitize_verified_false(self):
        from accounts.views import _sanitize_otpy_response
        result = _sanitize_otpy_response({"verified": False, "message": "invalid code"})
        self.assertEqual(result, "provider-200-no-verified-true")

    def test_sanitize_401_auth_error(self):
        from accounts.views import _sanitize_otpy_response
        result = _sanitize_otpy_response({"error": "Invalid API key", "status_code": 401})
        self.assertEqual(result, "provider-401-auth")

    def test_sanitize_403_forbidden(self):
        from accounts.views import _sanitize_otpy_response
        result = _sanitize_otpy_response({"error": "Forbidden", "status_code": 403})
        self.assertEqual(result, "provider-403-forbidden")

    def test_sanitize_404_not_found(self):
        from accounts.views import _sanitize_otpy_response
        result = _sanitize_otpy_response({"error": "Not found", "status_code": 404})
        self.assertEqual(result, "provider-404-not-found")

    def test_sanitize_429_rate_limited(self):
        from accounts.views import _sanitize_otpy_response
        result = _sanitize_otpy_response({"error": "Rate limited", "status_code": 429})
        self.assertEqual(result, "provider-429-rate-limited")

    def test_sanitize_500_server_error(self):
        from accounts.views import _sanitize_otpy_response
        result = _sanitize_otpy_response({"error": "Internal error", "status_code": 500})
        self.assertEqual(result, "provider-5xx")

    def test_sanitize_502_bad_gateway(self):
        from accounts.views import _sanitize_otpy_response
        result = _sanitize_otpy_response({"error": "Bad gateway", "status_code": 502})
        self.assertEqual(result, "provider-5xx")

    def test_sanitize_other_4xx(self):
        from accounts.views import _sanitize_otpy_response
        result = _sanitize_otpy_response({"error": "Bad request", "status_code": 400})
        self.assertEqual(result, "provider-4xx-other")

    def test_sanitize_connection_error(self):
        from accounts.views import _sanitize_otpy_response
        result = _sanitize_otpy_response({
            "error": "Connection refused",
            "status_code": None,
        })
        self.assertEqual(result, "connection-error")

    def test_sanitize_timeout_error(self):
        from accounts.views import _sanitize_otpy_response
        result = _sanitize_otpy_response({
            "error": "The read operation timed out",
            "status_code": None,
        })
        self.assertEqual(result, "timeout-error")

    def test_sanitize_tls_error(self):
        from accounts.views import _sanitize_otpy_response
        result = _sanitize_otpy_response({
            "error": "CERTIFICATE_VERIFY_FAILED",
            "status_code": None,
        })
        self.assertEqual(result, "tls-ssl-error")

    def test_sanitize_dns_error(self):
        from accounts.views import _sanitize_otpy_response
        result = _sanitize_otpy_response({
            "error": "Name or service not known",
            "status_code": None,
        })
        self.assertEqual(result, "dns-error")

    def test_sanitize_transport_error_unknown(self):
        from accounts.views import _sanitize_otpy_response
        result = _sanitize_otpy_response({
            "error": "Some obscure network error",
            "status_code": None,
        })
        self.assertEqual(result, "transport-error-unknown")

    def test_sanitize_non_dict_response(self):
        from accounts.views import _sanitize_otpy_response
        result = _sanitize_otpy_response("not-a-dict")
        self.assertEqual(result, "non-dict-response")

    def test_sanitize_empty_dict(self):
        from accounts.views import _sanitize_otpy_response
        result = _sanitize_otpy_response({})
        self.assertEqual(result, "provider-200-no-verified-true")


@override_settings(DEBUG=True, ALLOWED_HOSTS=["testserver", "127.0.0.1", "localhost"])
class TokenRefreshTests(APITestCase):
    def setUp(self):
        self.user = _make_user()
        from rest_framework_simplejwt.tokens import RefreshToken

        self.refresh = RefreshToken.for_user(self.user)

    def test_refresh_returns_usable_access_token(self):
        response = self.client.post(
            "/api/auth/refresh/", {"refresh": str(self.refresh)}, format="json"
        )
        self.assertEqual(response.status_code, 200)
        self.assertIn("access", response.data)
        self.assertIn("refresh", response.data)
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {response.data['access']}")
        protected = self.client.get("/api/commerce/orders/mine/")
        self.assertEqual(protected.status_code, 200)

    def test_invalid_refresh_is_rejected(self):
        response = self.client.post(
            "/api/auth/refresh/", {"refresh": "not-a-token"}, format="json"
        )
        self.assertEqual(response.status_code, 401)
