from django.urls import path, re_path
from rest_framework_simplejwt.views import TokenRefreshView

from . import views


urlpatterns = [
    path("refresh/", TokenRefreshView.as_view(), name="token-refresh"),
    re_path(r"^request-otp/?$", views.RequestOTPView.as_view(), name="request-otp"),
    re_path(r"^verify-otp/?$", views.VerifyOTPView.as_view(), name="verify-otp"),
    re_path(r"^signup/?$", views.SignupView.as_view(), name="signup"),
    path("me/", views.MeView.as_view(), name="auth-me"),
]
