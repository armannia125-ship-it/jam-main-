"""Admin RBAC, provisioning, and audit tests.

Covers: make_admin command semantics, server-side role enforcement (normal
users get 401/403 on every admin API), promotion/demotion rules including
last-admin protection, real-data dashboard aggregates, and audit logging.
"""

from io import StringIO

from django.core.management import call_command
from django.core.management.base import CommandError
from django.urls import reverse
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APITestCase

from accounts.models import AdminAction, User
from businesses.models import Business
from subscriptions.models import (
    SubscriptionEntitlement,
    SubscriptionProduct,
    SubscriptionPurchase,
)


def _make_user(phone, **extra):
    return User.objects.create_user(phone=phone, **extra)


class MakeAdminCommandTests(APITestCase):
    def test_promotes_existing_user_only(self):
        user = _make_user("09120000101")
        out = StringIO()
        call_command("make_admin", "--phone", "09120000101", stdout=out)
        user.refresh_from_db()
        self.assertEqual(user.role, User.Role.ADMIN)
        self.assertTrue(AdminAction.objects.filter(action="admin_promoted", target_id=str(user.pk)).exists())

    def test_never_creates_missing_user(self):
        with self.assertRaises(CommandError):
            call_command("make_admin", "--phone", "09129999999", stdout=StringIO())
        self.assertEqual(User.objects.filter(phone="09129999999").count(), 0)

    def test_idempotent_promotion(self):
        user = _make_user("09120000102")
        call_command("make_admin", "--phone", "09120000102", stdout=StringIO())
        call_command("make_admin", "--phone", "09120000102", stdout=StringIO())
        user.refresh_from_db()
        self.assertEqual(user.role, User.Role.ADMIN)

    def test_refuses_to_demote_last_admin(self):
        user = _make_user("09120000103")
        call_command("make_admin", "--phone", "09120000103", stdout=StringIO())
        with self.assertRaises(CommandError):
            call_command("make_admin", "--phone", "09120000103", "--demote", stdout=StringIO())
        user.refresh_from_db()
        self.assertEqual(user.role, User.Role.ADMIN)

    def test_demote_records_audit(self):
        first = _make_user("09120000104")
        second = _make_user("09120000105")
        call_command("make_admin", "--phone", "09120000104", stdout=StringIO())
        call_command("make_admin", "--phone", "09120000105", stdout=StringIO())
        call_command("make_admin", "--phone", "09120000105", "--demote", stdout=StringIO())
        second.refresh_from_db()
        self.assertEqual(second.role, User.Role.USER)
        self.assertTrue(AdminAction.objects.filter(action="admin_demoted", target_id=str(second.pk)).exists())

    def test_inactive_user_cannot_be_promoted(self):
        user = _make_user("09120000106")
        user.is_active = False
        user.save(update_fields=["is_active"])
        with self.assertRaises(CommandError):
            call_command("make_admin", "--phone", "09120000106", stdout=StringIO())


class AdminRBACTests(APITestCase):
    ENDPOINTS = [
        "/api/admin/overview/",
        "/api/admin/users/",
        "/api/admin/payments/",
        "/api/admin/subscriptions/",
        "/api/admin/audit/",
    ]

    def setUp(self):
        self.admin = _make_user("09120000201", role=User.Role.ADMIN)
        self.normal = _make_user("09120000202")

    def test_admin_sees_endpoints(self):
        self.client.force_authenticate(self.admin)
        for url in self.ENDPOINTS:
            response = self.client.get(url)
            self.assertEqual(response.status_code, 200, url)

    def test_normal_user_is_denied_everywhere(self):
        self.client.force_authenticate(self.normal)
        for url in self.ENDPOINTS:
            response = self.client.get(url)
            self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN, url)

    def test_anonymous_is_denied(self):
        for url in self.ENDPOINTS:
            response = self.client.get(url)
            self.assertIn(response.status_code, (status.HTTP_401_UNAUTHORIZED, status.HTTP_403_FORBIDDEN), url)

    def test_normal_user_cannot_promote_anyone(self):
        self.client.force_authenticate(self.normal)
        response = self.client.post(f"/api/admin/users/{self.normal.pk}/role/promote/")
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
        self.normal.refresh_from_db()
        self.assertEqual(self.normal.role, User.Role.USER)

    def test_admin_cannot_demote_self(self):
        self.client.force_authenticate(self.admin)
        response = self.client.post(f"/api/admin/users/{self.admin.pk}/role/demote/")
        if response.status_code != 409:
            print("DBG:", response.status_code, response.data, getattr(response.request or {}, "PATH_INFO", None))
        self.assertEqual(response.status_code, status.HTTP_409_CONFLICT)
        self.admin.refresh_from_db()
        self.assertEqual(self.admin.role, User.Role.ADMIN)

    def test_admin_promotes_and_last_admin_protected(self):
        self.client.force_authenticate(self.admin)
        ok = self.client.post(f"/api/admin/users/{self.normal.pk}/role/promote/")
        self.assertEqual(ok.status_code, 200)
        self.normal.refresh_from_db()
        self.assertEqual(self.normal.role, User.Role.ADMIN)
        # Two admins now: demoting one is fine, but self-demotion still blocked.
        response = self.client.post(f"/api/admin/users/{self.normal.pk}/role/demote/")
        self.assertEqual(response.status_code, 200)
        # Back to a single admin — demote must be refused.
        response = self.client.post(f"/api/admin/users/{self.normal.pk}/role/demote/")
        self.assertEqual(response.status_code, status.HTTP_409_CONFLICT)
        self.assertTrue(AdminAction.objects.filter(action="admin_promoted").exists())
        self.assertTrue(AdminAction.objects.filter(action="admin_demoted").exists())


class AdminDashboardDataTests(APITestCase):
    def setUp(self):
        self.admin = _make_user("09120000301", role=User.Role.ADMIN)
        self.owner = _make_user("09120000302")
        self.business = Business.objects.create(owner=self.owner, name="Shop", slug="shop")
        self.product = SubscriptionProduct.objects.get(slug="premium")
        self.purchase = SubscriptionPurchase.objects.create(
            user=self.owner,
            business=self.business,
            product=self.product,
            price_toman=self.product.price_toman,
            status=SubscriptionPurchase.Status.PAID,
            confirmed_at=timezone.now(),
        )
        SubscriptionEntitlement.objects.create(
            user=self.owner,
            business=self.business,
            entitlement_type=SubscriptionEntitlement.Type.MENU,
            product=self.product,
            purchase=self.purchase,
            starts_at=timezone.now(),
            ends_at=timezone.now() + timezone.timedelta(days=30),
        )

    def test_overview_uses_real_data(self):
        self.client.force_authenticate(self.admin)
        response = self.client.get("/api/admin/overview/")
        data = response.json()
        self.assertEqual(data["users_total"], 2)
        self.assertEqual(data["menu_entitlements_active"], 1)
        self.assertEqual(len(data["recent_purchases"]), 1)
        self.assertEqual(data["recent_purchases"][0]["price_toman"], 350000)

    def test_user_detail_scopes_payments(self):
        other = _make_user("09120000303")
        self.client.force_authenticate(self.admin)
        response = self.client.get(f"/api/admin/users/{other.pk}/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["payments"], [])
        self.assertEqual(response.json()["entitlements"], [])

    def test_entitlement_revocation_is_audited(self):
        ent = SubscriptionEntitlement.objects.first()
        self.client.force_authenticate(self.admin)
        response = self.client.post(f"/api/admin/entitlements/{ent.pk}/revoke/", {"reason": "test"}, format="json")
        self.assertEqual(response.status_code, 200)
        ent.refresh_from_db()
        self.assertEqual(ent.status, SubscriptionEntitlement.Status.REVOKED)
        self.assertTrue(
            AdminAction.objects.filter(
                action="entitlement_revoked", target_id=str(ent.pk), actor=self.admin
            ).exists()
        )

    def test_mark_pending_purchase_failed_never_touches_paid(self):
        from payments.models import Transaction

        pending = SubscriptionPurchase.objects.create(
            user=self.owner,
            business=self.business,
            product=self.product,
            price_toman=self.product.price_toman,
            status=SubscriptionPurchase.Status.PENDING,
        )
        Transaction.objects.create(purchase=pending, amount_toman=pending.price_toman)
        self.client.force_authenticate(self.admin)
        ok = self.client.post(f"/api/admin/purchases/{pending.pk}/mark-failed/")
        self.assertEqual(ok.status_code, 200)
        pending.refresh_from_db()
        self.assertEqual(pending.status, SubscriptionPurchase.Status.FAILED)
        denied = self.client.post(f"/api/admin/purchases/{self.purchase.pk}/mark-failed/")
        self.assertEqual(denied.status_code, status.HTTP_409_CONFLICT)
