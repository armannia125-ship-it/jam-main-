"""Platform-admin API.

Every view requires JWT authentication AND the server-side ``admin`` role
(``accounts.permissions.IsAdmin``). The effective role is always read from the
authenticated user row — never from client payloads. All role changes and
sensitive administrative mutations are audited via ``accounts.AdminAction``.
"""

from django.contrib.auth import get_user_model
from django.db import transaction
from django.db.models import Count, Q
from django.utils import timezone

from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from accounts.models import AdminAction
from accounts.permissions import IsAdmin
from commerce.models import (
    Invoice,
    Order,
    SettlementEntry,
)
from payments.models import Transaction
from subscriptions.entitlements import revoke_entitlement
from subscriptions.models import (
    SubscriptionEntitlement,
    SubscriptionProduct,
    SubscriptionPurchase,
)

User = get_user_model()


def _user_brief(user):
    return {
        "id": user.pk,
        "name": " ".join(filter(None, [user.first_name, user.last_name])).strip()
        or (user.phone or user.email or ""),
        "phone": user.phone,
        "email": user.email,
        "role": user.role,
        "is_active": user.is_active,
        "date_joined": user.date_joined,
    }


def _mask_amount(amount_toman):
    """Amounts are stored as integer Toman and surfaced as-is (no float math)."""
    return int(amount_toman or 0)


class AdminOverviewView(APIView):
    """Real aggregate dashboard data from the database; nothing fabricated."""

    permission_classes = [IsAdmin]

    def get(self, request):
        now = timezone.now()
        active_menu = SubscriptionEntitlement.objects.filter(
            entitlement_type=SubscriptionEntitlement.Type.MENU,
            status=SubscriptionEntitlement.Status.ACTIVE,
            starts_at__lte=now,
            ends_at__gt=now,
        ).count()
        active_club_new = SubscriptionEntitlement.objects.filter(
            entitlement_type=SubscriptionEntitlement.Type.CLUB,
            status=SubscriptionEntitlement.Status.ACTIVE,
            starts_at__lte=now,
            ends_at__gt=now,
        ).count()
        confirmed_total = Transaction.objects.filter(status=Transaction.Status.SUCCESS).aggregate(
            total=Count("pk")
        )["total"]
        confirmed_revenue_toman = sum(
            _mask_amount(t["amount_toman"])
            for t in Transaction.objects.filter(status=Transaction.Status.SUCCESS).values("amount_toman")
        )
        return Response(
            {
                "users_total": User.objects.count(),
                "users_active": User.objects.filter(is_active=True).count(),
                "menu_entitlements_active": active_menu,
                "club_entitlements_active": active_club_new,
                "subscriptions_expired": SubscriptionEntitlement.objects.filter(
                    status=SubscriptionEntitlement.Status.EXPIRED
                ).count(),
                "payments_pending": Transaction.objects.filter(
                    status=Transaction.Status.INITIATED
                ).count(),
                "payments_confirmed": confirmed_total,
                "payments_failed": Transaction.objects.filter(status=Transaction.Status.FAILED).count(),
                "confirmed_revenue_toman": confirmed_revenue_toman,
                "recent_purchases": [
                    {
                        "id": p.pk,
                        "user": _user_brief(p.user),
                        "business": p.business.name,
                        "product": p.product.slug,
                        "price_toman": _mask_amount(p.price_toman),
                        "status": p.status,
                        "created_at": p.created_at,
                    }
                    for p in SubscriptionPurchase.objects.select_related(
                        "user", "business", "product"
                    ).order_by("-created_at")[:10]
                ],
                "recent_admin_actions": [
                    {
                        "id": a.pk,
                        "actor": _user_brief(a.actor) if a.actor else None,
                        "action": a.action,
                        "target": f"{a.target_type}:{a.target_id}",
                        "created_at": a.created_at,
                    }
                    for a in AdminAction.objects.select_related("actor").order_by("-created_at")[:10]
                ],
            }
        )


class AdminUserListView(APIView):
    permission_classes = [IsAdmin]

    def get(self, request):
        q = (request.query_params.get("q") or "").strip()
        qs = User.objects.all().order_by("-date_joined")
        if q:
            qs = qs.filter(
                Q(phone__icontains=q) | Q(email__icontains=q) | Q(first_name__icontains=q) | Q(last_name__icontains=q)
            )
        try:
            limit = min(200, max(1, int(request.query_params.get("limit", 50))))
        except ValueError:
            limit = 50
        return Response(
            {"results": [_user_brief(u) for u in qs[:limit]]}
        )


class AdminUserDetailView(APIView):
    permission_classes = [IsAdmin]

    def get(self, request, user_id):
        user = User.objects.filter(pk=user_id).first()
        if user is None:
            return Response({"detail": "کاربر پیدا نشد."}, status=status.HTTP_404_NOT_FOUND)
        entitlements = SubscriptionEntitlement.objects.filter(user=user).select_related("product", "business")
        businesses = list(user.businesses.all())
        return Response(
            {
                "user": _user_brief(user),
                "businesses": [{"id": b.pk, "name": b.name, "slug": b.slug} for b in businesses],
                "entitlements": [
                    {
                        "id": e.pk,
                        "business": e.business.name,
                        "type": e.entitlement_type,
                        "product": e.product.slug,
                        "status": "active" if e.is_current else e.status,
                        "starts_at": e.starts_at,
                        "ends_at": e.ends_at,
                    }
                    for e in entitlements
                ],
                "purchases": [
                    {
                        "id": p.pk,
                        "product": p.product.slug,
                        "price_toman": _mask_amount(p.price_toman),
                        "status": p.status,
                        "created_at": p.created_at,
                        "confirmed_at": p.confirmed_at,
                    }
                    for p in user.subscription_purchases.select_related("product").order_by("-created_at")[:20]
                ],
                "payments": [
                    {
                        "id": t.pk,
                        "amount_toman": _mask_amount(t.amount_toman),
                        "status": t.status,
                        "gateway": t.gateway,
                        "ref_id": t.ref_id,
                        "created_at": t.created_at,
                    }
                    for t in Transaction.objects.filter(purchase__user=user).order_by(
                        "-created_at"
                    )[:20]
                ],
            }
        )


class AdminRoleView(APIView):
    """Promote/demote. Protected against self-demotion abuse and last-admin loss."""

    permission_classes = [IsAdmin]

    def post(self, request, user_id, action):
        target = User.objects.filter(pk=user_id).first()
        if target is None:
            return Response({"detail": "کاربر پیدا نشد."}, status=status.HTTP_404_NOT_FOUND)
        admin_count = User.objects.filter(role=User.Role.ADMIN, is_active=True).count()

        with transaction.atomic():
            if action == "promote":
                if not target.is_active:
                    return Response({"detail": "کاربر غیرفعال قابل ارتقا نیست."}, status=status.HTTP_409_CONFLICT)
                if target.role == User.Role.ADMIN:
                    return Response({"detail": "این کاربر از قبل مدیر است."}, status=status.HTTP_409_CONFLICT)
                target.role = User.Role.ADMIN
                target.save(update_fields=["role"])
                AdminAction.record(
                    actor=request.user,
                    action=AdminAction.Action.ADMIN_PROMOTED,
                    target=target,
                    metadata={"phone": target.phone},
                )
                return Response({"detail": "کاربر به مدیر ارتقا یافت.", "role": target.role})
            if action == "demote":
                if request.user.pk == target.pk:
                    return Response(
                        {"detail": "نمی‌توانید نقش خودتان را تغییر دهید."}, status=status.HTTP_409_CONFLICT
                    )
                if target.role != User.Role.ADMIN:
                    return Response({"detail": "این کاربر مدیر نیست."}, status=status.HTTP_409_CONFLICT)
                if admin_count <= 1:
                    return Response(
                        {"detail": "حذف آخرین مدیر مجاز نیست."}, status=status.HTTP_409_CONFLICT
                    )
                target.role = User.Role.USER
                target.save(update_fields=["role"])
                AdminAction.record(
                    actor=request.user,
                    action=AdminAction.Action.ADMIN_DEMOTED,
                    target=target,
                    metadata={"phone": target.phone},
                )
                return Response({"detail": "نقش مدیر کاربر حذف شد.", "role": target.role})
        return Response({"detail": "عملیات نامعتبر."}, status=status.HTTP_400_BAD_REQUEST)


class AdminPaymentListView(APIView):
    """Payments derived from authoritative backend data. No manual confirmation."""

    permission_classes = [IsAdmin]

    def get(self, request):
        qs = Transaction.objects.select_related(
            "purchase__user", "purchase__product", "purchase__business"
        )
        status_filter = request.query_params.get("status")
        if status_filter:
            qs = qs.filter(status=status_filter)
        q = (request.query_params.get("q") or "").strip()
        if q:
            qs = qs.filter(Q(ref_id__icontains=q) | Q(authority__icontains=q))
        try:
            limit = min(200, max(1, int(request.query_params.get("limit", 50))))
        except ValueError:
            limit = 50
        return Response(
            {
                "results": [
                    {
                        "id": t.pk,
                        "user": _user_brief(t.purchase.user),
                        "target": f"purchase:{t.purchase_id}",
                        "product": t.purchase.product.slug,
                        "amount_toman": _mask_amount(t.amount_toman),
                        "gateway": t.gateway,
                        "status": t.status,
                        "ref_id": t.ref_id,
                        "created_at": t.created_at,
                    }
                    for t in qs.order_by("-created_at")[:limit]
                ]
            }
        )


class AdminSubscriptionListView(APIView):
    permission_classes = [IsAdmin]

    def get(self, request):
        now = timezone.now()
        ent = SubscriptionEntitlement.objects.select_related("user", "business", "product", "purchase")
        type_filter = request.query_params.get("type")
        status_filter = request.query_params.get("status")
        if type_filter:
            ent = ent.filter(entitlement_type=type_filter)
        if status_filter == "active":
            ent = ent.filter(status=SubscriptionEntitlement.Status.ACTIVE, starts_at__lte=now, ends_at__gt=now)
        elif status_filter:
            ent = ent.filter(status=status_filter)
        try:
            limit = min(200, max(1, int(request.query_params.get("limit", 50))))
        except ValueError:
            limit = 50
        return Response(
            {
                "results": [
                    {
                        "id": e.pk,
                        "user": _user_brief(e.user),
                        "business": e.business.name,
                        "type": e.entitlement_type,
                        "product": e.product.slug,
                        "status": "active" if e.is_current else e.status,
                        "starts_at": e.starts_at,
                        "ends_at": e.ends_at,
                        "purchase": e.purchase_id,
                    }
                    for e in ent.order_by("-ends_at")[:limit]
                ],
                "products": [
                    {
                        "slug": p.slug,
                        "name": p.name,
                        "price_toman": _mask_amount(p.price_toman),
                        "duration_days": p.duration_days,
                        "category": p.category,
                        "is_active": p.is_active,
                    }
                    for p in SubscriptionProduct.objects.order_by("sort_order")
                ],
            }
        )


class AdminEntitlementRevokeView(APIView):
    """Explicit, audited administrative revocation of ONE entitlement."""

    permission_classes = [IsAdmin]

    def post(self, request, entitlement_id):
        ent = SubscriptionEntitlement.objects.filter(pk=entitlement_id).first()
        if ent is None:
            return Response({"detail": "اعتبار پیدا نشد."}, status=status.HTTP_404_NOT_FOUND)
        if ent.status == SubscriptionEntitlement.Status.REVOKED:
            return Response({"detail": "این اعتبار قبلاً لغو شده است."}, status=status.HTTP_409_CONFLICT)
        reason = (request.data or {}).get("reason", "")
        with transaction.atomic():
            revoke_entitlement(ent, revoked_by=request.user, reason=reason)
            AdminAction.record(
                actor=request.user,
                action=AdminAction.Action.ENTITLEMENT_REVOKED,
                target=ent,
                metadata={"type": ent.entitlement_type, "reason": reason[:200]},
            )
        return Response({"detail": "اعتبار لغو شد.", "status": ent.status})


class AdminAuditListView(APIView):
    permission_classes = [IsAdmin]

    def get(self, request):
        qs = AdminAction.objects.select_related("actor")
        action_filter = request.query_params.get("action")
        if action_filter:
            qs = qs.filter(action=action_filter)
        try:
            limit = min(200, max(1, int(request.query_params.get("limit", 50))))
        except ValueError:
            limit = 50
        return Response(
            {
                "results": [
                    {
                        "id": a.pk,
                        "actor": _user_brief(a.actor) if a.actor else None,
                        "action": a.action,
                        "target_type": a.target_type,
                        "target_id": a.target_id,
                        "metadata": a.metadata,
                        "created_at": a.created_at,
                    }
                    for a in qs.order_by("-created_at")[:limit]
                ]
            }
        )


class AdminMarkPurchaseFailedView(APIView):
    """Operational correction: mark an abandoned pending purchase FAILED.

    This never activates anything and never touches a PAID purchase; it is
    audited. Payment status itself remains provider-authoritative.
    """

    permission_classes = [IsAdmin]

    def post(self, request, purchase_id):
        from subscriptions.models import SubscriptionPurchase

        purchase = SubscriptionPurchase.objects.filter(pk=purchase_id).first()
        if purchase is None:
            return Response({"detail": "خرید پیدا نشد."}, status=status.HTTP_404_NOT_FOUND)
        if purchase.status != SubscriptionPurchase.Status.PENDING:
            return Response(
                {"detail": "فقط خرید در انتظار پرداخت قابل تغییر است."}, status=status.HTTP_409_CONFLICT
            )
        with transaction.atomic():
            purchase.status = SubscriptionPurchase.Status.FAILED
            purchase.save(update_fields=["status"])
            purchase.transactions.exclude(status=Transaction.Status.SUCCESS).update(
                status=Transaction.Status.FAILED
            )
            AdminAction.record(
                actor=request.user,
                action=AdminAction.Action.PURCHASE_MARKED_FAILED,
                target=purchase,
                metadata={"product": purchase.product.slug},
            )
        return Response({"detail": "خرید به وضعیت ناموفق تغییر یافت.", "status": purchase.status})
