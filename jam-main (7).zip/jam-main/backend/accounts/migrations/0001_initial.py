import django.contrib.auth.models
import django.contrib.auth.validators
import django.core.validators
import django.utils.timezone
from django.db import migrations, models

class Migration(migrations.Migration):
    initial = True
    dependencies = [("auth", "0012_alter_user_first_name_max_length")]
    operations = [migrations.CreateModel(name="User", fields=[
        ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
        ("password", models.CharField(max_length=128, verbose_name="password")),
        ("last_login", models.DateTimeField(blank=True, null=True, verbose_name="last login")),
        ("is_superuser", models.BooleanField(default=False, help_text="Designates that this user has all permissions without explicitly assigning them.", verbose_name="superuser status")),
        ("phone", models.CharField(blank=True, max_length=13, null=True, unique=True, validators=[django.core.validators.RegexValidator(message="Use an Iranian mobile number: 09xxxxxxxxx or +989xxxxxxxxx.", regex="^(?:\\+98|0)9\\d{9}$")])),
        ("email", models.EmailField(blank=True, max_length=254, null=True, unique=True)),
        ("first_name", models.CharField(blank=True, max_length=150)),
        ("last_name", models.CharField(blank=True, max_length=150)),
        ("is_staff", models.BooleanField(default=False)), ("is_active", models.BooleanField(default=True)),
        ("date_joined", models.DateTimeField(default=django.utils.timezone.now)),
        ("created_at", models.DateTimeField(auto_now_add=True)),
        ("groups", models.ManyToManyField(blank=True, help_text="The groups this user belongs to. A user will get all permissions granted to each of their groups.", related_name="user_set", related_query_name="user", to="auth.group", verbose_name="groups")),
        ("user_permissions", models.ManyToManyField(blank=True, help_text="Specific permissions for this user.", related_name="user_set", related_query_name="user", to="auth.permission", verbose_name="user permissions")),
    ], options={"verbose_name": "user", "verbose_name_plural": "users", "abstract": False}),
    migrations.CreateModel(name="OTPChallenge", fields=[
        ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
        ("identifier", models.CharField(db_index=True, max_length=254)), ("code_hash", models.CharField(max_length=128)),
        ("expires_at", models.DateTimeField(db_index=True)), ("attempts", models.PositiveSmallIntegerField(default=0)),
        ("consumed_at", models.DateTimeField(blank=True, null=True)), ("created_at", models.DateTimeField(auto_now_add=True)),
    ])]
