"""Provision or remove platform administrators securely.

Usage (no public registration endpoint exists; run on the server):

    python manage.py make_admin --phone +989xxxxxxxxx            # promote
    python manage.py make_admin --phone +989xxxxxxxxx --demote   # demote

The command:
* never creates a new account — it promotes/demotes an EXISTING user only;
* is idempotent (safe to run more than once);
* refuses to demote the last active admin;
* records an audit entry for every change;
* never accepts or sets a password (users log in with the existing OTP flow).
"""
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from accounts.models import AdminAction, User


class Command(BaseCommand):
    help = "Promote or demote an existing user to/from the platform admin role."

    def add_arguments(self, parser):
        parser.add_argument("--phone", required=True, help="Phone of an EXISTING user")
        parser.add_argument("--demote", action="store_true", help="Demote instead of promote")

    @transaction.atomic
    def handle(self, *args, **options):
        from accounts.models import User as U, normalize_phone

        phone = normalize_phone(options["phone"])
        user = U.objects.filter(phone=phone).first()
        if user is None:
            raise CommandError("No registered user with this phone exists. Admins are promoted, never created.")

        admin_count = U.objects.filter(role=U.Role.ADMIN, is_active=True).count()

        if options["demote"]:
            if user.role != U.Role.ADMIN:
                self.stdout.write(self.style.WARNING("User is not an admin; nothing to do."))
                return
            if admin_count <= 1:
                raise CommandError("Refusing to demote the last active admin.")
            user.role = U.Role.USER
            user.save(update_fields=["role"])
            AdminAction.record(actor=user, action=AdminAction.Action.ADMIN_DEMOTED, target=user)
            self.stdout.write(self.style.SUCCESS(f"{phone} demoted to user."))
            return

        if user.role == U.Role.ADMIN:
            self.stdout.write(self.style.WARNING("User is already an admin; nothing to do."))
            return
        if not user.is_active:
            raise CommandError("Inactive users cannot be promoted. Activate the account first.")
        user.role = U.Role.ADMIN
        user.save(update_fields=["role"])
        AdminAction.record(actor=user, action=AdminAction.Action.ADMIN_PROMOTED, target=user)
        self.stdout.write(self.style.SUCCESS(f"{phone} promoted to admin."))
