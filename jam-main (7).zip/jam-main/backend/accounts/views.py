import json
import logging
import urllib.request
import urllib.error
from datetime import timedelta
from django.conf import settings
from django.contrib.auth.hashers import check_password, make_password
from django.db import IntegrityError, transaction
from django.utils import timezone
from rest_framework import status
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.throttling import SimpleRateThrottle, AnonRateThrottle
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken
from .models import OTPChallenge, User, normalize_phone
from .serializers import OTPRequestSerializer, OTPVerifySerializer

OTPY_BASE_URL = "https://api.otpy.ir"
OTPY_SEND_PATH = "/v1/otp/send"
OTPY_VERIFY_PATH = "/v1/otp/verify"
OTPY_USER_AGENT = "JAM-Integration/1.0"

logger = logging.getLogger(__name__)


def _otpy_request(method, path, phone, code=None, timeout=10):
    """Make an OTPy API request with proper error handling."""
    url = f"{OTPY_BASE_URL}{path}"
    headers = {
        "Authorization": f"Bearer {settings.OTPY_API_KEY}",
        "Content-Type": "application/json",
        "User-Agent": OTPY_USER_AGENT,
    }
    body_dict = {"phone": phone}
    if code is not None:
        body_dict["code"] = code
    body = json.dumps(body_dict).encode("utf-8") if method == "POST" else None
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            text = resp.read().decode("utf-8")
            content_type = resp.headers.get("Content-Type", "unknown")
            try:
                data = json.loads(text)
            except json.JSONDecodeError:
                return {"error": "Malformed provider response", "status_code": None, "content_type": content_type}, None
            return {**data, "content_type": content_type}, resp.status
    except urllib.error.HTTPError as e:
        body_bytes = e.read()
        body = body_bytes.decode("utf-8") if body_bytes else ""
        error_category = body.strip()[:50] if body else f"HTTP {e.code}"
        logger.debug("_otpy_request HTTP error: status=%s, category=%s", e.code, error_category)
        return {"error": body or f"HTTP {e.code}", "status_code": e.code, "content_type": "unknown"}, e.code
    except (urllib.error.URLError, ConnectionError, OSError, json.JSONDecodeError) as e:
        logger.debug("_otpy_request connection error: %s", str(e)[:100])
        return {"error": str(e)[:100], "status_code": None, "content_type": "unknown"}, None


def _send_via_otpy(phone):
    """Send OTP via OTPy provider."""
    result, status_code = _otpy_request("POST", OTPY_SEND_PATH, phone)
    if status_code != 200:
        return result
    return result


def _verify_via_otpy(phone, code):
    """Verify OTP via OTPy provider.

    Returns:
        True   if verified: true (successful verification)
        '429'  if OTPy returned HTTP 429 (rate limited)
        None   if there's a TLS/connection error (not an invalid code)
        False  if verified: false or other non-verified response
    """
    result, status_code = _otpy_request("POST", OTPY_VERIFY_PATH, phone, code=code)
    # --- Diagnostic: record sanitized provider response info ---
    # Temporary diagnostic for investigating OTPy verification failures.
    # Logs at INFO level (visible in development) but never logs phone,
    # code, API key, tokens, or raw provider response bodies.
    # Remove after root cause is identified.
    has_verified_key = isinstance(result.get("verified"), bool)
    status_repr = status_code if status_code is not None else "connection/TLS-error"
    response_category = _sanitize_otpy_response(result)
    content_type = result.get("content_type", "unknown")
    logger.info(
        "OTPy verify attempt: status=%s, content-type=%s, has_verified_bool=%s, sanitized_category=%s",
        status_repr,
        content_type,
        has_verified_key,
        response_category,
    )
    # -------------------------------------------
    # Distinguish TLS/connection errors from other responses
    if result.get("verified") is True:
        return True
    # If there's a connection/SSL error (status_code is None and 'error' key exists),
    # treat it as a transport error, not an invalid code
    if result.get("status_code") is None and "error" in result:
        logger.debug(
            "_verify_via_otpy: transport error, not invalid code: %s",
            result.get("error")[:80],
        )
        return None  # signal transport error to the caller
    # OTPy HTTP 429 - preserve the rate-limit response, do not treat as invalid code
    if result.get("status_code") == 429:
        return '429'
    return False


def _sanitize_otpy_response(result):
    """Return a short, sanitized category string describing the provider response.

    Never includes phone, code, API key, tokens, or raw response values.
    Used only for DEBUG-level diagnostics.
    """
    if not isinstance(result, dict):
        return "non-dict-response"
    # Recognized success shape
    if result.get("verified") is True:
        return "verified-true"
    # Recognized error shapes without leaking values
    status_code = result.get("status_code")
    if status_code == 401:
        return "provider-401-auth"
    if status_code == 403:
        return "provider-403-forbidden"
    if status_code == 404:
        return "provider-404-not-found"
    if status_code == 429:
        return "provider-429-rate-limited"
    if status_code and status_code >= 500:
        return "provider-5xx"
    if status_code and status_code >= 400:
        return "provider-4xx-other"
    # Connection/TLS/DNS pathway
    if status_code is None and result.get("error"):
        err = str(result.get("error"))[:40]
        if "CERT" in err.upper() or "SSL" in err.upper() or "TLS" in err.upper():
            return "tls-ssl-error"
        if "DNS" in err.upper() or "Name or service not known" in err:
            return "dns-error"
        if "timed out" in err.lower() or "timeout" in err.lower():
            return "timeout-error"
        if "Connection" in err or "connection" in err:
            return "connection-error"
        return "transport-error-unknown"
    # Provider returned a 200-ish response but without verified:true
    if status_code == 200 or status_code is None:
        return "provider-200-no-verified-true"
    return "provider-unknown"


def deliver_otp_sms(identifier, code):
    """Send OTP via OTPy. Never logs OTP values."""
    normalized = normalize_phone(identifier) if "@" not in identifier else identifier
    return _send_via_otpy(normalized)


class DevelopmentRateThrottle(AnonRateThrottle):
    """Custom throttle that is bypassed when DEBUG is True."""
    scope = "otp"

    def allow_request(self, request, view):
        # In development, always allow the request to avoid 429 during testing
        if settings.DEBUG:
            return True
        return super().allow_request(request, view)


class RequestOTPView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = []
    throttle_classes = [DevelopmentRateThrottle]

    def post(self, request):
        serializer = OTPRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        identifier = serializer.validated_data["identifier"]
        with transaction.atomic():
            OTPChallenge.objects.filter(identifier=identifier, consumed_at__isnull=True).update(consumed_at=timezone.now())
            OTPChallenge.objects.create(
                identifier=identifier,
                expires_at=timezone.now() + timedelta(minutes=5),
            )
        # Call OTPy provider to send the OTP
        result = _send_via_otpy(identifier)
        if "error" in result:
            # Fail closed: do not report success if provider fails
            status_code = result.get("status_code")
            detail = result.get("error", "Provider error")
            if status_code == 401:
                return Response({"detail": "Invalid OTP provider credentials."}, status=status.HTTP_503_SERVICE_UNAVAILABLE)
            if status_code == 429:
                return Response({"detail": "Too many requests to OTP provider."}, status=status.HTTP_429_TOO_MANY_REQUESTS)
            return Response({"detail": detail}, status=status.HTTP_502_BAD_GATEWAY)
        # Return success only when OTPy accepted the request
        return Response({"detail": "If the contact can receive messages, a verification code has been sent."}, status=status.HTTP_200_OK)


class VerifyOTPView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = []
    throttle_classes = [DevelopmentRateThrottle]

    def post(self, request):
        serializer = OTPVerifySerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        identifier = serializer.validated_data["identifier"]
        code = serializer.validated_data["code"]
        # Check user existence before provider verification to avoid
        # unnecessary provider calls for unregistered identifiers.
        # This preserves existing response semantics (404 for unregistered)
        # while reducing provider load.
        if "@" in identifier:
            try:
                user = User.objects.get(email__iexact=identifier)
            except User.DoesNotExist:
                return Response({"detail": "User not found."}, status=status.HTTP_404_NOT_FOUND)
        else:
            try:
                normalized_phone = normalize_phone(identifier)
                user = User.objects.get(phone=normalized_phone)
            except User.DoesNotExist:
                return Response({"detail": "This phone number is not registered. Please sign up first."}, status=status.HTTP_404_NOT_FOUND)
        if not user.is_active:
            return Response({"detail": "This account is disabled."}, status=status.HTTP_403_FORBIDDEN)
        with transaction.atomic():
            challenge = OTPChallenge.objects.select_for_update().filter(
                identifier=identifier, consumed_at__isnull=True, expires_at__gt=timezone.now(), attempts__lt=5
            ).order_by("-created_at").first()
            if challenge is None:
                return Response({"detail": "No pending verification code."}, status=status.HTTP_400_BAD_REQUEST)
            # Verify via OTPy provider (user exists, challenge valid)
            verify_result = _verify_via_otpy(identifier, code)
            if verify_result is None:
                # Transport/SSL/DNS error - do not treat as invalid code
                # Return 502/503 without incrementing attempt counter
                return Response({"detail": "OTP verification service is temporarily unavailable."}, status=status.HTTP_502_BAD_GATEWAY)
            if verify_result == '429':
                # OTPy HTTP 429 - preserve rate-limit response without incrementing attempt counter
                return Response({"detail": "Too many requests to OTP provider."}, status=status.HTTP_429_TOO_MANY_REQUESTS)
            if not verify_result:
                challenge.attempts += 1
                challenge.save(update_fields=["attempts"])
                return Response({"detail": "Invalid or expired verification code."}, status=status.HTTP_400_BAD_REQUEST)
            # OTPy verified - mark challenge consumed and issue tokens
            challenge.consumed_at = timezone.now()
            challenge.save(update_fields=["consumed_at"])
            refresh = RefreshToken.for_user(user)
        return Response({"access": str(refresh.access_token), "refresh": str(refresh), "user": {
            "id": user.pk, "phone": user.phone, "email": user.email,
            "role": user.role,
        }})


class MeView(APIView):
    """The authenticated user's own profile, incl. the server-side role.

    The frontend MUST derive area access from this server-authoritative role;
    it is never taken from a client-stored value.
    """

    def get(self, request):
        user = request.user
        return Response({
            "id": user.pk,
            "phone": user.phone,
            "email": user.email,
            "name": " ".join(filter(None, [user.first_name, user.last_name])).strip(),
            "role": user.role,
            "is_active": user.is_active,
        })


class SignupView(APIView):
    """
    Create a new user from a phone identifier after OTP verification.

    This endpoint is called by the sign-up flow AFTER OTPy has confirmed
    the verification code. It creates a new User with the given phone
    number (which must not already be registered).

    No password is required; OTP verification serves as authentication.
    The user is created with an unusable password set, same as the
    existing user creation pattern in tests.
    """
    permission_classes = [AllowAny]
    authentication_classes = []

    def post(self, request):
        identifier = request.data.get("identifier", "").strip()
        code = (request.data.get("code") or "").strip()
        if not identifier:
            return Response({"detail": "Phone number is required."}, status=status.HTTP_400_BAD_REQUEST)
        if "@" in identifier:
            # Email sign-up not supported for phone-OTP flow
            return Response({"detail": "Email sign-up is not available. Please use a phone number."}, status=status.HTTP_400_BAD_REQUEST)
        try:
            normalized_phone = normalize_phone(identifier)
        except Exception as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        # Double-check that user does not already exist
        if User.objects.filter(phone=normalized_phone).exists():
            return Response({"detail": "This phone number is already registered. Please log in."}, status=status.HTTP_400_BAD_REQUEST)
        # Verify OTP via OTPy provider before creating account
        logger.info("SIGNUP_STAGE: entering _verify_via_otpy call")
        verify_result = _verify_via_otpy(identifier, code)
        logger.info("SIGNUP_STAGE: exited _verify_via_otpy, result_category=%s", 
                    "True" if verify_result is True else "False" if verify_result is False else "None/transport-error" if verify_result is None else "429-rate-limited")
        if verify_result is None:
            # Transport/SSL/DNS error - do not treat as invalid code
            return Response({"detail": "OTP verification service is temporarily unavailable."}, status=status.HTTP_502_BAD_GATEWAY)
        if verify_result == '429':
            # OTPy HTTP 429 - preserve rate-limit response without incrementing attempt counter
            return Response({"detail": "Too many requests to OTP provider."}, status=status.HTTP_429_TOO_MANY_REQUESTS)
        if not verify_result:
            # OTPy verification failed - do not create account
            return Response({"detail": "Invalid or expired verification code."}, status=status.HTTP_400_BAD_REQUEST)
        # OTPy verified - now create the account
        try:
            with transaction.atomic():
                user = User.objects.create(phone=normalized_phone)
        except IntegrityError:
            # Database-level uniqueness constraint hit (e.g. concurrent sign-up)
            return Response({"detail": "This phone number is already registered. Please log in."}, status=status.HTTP_400_BAD_REQUEST)
        except Exception:
            # Re-raise other unexpected errors
            raise
        user.set_unusable_password()
        user.save()
        if not User.objects.filter(phone=normalized_phone).exists():
            return Response({"detail": "Failed to create account."}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        refresh = RefreshToken.for_user(user)
        return Response(
            {
                "access": str(refresh.access_token),
                "refresh": str(refresh),
                "verified": True,
            },
            status=status.HTTP_201_CREATED,
        )
