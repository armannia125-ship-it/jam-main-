from django.urls import path

from . import admin_views

urlpatterns = [
    path("overview/", admin_views.AdminOverviewView.as_view(), name="admin-overview"),
    path("users/", admin_views.AdminUserListView.as_view(), name="admin-users"),
    path("users/<int:user_id>/", admin_views.AdminUserDetailView.as_view(), name="admin-user-detail"),
    path("users/<int:user_id>/role/<str:action>/", admin_views.AdminRoleView.as_view(), name="admin-role"),
    path("payments/", admin_views.AdminPaymentListView.as_view(), name="admin-payments"),
    path("subscriptions/", admin_views.AdminSubscriptionListView.as_view(), name="admin-subscriptions"),
    path(
        "entitlements/<int:entitlement_id>/revoke/",
        admin_views.AdminEntitlementRevokeView.as_view(),
        name="admin-entitlement-revoke",
    ),
    path(
        "purchases/<int:purchase_id>/mark-failed/",
        admin_views.AdminMarkPurchaseFailedView.as_view(),
        name="admin-purchase-mark-failed",
    ),
    path("audit/", admin_views.AdminAuditListView.as_view(), name="admin-audit"),
]
