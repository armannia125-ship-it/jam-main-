"""Server-side RBAC primitives.

The role is ALWAYS read from the authenticated server-side user row
(``accounts.User.role``); a role supplied by the client is never trusted.
"""

from rest_framework.permissions import BasePermission


class IsAdmin(BasePermission):
    """Allow only active users whose server-side role is ``admin``."""

    message = "این بخش فقط برای مدیران سامانه در دسترس است."

    def has_permission(self, request, view):
        user = request.user
        return bool(user and user.is_authenticated and user.is_admin)
