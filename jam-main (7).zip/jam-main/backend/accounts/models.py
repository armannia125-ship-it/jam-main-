import re
from django.contrib.auth.base_user import AbstractBaseUser, BaseUserManager
from django.contrib.auth.models import PermissionsMixin
from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone
from django.core.validators import RegexValidator

iran_phone_validator = RegexValidator(
    regex=r"^(?:\+98|0)9\d{9}$",
    message="Use an Iranian mobile number: 09xxxxxxxxx or +989xxxxxxxxx.",
)

def normalize_phone(value):
    value = (value or "").strip().replace(" ", "").replace("-", "")
    if value.startswith("0") and len(value) == 11:
        value = "+98" + value[1:]
    if not re.fullmatch(r"\+989\d{9}", value):
        raise ValidationError("Use an Iranian mobile number: 09xxxxxxxxx or +989xxxxxxxxx.")
    return value

class UserManager(BaseUserManager):
    use_in_migrations = True

    def create_user(self, phone=None, email=None, password=None, **extra_fields):
        if not phone and not email:
            raise ValueError("A phone number or email is required.")
        if phone:
            phone = normalize_phone(phone)
        if email:
            email = self.normalize_email(email).lower()
        user = self.model(phone=phone, email=email, **extra_fields)
        if password:
            user.set_password(password)
        else:
            user.set_unusable_password()
        user.save(using=self._db)
        return user

    def create_superuser(self, phone, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        extra_fields.setdefault("is_active", True)
        if extra_fields.get("is_staff") is not True or extra_fields.get("is_superuser") is not True:
            raise ValueError("Superuser must have is_staff=True and is_superuser=True.")
        return self.create_user(phone=phone, password=password, **extra_fields)

class User(AbstractBaseUser, PermissionsMixin):
    class Role(models.TextChoices):
        USER = "user", "User"
        ADMIN = "admin", "Admin"

    phone = models.CharField(max_length=13, unique=True, null=True, blank=True, validators=[iran_phone_validator])
    email = models.EmailField(max_length=254, unique=True, null=True, blank=True)
    first_name = models.CharField(max_length=150, blank=True)
    last_name = models.CharField(max_length=150, blank=True)
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    # App-level platform role, read ONLY from this server-side field.
    role = models.CharField(max_length=10, choices=Role.choices, default=Role.USER, db_index=True)
    date_joined = models.DateTimeField(default=timezone.now)
    created_at = models.DateTimeField(auto_now_add=True)

    objects = UserManager()
    USERNAME_FIELD = "phone"
    REQUIRED_FIELDS = []

    def clean(self):
        super().clean()
        if self.phone:
            self.phone = normalize_phone(self.phone)
        if self.email:
            self.email = self.email.strip().lower()
        if not self.phone and not self.email:
            raise ValidationError("A phone number or email is required.")

    def save(self, *args, **kwargs):
        self.phone = normalize_phone(self.phone) if self.phone else None
        self.email = self.email.strip().lower() if self.email else None
        super().save(*args, **kwargs)

    @property
    def is_admin(self):
        return self.role == self.Role.ADMIN and self.is_active

    def __str__(self):
        return self.phone or self.email or f"user-{self.pk}"


class AdminAction(models.Model):
    """Audit log of security-sensitive administrative actions.

    Records the acting admin, the action, the target object, and safe metadata.
    Secrets, OTP values and credentials are never stored here.
    """

    class Action(models.TextChoices):
        ADMIN_PROMOTED = "admin_promoted", "User promoted to admin"
        ADMIN_DEMOTED = "admin_demoted", "Admin demoted to user"
        ENTITLEMENT_REVOKED = "entitlement_revoked", "Subscription entitlement revoked"
        PAYMENT_INSPECTED = "payment_inspected", "Payment inspected"
        PURCHASE_MARKED_FAILED = "purchase_marked_failed", "Purchase marked failed"

    actor = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True, related_name="admin_actions"
    )
    action = models.CharField(max_length=40, choices=Action.choices)
    target_type = models.CharField(max_length=60)
    target_id = models.CharField(max_length=64, blank=True, default="")
    metadata = models.JSONField(default=dict, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        indexes = [models.Index(fields=["action", "created_at"]), models.Index(fields=["actor", "created_at"])]

    @classmethod
    def record(cls, *, actor, action, target=None, metadata=None):
        return cls.objects.create(
            actor=actor,
            action=action,
            target_type=type(target).__name__ if target is not None else "-",
            target_id=str(getattr(target, "pk", target) or ""),
            metadata=metadata or {},
        )

    def __str__(self):
        return f"{self.action} by {self.actor_id} on {self.target_type}:{self.target_id}"


class OTPChallenge(models.Model):
    identifier = models.CharField(max_length=254, db_index=True)
    code_hash = models.CharField(max_length=128)
    expires_at = models.DateTimeField(db_index=True)
    attempts = models.PositiveSmallIntegerField(default=0)
    consumed_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    @property
    def is_valid(self):
        return self.consumed_at is None and self.expires_at > timezone.now() and self.attempts < 5
