from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import OTPChallenge, User
from .forms import AccountCreationForm, AccountChangeForm

@admin.register(User)
class UserAdmin(BaseUserAdmin):
    add_form = AccountCreationForm
    form = AccountChangeForm
    ordering = ("id",)
    list_display = ("id", "phone", "email", "is_staff", "is_active")
    fieldsets = ((None, {"fields": ("phone", "email", "password")}),
                 ("Personal info", {"fields": ("first_name", "last_name")}),
                 ("Permissions", {"fields": ("is_active", "is_staff", "is_superuser", "groups", "user_permissions")}))
    add_fieldsets = ((None, {"classes": ("wide",), "fields": ("phone", "email", "password1", "password2")} ),)
    search_fields = ("phone", "email")

admin.site.register(OTPChallenge)
