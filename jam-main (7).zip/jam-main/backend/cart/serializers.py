from rest_framework import serializers
from .models import Cart, CartItem


class CartItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = CartItem
        fields = ["id", "product_id", "name", "price_toman", "quantity", "image"]


class CartSerializer(serializers.ModelSerializer):
    items = CartItemSerializer(many=True, read_only=True)

    class Meta:
        model = Cart
        fields = ["id", "items", "created_at", "updated_at"]

    def get_items(self, obj):
        # Return serialized items with product data
        items = obj.items.all()
        return CartItemSerializer(items, many=True).data