from django.urls import path
from .views import CartView, CartItemUpdateView

urlpatterns = [
    path("", CartView.as_view(), name="cart"),
    path("items/<int:item_id>/", CartItemUpdateView.as_view(), name="cart-item-update"),
]