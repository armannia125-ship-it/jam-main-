from django.db import models
from django.conf import settings


def cart_path(instance, filename):
    ext = filename.split(".")[-1] if "." in filename else "json"
    return f"cart/{instance.id}.{ext}"


class Cart(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="cart")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Cart for {self.user.phone or self.user.email}"


class CartItem(models.Model):
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE, related_name="items")
    product_id = models.CharField(max_length=50)
    name = models.CharField(max_length=200)
    price_toman = models.PositiveBigIntegerField()
    quantity = models.PositiveIntegerField(default=1)
    image = models.CharField(max_length=200, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ("cart", "product_id")

    def __str__(self):
        return f"{self.name} x{self.quantity}"