from rest_framework import permissions, status
from rest_framework.views import APIView
from rest_framework.response import Response
from django.contrib.auth import get_user_model
from .models import Cart, CartItem
from .serializers import CartSerializer, CartItemSerializer

User = get_user_model()


class CartView(APIView):
    """Get or create cart for authenticated user."""
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        cart, created = Cart.objects.get_or_create(user=request.user)
        serializer = CartSerializer(cart)
        return Response(serializer.data)

    def post(self, request):
        """Add item to cart."""
        product_id = request.data.get("product_id")
        quantity = int(request.data.get("quantity", 1))

        if not product_id:
            return Response({"detail": "product_id is required."}, status=status.HTTP_400_BAD_REQUEST)

        # Try to get product from businesses API data
        # For now, we'll create a cart item with basic data
        cart, created = Cart.objects.get_or_create(user=request.user)

        # Check if item already exists
        item, item_created = CartItem.objects.get_or_create(
            cart=cart,
            product_id=product_id,
            defaults={
                "name": request.data.get("name", "Product"),
                "price_toman": float(request.data.get("price_toman", 0)),
                "quantity": quantity,
                "image": request.data.get("image", ""),
            }
        )

        if not item_created:
            item.quantity += quantity
            item.save()

        serializer = CartSerializer(cart)
        return Response(serializer.data)


class CartItemUpdateView(APIView):
    """Update cart item quantity."""
    permission_classes = [permissions.IsAuthenticated]

    def put(self, request, item_id):
        try:
            item = CartItem.objects.get(id=item_id, cart__user=request.user)
        except CartItem.DoesNotExist:
            return Response({"detail": "Item not found."}, status=status.HTTP_404_NOT_FOUND)

        quantity = int(request.data.get("quantity", 0))
        if quantity <= 0:
            item.delete()
            return Response({"detail": "Item removed."}, status=status.HTTP_204_NO_CONTENT)

        item.quantity = max(1, quantity)
        item.save()
        from .serializers import CartItemSerializer
        return Response(CartItemSerializer(item).data)