import django.db.models.deletion
from django.db import migrations, models

class Migration(migrations.Migration):
    initial = True
    dependencies = [("subscriptions", "0001_initial")]
    operations = [migrations.CreateModel(name="Transaction", fields=[("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")), ("amount_toman", models.PositiveBigIntegerField()), ("gateway", models.CharField(default="zarinpal", max_length=32)), ("status", models.CharField(choices=[("initiated", "Initiated"), ("success", "Success"), ("failed", "Failed")], default="initiated", max_length=12)), ("authority", models.CharField(blank=True, db_index=True, max_length=100)), ("ref_id", models.CharField(blank=True, max_length=100)), ("gateway_payload", models.JSONField(blank=True, default=dict)), ("created_at", models.DateTimeField(auto_now_add=True)), ("updated_at", models.DateTimeField(auto_now=True)), ("subscription", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="transactions", to="subscriptions.subscription"))])]
