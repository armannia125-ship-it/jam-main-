from django.http import HttpResponse
from django.db import transaction
from django.utils import timezone

from businesses.models import Business
from rest_framework.permissions import AllowAny
from rest_framework.views import APIView
from .gateways.zarinpal import ZarinPalGateway
from .models import Transaction
from subscriptions.entitlements import activate_entitlements_for_purchase
from subscriptions.models import SubscriptionPurchase


class ZarinPalCallbackView(APIView):
    """Provider callback — verification is server-side and idempotent.

    A callback request alone is never proof of payment: the payment is verified
    against the provider before anything changes. Entitlement activation is
    transactional and idempotent (unique ``(purchase, type)`` constraint), so
    replayed or concurrent callbacks cannot create duplicate entitlements.

    Verification marks the canonical purchase PAID and activates its
    entitlement(s) atomically (Gold → MENU + CLUB). There is no legacy
    subscription target.
    """

    permission_classes = [AllowAny]
    authentication_classes = []

    def get(self, request):
        authority = request.query_params.get("Authority", "").strip()
        status_param = request.query_params.get("Status", "")
        if not authority:
            return HttpResponse("Authority is required", status=400)
        # Serialize repeat/concurrent callbacks. Successful payments never
        # reactivate anything or reset expiry on callback replay.
        with transaction.atomic():
            preview = (
                Transaction.objects.select_related("purchase")
                .filter(authority=authority)
                .first()
            )
            if not preview:
                return HttpResponse("Payment not found", status=404)
            if preview.status == Transaction.Status.SUCCESS:
                return HttpResponse("Payment already verified", status=200)

            # Lock in business → transaction → purchase order, matching the
            # purchase-initiation path so callback replay and a parallel
            # initiation cannot deadlock or create duplicate state.
            Business.objects.select_for_update().get(pk=preview.purchase.business_id)
            payment = Transaction.objects.select_for_update().get(pk=preview.pk)
            if payment.status == Transaction.Status.SUCCESS:
                return HttpResponse("Payment already verified", status=200)
            if status_param != "OK":
                payment.status = Transaction.Status.FAILED
                payment.save(update_fields=["status", "updated_at"])
                if payment.purchase_id:
                    SubscriptionPurchase.objects.filter(
                        pk=payment.purchase_id, status=SubscriptionPurchase.Status.PENDING
                    ).update(status=SubscriptionPurchase.Status.FAILED)
                return HttpResponse("Payment was cancelled or failed", status=400)
            try:
                result = ZarinPalGateway().verify_payment(authority, payment.amount_toman)
            except Exception:
                # Leave the transaction INITIATED so verification can be retried;
                # nothing is activated for an unverified payment.
                return HttpResponse("Payment verification failed; retry or contact support", status=502)

            payment.status = Transaction.Status.SUCCESS
            payment.ref_id = result["ref_id"]
            payment.gateway_payload = result["payload"]
            payment.save(update_fields=["status", "ref_id", "gateway_payload", "updated_at"])

            # Authoritative verified success → atomic, idempotent activation.
            purchase = SubscriptionPurchase.objects.select_for_update().select_related(
                "product", "user", "business"
            ).get(pk=payment.purchase_id)
            if purchase.status == SubscriptionPurchase.Status.PENDING:
                purchase.status = SubscriptionPurchase.Status.PAID
                purchase.confirmed_at = timezone.now()
                purchase.save(update_fields=["status", "confirmed_at"])
                activate_entitlements_for_purchase(purchase)
        return HttpResponse("Payment verified.", status=200)

