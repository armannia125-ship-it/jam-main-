from abc import ABC, abstractmethod

class PaymentGateway(ABC):
    """Provider boundary. Amounts in this project are denominated in Toman."""
    @abstractmethod
    def create_payment(self, transaction, description=""):
        raise NotImplementedError

    @abstractmethod
    def verify_payment(self, authority, amount_toman):
        raise NotImplementedError
