import requests
from django.conf import settings
from .base import PaymentGateway

class ZarinPalGateway(PaymentGateway):
    def __init__(self):
        self.merchant_id = settings.ZARINPAL_MERCHANT_ID
        if not self.merchant_id:
            raise ValueError("ZARINPAL_MERCHANT_ID is required")
        self.api_base = "https://sandbox.zarinpal.com/pg/v4" if settings.ZARINPAL_SANDBOX else "https://api.zarinpal.com/pg/v4"
        self.start_base = "https://sandbox.zarinpal.com/pg/StartPay/" if settings.ZARINPAL_SANDBOX else "https://www.zarinpal.com/pg/StartPay/"

    def create_payment(self, transaction, description="Jam payment"):
        response = requests.post(f"{self.api_base}/payment/request.json", json={
            "merchant_id": self.merchant_id,
            "amount": int(transaction.amount_toman) * 10,  # provider expects IRR
            "callback_url": settings.ZARINPAL_CALLBACK_URL,
            "description": description[:255],
        }, timeout=20)
        response.raise_for_status()
        payload = response.json()
        data = payload.get("data", {})
        if data.get("code") != 100 or not data.get("authority"):
            raise RuntimeError("ZarinPal did not return a payment authority")
        transaction.gateway_payload = payload
        return {"authority": data["authority"], "payment_url": self.start_base + data["authority"]}

    def verify_payment(self, authority, amount_toman):
        response = requests.post(f"{self.api_base}/payment/verify.json", json={
            "merchant_id": self.merchant_id, "amount": int(amount_toman) * 10, "authority": authority,
        }, timeout=20)
        response.raise_for_status()
        payload = response.json()
        data = payload.get("data", {})
        if data.get("code") not in (100, 101):
            raise RuntimeError("ZarinPal verification failed")
        return {"ref_id": str(data.get("ref_id", "")), "payload": payload}
