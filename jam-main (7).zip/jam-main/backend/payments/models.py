from django.db import models
from django.db.models import Q

from subscriptions.models import SubscriptionPurchase

class Transaction(models.Model):
    class Status(models.TextChoices):
        INITIATED = "initiated", "Initiated"
        SUCCESS = "success", "Success"
        FAILED = "failed", "Failed"
    purchase = models.ForeignKey(
        SubscriptionPurchase, on_delete=models.PROTECT, related_name="transactions"
    )
    amount_toman = models.PositiveBigIntegerField()
    gateway = models.CharField(max_length=32, default="zarinpal")
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.INITIATED)
    authority = models.CharField(max_length=100, blank=True, db_index=True)
    ref_id = models.CharField(max_length=100, blank=True)
    gateway_payload = models.JSONField(default=dict, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["authority"],
                condition=~Q(authority=""),
                name="unique_nonempty_transaction_authority",
            ),
        ]

    def __str__(self):
        return f"{self.gateway}:{self.pk} {self.status}"
