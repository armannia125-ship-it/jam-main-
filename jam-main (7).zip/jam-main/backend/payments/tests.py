from unittest.mock import patch

from django.test import TestCase, override_settings

from accounts.models import User
from businesses.models import Business
from subscriptions.models import (
    SubscriptionEntitlement,
    SubscriptionProduct,
    SubscriptionPurchase,
)

from .gateways.zarinpal import ZarinPalGateway
from .models import Transaction


class PaymentTests(TestCase):
    def setUp(self):
        user = User.objects.create_user(email="owner@example.com")
        business = Business.objects.create(owner=user, name="Cafe", slug="cafe")
        product = SubscriptionProduct.objects.get(slug="basic")
        self.purchase = SubscriptionPurchase.objects.create(
            user=user,
            business=business,
            product=product,
            price_toman=product.price_toman,
        )
        self.payment = Transaction.objects.create(
            purchase=self.purchase,
            amount_toman=product.price_toman,
            authority="test-authority",
        )

    @patch("payments.views.ZarinPalGateway")
    def test_callback_is_idempotent(self, gateway):
        gateway.return_value.verify_payment.return_value = {"ref_id": "123", "payload": {}}
        url = "/api/payments/zarinpal/callback/?Authority=test-authority&Status=OK"
        self.assertEqual(self.client.get(url).status_code, 200)
        self.purchase.refresh_from_db()
        self.assertEqual(self.purchase.status, SubscriptionPurchase.Status.PAID)
        entitlement = SubscriptionEntitlement.objects.get(purchase=self.purchase)
        expires = entitlement.ends_at
        self.assertEqual(self.client.get(url).status_code, 200)
        entitlement.refresh_from_db()
        self.assertEqual(entitlement.ends_at, expires)
        self.assertEqual(
            SubscriptionEntitlement.objects.filter(purchase=self.purchase).count(), 1
        )
        self.assertEqual(gateway.return_value.verify_payment.call_count, 1)

    @override_settings(ZARINPAL_MERCHANT_ID="test-merchant")
    @patch("payments.gateways.zarinpal.requests.post")
    def test_toman_converted_to_rial(self, post):
        post.return_value.json.return_value = {"data": {"code": 100, "authority": "abc"}}
        ZarinPalGateway().create_payment(self.payment)
        self.assertEqual(post.call_args.kwargs["json"]["amount"], self.payment.amount_toman * 10)
