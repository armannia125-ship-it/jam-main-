"""Centralized subscription-entitlement service.

Single source of truth for "what may this business do right now?" — enforced at
backend boundaries (never by hiding frontend buttons). Only current
``SubscriptionEntitlement`` rows grant access; legacy subscription and club
membership records no longer participate.

Renewal rule (documented, deterministic, no proration): a new purchase of the
same entitlement type starts at ``max(now, latest current entitlement end)`` so
windows never overlap; there is no cancellation and no refund flow.
"""

from dataclasses import dataclass
from datetime import timedelta

from django.db import IntegrityError, transaction
from django.db.models import Max
from django.utils import timezone

from businesses.models import Business

from .models import SubscriptionEntitlement, SubscriptionProduct


@dataclass(frozen=True)
class ProductRef:
    slug: str
    name: str
    price_toman: int
    duration_days: int


BASIC_PRODUCT_LIMIT = 80


def menu_access(business):
    """True when the business may publish/edit menus."""
    now = timezone.now()
    return SubscriptionEntitlement.objects.filter(
        business=business,
        entitlement_type=SubscriptionEntitlement.Type.MENU,
        status=SubscriptionEntitlement.Status.ACTIVE,
        starts_at__lte=now,
        ends_at__gt=now,
    ).exists()


def club_access(business, moment=None):
    """True when the business has a current CLUB entitlement.

    ``moment`` allows checking access at a specific point in time; defaults to
    now.
    """
    moment = moment or timezone.now()
    return SubscriptionEntitlement.objects.filter(
        business=business,
        entitlement_type=SubscriptionEntitlement.Type.CLUB,
        status=SubscriptionEntitlement.Status.ACTIVE,
        starts_at__lte=moment,
        ends_at__gt=moment,
    ).exists()


def product_limit(business):
    """Maximum number of products allowed, or ``None`` for unlimited.

    Only the current MENU entitlement's product applies. No MENU entitlement
    means no products may be created.
    """
    ent = (
        SubscriptionEntitlement.objects.filter(
            business=business,
            entitlement_type=SubscriptionEntitlement.Type.MENU,
            status=SubscriptionEntitlement.Status.ACTIVE,
            starts_at__lte=timezone.now(),
            ends_at__gt=timezone.now(),
        )
        .select_related("product")
        .order_by("-ends_at")
        .first()
    )
    if ent is None:
        return 0
    return ent.product.max_products


def current_entitlements(business, entitlement_type=None):
    qs = SubscriptionEntitlement.objects.filter(
        business=business,
        status=SubscriptionEntitlement.Status.ACTIVE,
        starts_at__lte=timezone.now(),
        ends_at__gt=timezone.now(),
    ).select_related("product", "purchase")
    if entitlement_type:
        qs = qs.filter(entitlement_type=entitlement_type)
    return qs


def entitlement_summary(business):
    """Structured payload for the user panel / admin views."""
    now = timezone.now()
    # Lazily mark elapsed entitlements expired (safe, idempotent).
    SubscriptionEntitlement.objects.filter(
        business=business,
        status=SubscriptionEntitlement.Status.ACTIVE,
        ends_at__lte=now,
    ).update(status=SubscriptionEntitlement.Status.EXPIRED)
    return [
        {
            "type": e.entitlement_type,
            "product_slug": e.product.slug,
            "product_name": e.product.name,
            "status": "active" if e.is_current else e.status,
            "starts_at": e.starts_at,
            "ends_at": e.ends_at,
            "remaining_days": max(0, (e.ends_at - now).days),
        }
        for e in current_entitlements(business)
    ]


@transaction.atomic
def activate_entitlements_for_purchase(purchase):
    """Create the entitlement(s) for a PAID purchase, atomically and idempotently.

    Gold (category ``combo``) creates both a MENU and a CLUB entitlement, each
    with its own 30-day window. Duplicate callbacks cannot create duplicates:
    the unique constraint ``(purchase, entitlement_type)`` plus a re-read inside
    the transaction make this safe.
    """
    from .models import SubscriptionEntitlement as Entitlement

    # Serialize renewals and first-time activation per business so concurrent
    # purchases cannot compute the same renewal base and overlap windows.
    Business.objects.select_for_update().get(pk=purchase.business_id)

    product = purchase.product
    created = []
    types = (
        [Entitlement.Type.MENU, Entitlement.Type.CLUB]
        if product.category == SubscriptionProduct.Category.COMBO
        else (
            [Entitlement.Type.CLUB]
            if product.category == SubscriptionProduct.Category.CLUB
            else [Entitlement.Type.MENU]
        )
    )
    for etype in types:
        if Entitlement.objects.filter(purchase=purchase, entitlement_type=etype).exists():
            continue
        base = (
            Entitlement.objects.filter(
                business=purchase.business,
                entitlement_type=etype,
                status=Entitlement.Status.ACTIVE,
            ).aggregate(latest=Max("ends_at"))["latest"]
            or timezone.now()
        )
        starts_at = max(timezone.now(), base)
        ends_at = starts_at + timedelta(days=product.duration_days)
        try:
            # The savepoint keeps the outer activation transaction usable when
            # another concurrent caller wins the unique(purchase, type) race.
            with transaction.atomic():
                created.append(
                    Entitlement.objects.create(
                        user=purchase.user,
                        business=purchase.business,
                        entitlement_type=etype,
                        product=product,
                        purchase=purchase,
                        starts_at=starts_at,
                        ends_at=ends_at,
                        status=Entitlement.Status.ACTIVE,
                    )
                )
        except IntegrityError:
            # Another transaction already activated this type. Idempotency is
            # the contract; a duplicate callback must not fail the request.
            continue
    return created


@transaction.atomic
def revoke_entitlement(entitlement, revoked_by, reason=""):
    """Admin-initiated revocation. Only touches the targeted entitlement."""
    now = timezone.now()
    entitlement.status = SubscriptionEntitlement.Status.REVOKED
    entitlement.revoked_at = now
    entitlement.revoked_by = revoked_by
    entitlement.revocation_reason = reason[:200]
    entitlement.save(update_fields=["status", "revoked_at", "revoked_by", "revocation_reason"])
    return entitlement


def product_slugs():
    """Stable catalog slugs (the authoritative seeded products)."""
    return ["basic", "professional", "premium", "gold", "seller_club"]


def get_product(slug):
    return SubscriptionProduct.objects.get(slug=slug, is_active=True)
