"""Five-day expiration notification tests.

Boundary conditions per the acceptance criteria: exactly five days, more than
five days, less than five on a first run, already expired, revoked, repeated
runs (idempotency), Gold's two independent notifications, user ownership, and
timezone boundary handling.
"""

from datetime import timedelta
from io import StringIO

from django.core.management import call_command
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APITestCase

from accounts.models import User
from businesses.models import Business
from subscriptions.management.commands.notify_expiring_entitlements import (
    run_expiration_notifications,
)
from subscriptions.models import (
    EntitlementNotification,
    SubscriptionEntitlement,
    SubscriptionProduct,
    SubscriptionPurchase,
)


def _make_user(phone):
    return User.objects.create_user(phone=phone)


def _gold_entitlement(owner, business, user, ends_in_days, status=SubscriptionEntitlement.Status.ACTIVE):
    product = SubscriptionProduct.objects.get(slug="gold")
    purchase = SubscriptionPurchase.objects.create(
        user=owner, business=business, product=product,
        price_toman=product.price_toman, status=SubscriptionPurchase.Status.PAID,
    )
    now = timezone.now()
    return SubscriptionEntitlement.objects.create(
        user=user, business=business, entitlement_type=SubscriptionEntitlement.Type.MENU,
        product=product, purchase=purchase,
        starts_at=now - timedelta(days=25),
        ends_at=now + timedelta(days=ends_in_days),
        status=status,
    )


class ExpirationNotificationTests(APITestCase):
    def setUp(self):
        self.owner = _make_user("09120000401")
        self.business = Business.objects.create(owner=self.owner, name="Shop", slug="shop")

    def test_exactly_five_days_notifies_once(self):
        ent = _gold_entitlement(self.owner, self.business, self.owner, 5)
        created, _ = run_expiration_notifications()
        self.assertEqual(created, 1)
        self.assertTrue(EntitlementNotification.objects.filter(entitlement=ent).exists())
        # repeated execution is a no-op
        created2, skipped2 = run_expiration_notifications()
        self.assertEqual((created2, skipped2), (0, 1))
        self.assertEqual(EntitlementNotification.objects.filter(entitlement=ent).count(), 1)

    def test_more_than_five_days_does_not_notify(self):
        _gold_entitlement(self.owner, self.business, self.owner, 6)
        created, _ = run_expiration_notifications()
        self.assertEqual(created, 0)

    def test_less_than_five_days_notifies_on_first_run(self):
        ent = _gold_entitlement(self.owner, self.business, self.owner, 3)
        created, _ = run_expiration_notifications()
        self.assertEqual(created, 1)
        note = EntitlementNotification.objects.get(entitlement=ent)
        self.assertEqual(note.payload["entitlement_type"], "menu")
        self.assertEqual(note.user_id, self.owner.pk)

    def test_already_expired_does_not_notify(self):
        ent = _gold_entitlement(self.owner, self.business, self.owner, -1)
        created, _ = run_expiration_notifications()
        self.assertEqual(created, 0)
        self.assertFalse(EntitlementNotification.objects.filter(entitlement=ent).exists())

    def test_revoked_does_not_notify(self):
        ent = _gold_entitlement(self.owner, self.business, self.owner, 4)
        ent.status = SubscriptionEntitlement.Status.REVOKED
        ent.save(update_fields=["status"])
        created, _ = run_expiration_notifications()
        self.assertEqual(created, 0)

    def test_gold_produces_independent_notifications(self):
        product = SubscriptionProduct.objects.get(slug="gold")
        purchase = SubscriptionPurchase.objects.create(
            user=self.owner, business=self.business, product=product,
            price_toman=product.price_toman, status=SubscriptionPurchase.Status.PAID,
        )
        now = timezone.now()
        for etype in (SubscriptionEntitlement.Type.MENU, SubscriptionEntitlement.Type.CLUB):
            SubscriptionEntitlement.objects.create(
                user=self.owner, business=self.business, entitlement_type=etype,
                product=product, purchase=purchase,
                starts_at=now - timedelta(days=25),
                ends_at=now + timedelta(days=5),
            )
        created, _ = run_expiration_notifications()
        self.assertEqual(created, 2)  # two independent lifecycles → two notifications
        kinds = EntitlementNotification.objects.values_list("payload__entitlement_type", flat=True)
        self.assertEqual(set(kinds), {"menu", "club"})

    def test_command_runs_and_is_safe_repeatedly(self):
        _gold_entitlement(self.owner, self.business, self.owner, 5)
        out = StringIO()
        call_command("notify_expiring_entitlements", stdout=out)
        self.assertIn("created=1", out.getvalue())
        call_command("notify_expiring_entitlements", stdout=out)
        self.assertIn("created=0", out.getvalue())

    def test_notification_belongs_to_entitlement_owner_only(self):
        ent = _gold_entitlement(self.owner, self.business, self.owner, 5)
        other = _make_user("09120000402")
        run_expiration_notifications()
        self.assertFalse(EntitlementNotification.objects.filter(user=other).exists())
        note = EntitlementNotification.objects.get(entitlement=ent)
        self.assertEqual(note.user_id, self.owner.pk)

    def test_timezone_boundary_uses_window_edges_correctly(self):
        """5 days + 1 second → outside window; 4 days 23h → inside window."""
        outside = _gold_entitlement(self.owner, self.business, self.owner, 5)
        outside.ends_at = timezone.now() + timedelta(days=5, seconds=1)
        outside.save(update_fields=["ends_at"])
        inside = _gold_entitlement(self.owner, self.business, self.owner, 4)
        inside.ends_at = timezone.now() + timedelta(days=4, hours=23)
        inside.save(update_fields=["ends_at"])
        created, _ = run_expiration_notifications()
        self.assertEqual(created, 1)
        self.assertTrue(EntitlementNotification.objects.filter(entitlement=inside).exists())
        self.assertFalse(EntitlementNotification.objects.filter(entitlement=outside).exists())

    def test_notification_api_is_user_scoped(self):
        ent = _gold_entitlement(self.owner, self.business, self.owner, 5)
        run_expiration_notifications()
        self.client.force_authenticate(self.owner)
        response = self.client.get("/api/subscriptions/notifications/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.json()["results"]), 1)
        other = _make_user("09120000403")
        self.client.force_authenticate(other)
        response = self.client.get("/api/subscriptions/notifications/")
        self.assertEqual(response.json()["results"], [])
        # mark-as-read
        self.client.force_authenticate(self.owner)
        marked = self.client.post("/api/subscriptions/notifications/")
        self.assertEqual(marked.status_code, 200)
        unread = self.client.get("/api/subscriptions/notifications/", {"unread": "1"})
        self.assertEqual(unread.json()["results"], [])
        # anonymous denied
        self.client.force_authenticate(user=None)
        denied = self.client.get("/api/subscriptions/notifications/")
        self.assertEqual(denied.status_code, status.HTTP_401_UNAUTHORIZED)
