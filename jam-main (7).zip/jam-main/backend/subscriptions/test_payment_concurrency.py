"""PostgreSQL-only concurrency checks for the online purchase flow.

Verifies what SQLite cannot: that concurrent duplicate callbacks (replays) and
parallel Gold activation produce exactly one payment success and exactly the
approved set of entitlements, thanks to ``select_for_update`` plus the
``unique(purchase, entitlement_type)`` constraint.
"""

import threading
import unittest
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta
from unittest import mock
from urllib.parse import urlencode

from django.db import close_old_connections, connection
from django.test import Client, TransactionTestCase
from django.utils import timezone

from accounts.models import User
from businesses.models import Business

from .models import (
    SubscriptionEntitlement,
    SubscriptionProduct,
    SubscriptionPurchase,
)


def _run_parallel(workers):
    barrier = threading.Barrier(len(workers))

    def wrapped(index):
        close_old_connections()
        try:
            barrier.wait(timeout=10)
            return ("ok", workers[index]())
        except Exception as exc:
            return ("error", type(exc).__name__, str(exc))
        finally:
            connection.close()

    with ThreadPoolExecutor(max_workers=len(workers)) as pool:
        return list(pool.map(wrapped, range(len(workers))))


@unittest.skipUnless(connection.vendor == "postgresql", "PostgreSQL-only concurrency tests")
class PurchaseCallbackConcurrencyTests(TransactionTestCase):
    reset_sequences = True

    def setUp(self):
        # TransactionTestCase flushes data (incl. seed migrations) between tests,
        # so the product row is ensured here rather than assumed from seeds.
        self.owner = User.objects.create_user(phone="09120000501")
        self.business = Business.objects.create(owner=self.owner, name="Shop", slug="shop")
        self.product, _ = SubscriptionProduct.objects.get_or_create(
            slug="gold",
            defaults={
                "name": "طلایی",
                "category": "combo",
                "price_toman": 450000,
                "duration_days": 30,
                "sort_order": 40,
            },
        )
        self.purchase = SubscriptionPurchase.objects.create(
            user=self.owner,
            business=self.business,
            product=self.product,
            price_toman=self.product.price_toman,
            status=SubscriptionPurchase.Status.PENDING,
        )
        from payments.models import Transaction

        self.transaction = Transaction.objects.create(
            purchase=self.purchase,
            amount_toman=self.product.price_toman,
            gateway="zarinpal",
            status=Transaction.Status.INITIATED,
            authority="AUTHCONC1",
        )
        self.callback_url = "/api/payments/zarinpal/callback/?" + urlencode(
            {"Authority": "AUTHCONC1", "Status": "OK"}
        )

    def test_concurrent_duplicate_callbacks_create_exactly_two_entitlements(self):
        """Concurrent callbacks with mocked verification: no duplicate activation."""
        client = Client()

        def _call():
            return client.get(self.callback_url, follow=True)

        with mock.patch(
            "payments.views.ZarinPalGateway",
            **{
                "return_value.verify_payment.return_value": {
                    "ref_id": "REF1",
                    "payload": {"mock": True},
                }
            },
        ):
            results = _run_parallel([_call, _call, _call, _call])

        statuses = [r if r[0] == "error" else r[1].status_code for r in results]
        if any(s != 200 for s in statuses if isinstance(s, int)) or any(
            isinstance(s, tuple) for s in statuses
        ):
            self.fail(f"unexpected callback thread results: {statuses}")
        self.purchase.refresh_from_db()
        self.assertEqual(self.purchase.status, SubscriptionPurchase.Status.PAID)
        self.assertEqual(SubscriptionEntitlement.objects.filter(purchase=self.purchase).count(), 2)

    def test_concurrent_entitlement_creation_respects_unique_constraint(self):
        """Parallel activate_entitlements_for_purchase calls are idempotent."""
        self.purchase.status = SubscriptionPurchase.Status.PAID
        self.purchase.confirmed_at = timezone.now()
        self.purchase.save(update_fields=["status", "confirmed_at"])

        from subscriptions.entitlements import activate_entitlements_for_purchase

        def _activate():
            return len(activate_entitlements_for_purchase(self.purchase))

        results = _run_parallel([_activate, _activate, _activate])
        # Exactly one worker creates the two rows; losers are blocked by the
        # unique (purchase, entitlement_type) constraint — this is the desired
        # idempotency guarantee under concurrent callbacks.
        winners = [r for r in results if r[0] == "ok"]
        losers = [r for r in results if r[0] == "error" and r[1] == "IntegrityError"]
        self.assertEqual(len(winners) + len(losers), len(results))
        self.assertEqual(sum(r[1] for r in winners), 2)
        entitlements = SubscriptionEntitlement.objects.filter(purchase=self.purchase)
        self.assertEqual(entitlements.count(), 2)
        self.assertEqual(
            sorted(entitlements.values_list("entitlement_type", flat=True)),
            [SubscriptionEntitlement.Type.CLUB, SubscriptionEntitlement.Type.MENU],
        )
