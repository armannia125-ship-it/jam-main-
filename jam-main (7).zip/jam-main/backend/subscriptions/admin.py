"""Legacy subscription admin removed.

Canonical purchase/entitlement administration lives in the dedicated admin UI.
"""
