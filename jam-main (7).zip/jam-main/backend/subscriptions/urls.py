from django.urls import path

from .purchase_views import (
    EntitlementNotificationsView,
    SubscriptionCatalogView,
    SubscriptionPurchaseStatusView,
    SubscriptionPurchaseView,
)

urlpatterns = [
    path("products/", SubscriptionCatalogView.as_view(), name="subscription-products"),
    path("purchases/", SubscriptionPurchaseView.as_view(), name="subscription-purchase"),
    path("purchases/<int:purchase_id>/", SubscriptionPurchaseStatusView.as_view(), name="subscription-purchase-status"),
    path("notifications/", EntitlementNotificationsView.as_view(), name="subscription-notifications"),
]
