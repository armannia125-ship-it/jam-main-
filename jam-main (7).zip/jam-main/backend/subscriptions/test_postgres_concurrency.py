"""Deterministic PostgreSQL concurrency coverage for purchases and access.

These tests use real threads and independent connections. They are skipped on
SQLite, which cannot exercise row locking or cross-connection uniqueness.
"""

import threading
import unittest
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta
from unittest import mock

from django.db import close_old_connections, connection
from django.test import TransactionTestCase
from django.utils import timezone
from rest_framework.test import APIClient

from accounts.models import User
from businesses.models import Business, Category, Menu, Product
from payments.models import Transaction

from .entitlements import activate_entitlements_for_purchase
from .models import SubscriptionEntitlement, SubscriptionProduct, SubscriptionPurchase


def _run_parallel(workers):
    barrier = threading.Barrier(len(workers))

    def wrapped(index):
        close_old_connections()
        try:
            barrier.wait(timeout=10)
            return ("ok", workers[index]())
        except Exception as exc:
            return ("error", type(exc).__name__, str(exc))
        finally:
            connection.close()

    with ThreadPoolExecutor(max_workers=len(workers)) as pool:
        return list(pool.map(wrapped, range(len(workers))))


def _product(slug, **overrides):
    defaults = {
        "name": slug.title(),
        "category": SubscriptionProduct.Category.MENU,
        "price_toman": 100000,
        "duration_days": 30,
        "max_products": 80,
        "sort_order": 10,
    }
    defaults.update(overrides)
    product, _ = SubscriptionProduct.objects.get_or_create(slug=slug, defaults=defaults)
    return product


def _paid_purchase(user, business, product):
    return SubscriptionPurchase.objects.create(
        user=user,
        business=business,
        product=product,
        price_toman=product.price_toman,
        status=SubscriptionPurchase.Status.PAID,
        confirmed_at=timezone.now(),
    )


@unittest.skipUnless(connection.vendor == "postgresql", "PostgreSQL-only concurrency tests")
class PurchaseInitiationConcurrencyTests(TransactionTestCase):
    reset_sequences = True

    def setUp(self):
        self.owner = User.objects.create_user(phone="09120000601")
        self.business = Business.objects.create(owner=self.owner, name="Shop", slug="shop")
        self.product = _product("basic")

    def _post(self):
        client = APIClient()
        client.force_authenticate(user=self.owner)
        return client.post(
            "/api/subscriptions/purchases/",
            {"product_slug": self.product.slug, "business_id": self.business.pk},
            format="json",
        )

    def test_concurrent_purchase_requests_create_one_pending_purchase(self):
        with mock.patch("subscriptions.purchase_views.ZarinPalGateway") as gateway:
            gateway.return_value.create_payment.return_value = {
                "authority": "AUTHRACE",
                "payment_url": "https://example.test/pay/AUTHRACE",
            }
            outcomes = _run_parallel([self._post for _ in range(8)])

        self.assertTrue(all(kind == "ok" for kind, *rest in outcomes), outcomes)
        self.assertEqual(
            [r.status_code for _, r in outcomes],
            [201] * len(outcomes),
            outcomes,
        )
        self.assertEqual(SubscriptionPurchase.objects.count(), 1)
        self.assertEqual(SubscriptionPurchase.objects.get().status, SubscriptionPurchase.Status.PENDING)


@unittest.skipUnless(connection.vendor == "postgresql", "PostgreSQL-only concurrency tests")
class EntitlementActivationConcurrencyTests(TransactionTestCase):
    reset_sequences = True

    def setUp(self):
        self.owner = User.objects.create_user(phone="09120000602")
        self.business = Business.objects.create(owner=self.owner, name="Shop", slug="shop")

    def test_concurrent_renewals_do_not_overlap(self):
        product = _product("basic")
        first = _paid_purchase(self.owner, self.business, product)
        second = _paid_purchase(self.owner, self.business, product)

        outcomes = _run_parallel([
            lambda: len(activate_entitlements_for_purchase(first)),
            lambda: len(activate_entitlements_for_purchase(second)),
        ])
        self.assertTrue(all(kind == "ok" for kind, *rest in outcomes), outcomes)
        self.assertEqual(sum(r for kind, *rest in outcomes if kind == "ok" for r in rest), 2)

        entitlements = list(
            SubscriptionEntitlement.objects.filter(
                business=self.business,
                entitlement_type=SubscriptionEntitlement.Type.MENU,
            ).order_by("starts_at", "pk")
        )
        self.assertEqual(len(entitlements), 2)
        self.assertGreaterEqual(entitlements[1].starts_at, entitlements[0].ends_at)
        self.assertEqual(SubscriptionEntitlement.objects.count(), 2)

    def test_failed_gold_activation_rolls_back_both_entitlements(self):
        gold = _product(
            "gold",
            category=SubscriptionProduct.Category.COMBO,
            price_toman=450000,
            sort_order=40,
        )
        purchase = _paid_purchase(self.owner, self.business, gold)
        original_create = SubscriptionEntitlement.objects.create

        def create_with_club_failure(**kwargs):
            if kwargs["entitlement_type"] == SubscriptionEntitlement.Type.CLUB:
                raise RuntimeError("forced club activation failure")
            return original_create(**kwargs)

        with mock.patch.object(
            SubscriptionEntitlement.objects,
            "create",
            side_effect=create_with_club_failure,
        ):
            with self.assertRaises(RuntimeError):
                activate_entitlements_for_purchase(purchase)

        self.assertEqual(SubscriptionEntitlement.objects.filter(purchase=purchase).count(), 0)


@unittest.skipUnless(connection.vendor == "postgresql", "PostgreSQL-only concurrency tests")
class PaymentCallbackRollbackTests(TransactionTestCase):
    reset_sequences = True

    def test_verification_failure_leaves_no_entitlement_and_no_paid_purchase(self):
        owner = User.objects.create_user(phone="09120000604")
        business = Business.objects.create(owner=owner, name="Shop", slug="shop")
        product = _product("basic")
        purchase = SubscriptionPurchase.objects.create(
            user=owner,
            business=business,
            product=product,
            price_toman=product.price_toman,
        )
        Transaction.objects.create(
            purchase=purchase,
            amount_toman=product.price_toman,
            authority="AUTHROLLBACK",
        )

        with mock.patch("payments.views.ZarinPalGateway") as gateway:
            gateway.return_value.verify_payment.side_effect = RuntimeError("provider down")
            response = self.client.get(
                "/api/payments/zarinpal/callback/?Authority=AUTHROLLBACK&Status=OK"
            )

        self.assertEqual(response.status_code, 502)
        purchase.refresh_from_db()
        self.assertEqual(purchase.status, SubscriptionPurchase.Status.PENDING)
        self.assertIsNone(purchase.confirmed_at)
        self.assertEqual(SubscriptionEntitlement.objects.filter(purchase=purchase).count(), 0)
        self.assertEqual(Transaction.objects.get(purchase=purchase).status, Transaction.Status.INITIATED)


@unittest.skipUnless(connection.vendor == "postgresql", "PostgreSQL-only concurrency tests")
class ProductLimitConcurrencyTests(TransactionTestCase):
    reset_sequences = True

    def setUp(self):
        self.owner = User.objects.create_user(phone="09120000603")
        self.business = Business.objects.create(owner=self.owner, name="Shop", slug="shop")
        self.menu = Menu.objects.create(business=self.business, title="Menu", slug="menu")
        self.category = Category.objects.create(menu=self.menu, name="Food")
        Product.objects.create(category=self.category, name="Existing", price_toman=1000)

        product = _product("basic", max_products=2)
        purchase = _paid_purchase(self.owner, self.business, product)
        now = timezone.now()
        SubscriptionEntitlement.objects.create(
            user=self.owner,
            business=self.business,
            entitlement_type=SubscriptionEntitlement.Type.MENU,
            product=product,
            purchase=purchase,
            starts_at=now - timedelta(minutes=1),
            ends_at=now + timedelta(days=30),
            status=SubscriptionEntitlement.Status.ACTIVE,
        )

    def _post(self, index):
        client = APIClient()
        client.force_authenticate(user=self.owner)
        return client.post(
            "/api/products/",
            {
                "category": self.category.pk,
                "name": f"Concurrent {index}",
                "price_toman": 1000,
            },
            format="json",
        )

    def test_concurrent_creation_cannot_exceed_product_limit(self):
        outcomes = _run_parallel([lambda i=i: self._post(i) for i in range(8)])

        self.assertTrue(all(kind == "ok" for kind, *rest in outcomes), outcomes)
        statuses = [r.status_code for _, r in outcomes]
        self.assertEqual(statuses.count(201), 1, statuses)
        self.assertEqual(statuses.count(403), 7, statuses)
        self.assertEqual(Product.objects.filter(category__menu__business=self.business).count(), 2)

    def test_revocation_does_not_remove_the_other_entitlement_type(self):
        product = _product(
            "gold",
            category=SubscriptionProduct.Category.COMBO,
            price_toman=450000,
            sort_order=40,
        )
        purchase = _paid_purchase(self.owner, self.business, product)
        activate_entitlements_for_purchase(purchase)

        menu_ent = SubscriptionEntitlement.objects.get(
            purchase=purchase, entitlement_type=SubscriptionEntitlement.Type.MENU
        )
        club_ent = SubscriptionEntitlement.objects.get(
            purchase=purchase, entitlement_type=SubscriptionEntitlement.Type.CLUB
        )
        menu_ent.status = SubscriptionEntitlement.Status.REVOKED
        menu_ent.save(update_fields=["status"])

        club_ent.refresh_from_db()
        self.assertEqual(club_ent.status, SubscriptionEntitlement.Status.ACTIVE)
        self.assertFalse(
            SubscriptionEntitlement.objects.filter(
                business=self.business, entitlement_type=SubscriptionEntitlement.Type.CLUB
            ).exclude(status=SubscriptionEntitlement.Status.ACTIVE).exists()
        )
