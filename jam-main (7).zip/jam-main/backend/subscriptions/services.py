"""Legacy manual subscription service removed."""
