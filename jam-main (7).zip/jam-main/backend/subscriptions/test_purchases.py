"""Online subscription-purchase and payment-lifecycle tests.

All provider interactions are mocked — no real Zarinpal request is ever sent.
Covers the owner-approved acceptance criteria: server-authoritative prices,
safe failure when the provider is unconfigured, idempotent callbacks, Gold's
two independent entitlements, and RBAC/ownership guards.
"""

import contextlib
from datetime import timedelta
from unittest import mock

from django.test import override_settings
from django.urls import reverse
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APITestCase

from accounts.models import User
from businesses.models import Business
from payments.models import Transaction
from subscriptions.models import (
    SubscriptionEntitlement,
    SubscriptionProduct,
    SubscriptionPurchase,
)


def _make_user(phone):
    return User.objects.create_user(phone=phone)


def _make_business(owner, name, slug):
    return Business.objects.create(owner=owner, name=name, slug=slug)


class PurchaseFlowTests(APITestCase):
    def setUp(self):
        self.owner = _make_user("09120000021")
        self.other = _make_user("09120000022")
        self.business = _make_business(self.owner, "Cafe A", "cafe-a")
        self.product = SubscriptionProduct.objects.get(slug="gold")
        self.client.force_authenticate(self.owner)

    @contextlib.contextmanager
    def _mock_gateway(self, authority="AUTH123", ref_id="REF9", verify_payload=None):
        """Patch both import sites of the gateway (purchase view + callback view)."""
        spec = {
            "return_value.create_payment.return_value": {
                "authority": authority,
                "payment_url": "https://example.com/pay/" + authority,
            },
            "return_value.verify_payment.return_value": verify_payload
            or {"ref_id": ref_id, "payload": {"mock": True}},
        }
        with mock.patch("subscriptions.purchase_views.ZarinPalGateway", **spec), mock.patch(
            "payments.views.ZarinPalGateway", **spec
        ):
            yield

    def _use_gateway(self, **kwargs):
        cm = self._mock_gateway(**kwargs)
        cm.__enter__()
        self.addCleanup(lambda: cm.__exit__(None, None, None))

    def test_catalog_lists_five_products_with_exact_prices(self):
        self.client.force_authenticate(user=None)
        response = self.client.get("/api/subscriptions/products/")
        self.assertEqual(response.status_code, 200)
        by_slug = {p["slug"]: p for p in response.json()["results"]}
        expected = {
            "basic": 200000,
            "professional": 250000,
            "premium": 350000,
            "gold": 450000,
            "seller_club": 350000,
        }
        self.assertEqual(set(by_slug), set(expected))
        for slug, price in expected.items():
            self.assertEqual(by_slug[slug]["price_toman"], price)
            self.assertEqual(by_slug[slug]["duration_days"], 30)

    def test_purchase_start_creates_pending_purchase_and_initiated_payment(self):
        with self._mock_gateway():
            response = self.client.post(
                "/api/subscriptions/purchases/",
                {"product_slug": "gold", "business_id": self.business.pk},
                format="json",
            )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        purchase = SubscriptionPurchase.objects.get(pk=response.json()["purchase_id"])
        self.assertEqual(purchase.status, SubscriptionPurchase.Status.PENDING)
        self.assertEqual(purchase.price_toman, 450000)  # server-authoritative snapshot
        self.assertTrue(purchase.transactions.filter(status=Transaction.Status.INITIATED).exists())
        self.assertTrue(response.json()["payment_url"])

    def test_purchase_ignores_client_supplied_price(self):
        with self._mock_gateway():
            response = self.client.post(
                "/api/subscriptions/purchases/",
                {"product_slug": "gold", "business_id": self.business.pk, "price_toman": 1},
                format="json",
            )
        purchase = SubscriptionPurchase.objects.get(pk=response.json()["purchase_id"])
        self.assertEqual(purchase.price_toman, 450000)

    def test_purchase_requires_ownership_of_business(self):
        self.client.force_authenticate(self.other)
        response = self.client.post(
            "/api/subscriptions/purchases/",
            {"product_slug": "gold", "business_id": self.business.pk},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)
        self.assertEqual(SubscriptionPurchase.objects.count(), 0)

    def test_purchase_unknown_product(self):
        response = self.client.post(
            "/api/subscriptions/purchases/",
            {"product_slug": "nope", "business_id": self.business.pk},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_unconfigured_provider_fails_safely(self):
        """No merchant credentials → 503 and NOTHING created (never fake success)."""
        with override_settings(ZARINPAL_MERCHANT_ID=""):
            response = self.client.post(
                "/api/subscriptions/purchases/",
                {"product_slug": "gold", "business_id": self.business.pk},
                format="json",
            )
        self.assertEqual(response.status_code, status.HTTP_503_SERVICE_UNAVAILABLE)
        self.assertEqual(response.json()["code"], "payment_provider_unconfigured")
        self.assertEqual(SubscriptionPurchase.objects.count(), 0)
        self.assertEqual(Transaction.objects.count(), 0)

    def test_repeated_purchase_reuses_pending_purchase(self):
        with self._mock_gateway():
            first = self.client.post(
                "/api/subscriptions/purchases/",
                {"product_slug": "gold", "business_id": self.business.pk},
                format="json",
            )
            second = self.client.post(
                "/api/subscriptions/purchases/",
                {"product_slug": "gold", "business_id": self.business.pk},
                format="json",
            )
        self.assertEqual(first.json()["purchase_id"], second.json()["purchase_id"])
        self.assertEqual(SubscriptionPurchase.objects.count(), 1)

    def test_provider_transport_error_keeps_attempt_initiated(self):
        with mock.patch(
            "subscriptions.purchase_views.ZarinPalGateway",
            **{"return_value.create_payment.side_effect": RuntimeError("boom")},
        ):
            response = self.client.post(
                "/api/subscriptions/purchases/",
                {"product_slug": "gold", "business_id": self.business.pk},
                format="json",
            )
        self.assertEqual(response.status_code, status.HTTP_502_BAD_GATEWAY)
        # The attempt stays INITIATED for retry (the 502 body deliberately omits
        # the purchase id; read it from the DB).
        purchase = SubscriptionPurchase.objects.get(
            user=self.owner, product=self.product, business=self.business
        )
        self.assertEqual(purchase.status, SubscriptionPurchase.Status.PENDING)
        self.assertTrue(purchase.transactions.filter(status=Transaction.Status.INITIATED).exists())

    # ---- callback lifecycle -------------------------------------------------

    def _start_purchase(self, authority="AUTHX1"):
        with self._mock_gateway(authority=authority):
            response = self.client.post(
                "/api/subscriptions/purchases/",
                {"product_slug": "gold", "business_id": self.business.pk},
                format="json",
            )
        return SubscriptionPurchase.objects.get(pk=response.json()["purchase_id"])

    def test_verified_callback_marks_paid_and_creates_two_entitlements(self):
        purchase = self._start_purchase("AUTHG1")
        self._use_gateway()
        response = self.client.get(
            "/api/payments/zarinpal/callback/", {"Authority": "AUTHG1", "Status": "OK"}
        )
        self.assertEqual(response.status_code, 200)
        purchase.refresh_from_db()
        self.assertEqual(purchase.status, SubscriptionPurchase.Status.PAID)
        self.assertIsNotNone(purchase.confirmed_at)
        entitlements = list(SubscriptionEntitlement.objects.filter(purchase=purchase))
        self.assertEqual(len(entitlements), 2)
        types = {e.entitlement_type for e in entitlements}
        self.assertEqual(types, {"menu", "club"})
        for e in entitlements:
            self.assertEqual((e.ends_at - e.starts_at).days, 30)
            self.assertTrue(e.is_current)

    def test_cancelled_callback_marks_purchase_failed_without_entitlements(self):
        purchase = self._start_purchase("AUTHC1")
        response = self.client.get(
            "/api/payments/zarinpal/callback/", {"Authority": "AUTHC1", "Status": "NOK"}
        )
        self.assertEqual(response.status_code, 400)
        purchase.refresh_from_db()
        self.assertEqual(purchase.status, SubscriptionPurchase.Status.FAILED)
        self.assertEqual(SubscriptionEntitlement.objects.filter(purchase=purchase).count(), 0)

    def test_failed_verification_activates_nothing(self):
        purchase = self._start_purchase("AUTHF1")
        with mock.patch(
            "payments.views.ZarinPalGateway",
            **{"return_value.verify_payment.side_effect": RuntimeError("verify failed")},
        ):
            response = self.client.get(
                "/api/payments/zarinpal/callback/", {"Authority": "AUTHF1", "Status": "OK"}
            )
        self.assertEqual(response.status_code, 502)
        purchase.refresh_from_db()
        self.assertEqual(purchase.status, SubscriptionPurchase.Status.PENDING)
        self.assertEqual(SubscriptionEntitlement.objects.filter(purchase=purchase).count(), 0)

    def test_callback_is_idempotent_on_replay(self):
        purchase = self._start_purchase("AUTHR1")
        self._use_gateway()
        for _ in range(3):
            response = self.client.get(
                "/api/payments/zarinpal/callback/", {"Authority": "AUTHR1", "Status": "OK"}
            )
            self.assertEqual(response.status_code, 200)
        purchase.refresh_from_db()
        self.assertEqual(purchase.status, SubscriptionPurchase.Status.PAID)
        self.assertEqual(SubscriptionEntitlement.objects.filter(purchase=purchase).count(), 2)
        self.assertEqual(purchase.transactions.filter(status=Transaction.Status.SUCCESS).count(), 1)

    def test_callback_unknown_authority(self):
        response = self.client.get(
            "/api/payments/zarinpal/callback/", {"Authority": "UNKNOWN", "Status": "OK"}
        )
        self.assertEqual(response.status_code, 404)

    def test_gold_entitlements_expire_and_revoke_independently(self):
        self._use_gateway(authority="AUTHI1")
        purchase = self._start_purchase("AUTHI1")
        self.client.get("/api/payments/zarinpal/callback/", {"Authority": "AUTHI1", "Status": "OK"})
        menu = SubscriptionEntitlement.objects.get(purchase=purchase, entitlement_type="menu")
        club = SubscriptionEntitlement.objects.get(purchase=purchase, entitlement_type="club")
        self.assertNotEqual(menu.ends_at, club.ends_at)  # independent windows
        menu.status = SubscriptionEntitlement.Status.EXPIRED
        menu.save(update_fields=["status"])
        club.refresh_from_db()
        self.assertEqual(club.status, SubscriptionEntitlement.Status.ACTIVE)
        self.assertTrue(club.is_current)

    def test_renewal_starts_after_current_window_ends(self):
        self._use_gateway(authority="AUTHN1")
        purchase = self._start_purchase("AUTHN1")
        self.client.get("/api/payments/zarinpal/callback/", {"Authority": "AUTHN1", "Status": "OK"})
        # Renew: second gold purchase for the same business.
        with self._mock_gateway(authority="AUTHN2"):
            response = self.client.post(
                "/api/subscriptions/purchases/",
                {"product_slug": "gold", "business_id": self.business.pk},
                format="json",
            )
        self.client.get("/api/payments/zarinpal/callback/", {"Authority": "AUTHN2", "Status": "OK"})
        purchase2 = SubscriptionPurchase.objects.get(pk=response.json()["purchase_id"])
        first_menu = SubscriptionEntitlement.objects.get(purchase=purchase, entitlement_type="menu")
        second_menu = SubscriptionEntitlement.objects.get(purchase=purchase2, entitlement_type="menu")
        self.assertEqual(second_menu.starts_at, first_menu.ends_at)  # stacked, not overlapping

    def test_purchase_status_is_owner_scoped(self):
        purchase = self._start_purchase("AUTHS1")
        response = self.client.get(f"/api/subscriptions/purchases/{purchase.pk}/")
        self.assertEqual(response.status_code, 200)
        self.client.force_authenticate(self.other)
        response = self.client.get(f"/api/subscriptions/purchases/{purchase.pk}/")
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_purchase_history_requires_authentication(self):
        self.client.force_authenticate(user=None)
        response = self.client.get("/api/subscriptions/purchases/")
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)
