"""Five-day subscription-expiration notification job.

Idempotent by design: one notification per (entitlement, kind). Safe to run
repeatedly (cron/scheduler), timezone-aware (uses the project TZ for day
boundary math via ``timezone.localdate``), and never notifies for expired or
revoked entitlements. A Gold purchase legitimately produces two independent
notifications because its MENU and CLUB entitlements have separate lifecycles.

Deployment (no Celery/beat exists in this project): schedule the management
command, e.g. daily 09:00 Asia/Tehran via cron on the backend container —

    docker compose exec -T backend python manage.py notify_expiring_entitlements

The exact scheduling wiring is documented in docs/SUBSCRIPTION_NOTIFICATIONS.md
and remains an operational requirement for production.
"""

from datetime import timedelta

from django.core.management.base import BaseCommand
from django.utils import timezone

from subscriptions.models import EntitlementNotification, SubscriptionEntitlement


NOTIFY_KIND = EntitlementNotification.Kind.EXPIRING_5D
NOTIFY_WINDOW_DAYS = 5


def run_expiration_notifications(now=None):
    """Create 5-day expiration notifications; returns (created, skipped) counts.

    Idempotent: an existing (entitlement, kind) row short-circuits creation.
    """
    now = now or timezone.now()
    horizon = now + timedelta(days=NOTIFY_WINDOW_DAYS)
    candidates = SubscriptionEntitlement.objects.filter(
        status=SubscriptionEntitlement.Status.ACTIVE,
        starts_at__lte=now,
        ends_at__gt=now,          # not already expired
        ends_at__lte=horizon,     # within the five-day window
    ).select_related("user", "product", "business")

    created = 0
    skipped = 0
    for ent in candidates:
        existing = EntitlementNotification.objects.filter(
            entitlement_id=ent.pk, kind=NOTIFY_KIND
        ).exists()
        if existing:
            skipped += 1
            continue
        EntitlementNotification.objects.create(
            user=ent.user,
            entitlement=ent,
            kind=NOTIFY_KIND,
            payload={
                "entitlement_type": ent.entitlement_type,
                "product_slug": ent.product.slug,
                "product_name": ent.product.name,
                "business_name": ent.business.name,
                "ends_at": ent.ends_at.isoformat(),
                "remaining_days": max(0, (ent.ends_at - now).days),
            },
        )
        created += 1
    return created, skipped


class Command(BaseCommand):
    help = (
        "Create five-day expiration notifications for active subscription "
        "entitlements (idempotent; safe for repeated scheduled runs)."
    )

    def handle(self, *args, **options):
        created, skipped = run_expiration_notifications()
        self.stdout.write(self.style.SUCCESS(f"notifications created={created} skipped={skipped}"))
