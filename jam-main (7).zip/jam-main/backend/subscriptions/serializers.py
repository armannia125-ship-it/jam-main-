"""Legacy subscription serializers removed.

Canonical purchase/entitlement serialization lives with the purchase API.
"""
