from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("payments", "0004_remove_transaction_transaction_has_one_target_and_more"),
        ("subscriptions", "0006_entitlementnotification"),
    ]

    operations = [
        migrations.DeleteModel(name="ActivationCodeEvent"),
        migrations.DeleteModel(name="ActivationCode"),
        migrations.DeleteModel(name="Subscription"),
        migrations.DeleteModel(name="SubscriptionPlan"),
    ]
