import hashlib

from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion
import django.core.validators


def hash_existing_codes(apps, schema_editor):
    ActivationCode = apps.get_model("subscriptions", "ActivationCode")
    for code in ActivationCode.objects.all().iterator():
        raw = (code.code or "").strip().upper()
        if not raw:
            continue
        code.code_hash = hashlib.sha256(raw.encode("utf-8")).hexdigest()
        code.code_hint = raw[-4:]
        code.save(update_fields=["code_hash", "code_hint"])


class Migration(migrations.Migration):

    dependencies = [
        ("subscriptions", "0002_add_payment_confirmed_and_activation_code"),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.AddField(
            model_name="activationcode",
            name="code_hash",
            field=models.CharField(blank=True, max_length=64, null=True),
        ),
        migrations.AddField(
            model_name="activationcode",
            name="code_hint",
            field=models.CharField(default="", max_length=4),
        ),
        migrations.AddField(
            model_name="activationcode",
            name="issued_by",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="issued_activation_codes",
                to=settings.AUTH_USER_MODEL,
            ),
        ),
        migrations.AddField(
            model_name="activationcode",
            name="issued_via",
            field=models.CharField(
                choices=[("admin", "Django admin"), ("bot", "Authorized bot"), ("test", "Test")],
                default="admin",
                max_length=16,
            ),
        ),
        migrations.AddField(
            model_name="activationcode",
            name="revoked_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="activationcode",
            name="revoked_by",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="revoked_activation_codes",
                to=settings.AUTH_USER_MODEL,
            ),
        ),
        migrations.RunPython(hash_existing_codes, migrations.RunPython.noop),
        migrations.AlterField(
            model_name="activationcode",
            name="code_hash",
            field=models.CharField(max_length=64, unique=True),
        ),
        migrations.RemoveField(
            model_name="activationcode",
            name="code",
        ),
        migrations.AlterField(
            model_name="activationcode",
            name="redeemed_by",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="redeemed_activation_codes",
                to=settings.AUTH_USER_MODEL,
            ),
        ),
        migrations.AlterField(
            model_name="subscriptionplan",
            name="duration_days",
            field=models.PositiveIntegerField(
                default=30, validators=[django.core.validators.MinValueValidator(1)]
            ),
        ),
        migrations.AlterField(
            model_name="subscriptionplan",
            name="price_toman",
            field=models.PositiveBigIntegerField(
                validators=[django.core.validators.MinValueValidator(1)]
            ),
        ),
        migrations.AddConstraint(
            model_name="subscriptionplan",
            constraint=models.CheckConstraint(
                condition=models.Q(("price_toman__gt", 0)),
                name="subscription_plan_price_positive",
            ),
        ),
        migrations.AddConstraint(
            model_name="subscriptionplan",
            constraint=models.CheckConstraint(
                condition=models.Q(("duration_days__gt", 0)),
                name="subscription_plan_duration_positive",
            ),
        ),
        migrations.AlterModelOptions(
            name="activationcode",
            options={"ordering": ["-issued_at", "-id"]},
        ),
        migrations.AddIndex(
            model_name="activationcode",
            index=models.Index(
                fields=["subscription", "redeemed_at", "revoked_at"],
                name="subscriptio_subscri_d610f9_idx",
            ),
        ),
        migrations.AddIndex(
            model_name="activationcode",
            index=models.Index(fields=["expires_at"], name="subscriptio_expires_e8cb25_idx"),
        ),
        migrations.CreateModel(
            name="ActivationCodeEvent",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True, primary_key=True, serialize=False, verbose_name="ID"
                    ),
                ),
                (
                    "event",
                    models.CharField(
                        choices=[
                            ("issued", "Issued"),
                            ("redeemed", "Redeemed"),
                            ("revoked", "Revoked"),
                            ("expired_attempt", "Expired redemption attempt"),
                        ],
                        max_length=24,
                    ),
                ),
                ("detail", models.JSONField(blank=True, default=dict)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                (
                    "actor",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="activation_code_events",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
                (
                    "code",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="events",
                        to="subscriptions.activationcode",
                    ),
                ),
            ],
            options={"ordering": ["created_at", "id"]},
        ),
        migrations.AddIndex(
            model_name="activationcodeevent",
            index=models.Index(
                fields=["code", "created_at"], name="subscriptio_code_id_c77453_idx"
            ),
        ),
    ]
