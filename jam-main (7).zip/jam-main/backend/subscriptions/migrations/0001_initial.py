import django.db.models.deletion
from django.db import migrations, models

class Migration(migrations.Migration):
    initial = True
    dependencies = [("businesses", "0001_initial")]
    operations = [
        migrations.CreateModel(name="SubscriptionPlan", fields=[("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")), ("name", models.CharField(max_length=120)), ("description", models.TextField(blank=True)), ("duration_days", models.PositiveIntegerField(default=30)), ("price_toman", models.PositiveBigIntegerField()), ("is_active", models.BooleanField(default=True))]),
        migrations.CreateModel(name="Subscription", fields=[("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")), ("status", models.CharField(choices=[("pending", "Pending"), ("active", "Active"), ("expired", "Expired"), ("cancelled", "Cancelled")], default="pending", max_length=12)), ("starts_at", models.DateTimeField(blank=True, null=True)), ("ends_at", models.DateTimeField(blank=True, null=True)), ("created_at", models.DateTimeField(auto_now_add=True)), ("business", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="subscriptions", to="businesses.business")), ("plan", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="subscriptions", to="subscriptions.subscriptionplan"))]),
    ]
