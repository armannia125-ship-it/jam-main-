"""Seed the owner-approved five-product subscription catalog.

Prices are authoritative (owner decision, 2026-11-08), integer Toman, 30-day
duration. Gold is a combo product whose purchase activates two independent
entitlements. Idempotent: existing slug rows are updated, never duplicated.
"""
from django.db import migrations

CATALOG = [
    {
        "slug": "basic",
        "name": "پایه",
        "description": "حضور دیجیتال با منوی دیجیتال و QR",
        "category": "menu",
        "price_toman": 200000,
        "duration_days": 30,
        "max_products": 80,
        "features": [
            "منوی دیجیتال با سه قالب آماده",
            "لینک اختصاصی و QR منو",
            "مدیریت منو از پنل سایت",
            "حداکثر ۸۰ محصول",
        ],
        "sort_order": 10,
    },
    {
        "slug": "professional",
        "name": "حرفه‌ای",
        "description": "منو + دریافت سفارش آنلاین",
        "category": "menu",
        "price_toman": 250000,
        "duration_days": 30,
        "max_products": None,
        "features": [
            "همه امکانات پایه",
            "دریافت سفارش آنلاین و پرداخت آنلاین سفارش‌ها",
            "پیگیری سفارش در پنل سایت",
            "محصولات نامحدود",
            "گزارش فروش و بازدید",
        ],
        "sort_order": 20,
    },
    {
        "slug": "premium",
        "name": "ویژه",
        "description": "بیشترین امکان منو",
        "category": "menu",
        "price_toman": 350000,
        "duration_days": 30,
        "max_products": None,
        "features": [
            "همه امکانات حرفه‌ای",
            "تنظیم قالب و رنگ منو",
            "مدیریت چیدمان دسته‌بندی‌ها",
            "گزارش‌های پیشرفته",
            "طراحی اختصاصی منو و پشتیبانی اولویت‌دار",
        ],
        "sort_order": 30,
    },
    {
        "slug": "gold",
        "name": "طلایی",
        "description": "منو با تمام امکانات + باشگاه فروشندگان؛ دو اعتبار مستقل ۳۰ روزه",
        "category": "combo",
        "price_toman": 450000,
        "duration_days": 30,
        "max_products": None,
        "features": [
            "همه امکانات ویژه (منو)",
            "اعتبار مستقل باشگاه فروشندگان به مدت ۳۰ روز",
            "نمایش ویژه در فهرست باشگاه",
            "دو اعتبار مستقل با تاریخ و وضعیت جدا",
        ],
        "sort_order": 40,
    },
    {
        "slug": "seller_club",
        "name": "باشگاه فروشندگان",
        "description": "عضویت مستقل باشگاه، بدون اشتراک منو",
        "category": "club",
        "price_toman": 350000,
        "duration_days": 30,
        "max_products": None,
        "features": [
            "نمایش ویژه در فهرست باشگاه فروشندگان",
            "نمایش وضعیت عضویت",
            "نمایش پیشنهاد مشخص فروشگاه",
            "ابزارهای بازگشت مشتریِ پشتیبانی‌شده",
        ],
        "sort_order": 50,
    },
]


def seed(apps, schema_editor):
    SubscriptionProduct = apps.get_model("subscriptions", "SubscriptionProduct")
    for entry in CATALOG:
        obj, created = SubscriptionProduct.objects.update_or_create(
            slug=entry["slug"],
            defaults={
                "name": entry["name"],
                "description": entry["description"],
                "category": entry["category"],
                "price_toman": entry["price_toman"],
                "duration_days": entry["duration_days"],
                "max_products": entry["max_products"],
                "features": entry["features"],
                "sort_order": entry["sort_order"],
                "is_active": True,
            },
        )


def unseed(apps, schema_editor):
    SubscriptionProduct = apps.get_model("subscriptions", "SubscriptionProduct")
    SubscriptionProduct.objects.filter(slug__in=[c["slug"] for c in CATALOG]).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("subscriptions", "0004_subscriptionproduct_subscriptionpurchase_and_more"),
    ]

    operations = [
        migrations.RunPython(seed, unseed),
    ]
