from django.core.validators import MinValueValidator
from django.db import models
from django.utils import timezone

from businesses.models import Business


# ---------------------------------------------------------------------------
# Canonical purchase and entitlement architecture (owner-approved, 2026-11).
# ---------------------------------------------------------------------------


class SubscriptionProduct(models.Model):
    """A purchasable subscription product (canonical catalog entry).

    Prices are stored as integer Toman. ``max_products`` is the enforcement
    limit for the menu product limit (``None`` means unlimited).
    """

    class Category(models.TextChoices):
        MENU = "menu", "Menu subscription"
        CLUB = "club", "Seller Club subscription"
        COMBO = "combo", "Combined subscription"

    slug = models.SlugField(max_length=40, unique=True)
    name = models.CharField(max_length=120)
    description = models.TextField(blank=True, default="")
    category = models.CharField(max_length=12, choices=Category.choices, default=Category.MENU)
    price_toman = models.PositiveBigIntegerField(validators=[MinValueValidator(1)])
    duration_days = models.PositiveIntegerField(default=30, validators=[MinValueValidator(1)])
    features = models.JSONField(default=list, blank=True)
    max_products = models.PositiveIntegerField(null=True, blank=True)
    sort_order = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["sort_order", "id"]
        constraints = [
            models.CheckConstraint(
                condition=models.Q(price_toman__gt=0), name="subscription_product_price_positive"
            ),
            models.CheckConstraint(
                condition=models.Q(duration_days__gt=0), name="subscription_product_duration_positive"
            ),
        ]

    def __str__(self):
        return f"{self.name} ({self.slug})"


class SubscriptionPurchase(models.Model):
    """A user's purchase intent for a subscription product.

    The price is snapshotted at purchase time so later catalog changes never
    rewrite history. A purchase is activated only by a verified online
    payment (see ``payments``); there is no cancellation flow by owner decision.
    """

    class Status(models.TextChoices):
        PENDING = "pending", "Awaiting payment"
        PAID = "paid", "Paid"
        FAILED = "failed", "Payment failed"

    user = models.ForeignKey(
        "accounts.User", on_delete=models.PROTECT, related_name="subscription_purchases"
    )
    business = models.ForeignKey(
        Business, on_delete=models.PROTECT, related_name="subscription_purchases"
    )
    product = models.ForeignKey(
        SubscriptionProduct, on_delete=models.PROTECT, related_name="purchases"
    )
    price_toman = models.PositiveBigIntegerField(validators=[MinValueValidator(1)])
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.PENDING)
    created_at = models.DateTimeField(auto_now_add=True)
    confirmed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        indexes = [
            models.Index(fields=["user", "status"]),
            models.Index(fields=["business", "status"]),
        ]
        constraints = [
            models.CheckConstraint(
                condition=models.Q(price_toman__gt=0), name="subscription_purchase_price_positive"
            ),
        ]

    def __str__(self):
        return f"{self.user_id} → {self.product.slug} for {self.business_id} ({self.status})"


class SubscriptionEntitlement(models.Model):
    """Concrete access right granted by a paid purchase.

    Gold purchases create one MENU and one CLUB entitlement atomically with
    independent windows. Status EXPIRED is applied lazily/by the maintenance
    job; ``is_current`` is always the authoritative runtime check.
    """

    class Type(models.TextChoices):
        MENU = "menu", "Menu"
        CLUB = "club", "Seller Club"

    class Status(models.TextChoices):
        ACTIVE = "active", "Active"
        EXPIRED = "expired", "Expired"
        REVOKED = "revoked", "Revoked"

    user = models.ForeignKey(
        "accounts.User", on_delete=models.PROTECT, related_name="subscription_entitlements"
    )
    business = models.ForeignKey(
        Business, on_delete=models.PROTECT, related_name="subscription_entitlements"
    )
    entitlement_type = models.CharField(max_length=8, choices=Type.choices)
    product = models.ForeignKey(
        SubscriptionProduct, on_delete=models.PROTECT, related_name="entitlements"
    )
    purchase = models.ForeignKey(
        SubscriptionPurchase, on_delete=models.PROTECT, related_name="entitlements"
    )
    starts_at = models.DateTimeField()
    ends_at = models.DateTimeField()
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.ACTIVE)
    revoked_at = models.DateTimeField(null=True, blank=True)
    revoked_by = models.ForeignKey(
        "accounts.User",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="revoked_subscription_entitlements",
    )
    revocation_reason = models.CharField(max_length=200, blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-ends_at", "-id"]
        indexes = [
            models.Index(fields=["business", "entitlement_type", "status"]),
            models.Index(fields=["ends_at"]),
        ]
        constraints = [
            # A payment activates each entitlement type exactly once (idempotent
            # callback protection at the database level).
            models.UniqueConstraint(
                fields=["purchase", "entitlement_type"], name="unique_entitlement_per_purchase_type"
            ),
            models.CheckConstraint(
                condition=models.Q(ends_at__gt=models.F("starts_at")),
                name="subscription_entitlement_window_valid",
            ),
        ]

    @property
    def is_current(self):
        now = timezone.now()
        return bool(
            self.status == self.Status.ACTIVE
            and self.starts_at <= now < self.ends_at
        )

    def __str__(self):
        return f"{self.business_id} {self.entitlement_type} until {self.ends_at:%Y-%m-%d}"


class EntitlementNotification(models.Model):
    """A user-visible notification generated from backend entitlement data.

    One notification per (entitlement, kind) — repeated scheduled runs never
    duplicate, and a renewed entitlement (a new row) notifies again legitimately.
    """

    class Kind(models.TextChoices):
        EXPIRING_5D = "expiring_5d", "Subscription expires within five days"

    user = models.ForeignKey(
        "accounts.User", on_delete=models.CASCADE, related_name="entitlement_notifications"
    )
    entitlement = models.ForeignKey(
        SubscriptionEntitlement, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="notifications",
    )
    kind = models.CharField(max_length=20, choices=Kind.choices)
    payload = models.JSONField(default=dict, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    read_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        constraints = [
            models.UniqueConstraint(
                fields=["entitlement", "kind"],
                condition=models.Q(entitlement__isnull=False),
                name="unique_notification_per_entitlement_kind",
            ),
        ]

    def __str__(self):
        return f"{self.kind} for user {self.user_id}"
