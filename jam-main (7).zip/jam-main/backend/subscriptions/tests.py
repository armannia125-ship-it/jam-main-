from datetime import timedelta

from django.test import TestCase
from django.utils import timezone
from rest_framework.test import APITestCase

from accounts.models import User
from businesses.models import Business, Category, Menu, Product
from subscriptions.entitlements import (
    activate_entitlements_for_purchase,
    club_access,
    menu_access,
    product_limit,
)
from subscriptions.models import (
    SubscriptionEntitlement,
    SubscriptionProduct,
    SubscriptionPurchase,
)


def make_user(email):
    return User.objects.create_user(email=email)


def make_business(owner, name="Cafe", slug="cafe"):
    return Business.objects.create(owner=owner, name=name, slug=slug)


def make_entitlement(business, entitlement_type, *, starts_at=None, ends_at=None, status=None):
    product = SubscriptionProduct.objects.get(
        slug="seller_club" if entitlement_type == SubscriptionEntitlement.Type.CLUB else "basic"
    )
    purchase = SubscriptionPurchase.objects.create(
        user=business.owner,
        business=business,
        product=product,
        price_toman=product.price_toman,
        status=SubscriptionPurchase.Status.PAID,
    )
    now = timezone.now()
    return SubscriptionEntitlement.objects.create(
        user=business.owner,
        business=business,
        entitlement_type=entitlement_type,
        product=product,
        purchase=purchase,
        starts_at=starts_at or now,
        ends_at=ends_at or now + timedelta(days=30),
        status=status or SubscriptionEntitlement.Status.ACTIVE,
    )


class EntitlementAccessTests(TestCase):
    def setUp(self):
        self.owner = make_user("owner@example.com")
        self.business = make_business(self.owner)

    def test_menu_access_requires_current_menu_entitlement(self):
        self.assertFalse(menu_access(self.business))
        make_entitlement(self.business, SubscriptionEntitlement.Type.MENU)
        self.assertTrue(menu_access(self.business))

    def test_club_only_does_not_grant_menu_access(self):
        make_entitlement(self.business, SubscriptionEntitlement.Type.CLUB)
        self.assertFalse(menu_access(self.business))
        self.assertTrue(club_access(self.business))

    def test_expired_and_revoked_entitlements_do_not_grant_access(self):
        now = timezone.now()
        make_entitlement(
            self.business,
            SubscriptionEntitlement.Type.MENU,
            starts_at=now - timedelta(days=40),
            ends_at=now - timedelta(days=1),
        )
        self.assertFalse(menu_access(self.business))
        SubscriptionEntitlement.objects.all().delete()
        make_entitlement(
            self.business,
            SubscriptionEntitlement.Type.MENU,
            status=SubscriptionEntitlement.Status.REVOKED,
        )
        self.assertFalse(menu_access(self.business))

    def test_product_limit_comes_from_current_menu_product(self):
        self.assertEqual(product_limit(self.business), 0)
        make_entitlement(self.business, SubscriptionEntitlement.Type.MENU)
        self.assertEqual(
            product_limit(self.business),
            SubscriptionProduct.objects.get(slug="basic").max_products,
        )

    def test_gold_purchase_creates_independent_menu_and_club_entitlements(self):
        product = SubscriptionProduct.objects.get(slug="gold")
        purchase = SubscriptionPurchase.objects.create(
            user=self.owner,
            business=self.business,
            product=product,
            price_toman=product.price_toman,
            status=SubscriptionPurchase.Status.PAID,
        )
        activate_entitlements_for_purchase(purchase)
        menu = SubscriptionEntitlement.objects.get(
            purchase=purchase, entitlement_type=SubscriptionEntitlement.Type.MENU
        )
        club = SubscriptionEntitlement.objects.get(
            purchase=purchase, entitlement_type=SubscriptionEntitlement.Type.CLUB
        )
        menu.status = SubscriptionEntitlement.Status.REVOKED
        menu.save(update_fields=["status"])
        self.assertTrue(club_access(self.business))
        self.assertFalse(menu_access(self.business))


class MenuSubscriptionGateTests(APITestCase):
    def setUp(self):
        self.owner = make_user("owner@example.com")
        self.business = make_business(self.owner)

    def test_menu_creation_saves_as_draft_without_entitlement(self):
        self.client.force_authenticate(self.owner)
        response = self.client.post(
            "/api/menus/",
            {"business": self.business.pk, "title": "Draft", "slug": "draft-menu", "is_active": True},
            format="json",
        )
        self.assertEqual(response.status_code, 201)
        menu = Menu.objects.get(slug="draft-menu")
        self.assertFalse(menu.is_active)

    def test_menu_creation_allowed_with_current_entitlement(self):
        make_entitlement(self.business, SubscriptionEntitlement.Type.MENU)
        self.client.force_authenticate(self.owner)
        response = self.client.post(
            "/api/menus/",
            {"business": self.business.pk, "title": "Menu", "slug": "active-menu"},
            format="json",
        )
        self.assertEqual(response.status_code, 201)
        self.assertTrue(Menu.objects.get(slug="active-menu").is_active)

    def test_category_and_product_creation_require_entitlement(self):
        menu = Menu.objects.create(business=self.business, title="Menu", slug="menu-slug")
        self.client.force_authenticate(self.owner)
        category_response = self.client.post(
            "/api/categories/", {"menu": menu.pk, "name": "Drinks"}, format="json"
        )
        self.assertEqual(category_response.status_code, 403)
        category = Category.objects.create(menu=menu, name="Food")
        product_response = self.client.post(
            "/api/products/",
            {"category": category.pk, "name": "Coffee", "price_toman": 50000},
            format="json",
        )
        self.assertEqual(product_response.status_code, 403)


class PublicMenuEntitlementTests(APITestCase):
    def setUp(self):
        self.owner = make_user("owner@example.com")
        self.business = make_business(self.owner)
        self.menu = Menu.objects.create(
            business=self.business, title="Menu", slug="cafe-menu", is_active=True
        )
        Category.objects.create(menu=self.menu, name="Drinks")
        Product.objects.create(
            category=self.menu.categories.get(), name="Tea", price_toman=50000
        )

    def test_public_menu_and_qr_require_menu_entitlement(self):
        self.assertEqual(self.client.get("/api/public/menus/cafe-menu/").status_code, 404)
        self.assertEqual(self.client.get("/api/qr/cafe-menu/").status_code, 404)

    def test_public_menu_and_qr_available_with_current_menu_entitlement(self):
        make_entitlement(self.business, SubscriptionEntitlement.Type.MENU)
        self.assertEqual(self.client.get("/api/public/menus/cafe-menu/").status_code, 200)
        self.assertEqual(self.client.get("/api/qr/cafe-menu/").status_code, 200)

    def test_club_only_and_expired_entitlements_do_not_publish_menu(self):
        make_entitlement(self.business, SubscriptionEntitlement.Type.CLUB)
        self.assertEqual(self.client.get("/api/public/menus/cafe-menu/").status_code, 404)
        SubscriptionEntitlement.objects.all().delete()
        now = timezone.now()
        make_entitlement(
            self.business,
            SubscriptionEntitlement.Type.MENU,
            starts_at=now - timedelta(days=40),
            ends_at=now - timedelta(days=1),
        )
        self.assertEqual(self.client.get("/api/public/menus/cafe-menu/").status_code, 404)
