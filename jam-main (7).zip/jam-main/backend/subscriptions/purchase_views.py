"""Online subscription-purchase flow (owner-approved: online payment only).

Server-authoritative prices from the seeded ``SubscriptionProduct`` catalog;
the frontend never supplies an amount. If the payment provider is not
configured, initiation fails safely with 503 and NOTHING is created — a payment
can never be silently treated as successful.

ZarinPal is the only payment route; there is no manual or offline purchase
flow.
"""

from django.db import transaction
from django.utils import timezone

from rest_framework import status
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView

from businesses.models import Business
from payments.gateways.zarinpal import ZarinPalGateway
from payments.models import Transaction
from subscriptions.entitlements import activate_entitlements_for_purchase
from subscriptions.models import (
    EntitlementNotification,
    SubscriptionEntitlement,
    SubscriptionProduct,
    SubscriptionPurchase,
)

from rest_framework.exceptions import APIException


class PaymentProviderUnconfigured(APIException):
    status_code = status.HTTP_503_SERVICE_UNAVAILABLE
    default_detail = "پرداخت آنلاین موقتاً در دسترس نیست؛ تنظیمات درگاه انجام نشده است."
    default_code = "payment_provider_unconfigured"


class SubscriptionCatalogView(APIView):
    """The five approved products, from the DB (canonical source of truth)."""

    permission_classes = [AllowAny]
    authentication_classes = []

    def get(self, request):
        return Response(
            {
                "results": [
                    {
                        "slug": p.slug,
                        "name": p.name,
                        "description": p.description,
                        "category": p.category,
                        "price_toman": int(p.price_toman),
                        "duration_days": p.duration_days,
                        "features": p.features,
                        "max_products": p.max_products,
                    }
                    for p in SubscriptionProduct.objects.filter(is_active=True).order_by("sort_order")
                ]
            }
        )


class SubscriptionPurchaseView(APIView):
    """Start a subscription purchase: create the purchase + payment attempt.

    POST {product_slug, business_id} → {purchase_id, payment_url}
    """

    def post(self, request):
        product_slug = (request.data or {}).get("product_slug") or ""
        business_id = (request.data or {}).get("business_id")
        product = SubscriptionProduct.objects.filter(slug=product_slug, is_active=True).first()
        if product is None:
            return Response({"detail": "محصول اشتراک پیدا نشد."}, status=status.HTTP_404_NOT_FOUND)
        # Serialize the open-purchase check per business. Without this lock two
        # concurrent requests both see no pending purchase and create two.
        with transaction.atomic():
            business = Business.objects.select_for_update().filter(
                pk=business_id, owner=request.user
            ).first()
            if business is None:
                return Response({"detail": "کسب‌وکار پیدا نشد."}, status=status.HTTP_404_NOT_FOUND)

            # Idempotency: one open purchase per (user, business, product) — reuse
            # it instead of stacking pending purchases.
            existing = (
                SubscriptionPurchase.objects.filter(
                    user=request.user,
                    business=business,
                    product=product,
                    status=SubscriptionPurchase.Status.PENDING,
                )
                .order_by("-created_at")
                .first()
            )
            if existing is not None:
                purchase = existing
            else:
                purchase = SubscriptionPurchase.objects.create(
                    user=request.user,
                    business=business,
                    product=product,
                    price_toman=product.price_toman,  # authoritative, server-side
                    status=SubscriptionPurchase.Status.PENDING,
                )

        # Payment attempt against the provider; fail safely if unconfigured.
        with transaction.atomic():
            transaction_row = Transaction.objects.select_for_update().filter(
                purchase=purchase, status=Transaction.Status.INITIATED
            ).first()
            if transaction_row is None:
                transaction_row = Transaction.objects.create(
                    purchase=purchase,
                    amount_toman=product.price_toman,
                    gateway="zarinpal",
                    status=Transaction.Status.INITIATED,
                )
            try:
                gateway = ZarinPalGateway()
            except ValueError:
                # Fail safely and atomically: no purchase/transaction may exist
                # when the provider is not configured.
                transaction_row.delete()
                purchase.delete()
                return Response(
                    {
                        "code": "payment_provider_unconfigured",
                        "detail": "پرداخت آنلاین موقتاً در دسترس نیست؛ تنظیمات درگاه انجام نشده است.",
                    },
                    status=status.HTTP_503_SERVICE_UNAVAILABLE,
                )
            try:
                result = gateway.create_payment(
                    transaction_row,
                    description=f"اشتراک {product.name} — {business.name}",
                )
            except Exception:
                # Transport/provider error: keep the attempt INITIATED for retry.
                return Response(
                    {"detail": "ایجاد پرداخت ناموفق بود؛ دوباره تلاش کنید."},
                    status=status.HTTP_502_BAD_GATEWAY,
                )
            transaction_row.authority = result["authority"]
            transaction_row.save(update_fields=["authority", "updated_at"])

        return Response(
            {
                "purchase_id": purchase.pk,
                "amount_toman": int(purchase.price_toman),
                "payment_url": result["payment_url"],
                "authority": result["authority"],
            },
            status=status.HTTP_201_CREATED,
        )

    def get(self, request):
        """The authenticated user's own purchase history (ownership enforced)."""
        purchases = SubscriptionPurchase.objects.filter(user=request.user).select_related(
            "product", "business"
        )
        return Response(
            {
                "results": [
                    {
                        "id": p.pk,
                        "product": p.product.slug,
                        "business": p.business.name,
                        "business_id": p.business_id,
                        "price_toman": int(p.price_toman),
                        "status": p.status,
                        "created_at": p.created_at,
                        "confirmed_at": p.confirmed_at,
                    }
                    for p in purchases.order_by("-created_at")[:50]
                ]
            }
        )


class SubscriptionPurchaseStatusView(APIView):
    """Owner-scoped purchase status (frontend polls this after redirect)."""

    def get(self, request, purchase_id):
        purchase = SubscriptionPurchase.objects.filter(
            pk=purchase_id, user=request.user
        ).select_related("product", "business").first()
        if purchase is None:
            return Response({"detail": "خرید پیدا نشد."}, status=status.HTTP_404_NOT_FOUND)
        latest_transaction = purchase.transactions.order_by("-created_at").first()
        entitlements = SubscriptionEntitlement.objects.filter(purchase=purchase)
        return Response(
            {
                "id": purchase.pk,
                "status": purchase.status,
                "product": purchase.product.slug,
                "amount_toman": int(purchase.price_toman),
                "confirmed_at": purchase.confirmed_at,
                "payment_status": latest_transaction.status if latest_transaction else None,
                "entitlements": [
                    {
                        "type": e.entitlement_type,
                        "starts_at": e.starts_at,
                        "ends_at": e.ends_at,
                    }
                    for e in entitlements
                ],
            }
        )


class EntitlementNotificationsView(APIView):
    """The authenticated user's subscription notifications (ownership scoped)."""

    def get(self, request):
        notifications = EntitlementNotification.objects.filter(user=request.user)
        unread_only = request.query_params.get("unread") == "1"
        if unread_only:
            notifications = notifications.filter(read_at__isnull=True)
        return Response(
            {
                "results": [
                    {
                        "id": n.pk,
                        "kind": n.kind,
                        "payload": n.payload,
                        "created_at": n.created_at,
                        "read_at": n.read_at,
                    }
                    for n in notifications[:50]
                ]
            }
        )

    def post(self, request):
        """Mark all of the user's notifications as read."""
        EntitlementNotification.objects.filter(user=request.user, read_at__isnull=True).update(
            read_at=timezone.now()
        )
        return Response({"detail": "همهٔ اعلان‌ها خوانده شد."})
