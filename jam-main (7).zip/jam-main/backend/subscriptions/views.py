"""Legacy subscription views removed.

The canonical purchase and entitlement API lives in ``purchase_views.py``.
"""
