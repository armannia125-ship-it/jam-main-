import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models

class Migration(migrations.Migration):
    initial = True
    dependencies = [migrations.swappable_dependency(settings.AUTH_USER_MODEL)]
    operations = [
        migrations.CreateModel(name="Business", fields=[("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")), ("name", models.CharField(max_length=160)), ("slug", models.SlugField(max_length=180, unique=True)), ("description", models.TextField(blank=True)), ("created_at", models.DateTimeField(auto_now_add=True)), ("owner", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="businesses", to=settings.AUTH_USER_MODEL))]),
        migrations.CreateModel(name="Menu", fields=[("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")), ("title", models.CharField(default="منوی اصلی", max_length=160)), ("slug", models.SlugField(max_length=180, unique=True)), ("is_active", models.BooleanField(default=True)), ("created_at", models.DateTimeField(auto_now_add=True)), ("business", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="menus", to="businesses.business"))]),
        migrations.CreateModel(name="Category", fields=[("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")), ("name", models.CharField(max_length=120)), ("sort_order", models.PositiveIntegerField(default=0)), ("menu", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="categories", to="businesses.menu"))], options={"ordering": ["sort_order", "id"]}),
        migrations.CreateModel(name="Product", fields=[("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")), ("name", models.CharField(max_length=160)), ("description", models.TextField(blank=True)), ("price_toman", models.PositiveBigIntegerField()), ("is_available", models.BooleanField(default=True)), ("sort_order", models.PositiveIntegerField(default=0)), ("created_at", models.DateTimeField(auto_now_add=True)), ("category", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="products", to="businesses.category"))], options={"ordering": ["sort_order", "id"]}),
    ]
