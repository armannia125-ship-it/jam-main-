import os
import uuid

from django.conf import settings
from django.db import models
from django.utils.text import slugify


def upload_product_image_path(instance, filename):
    """Generate safe upload path for product images."""
    ext = filename.split(".")[-1] if "." in filename else "jpg"
    safe_name = f"products/{uuid.uuid4().hex}.{ext}"
    return safe_name


def upload_business_image_path(instance, filename):
    """Generate safe upload path for business logo/images."""
    ext = filename.split(".")[-1] if "." in filename else "jpg"
    safe_name = f"businesses/{uuid.uuid4().hex}.{ext}"
    return safe_name


class Business(models.Model):
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="businesses")
    name = models.CharField(max_length=160)
    slug = models.SlugField(max_length=180, unique=True)
    description = models.TextField(blank=True)
    logo = models.ImageField(upload_to=upload_business_image_path, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if not self.slug and self.name:
            self.slug = slugify(self.name, allow_unicode=True)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name


class Menu(models.Model):
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="menus")
    title = models.CharField(max_length=160, default="منوی اصلی")
    slug = models.SlugField(max_length=180, unique=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if not self.slug and self.title:
            self.slug = slugify(self.title, allow_unicode=True)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.title


class Category(models.Model):
    menu = models.ForeignKey(Menu, on_delete=models.CASCADE, related_name="categories")
    name = models.CharField(max_length=120)
    sort_order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["sort_order", "id"]

    def __str__(self):
        return self.name


class Product(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name="products")
    name = models.CharField(max_length=160)
    description = models.TextField(blank=True)
    price_toman = models.PositiveBigIntegerField()
    is_available = models.BooleanField(default=True)
    sort_order = models.PositiveIntegerField(default=0)
    image = models.ImageField(upload_to=upload_product_image_path, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["sort_order", "id"]

    def __str__(self):
        return self.name