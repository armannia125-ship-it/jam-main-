from rest_framework import serializers
from .models import Business, Menu, Category, Product

class OwnedRelationSerializer(serializers.ModelSerializer):
    def owned_queryset(self, model, filter_key):
        user = self.context["request"].user
        return model.objects.filter(**{filter_key: user})

class BusinessSerializer(serializers.ModelSerializer):
    owner = serializers.PrimaryKeyRelatedField(read_only=True)
    logo = serializers.ImageField(required=False, allow_null=True)
    class Meta:
        model = Business
        fields = ["id", "owner", "name", "slug", "description", "logo", "created_at"]
        read_only_fields = ["id", "owner", "created_at"]

class MenuSerializer(OwnedRelationSerializer):
    business = serializers.PrimaryKeyRelatedField(queryset=Business.objects.none())
    class Meta:
        model = Menu
        fields = ["id", "business", "title", "slug", "is_active", "created_at"]
        read_only_fields = ["id", "created_at"]
    def get_fields(self):
        fields = super().get_fields()
        request = self.context.get("request")
        if request:
            fields["business"].queryset = Business.objects.filter(owner=request.user)
        return fields

class CategorySerializer(OwnedRelationSerializer):
    menu = serializers.PrimaryKeyRelatedField(queryset=Menu.objects.none())
    class Meta:
        model = Category
        fields = ["id", "menu", "name", "sort_order"]
        read_only_fields = ["id"]
    def get_fields(self):
        fields = super().get_fields()
        request = self.context.get("request")
        if request:
            fields["menu"].queryset = Menu.objects.filter(business__owner=request.user)
        return fields

class ProductSerializer(OwnedRelationSerializer):
    category = serializers.PrimaryKeyRelatedField(queryset=Category.objects.none())
    image = serializers.ImageField(required=False, allow_null=True)
    class Meta:
        model = Product
        fields = ["id", "category", "name", "description", "price_toman", "is_available", "sort_order", "image", "created_at"]
        read_only_fields = ["id", "created_at"]
    def get_fields(self):
        fields = super().get_fields()
        request = self.context.get("request")
        if request:
            fields["category"].queryset = Category.objects.filter(menu__business__owner=request.user)
        return fields

class PublicProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ["id", "name", "description", "price_toman", "sort_order", "image"]

class PublicCategorySerializer(serializers.ModelSerializer):
    products = serializers.SerializerMethodField()
    class Meta:
        model = Category
        fields = ["id", "name", "sort_order", "products"]
    def get_products(self, category):
        return PublicProductSerializer(category.products.filter(is_available=True), many=True).data

class PublicBusinessSerializer(serializers.ModelSerializer):
    class Meta:
        model = Business
        fields = ["id", "name", "slug", "description", "logo"]

class PublicMenuSerializer(serializers.ModelSerializer):
    business = PublicBusinessSerializer(read_only=True)
    categories = PublicCategorySerializer(many=True, read_only=True)
    delivery_fee_toman = serializers.SerializerMethodField()
    class Meta:
        model = Menu
        fields = ["title", "slug", "business", "categories", "delivery_fee_toman"]
    def get_delivery_fee_toman(self, menu):
        config = getattr(menu.business, "store_config", None)
        return int(config.delivery_fee_toman) if config else 0
