from datetime import timedelta
from rest_framework.test import APITestCase
from django.utils import timezone
from accounts.models import User
from subscriptions.models import (
    SubscriptionEntitlement,
    SubscriptionProduct,
    SubscriptionPurchase,
)
from .models import Business, Menu, Category, Product


class OwnershipTests(APITestCase):
    def setUp(self):
        self.owner = User.objects.create_user(email="owner@example.com")
        self.other = User.objects.create_user(email="other@example.com")
        business = Business.objects.create(owner=self.owner, name="Cafe", slug="cafe")
        self.menu = Menu.objects.create(business=business, title="Menu", slug="cafe-menu")
        self.category = Category.objects.create(menu=self.menu, name="Drinks")
        self.product = Product.objects.create(category=self.category, name="Tea", price_toman=50000)
        # Create current MENU entitlement for the business
        product = SubscriptionProduct.objects.get(slug="basic")
        purchase = SubscriptionPurchase.objects.create(
            user=self.owner,
            business=business,
            product=product,
            price_toman=product.price_toman,
            status=SubscriptionPurchase.Status.PAID,
        )
        SubscriptionEntitlement.objects.create(
            user=self.owner,
            business=business,
            entitlement_type=SubscriptionEntitlement.Type.MENU,
            product=product,
            purchase=purchase,
            starts_at=timezone.now(),
            ends_at=timezone.now() + timedelta(days=30),
            status=SubscriptionEntitlement.Status.ACTIVE,
        )

    def test_public_menu_hides_unavailable_products(self):
        self.product.is_available = False
        self.product.save()
        result = self.client.get("/api/public/menus/cafe-menu/")
        self.assertEqual(result.status_code, 200)
        self.assertEqual(result.data["categories"][0]["products"], [])

    def test_cross_owner_mutation_and_relation_rejected(self):
        self.client.force_authenticate(self.other)
        self.assertEqual(self.client.patch(f"/api/products/{self.product.pk}/", {"price_toman": 1}).status_code, 404)
        self.assertEqual(self.client.post("/api/products/", {"category": self.category.pk, "name": "Foreign", "price_toman": 1}).status_code, 400)

    def test_owner_can_create_product(self):
        self.client.force_authenticate(self.owner)
        result = self.client.post("/api/products/", {"category": self.category.pk, "name": "Coffee", "price_toman": 60000})
        self.assertEqual(result.status_code, 201)

    def test_menu_can_be_created_as_draft_without_active_subscription(self):
        SubscriptionEntitlement.objects.filter(business=self.menu.business).delete()
        self.client.force_authenticate(self.owner)
        response = self.client.post("/api/menus/", {"business": self.menu.business_id, "title": "Draft", "slug": "owner-draft", "is_active": True})
        self.assertEqual(response.status_code, 201)
        self.assertFalse(response.data["is_active"])

    def test_unpublished_menu_can_be_edited_without_subscription(self):
        self.menu.is_active = False
        self.menu.save(update_fields=["is_active"])
        SubscriptionEntitlement.objects.filter(business=self.menu.business).delete()
        self.client.force_authenticate(self.owner)
        response = self.client.patch(f"/api/menus/{self.menu.pk}/", {"title": "Saved draft"})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["title"], "Saved draft")

    def test_publish_requires_active_subscription_and_does_not_change_state(self):
        self.menu.is_active = False
        self.menu.save(update_fields=["is_active"])
        SubscriptionEntitlement.objects.filter(business=self.menu.business).delete()
        self.client.force_authenticate(self.owner)
        response = self.client.patch(f"/api/menus/{self.menu.pk}/", {"is_active": True})
        self.assertEqual(response.status_code, 403)
        self.menu.refresh_from_db()
        self.assertFalse(self.menu.is_active)

    def test_private_preview_is_owner_scoped_and_includes_draft(self):
        self.menu.is_active = False
        self.menu.save(update_fields=["is_active"])
        self.client.force_authenticate(self.owner)
        self.assertEqual(self.client.get("/api/seller/menus/cafe-menu/preview/").status_code, 200)
        self.client.force_authenticate(self.other)
        self.assertEqual(self.client.get("/api/seller/menus/cafe-menu/preview/").status_code, 404)

    def test_telegram_status_is_authenticated_and_owner_scoped(self):
        self.client.force_authenticate(self.owner)
        response = self.client.get("/api/bot/telegram/status/")
        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.data["linked"])
        self.client.force_authenticate(None)
        self.assertEqual(self.client.get("/api/bot/telegram/status/").status_code, 401)

    def test_image_upload_fields_are_writable(self):
        from io import BytesIO
        from tempfile import TemporaryDirectory
        from django.core.files.uploadedfile import SimpleUploadedFile
        from django.test import override_settings
        from PIL import Image

        image_buffer = BytesIO()
        Image.new("RGB", (2, 2), color="green").save(image_buffer, format="PNG")
        with TemporaryDirectory() as media_root, override_settings(MEDIA_ROOT=media_root):
            image_bytes = image_buffer.getvalue()
            self.client.force_authenticate(self.owner)
            business_response = self.client.patch(
                f"/api/businesses/{self.menu.business_id}/",
                {"logo": SimpleUploadedFile("logo.png", image_bytes, content_type="image/png")},
                format="multipart",
            )
            self.assertEqual(business_response.status_code, 200)
            product_response = self.client.post(
                "/api/products/",
                {
                    "category": self.category.pk,
                    "name": "With image",
                    "price_toman": 1,
                    "image": SimpleUploadedFile("product.png", image_bytes, content_type="image/png"),
                },
                format="multipart",
            )
            self.assertEqual(product_response.status_code, 201)
            self.assertTrue(product_response.data["image"])
