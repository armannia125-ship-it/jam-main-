from django.contrib import admin
from .models import Business, Menu, Category, Product
admin.site.register([Business, Menu, Category, Product])
