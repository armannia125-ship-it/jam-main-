from rest_framework.routers import DefaultRouter
from django.urls import path, include
from .views import (
    BusinessViewSet,
    MenuViewSet,
    CategoryViewSet,
    ProductViewSet,
    PublicMenuView,
    QrCodeView,
    SellerQrCodeView,
    SellerMenuPreviewView,
)
router = DefaultRouter()
router.register("businesses", BusinessViewSet, basename="business")
router.register("menus", MenuViewSet, basename="menu")
router.register("categories", CategoryViewSet, basename="category")
router.register("products", ProductViewSet, basename="product")
urlpatterns = router.urls + [
    path("seller/menus/<slug:slug>/preview/", SellerMenuPreviewView.as_view(), name="seller-menu-preview"),
    path("businesses/<int:business_id>/qr/", SellerQrCodeView.as_view(), name="seller-qr"),
    path("public/menus/<slug:slug>/", PublicMenuView.as_view(), name="public-menu"),
    path("qr/<slug:slug>/", QrCodeView.as_view(), name="qr-code"),
]
