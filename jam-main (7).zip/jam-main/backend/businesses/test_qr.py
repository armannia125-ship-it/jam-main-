"""Dedicated QR regression tests.

The QR payload is verified at the module-matrix level: the PNG is decoded back
to its black/white module grid and compared with an independently encoded grid
for the exact expected public URL. This proves the encoded destination without
adding a decoder dependency (AGENTS.md requires owner approval for new
dependencies).
"""

import base64
import io
from datetime import timedelta

import qrcode
from django.test import override_settings
from django.utils import timezone
from PIL import Image
from rest_framework.test import APITestCase

from accounts.models import User
from subscriptions.models import (
    SubscriptionEntitlement,
    SubscriptionProduct,
    SubscriptionPurchase,
)
from .models import Business, Menu

PUBLIC = "https://shop.example"


def qr_settings(**overrides):
    values = {"PUBLIC_FRONTEND_URL": PUBLIC}
    values.update(overrides)
    return override_settings(**values)


def make_entitlement(business, *, starts_at=None, ends_at=None):
    product = SubscriptionProduct.objects.get(slug="basic")
    purchase = SubscriptionPurchase.objects.create(
        user=business.owner,
        business=business,
        product=product,
        price_toman=product.price_toman,
        status=SubscriptionPurchase.Status.PAID,
    )
    now = timezone.now()
    return SubscriptionEntitlement.objects.create(
        user=business.owner,
        business=business,
        entitlement_type=SubscriptionEntitlement.Type.MENU,
        product=product,
        purchase=purchase,
        starts_at=starts_at or now,
        ends_at=ends_at or now + timedelta(days=30),
        status=SubscriptionEntitlement.Status.ACTIVE,
    )


def decode_png_modules(data_uri):
    """Decode a ``data:image/png;base64`` QR to its black/white module grid."""
    assert data_uri.startswith("data:image/png;base64,")
    raw = base64.b64decode(data_uri.split(",", 1)[1])
    image = Image.open(io.BytesIO(raw))
    assert image.format == "PNG"
    gray = image.convert("L")
    width, height = gray.size
    assert width == height
    # The endpoint renders with box_size=10 and border=4.
    assert width % 10 == 0
    modules = width // 10 - 8
    assert modules >= 21
    pixels = gray.load()
    return [
        [pixels[(column + 4) * 10 + 5, (row + 4) * 10 + 5] < 128 for column in range(modules)]
        for row in range(modules)
    ]


def expected_modules(text):
    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        box_size=10,
        border=4,
    )
    qr.add_data(text)
    qr.make(fit=True)
    return qr.modules


class SellerQrTests(APITestCase):
    def setUp(self):
        self.owner = User.objects.create_user(email="owner@example.com")
        self.other = User.objects.create_user(email="other@example.com")
        self.business = Business.objects.create(owner=self.owner, name="Cafe", slug="cafe")
        self.menu = Menu.objects.create(business=self.business, title="Menu", slug="cafe-menu")
        make_entitlement(self.business)

    def seller_url(self, business=None):
        return f"/api/businesses/{(business or self.business).pk}/qr/"

    def assert_qr_encodes(self, response, expected_url):
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["publicUrl"], expected_url)
        self.assertIn("qrCode", response.data)
        decoded = decode_png_modules(response.data["qrCode"])
        self.assertEqual(decoded, expected_modules(expected_url))

    def test_seller_qr_returns_valid_png_for_exact_public_url(self):
        self.client.force_authenticate(self.owner)
        with qr_settings():
            response = self.client.get(self.seller_url())
        self.assert_qr_encodes(response, f"{PUBLIC}/m/cafe-menu")
        self.assertEqual(response.data["menuSlug"], "cafe-menu")
        self.assertEqual(response.data["menuTitle"], "Menu")

    def test_qr_uses_menu_slug_not_business_slug(self):
        self.assertNotEqual(self.business.slug, self.menu.slug)
        self.client.force_authenticate(self.owner)
        with qr_settings():
            response = self.client.get(self.seller_url())
        self.assert_qr_encodes(response, f"{PUBLIC}/m/{self.menu.slug}")
        self.assertNotEqual(response.data["publicUrl"], f"{PUBLIC}/m/{self.business.slug}")

    def test_public_qr_endpoint_uses_configured_origin(self):
        with qr_settings():
            response = self.client.get("/api/qr/cafe-menu/")
        self.assert_qr_encodes(response, f"{PUBLIC}/m/cafe-menu")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_forged_host_headers_do_not_change_destination(self):
        self.client.force_authenticate(self.owner)
        with qr_settings():
            response = self.client.get(
                self.seller_url(),
                HTTP_HOST="internal-api:8000",
                HTTP_X_FORWARDED_HOST="evil.example",
                HTTP_X_FORWARDED_PROTO="https",
            )
        self.assert_qr_encodes(response, f"{PUBLIC}/m/cafe-menu")

    def test_missing_public_frontend_url_fails_closed(self):
        self.client.force_authenticate(self.owner)
        with qr_settings(PUBLIC_FRONTEND_URL=""):
            response = self.client.get(self.seller_url())
        self.assertEqual(response.status_code, 503)
        self.assertEqual(response.data["code"], "public_frontend_url_unconfigured")
        self.assertNotIn("qrCode", response.data)
        with qr_settings(PUBLIC_FRONTEND_URL=""):
            public_response = self.client.get("/api/qr/cafe-menu/")
        self.assertEqual(public_response.status_code, 503)

    def test_invalid_public_frontend_url_fails_closed(self):
        self.client.force_authenticate(self.owner)
        for invalid in ("not-a-url", "/relative/path", "ftp://shop.example", "https://shop.example/?q=1"):
            with self.subTest(value=invalid), qr_settings(PUBLIC_FRONTEND_URL=invalid):
                response = self.client.get(self.seller_url())
                self.assertEqual(response.status_code, 503)
                self.assertEqual(response.data["code"], "public_frontend_url_unconfigured")

    def test_public_frontend_url_is_normalized(self):
        self.client.force_authenticate(self.owner)
        with qr_settings(PUBLIC_FRONTEND_URL="https://shop.example/"):
            response = self.client.get(self.seller_url())
        self.assert_qr_encodes(response, "https://shop.example/m/cafe-menu")

    def test_http_localhost_origin_with_port_is_accepted(self):
        self.client.force_authenticate(self.owner)
        with qr_settings(PUBLIC_FRONTEND_URL="http://localhost:3000"):
            response = self.client.get(self.seller_url())
        self.assert_qr_encodes(response, "http://localhost:3000/m/cafe-menu")
        with qr_settings(PUBLIC_FRONTEND_URL="http://localhost:3000/"):
            response = self.client.get(self.seller_url())
        self.assert_qr_encodes(response, "http://localhost:3000/m/cafe-menu")

    def test_origin_with_missing_hostname_is_rejected(self):
        self.client.force_authenticate(self.owner)
        for invalid in ("https://", "https:///m", "https://:8080"):
            with self.subTest(value=invalid), qr_settings(PUBLIC_FRONTEND_URL=invalid):
                response = self.client.get(self.seller_url())
                self.assertEqual(response.status_code, 503)
                self.assertEqual(response.data["code"], "public_frontend_url_unconfigured")
                self.assertNotIn("qrCode", response.data)

    def test_origin_with_credentials_is_rejected(self):
        self.client.force_authenticate(self.owner)
        for invalid in (
            "https://user:password@shop.example",
            "https://user@shop.example",
            "https://:password@shop.example",
        ):
            with self.subTest(value=invalid), qr_settings(PUBLIC_FRONTEND_URL=invalid):
                response = self.client.get(self.seller_url())
                self.assertEqual(response.status_code, 503)
                self.assertEqual(response.data["code"], "public_frontend_url_unconfigured")

    def test_origin_with_query_or_fragment_is_rejected(self):
        self.client.force_authenticate(self.owner)
        for invalid in (
            "https://shop.example?x=1",
            "https://shop.example/?x=1",
            "https://shop.example#section",
            "https://shop.example/#section",
        ):
            with self.subTest(value=invalid), qr_settings(PUBLIC_FRONTEND_URL=invalid):
                response = self.client.get(self.seller_url())
                self.assertEqual(response.status_code, 503)
                self.assertEqual(response.data["code"], "public_frontend_url_unconfigured")

    def test_origin_with_non_root_path_is_rejected(self):
        self.client.force_authenticate(self.owner)
        for invalid in (
            "https://shop.example/m",
            "https://shop.example/m/",
            "https://shop.example/path/",
            "https://shop.example//",
        ):
            with self.subTest(value=invalid), qr_settings(PUBLIC_FRONTEND_URL=invalid):
                response = self.client.get(self.seller_url())
                self.assertEqual(response.status_code, 503)
                self.assertEqual(response.data["code"], "public_frontend_url_unconfigured")
                self.assertNotIn("qrCode", response.data)
                public_response = self.client.get("/api/qr/cafe-menu/")
                self.assertEqual(public_response.status_code, 503)

    def test_origin_with_invalid_or_out_of_range_port_is_rejected(self):
        self.client.force_authenticate(self.owner)
        for invalid in (
            "https://shop.example:abc",
            "https://shop.example:0",
            "https://shop.example:65536",
            "https://shop.example:70000",
            "https://shop.example:-1",
        ):
            with self.subTest(value=invalid), qr_settings(PUBLIC_FRONTEND_URL=invalid):
                response = self.client.get(self.seller_url())
                self.assertEqual(response.status_code, 503)
                self.assertEqual(response.data["code"], "public_frontend_url_unconfigured")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_host_header_alone_cannot_define_the_origin(self):
        self.client.force_authenticate(self.owner)
        with qr_settings():
            response = self.client.get(self.seller_url(), HTTP_HOST="evil.example")
        self.assert_qr_encodes(response, f"{PUBLIC}/m/cafe-menu")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_forwarded_host_header_alone_cannot_define_the_origin(self):
        self.client.force_authenticate(self.owner)
        with qr_settings():
            response = self.client.get(
                self.seller_url(),
                HTTP_X_FORWARDED_HOST="evil.example",
                HTTP_X_FORWARDED_PROTO="https",
            )
        self.assert_qr_encodes(response, f"{PUBLIC}/m/cafe-menu")

    @override_settings(ALLOWED_HOSTS=["*"])
    def test_spoofed_host_headers_cannot_rescue_missing_configuration(self):
        self.client.force_authenticate(self.owner)
        with qr_settings(PUBLIC_FRONTEND_URL=""):
            response = self.client.get(
                self.seller_url(),
                HTTP_HOST="evil.example",
                HTTP_X_FORWARDED_HOST="evil.example",
                HTTP_X_FORWARDED_PROTO="https",
            )
        self.assertEqual(response.status_code, 503)
        self.assertEqual(response.data["code"], "public_frontend_url_unconfigured")
        self.assertNotIn("qrCode", response.data)

    def test_inactive_entitlement_is_rejected(self):
        SubscriptionEntitlement.objects.all().delete()
        self.client.force_authenticate(self.owner)
        with qr_settings():
            response = self.client.get(self.seller_url())
            public_response = self.client.get("/api/qr/cafe-menu/")
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.data["code"], "menu_entitlement_inactive")
        self.assertEqual(public_response.status_code, 404)

    def test_unpublished_menu_is_rejected(self):
        self.menu.is_active = False
        self.menu.save(update_fields=["is_active"])
        self.client.force_authenticate(self.owner)
        with qr_settings():
            response = self.client.get(self.seller_url())
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.data["code"], "menu_unpublished")

    def test_business_without_menu_is_rejected(self):
        self.menu.delete()
        self.client.force_authenticate(self.owner)
        with qr_settings():
            response = self.client.get(self.seller_url())
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.data["code"], "menu_unavailable")

    def test_cross_owner_cannot_read_seller_qr(self):
        self.client.force_authenticate(self.other)
        with qr_settings():
            response = self.client.get(self.seller_url())
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.data["code"], "business_not_found")

    def test_authentication_is_required(self):
        response = self.client.get(self.seller_url())
        self.assertEqual(response.status_code, 401)

    def test_multiple_published_menus_require_explicit_selection(self):
        second = Menu.objects.create(business=self.business, title="Drinks", slug="cafe-drinks")
        self.client.force_authenticate(self.owner)
        with qr_settings():
            response = self.client.get(self.seller_url())
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.data["code"], "menu_selection_required")
        self.assertNotIn("qrCode", response.data)
        self.assertEqual(
            {row["slug"] for row in response.data["menus"]},
            {"cafe-menu", second.slug},
        )
        with qr_settings():
            explicit = self.client.get(self.seller_url() + f"?menu={second.slug}")
        self.assert_qr_encodes(explicit, f"{PUBLIC}/m/{second.slug}")

    def test_each_published_menu_generates_its_own_qr(self):
        second = Menu.objects.create(business=self.business, title="Drinks", slug="cafe-drinks")
        self.client.force_authenticate(self.owner)
        with qr_settings():
            first_response = self.client.get(self.seller_url() + f"?menu={self.menu.slug}")
            second_response = self.client.get(self.seller_url() + f"?menu={second.slug}")
        self.assert_qr_encodes(first_response, f"{PUBLIC}/m/{self.menu.slug}")
        self.assert_qr_encodes(second_response, f"{PUBLIC}/m/{second.slug}")
        self.assertEqual(first_response.data["menuTitle"], "Menu")
        self.assertEqual(second_response.data["menuTitle"], "Drinks")

    def test_unknown_menu_slug_is_rejected(self):
        Menu.objects.create(business=self.business, title="Drinks", slug="cafe-drinks")
        self.client.force_authenticate(self.owner)
        with qr_settings():
            response = self.client.get(self.seller_url() + "?menu=does-not-exist")
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.data["code"], "menu_not_published")
        self.assertNotIn("qrCode", response.data)

    def test_unpublished_menu_is_listed_nowhere_and_not_selectable(self):
        second = Menu.objects.create(
            business=self.business, title="Drinks", slug="cafe-drinks", is_active=False
        )
        self.client.force_authenticate(self.owner)
        with qr_settings():
            listing = self.client.get(self.seller_url())
        # Only the published legacy menu is ambiguous here, so the unpublished one
        # must neither appear in a picker nor be selectable.
        self.assert_qr_encodes(listing, f"{PUBLIC}/m/{self.menu.slug}")
        with qr_settings():
            explicit = self.client.get(self.seller_url() + f"?menu={second.slug}")
        self.assertEqual(explicit.status_code, 404)
        self.assertEqual(explicit.data["code"], "menu_not_published")

    def test_menu_selection_cannot_cross_same_owner_businesses(self):
        second_business = Business.objects.create(owner=self.owner, name="Bakery", slug="bakery")
        second_business_menu = Menu.objects.create(
            business=second_business, title="Bakery Menu", slug="bakery-menu"
        )
        self.client.force_authenticate(self.owner)
        with qr_settings():
            response = self.client.get(
                self.seller_url() + f"?menu={second_business_menu.slug}"
            )
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.data["code"], "menu_not_published")

    def test_menu_parameter_cannot_select_another_business_menu(self):
        foreign_owner = User.objects.create_user(email="foreign@example.com")
        foreign_business = Business.objects.create(owner=foreign_owner, name="Other", slug="other")
        foreign_menu = Menu.objects.create(business=foreign_business, title="Other", slug="other-menu")
        self.client.force_authenticate(self.owner)
        with qr_settings():
            response = self.client.get(self.seller_url() + f"?menu={foreign_menu.slug}")
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.data["code"], "menu_not_published")
