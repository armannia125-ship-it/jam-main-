import base64
import io
import ipaddress
import re
from urllib.parse import urlparse

import qrcode
from django.conf import settings
from django.core.exceptions import PermissionDenied
from django.db import transaction
from django.utils import timezone
from rest_framework import permissions, status, viewsets
from rest_framework.views import APIView
from rest_framework.generics import RetrieveAPIView
from rest_framework.response import Response
from subscriptions import entitlements
from subscriptions.models import SubscriptionEntitlement
from .models import Business, Menu, Category, Product
from .serializers import BusinessSerializer, MenuSerializer, CategorySerializer, ProductSerializer, PublicMenuSerializer


def _business_has_menu_access(business):
    """Menu access is granted only by a current MENU entitlement."""
    return entitlements.menu_access(business)


_HOST_LABEL = re.compile(r"[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?")


def _valid_hostname(hostname):
    """Return True for a syntactically valid hostname, IPv4, or IPv6 literal."""
    if not hostname or len(hostname) > 253:
        return False
    try:
        ipaddress.ip_address(hostname)
        return True
    except ValueError:
        pass
    if hostname.endswith("."):
        hostname = hostname[:-1]
    labels = hostname.split(".")
    return all(
        label and len(label) <= 63 and _HOST_LABEL.fullmatch(label) for label in labels
    )


def _public_frontend_base():
    """Return the validated absolute public frontend origin, or ``None``.

    ``PUBLIC_FRONTEND_URL`` is an *origin*: scheme plus host plus optional port.
    The generated menu path is appended by the caller, so a configured path
    (other than ``/``) would silently corrupt every QR destination and is
    rejected.

    QR destinations must never be derived from the request ``Host`` or
    ``X-Forwarded-Host`` headers: API requests may travel through an internal
    proxy whose host is not the customer-facing origin. A relative value, a
    non-HTTP scheme, credentials, a query/fragment, an invalid port, or a
    non-root path makes the configuration unusable so callers can fail closed.
    """
    raw = (getattr(settings, "PUBLIC_FRONTEND_URL", "") or "").strip()
    if not raw:
        return None
    try:
        parsed = urlparse(raw)
    except ValueError:
        return None
    if parsed.scheme not in ("http", "https"):
        return None
    if not parsed.netloc:
        return None
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        return None
    if not _valid_hostname(parsed.hostname):
        return None
    try:
        port = parsed.port
    except ValueError:
        return None
    if port is not None and not 1 <= port <= 65535:
        return None
    # Only the origin is accepted: "" or "/" is fine, anything else is a path prefix.
    if parsed.path not in ("", "/"):
        return None
    host = f"[{parsed.hostname}]" if ":" in parsed.hostname else parsed.hostname
    port_suffix = f":{port}" if port is not None else ""
    return f"{parsed.scheme}://{host}{port_suffix}"


def _public_menu_url(base, menu):
    """Build the public menu URL from the configured origin and the menu slug."""
    return f"{base}/m/{menu.slug}"


def _qr_payload_response(menu, public_url):
    """Render a PNG QR for ``public_url`` and return the API response body."""
    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        box_size=10,
        border=4,
    )
    qr.add_data(public_url)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    buffer = io.BytesIO()
    img.save(buffer, format="PNG")
    qr_base64 = base64.b64encode(buffer.getvalue()).decode("utf-8")
    return {
        "menuTitle": menu.title,
        "menuSlug": menu.slug,
        "publicUrl": public_url,
        "qrCode": f"data:image/png;base64,{qr_base64}",
    }


def _public_url_unconfigured():
    return Response(
        {
            "detail": "نشانی عمومی فرانت‌اند پیکربندی نشده است؛ ساخت QR در دسترس نیست.",
            "code": "public_frontend_url_unconfigured",
        },
        status=status.HTTP_503_SERVICE_UNAVAILABLE,
    )


class BusinessViewSet(viewsets.ModelViewSet):
    serializer_class = BusinessSerializer
    def get_queryset(self):
        return Business.objects.filter(owner=self.request.user)
    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)


class MenuViewSet(viewsets.ModelViewSet):
    serializer_class = MenuSerializer
    def get_queryset(self):
        return Menu.objects.filter(business__owner=self.request.user).select_related("business")

    def perform_create(self, serializer):
        business = serializer.validated_data["business"]
        if not _business_has_menu_access(business):
            serializer.validated_data["is_active"] = False
        serializer.save()

    def perform_update(self, serializer):
        menu = self.get_object()
        requested_publish = serializer.validated_data.get("is_active")
        if requested_publish is True and not _business_has_menu_access(menu.business):
            raise PermissionDenied("برای انتشار منو باید اشتراک فعال داشته باشید.")
        serializer.save()


class CategoryViewSet(viewsets.ModelViewSet):
    serializer_class = CategorySerializer

    def get_queryset(self):
        return Category.objects.filter(menu__business__owner=self.request.user).select_related("menu")

    def perform_create(self, serializer):
        menu = serializer.validated_data["menu"]
        if not _business_has_menu_access(menu.business):
            raise PermissionDenied("برای افزودن دسته‌بندی باید اشتراک فعال داشته باشید.")
        serializer.save()


class ProductViewSet(viewsets.ModelViewSet):
    serializer_class = ProductSerializer

    def get_queryset(self):
        return Product.objects.filter(category__menu__business__owner=self.request.user).select_related("category")

    def perform_create(self, serializer):
        category = serializer.validated_data["category"]
        business = category.menu.business
        # Lock the owning business so the count-and-insert limit check cannot
        # be raced by concurrent product creation requests.
        with transaction.atomic():
            Business.objects.select_for_update().get(pk=business.pk)
            if not _business_has_menu_access(business):
                raise PermissionDenied("برای افزودن محصول باید اشتراک فعال داشته باشید.")
            limit = entitlements.product_limit(business)
            if limit is not None and Product.objects.filter(category__menu__business=business).count() >= limit:
                raise PermissionDenied(
                    f"سقف محصولات اشتراک پایه {limit} عدد است؛ برای محصولات نامحدود، اشتراک بالاتر بخرید."
                )
            serializer.save()

    def perform_update(self, serializer):
        product = self.get_object()
        category = serializer.validated_data.get("category", product.category)
        if not _business_has_menu_access(category.menu.business):
            raise PermissionDenied("برای ویرایش محصول باید اشتراک فعال داشته باشید.")
        serializer.save()


class SellerMenuPreviewView(APIView):
    """Return owner-scoped menu content for a private seller preview."""

    def get(self, request, slug):
        menu = Menu.objects.filter(slug=slug, business__owner=request.user).select_related("business").prefetch_related("categories__products").first()
        if not menu:
            return Response({"detail": "منو پیدا نشد."}, status=status.HTTP_404_NOT_FOUND)
        return Response(PublicMenuSerializer(menu).data)


class PublicMenuView(RetrieveAPIView):
    permission_classes = [permissions.AllowAny]
    authentication_classes = []
    serializer_class = PublicMenuSerializer
    lookup_field = "slug"

    def get_queryset(self):
        now = timezone.now()
        return (
            Menu.objects.filter(
                is_active=True,
                business__owner__is_active=True,
            )
            .filter(
                business__subscription_entitlements__entitlement_type=SubscriptionEntitlement.Type.MENU,
                business__subscription_entitlements__status=SubscriptionEntitlement.Status.ACTIVE,
                business__subscription_entitlements__starts_at__lte=now,
                business__subscription_entitlements__ends_at__gt=now,
            )
            .distinct()
            .prefetch_related("categories__products")
            .select_related("business")
        )


class QrCodeView(APIView):
    """Public QR for a published menu, addressed by its own ``Menu.slug``.

    The destination is built from ``PUBLIC_FRONTEND_URL`` only. Request headers
    never influence it, so internal/proxy hosts cannot leak into QR payloads.
    """

    permission_classes = [permissions.AllowAny]
    authentication_classes = []

    def get(self, request, slug=None, format=None):
        base = _public_frontend_base()
        if base is None:
            return _public_url_unconfigured()
        now = timezone.now()
        menu = (
            Menu.objects.filter(slug=slug, is_active=True, business__owner__is_active=True)
            .filter(
                business__subscription_entitlements__entitlement_type=SubscriptionEntitlement.Type.MENU,
                business__subscription_entitlements__status=SubscriptionEntitlement.Status.ACTIVE,
                business__subscription_entitlements__starts_at__lte=now,
                business__subscription_entitlements__ends_at__gt=now,
            )
            .distinct()
            .select_related("business")
            .first()
        )
        if not menu:
            return Response(
                {"detail": "منو پیدا نشد یا منتشر نشده است.", "code": "menu_not_found"},
                status=status.HTTP_404_NOT_FOUND,
            )
        return Response(_qr_payload_response(menu, _public_menu_url(base, menu)))


class SellerQrCodeView(APIView):
    """Owner-scoped QR for one of the seller's own businesses.

    The eligible menu is resolved from the business relationship (never from
    ``Business.slug``). When the business has more than one published menu and
    no explicit ``?menu=<slug>`` is supplied, the endpoint refuses to guess and
    returns ``menu_selection_required`` so the caller can make an explicit
    choice.
    """

    def get(self, request, business_id):
        business = Business.objects.filter(pk=business_id, owner=request.user).first()
        if not business:
            return Response(
                {"detail": "کسب‌وکار پیدا نشد.", "code": "business_not_found"},
                status=status.HTTP_404_NOT_FOUND,
            )
        base = _public_frontend_base()
        if base is None:
            return _public_url_unconfigured()
        if not _business_has_menu_access(business):
            return Response(
                {
                    "detail": "برای ساخت QR باید اشتراک منو فعال باشد.",
                    "code": "menu_entitlement_inactive",
                },
                status=status.HTTP_404_NOT_FOUND,
            )
        menus = list(Menu.objects.filter(business=business).order_by("id"))
        if not menus:
            return Response(
                {"detail": "برای این کسب‌وکار منویی ثبت نشده است.", "code": "menu_unavailable"},
                status=status.HTTP_404_NOT_FOUND,
            )
        published = [menu for menu in menus if menu.is_active]
        if not published:
            return Response(
                {"detail": "منوی این کسب‌وکار منتشر نشده است.", "code": "menu_unpublished"},
                status=status.HTTP_404_NOT_FOUND,
            )
        requested = (request.query_params.get("menu") or "").strip()
        if requested:
            menu = next((item for item in published if item.slug == requested), None)
            if menu is None:
                return Response(
                    {
                        "detail": "منوی درخواستی برای این کسب‌وکار منتشر نشده است.",
                        "code": "menu_not_published",
                    },
                    status=status.HTTP_404_NOT_FOUND,
                )
        elif len(published) == 1:
            menu = published[0]
        else:
            return Response(
                {
                    "detail": "این کسب‌وکار چند منوی منتشرشده دارد؛ منوی موردنظر را مشخص کنید.",
                    "code": "menu_selection_required",
                    "menus": [{"slug": item.slug, "title": item.title} for item in published],
                },
                status=status.HTTP_409_CONFLICT,
            )
        return Response(_qr_payload_response(menu, _public_menu_url(base, menu)))

