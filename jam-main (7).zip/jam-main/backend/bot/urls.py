from django.urls import path
from .views import TelegramLinkView, TelegramVerifyView, TelegramUnlinkView
urlpatterns = [
    path("telegram/status/", TelegramLinkView.as_view(), name="telegram-status"),
    path("telegram/link/", TelegramLinkView.as_view(), name="telegram-link"),
    path("telegram/verify/", TelegramVerifyView.as_view(), name="telegram-verify"),
    path("telegram/unlink/", TelegramUnlinkView.as_view(), name="telegram-unlink"),
]
