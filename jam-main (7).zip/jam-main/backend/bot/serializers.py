from rest_framework import serializers
class LinkRequestSerializer(serializers.Serializer):
    pass
