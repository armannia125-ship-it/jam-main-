import secrets
import base64
from datetime import timedelta
from django.conf import settings
from django.contrib.auth.hashers import make_password
from django.utils import timezone
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import TelegramLink, TelegramLinkToken

class TelegramLinkView(APIView):
    def get(self, request):
        link = TelegramLink.objects.filter(user=request.user).first()
        return Response({"linked": bool(link), "username": link.username if link else None})

    def post(self, request):
        if not settings.TELEGRAM_BOT_USERNAME:
            return Response({"detail": "Telegram bot username is not configured."}, status=status.HTTP_503_SERVICE_UNAVAILABLE)
        secret = secrets.token_urlsafe(32)
        link_token = TelegramLinkToken.objects.create(user=request.user, token_hash=make_password(secret),
                                         expires_at=timezone.now() + timedelta(minutes=10))
        token = f"{link_token.pk}_{secret}"
        return Response({"link_url": f"https://t.me/{settings.TELEGRAM_BOT_USERNAME}?start={token}",
                         "expires_in_seconds": 600}, status=status.HTTP_201_CREATED)

class TelegramVerifyView(APIView):
    def post(self, request):
        """Handle Telegram account verification callback."""
        token = request.data.get("token")
        if not token:
            return Response({"detail": "Invalid verification data."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            parts = str(token).split("_")
            if len(parts) != 2:
                return Response({"detail": "Invalid token format."}, status=status.HTTP_400_BAD_REQUEST)
            token_pk = int(parts[0])
            secret = parts[1]
        except (ValueError, IndexError):
            return Response({"detail": "Invalid token format."}, status=status.HTTP_400_BAD_REQUEST)

        # Find the link token that is valid and not used
        try:
            link_token = TelegramLinkToken.objects.select_for_update().get(
                pk=token_pk,
                used_at__isnull=True,
                expires_at__gt=timezone.now()
            )
        except TelegramLinkToken.DoesNotExist:
            return Response({"detail": "Verification link expired or already used."}, status=status.HTTP_400_BAD_REQUEST)

        # Verify the secret matches using check_password (PBKDF2)
        from django.contrib.auth.hashers import check_password
        if not check_password(secret, link_token.token_hash):
            link_token.attempts = (link_token.attempts or 0) + 1
            link_token.save(update_fields=["attempts"])
            return Response({"detail": "Verification code mismatch."}, status=status.HTTP_400_BAD_REQUEST)

        # Mark as used and link the account
        link_token.used_at = timezone.now()
        link_token.save(update_fields=["used_at"])

        # Get or create the Telegram user
        telegram_user_id = link_token.user.telegram_links.filter().values_list('telegram_user_id', flat=True).first()
        user = link_token.user

        # Update or create the Telegram link
        tg_link, created = TelegramLink.objects.get_or_create(
            user=user,
            defaults={
                "telegram_user_id": telegram_user_id,
                "username": request.data.get("username", ""),
            }
        )
        if not created:
            # Update existing link if needed
            if telegram_user_id:
                tg_link.telegram_user_id = telegram_user_id
            if request.data.get("username"):
                tg_link.username = request.data["username"]
            tg_link.save()

        return Response({
            "detail": "Successfully linked Telegram account.",
            "user": {
                "id": user.pk,
                "phone": user.phone,
                "email": user.email,
            },
        })

class TelegramUnlinkView(APIView):
    def post(self, request):
        """Handle Telegram account unlinking."""
        user = request.user
        try:
            tg_link = TelegramLink.objects.get(user=user)
            tg_link.delete()
            return Response({"detail": "Successfully unlinked Telegram account."})
        except TelegramLink.DoesNotExist:
            return Response({"detail": "Telegram account not linked."}, status=status.HTTP_404_NOT_FOUND)

