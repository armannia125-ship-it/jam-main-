from django.conf import settings
from django.db import models

class TelegramLink(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="telegram_links")
    telegram_user_id = models.BigIntegerField(unique=True)
    username = models.CharField(max_length=100, blank=True)
    linked_at = models.DateTimeField(auto_now_add=True)

class TelegramLinkToken(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="telegram_link_tokens")
    token_hash = models.CharField(max_length=128)
    expires_at = models.DateTimeField()
    used_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
