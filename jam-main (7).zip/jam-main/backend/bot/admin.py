from django.contrib import admin
from .models import TelegramLink, TelegramLinkToken
admin.site.register([TelegramLink, TelegramLinkToken])
