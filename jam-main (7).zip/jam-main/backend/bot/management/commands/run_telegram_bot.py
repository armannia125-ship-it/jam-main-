from asgiref.sync import sync_to_async
from django.conf import settings
from django.contrib.auth.hashers import check_password
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.utils import timezone
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes, filters
from bot.models import TelegramLink, TelegramLinkToken
from businesses.models import Category, Product
from subscriptions.entitlements import menu_access

@sync_to_async
@transaction.atomic
def consume_link_token(token, telegram_user):
    token_id, separator, secret = token.partition("_")
    if not separator or not token_id.isdigit():
        return False
    match = TelegramLinkToken.objects.select_for_update().filter(
        pk=int(token_id), used_at__isnull=True, expires_at__gt=timezone.now(), user__is_active=True
    ).select_related("user").first()
    if match is None or not check_password(secret, match.token_hash):
        return False
    TelegramLink.objects.update_or_create(telegram_user_id=telegram_user.id,
        defaults={"user": match.user, "username": telegram_user.username or ""})
    match.used_at = timezone.now()
    match.save(update_fields=["used_at"])
    return True

@sync_to_async
def get_linked_user(telegram_id):
    link = TelegramLink.objects.select_related("user").filter(telegram_user_id=telegram_id, user__is_active=True).first()
    return link.user if link else None

@sync_to_async
def get_categories(user):
    return list(Category.objects.filter(menu__business__owner=user).values_list("id", "name", "menu__business__name"))

@sync_to_async
def get_products(user):
    return list(Product.objects.filter(category__menu__business__owner=user).values_list("id", "name", "price_toman", "category__name"))

def business_has_menu_access(user):
    """Check whether the user owns a business with current MENU access."""
    return any(menu_access(business) for business in user.businesses.all())


@sync_to_async
@transaction.atomic
def add_product(user, category_id, name, price):
    if not business_has_menu_access(user):
        raise PermissionError("Menu entitlement required")
    if category_id < 1 or not name or len(name) > 160 or price < 0:
        raise ValueError("Invalid product fields")
    category = Category.objects.filter(pk=category_id, menu__business__owner=user).first()
    if not category:
        return False
    Product.objects.create(category=category, name=name, price_toman=price)
    return True

@sync_to_async
@transaction.atomic
def edit_product(user, product_id, name, price):
    if not business_has_menu_access(user):
        raise PermissionError("Menu entitlement required")
    if product_id < 1 or (name is not None and (not name or len(name) > 160)) or (price is not None and price < 0):
        raise ValueError("Invalid product fields")
    product = Product.objects.filter(pk=product_id, category__menu__business__owner=user).first()
    if not product:
        return False
    if name is not None:
        product.name = name
    if price is not None:
        product.price_toman = price
    product.save(update_fields=["name", "price_toman"])
    return True

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if context.args:
        if await consume_link_token(context.args[0], update.effective_user):
            await update.message.reply_text("Jam account connected. Use /help to see menu commands.")
        else:
            await update.message.reply_text("This link is invalid, expired, or already used. Generate a new link from your Jam dashboard.")
        return
    user = await get_linked_user(update.effective_user.id)
    await update.message.reply_text("Welcome to Jam. Connect your account using the one-time link from your seller dashboard." if not user else "Your Jam account is connected. Use /help for commands.")

async def require_user(update):
    user = await get_linked_user(update.effective_user.id)
    if not user:
        await update.message.reply_text("Connect your Jam account first using /start <one-time-link-token>.")
    return user

async def reply_chunks(update, text):
    for offset in range(0, len(text), 3500):
        await update.message.reply_text(text[offset:offset + 3500])

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Menu management commands:\n/categories — list category IDs\n/products — list product IDs and prices\n/add <category_id> | <name> | <price_toman>\n/edit <product_id> | <new name> | <new price_toman>\n/setprice <product_id> <price_toman>")

async def categories_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = await require_user(update)
    if not user: return
    rows = await get_categories(user)
    await reply_chunks(update, "\n".join(f"#{row[0]} {row[1]} — {row[2]}" for row in rows) or "No categories yet.")

async def products_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = await require_user(update)
    if not user: return
    rows = await get_products(user)
    await reply_chunks(update, "\n".join(f"#{row[0]} {row[1]} — {row[2]:,} toman ({row[3]})" for row in rows) or "No products yet.")

async def add_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = await require_user(update)
    if not user: return
    try:
        category_id, name, price = " ".join(context.args).split("|", 2)
        ok = await add_product(user, int(category_id.strip()), name.strip(), int(price.strip()))
    except PermissionError:
        await update.message.reply_text("برای افزودن محصول باید اشتراک فعال داشته باشید. کد فعال‌سازی را از داشبورد وارد کنید.")
        return
    except (ValueError, TypeError):
        await update.message.reply_text("Usage: /add <category_id> | <name> | <price_toman>")
        return
    await update.message.reply_text("Product added." if ok else "Category not found in your account. Use /categories.")

async def edit_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = await require_user(update)
    if not user: return
    try:
        product_id, name, price = " ".join(context.args).split("|", 2)
        ok = await edit_product(user, int(product_id.strip()), name.strip(), int(price.strip()))
    except PermissionError:
        await update.message.reply_text("برای ویرایش محصول باید اشتراک فعال داشته باشید. کد فعال‌سازی را از داشبورد وارد کنید.")
        return
    except (ValueError, TypeError):
        await update.message.reply_text("Usage: /edit <product_id> | <new name> | <new price_toman>")
        return
    await update.message.reply_text("Product updated." if ok else "Product not found in your account.")

async def setprice_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = await require_user(update)
    if not user: return
    try:
        product_id, price = map(int, context.args[:2])
        ok = await edit_product(user, product_id, None, price)
    except PermissionError:
        await update.message.reply_text("برای تغییر قیمت باید اشتراک فعال داشته باشید. کد فعال‌سازی را از داشبورد وارد کنید.")
        return
    except (ValueError, TypeError):
        await update.message.reply_text("Usage: /setprice <product_id> <price_toman>")
        return
    await update.message.reply_text("Price updated." if ok else "Product not found in your account.")


class Command(BaseCommand):
    help = "Run the Jam Telegram menu-management bot."
    def handle(self, *args, **options):
        if not settings.TELEGRAM_BOT_TOKEN:
            raise CommandError("Set TELEGRAM_BOT_TOKEN before starting the bot.")
        app = Application.builder().token(settings.TELEGRAM_BOT_TOKEN).build()
        app.add_handler(CommandHandler("start", start, filters=filters.ChatType.PRIVATE))
        app.add_handler(CommandHandler("help", help_command, filters=filters.ChatType.PRIVATE))
        app.add_handler(CommandHandler("categories", categories_command, filters=filters.ChatType.PRIVATE))
        app.add_handler(CommandHandler("products", products_command, filters=filters.ChatType.PRIVATE))
        app.add_handler(CommandHandler("add", add_command, filters=filters.ChatType.PRIVATE))
        app.add_handler(CommandHandler("edit", edit_command, filters=filters.ChatType.PRIVATE))
        app.add_handler(CommandHandler("setprice", setprice_command, filters=filters.ChatType.PRIVATE))
        self.stdout.write(self.style.SUCCESS("Jam Telegram bot polling started"))
        app.run_polling()
