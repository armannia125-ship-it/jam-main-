# AGENTS.md — Instructions for AI Coding Agents

Repository-wide instructions for JAM. Read this before changing code, configuration, data, or deployment files. There are no nested `AGENTS.md` files.

## 1. Precedence and evidence

Use this order:

1. Explicit, latest owner-approved decisions.
2. Current implementation for technical behavior.
3. Canonical documentation current for the relevant area.
4. Historical reports and implementation summaries.
5. Agent inference.

Rules:

- Code must not silently override an explicit owner business decision.
- Documentation must not be treated as proof of current technical behavior when code differs.
- Historical reports are evidence of what was reported, not proof of current state.
- If two owner decisions conflict, or code contradicts a decision, **stop and report the conflict**. Do not choose arbitrarily.
- Do not turn suggestions, TODOs, or “owner decision required” items into approved rules.

## 2. Project and stack

JAM (جم لایف) is a Persian-first, RTL marketplace/menu platform for Jam, Iran. It combines a Django API, a Next.js storefront/panel, subscriptions, offline commerce/orders, a Telegram menu bot, and deployment tooling. The current working tree is intentionally dirty; it is not a clean release state.

Verified stack:

| Area | Technology |
|---|---|
| Backend | Python 3.12 image, Django 5.2.18, Django REST Framework 3.18.3, SimpleJWT 5.5.1 |
| Database | PostgreSQL (`psycopg` 3.3.6); tests use SQLite |
| Cache | Redis via `django-redis`; `LocMemCache` is local fallback only |
| Frontend | Next.js 15 App Router, React 19, TypeScript strict, Tailwind CSS v4 |
| Bot | `python-telegram-bot` 21.11.1, polling only |
| Money | Integer **Toman** everywhere; the only Toman→Rial conversion is inside the Zarinpal adapter (×10) |
| Runtime | Node 20 in Docker; local Node here is 24.22.0 |

**Not production ready.** See §8. Do not claim production readiness because a local build or Staging boot succeeds.

## 3. Architecture map

### Backend (`backend/`)

- `config/` — settings, root URLs, WSGI/ASGI, health/readiness, test/concurrency settings.
- `accounts/` — custom phone/email user, OTPy OTP login, JWT, server-side `role`, admin APIs, `AdminAction` audit, `make_admin`.
- `businesses/` — businesses, menus, categories, products, public menu, owner preview, QR.
- `subscriptions/` — five-product catalog, purchases, MENU/CLUB entitlements, renewal/expiry, notifications.
- `payments/` — `Transaction`, provider abstraction, Zarinpal adapter, callback verification.
- `commerce/` — store config, orders/statuses, commission/settlement, legacy club, visits, purchase codes, revenue/metrics, agreements.
- `cart/` — legacy/dead customer cart app; do not extend or use it for the real checkout.
- `bot/` — Telegram link flow and menu-management bot. Initial Staging must not start it.
- API paths are under `/api/`; route source of truth is `backend/config/urls.py` plus each app’s `urls.py`.
- Default DRF permission is `IsAuthenticated`. Public endpoints explicitly set `AllowAny` and usually `authentication_classes = []`.
- Health: `GET /api/health/live/` (process only), `GET /api/health/ready/` (PostgreSQL + cache; 503 when unhealthy).

### Frontend (`frontend/`)

- `app/` — App Router pages: storefront (`/`, `/search`, `/store/[id]`, `/m/[slug]`, `/cart`, `/checkout`, `/orders`), seller panel (`/panel/*`), admin (`/admin/*`), subscriptions, club, login, offline, health.
- `frontend/app/api/[...path]/route.ts` — server-side same-origin proxy to `API_INTERNAL_URL`; preserves Django trailing slashes, forwards auth/body, never caches API responses, serves `/api/media-proxy/*`.
- `frontend/lib/api.ts` — single API client; JWT in browser `localStorage` (`jam.auth.v1`), single-flight refresh, 401 retry.
- `frontend/lib/auth.tsx` — client auth context. `frontend/lib/commerce.tsx`, `frontend/lib/state.tsx` — cart/order client state. `frontend/lib/subscriptions-api.ts` — catalog/purchase/role hooks.
- `components/`, `components/features/`, `components/ui/` — shared and feature UI. Pages are largely client components.
- UI is Persian and RTL (`<html lang="fa" dir="rtl">`); use existing CSS variables/classes and Tailwind tokens. Do not introduce LTR-only layouts or hardcoded English user-facing copy.

### Infrastructure

- `docker-compose.yml` — base local production-like stack: PostgreSQL, Redis, backend, frontend.
- `docker-compose.dev.yml` — development overrides with source mounts and `npm run dev`.
- `docker-compose.prod.yml` — Caddy + backend + frontend + PostgreSQL + Redis, healthchecks, media volume.
- `Caddyfile`, `Caddyfile.common` — TLS/reverse proxy. Caddy routes `/admin/*` and `/static/*` to Django, `/media/*` from the shared volume, everything else through Next.js.
- `backend/Dockerfile` — Python 3.12, lockfile install, build-time `collectstatic`, non-root user, Gunicorn only. **No migration at build or startup.**
- `frontend/Dockerfile` — multi-stage Node 20, `npm ci`, production build, non-root runtime.

Implemented, configured, and deferred are different. In particular:

- Implemented: subscription catalog/purchases/entitlements, admin RBAC/audit, offline-commerce orders, Zarinpal infrastructure (unconfigured fail-safe), five-day notifications, S3-compatible storage configuration, readiness.
- Configured but not externally verified: Staging Render/Neon/Upstash/S3 topology, production Caddy/TLS stack, real Zarinpal, real OTPy delivery, real S3 uploads.
- Deferred/blocked: Staging migration/admin/bot execution on Render Free; live provider tests; order-bound online payment; production scheduling.
- Not implemented: plan-level gating for online ordering/analytics/customization; automated production scheduler wiring; real settlement payouts.

## 4. Owner-approved business rules

The authoritative catalog is the database `SubscriptionProduct` table, seeded by `backend/subscriptions/migrations/0005_seed_subscription_products.py`. Do not edit prices, names, durations, or seed data without explicit owner approval.

| Slug | Name | Price (Toman) | Duration | Category | Product limit |
|---|---|---:|---:|---|---:|
| `basic` | پایه | 200,000 | 30 days | menu | 80 |
| `professional` | حرفه‌ای | 250,000 | 30 days | menu | unlimited |
| `premium` | ویژه | 350,000 | 30 days | menu | unlimited |
| `gold` | طلایی | 450,000 | 30 days per entitlement | combo (menu + club) | unlimited |
| `seller_club` | باشگاه فروشندگان | 350,000 | 30 days | club | n/a |

Rules:

- **Gold** creates one MENU and one CLUB entitlement atomically; each has an independent 30-day window and renewal lifecycle. Gold includes Premium menu access and Seller Club access.
- **No discount claim:** 450,000 is not a 10% discount versus 350,000 + 350,000. Never reintroduce discount marketing copy. The 450,000 price is authoritative and component prices remain unchanged.
- **No free plan, no free trial, no cancellation, no proration, no refund flow.** Purchase statuses are `pending → paid | failed`. Renewal windows start at `max(now, latest current entitlement end)` and never overlap.
- **Five-day expiration notification** per entitlement via `notify_expiring_entitlements`; Gold produces two independent notifications. No Celery/beat exists; scheduling is external.
- **Menu access** = a current MENU entitlement only. **Club access** = a current CLUB entitlement only. Product limit comes from the current MENU entitlement's product (Basic 80; higher menu plans unlimited). Legacy `Subscription`, `SubscriptionPlan`, `ActivationCode`, `ActivationCodeEvent`, and `ClubMembership` are removed.
- **Only online payment and entitlements grant access.** ZarinPal is the only payment route; there is no manual subscription request, payment instruction, activation code, redemption, trial, or simulated subscription payment. Gold creates independent MENU and CLUB entitlements atomically.
- **ZarinPal is the only approved online payment provider.** Unconfigured provider must fail safely with `503 payment_provider_unconfigured` and create nothing. A browser redirect is never proof of payment; only server-side verification promotes state.
- **Admin:** `User.role` (`user`/`admin`) is server-side only. Admin APIs require `IsAdmin`; client checks are cosmetic. `make_admin --phone` promotes an **existing, active user only**; no public admin registration; last active admin cannot be demoted; role changes and sensitive admin mutations are audited. The first admin must already exist as a user.
- **OTP/authentication:** preserve the OTPy provider flow and JWT behavior. There is no approved development OTP bypass. Do not weaken verification, challenge consumption, attempt limits, throttling, or account checks to make tests pass.
- **Approved plan feature matrix** (catalog/owner intent): Basic lacks online ordering, analytics, and customization; Professional has online ordering and analytics; Premium adds customization/advanced analytics; Gold includes all menu features plus Seller Club; standalone Seller Club has club features only. **Enforcement gap:** current code enforces menu/club access and Basic's 80-product limit, but does not enforce plan-specific online-order, analytics, or customization gating. Do not claim it does; do not add gating without an owner decision and tests.

### Owner decisions still open

Do not invent policy for:

- refunds/cancellation beyond the current no-refund rule;
- production scheduler ownership/configuration;
- JWT revocation/logout and localStorage migration;
- settlement payout provider and reconciliation;
- final Staging execution channel for migrations/admin promotion.

## 5. Security and sensitive operations

- **Never** put secrets, tokens, OTP codes, passwords, full phone numbers, Redis URLs, database URLs, or provider payloads in source, logs, reports, commit messages, or command output.
- `.env` is git-ignored; `.env.example` is a placeholder template. Never commit real credentials. Never expose `BOT_API_TOKEN`, `DJANGO_SECRET_KEY`, `OTPY_API_KEY`, `ZARINPAL_MERCHANT_ID`, or Telegram tokens via `NEXT_PUBLIC_*`.
- Keep JWT in the existing `Authorization: Bearer` flow unless explicitly authorized to change architecture. Tokens currently live in `localStorage`; this is a documented XSS risk, and refresh-token blacklisting/logout revocation is not implemented. Do not quietly “fix” this by changing auth storage or adding dependencies.
- Admin authorization must remain server-side. Never rely on hidden buttons, client state, or a client-supplied role.
- Payment state changes only after server-side Zarinpal verification. Never trust callback query parameters, `Status=OK`, client amounts, or a browser redirect. Never manually mark a paid purchase failed; paid purchases are protected.
- Do not run real payments, refunds, OTP sends, Telegram messages, or provider calls without explicit owner authorization and credentials.
- Do not create, delete, or overwrite user media during integration testing. S3 Level B/C tests require an owner-approved bucket and a dedicated temporary UUID key; never touch existing user objects.
- Readiness may report only `ok`/`unavailable`; never expose URLs, credentials, stack traces, or internal hosts.
- Public media is served under `/media/` and is not private. Do not upload sensitive documents to `MEDIA_ROOT` or S3 public media.
- Do not run destructive database commands (`flush`, `reset`, mass delete/update, dropping schemas), modify production data, or run bulk data changes without explicit owner authorization.
- Do not start the Telegram bot or create a webhook in Staging. Initial Staging must keep it disabled.
- Treat `backend/bot/views.py::TelegramVerifyView` as known dead/buggy legacy code; do not build new behavior on it without an owner decision.

## 6. Engineering conventions

### Backend

- Stay within existing Django apps and boundaries. Do not create a parallel service or duplicate existing domain logic.
- Use DRF viewsets/routers for CRUD and `APIView` for custom endpoints. Keep API paths trailing-slash compatible.
- Scope every owner resource by `request.user` (querysets and serializer relation querysets). Cross-owner access should remain `404`, not leak existence with `403`.
- Return structured errors as `{"detail": "...", "code": "..."}`; user-facing messages are Persian. Do not return stack traces.
- Use `transaction.atomic()` and `select_for_update()` for money, entitlement, order, stock/limit, and callback transitions. Preserve idempotency and database constraints.
- Migrations are additive and reviewed. Run `makemigrations --check`; never create migrations casually, rewrite applied migrations, or add destructive operations without explicit approval. Test migrations against PostgreSQL when behavior is PostgreSQL-specific.
- Tests belong beside apps (`tests.py`, `test_*.py`) and use `APITestCase`/Django test runner. Add focused regression tests for behavior changes; do not weaken or delete existing assertions to get green.
- Tests use `config.test_settings` with in-memory SQLite. PostgreSQL-only concurrency tests are skipped there; SQLite success does not prove PostgreSQL concurrency, constraints, or locking.
- Management commands are limited to `make_admin`, `notify_expiring_entitlements`, and `run_telegram_bot`; extend deliberately, with tests and operator documentation.
- Do not use root `backend/test_settings.py` as the canonical test module; use `config.test_settings`.

### Frontend

- TypeScript is `strict`; keep explicit types at API boundaries. No `any` shortcuts or suppression comments just to pass.
- Use `frontend/lib/api.ts` for authenticated calls; do not scatter raw `fetch` auth logic, duplicate refresh logic, or expose internal backend URLs to the browser.
- Preserve Django trailing slashes and the same-origin `/api` proxy. API responses are `no-store`; do not cache private data.
- Respect the existing Persian/RTL design system, CSS variables, component classes, and mobile-first layout. Avoid unrelated visual redesigns.
- Prefer existing components and dependencies; do not add packages for small UI or utility tasks.
- Resolve server role through `GET /api/auth/me/`, never a client-stored role.
- Keep demo data behind `NEXT_PUBLIC_DEMO_MODE`; production must not fall back to demo stores or fake revenue.

### Storage and cache

- Default media storage is filesystem. S3 mode is selected only by `DEFAULT_FILE_STORAGE_BACKEND`; `AWS_STORAGE_BUCKET_NAME`, `AWS_ACCESS_KEY_ID`, and `AWS_SECRET_ACCESS_KEY` are all required or startup fails closed.
- S3 options live under Django’s `OPTIONS` mapping with lowercase django-storages keywords. Do not move them back to top-level keys.
- Redis is cache-only. With `DEBUG=false`, `CACHE_REQUIRE_REDIS` defaults true; a `LocMemCache` fallback must not be reported as external Redis connectivity.
- Distinguish configuration verification (Level A), real storage integration (Level B), and media delivery (Level C). Only claim what was actually executed.

## 7. Commands

Run from the stated directory. Commands that mutate state are marked.

### Frontend (`frontend/`)

| Command | Purpose | Mutates |
|---|---|---|
| `npm ci` | Install exact lockfile dependencies | `node_modules` |
| `npm run dev` | Next.js dev server | build cache |
| `npx tsc --noEmit` | TypeScript strict check (no npm `typecheck` script exists) | incremental build info |
| `npm run lint` | ESLint flat config | none |
| `npm run build` | Production build + Next type check | `.next` |
| `npm start` | Serve production build | none |

Requires `API_INTERNAL_URL` for the server-side proxy in non-local setups; local default is `http://localhost:8000`.

### Backend (`backend/`)

| Command | Purpose | Mutates |
|---|---|---|
| `python3 -m venv .venv && . .venv/bin/activate` | Create local environment | `.venv` |
| `pip install -r requirements.lock.txt` | Install validated dependencies | environment |
| `python manage.py runserver` | Local API server | none (DB reads/writes by app) |
| `python manage.py check --settings=config.test_settings` | Django checks | none |
| `python manage.py test --settings=config.test_settings` | Full SQLite suite | test DB only |
| `python manage.py makemigrations --check --dry-run --settings=config.test_settings` | Migration drift check | none |
| `python manage.py showmigrations` | Migration status | none |
| `python manage.py migrate --noinput` | Apply migrations | **database schema/data** |
| `python manage.py collectstatic --noinput` | Collect static files | `backend/staticfiles` |
| `python manage.py make_admin --phone +989xxxxxxxxx` | Promote existing user | **user role + audit** |
| `python manage.py notify_expiring_entitlements` | Create 5-day notifications | **notifications** |
| `python manage.py run_telegram_bot` | Start polling bot | external Telegram connection |

`config.test_settings` supplies test secrets and SQLite. Default `config.settings` requires `DJANGO_SECRET_KEY` and `OTPY_API_KEY` when `DJANGO_DEBUG=false`, and connects to PostgreSQL. `config.concurrency_settings` requires an isolated PostgreSQL instance (`PGTEST_*`); never point it at Staging or production.

There is **no CI/CD configuration** in the repository (no GitHub Actions, GitLab CI, or Jenkins file). All checks are local/manual; do not describe a build or test as CI-verified.

### Docker / operations (repository root)

| Command | Purpose | Mutates |
|---|---|---|
| `docker compose up --build` | Local base stack | containers/volumes |
| `docker compose -f docker-compose.dev.yml up --build` | Hot-reload dev stack | containers/volumes |
| `docker compose -f docker-compose.prod.yml config --quiet` | Validate prod Compose | none |
| `docker compose -f docker-compose.prod.yml up -d` | Start prod-like stack | **containers/TLS state** |
| `docker compose logs -f backend` (also `frontend`, `caddy`) | Logs | none |
| `docker compose exec backend python manage.py migrate --noinput` | Local Compose migration | **local DB only** |
| `docker compose exec db pg_isready -U jam -d jam` | PostgreSQL readiness | none |
| `docker compose exec redis redis-cli ping` | Redis readiness | none |
| `curl -sS http://localhost:8000/api/health/ready/` | Backend readiness | none |

Do not use the Compose migration command against Staging. Render Free has no verified shell/one-off execution path.

### Current verified baseline (2026-11-10)

- Backend: **236 tests, OK (skipped=17)**; all skips are PostgreSQL-only concurrency tests.
- Django checks/migration drift: clean; no migrations created.
- Frontend: `npx tsc --noEmit` exit 0; `npm run lint` exit 0 with **11 pre-existing warnings**; production `npm run build` was not re-run in this governance batch.
- Compose base and prod config validation: exit 0.
- Docker image build/start and external Staging services were not verified.

## 8. Environments and deployment boundaries

### Local

- Docker Compose provides PostgreSQL, Redis, backend, frontend.
- Without Docker, PostgreSQL must be available; Redis is optional only for local cache fallback. Tests use SQLite and LocMem.
- Media defaults to filesystem under `backend/media`; use S3 only with explicit credentials.
- Demo mode is local/dev-only and must be `false` for production builds.

### Staging

Intended: Render Free frontend + backend, Neon PostgreSQL, Upstash Redis, S3-compatible media.

- Staging is prepared in documentation, not provisioned or verified.
- **Render Free has no shell/SSH and no one-off jobs.** Migrations, `make_admin`, and manual bot start have no verified Free execution path. This is an owner-authorized Batch 2 blocker; do not add automatic migrations at startup as a workaround.
- Static files are collected at image build; redeploy to update them.
- Telegram bot must remain disabled. ZarinPal must remain unconfigured until explicitly authorized. No OTP bypass.
- Free-tier cold starts, ephemeral filesystem, storage limits, and Redis eviction are real limitations; do not treat a successful Staging boot as production readiness.

### Production-like Compose

`docker-compose.prod.yml` includes Caddy/TLS, private backend/frontend exposure, persistent PostgreSQL/Redis/media volumes, and healthchecks. It has **not** been built or deployed here (Docker daemon unavailable). Older readiness reports that say the backend runs migrations on startup or runs as root are stale; the current Dockerfile does neither.

## 9. Protected actions requiring explicit owner approval

Stop and ask before:

- committing, pushing, tagging, releasing, deploying, or provisioning infrastructure;
- creating/using external services, credentials, or real provider accounts;
- real payment, refund, OTP, Telegram, or S3 write/delete operations;
- production database changes, destructive database operations, data deletion, or bulk modification;
- changing prices, plans, durations, entitlements, cancellation/refund policy, or other owner business rules;
- changing authentication, OTP, JWT storage, admin authorization, or security posture;
- introducing a new architecture, service, dependency, queue/scheduler, or major refactor;
- adding plan-feature enforcement that does not exist today;
- modifying canonical documentation to match an unapproved assumption.

A general feature request does not authorize unrelated operational actions.

## 10. Known discrepancies — report, do not silently fix

1. **Public access is entitlement-only.** `entitlements.menu_access()`, `PublicMenuView`, `QrCodeView`, and `commerce.services.public_store_directory()` all require a current MENU entitlement. CLUB-only access never publishes a menu, and expired or revoked entitlements deny public access.
2. **Plan feature matrix is not fully enforced.** Only menu/club access and Basic’s 80-product limit are enforced. Online-order/analytics/customization differences are catalog copy/owner intent, not runtime gates.
3. **README is stale.** It describes Phase 1, carts/orders as out of scope, mocked OTP with `dev_otp`, and `npm run typecheck` (no such script). Do not use it as current behavior.
4. **Single/manual subscription docs are historical.** `docs/SINGLE_SUBSCRIPTION_MODEL.md` and `docs/MANUAL_SUBSCRIPTION_WORKFLOW.md` describe the retired manual single-plan flow. `docs/SUBSCRIPTION_ARCHITECTURE.md` is the current subscription contract; legacy flows are removed.
5. **Older deployment docs are stale.** `docs/PRODUCTION_DEPLOYMENT_READINESS.md` says the backend Dockerfile runs migrations and runs as root; current `backend/Dockerfile` does neither. Trust the Dockerfile and Staging docs dated 2026-11-10.
6. **`.env.example` has a stale comment** saying “All subscription payments are manual.” Active subscriptions use online Zarinpal; the manual path is retired.
7. **Staging preparation says “No public user registration system exists.”** A public phone signup endpoint/flow exists. Do not repeat that claim; verify current code.
8. **Not production ready.** Do not claim otherwise: live provider verification, TLS/runtime validation, order-bound payment, scheduler wiring, and several owner decisions remain open.

## 11. Canonical documentation index

Use exact paths; do not invent documents.

Current for their areas:

- `docs/SUBSCRIPTION_ARCHITECTURE.md` — active five-product model, prices, entitlements, purchase/payment flow.
- `docs/LEGACY_COMPATIBILITY.md` — legacy preservation and open legacy decisions.
- `docs/ADMIN_RBAC.md` — admin role, provisioning, endpoints, audit.
- `docs/ZARINPAL_PAYMENT_INTEGRATION.md` — provider config, lifecycle, live-test limitations.
- `docs/SUBSCRIPTION_NOTIFICATIONS.md` — five-day notifications and scheduling requirement.
- `docs/AUTHENTICATION_SECURITY_AUDIT.md` — OTP/JWT/authorization behavior and residual risks.
- `docs/PAYMENT_AND_FINANCIAL_INTEGRITY_AUDIT.md` — payment/order/commission/settlement audit; note it predates the multi-product activation change.
- `docs/DEMO_AND_ENVIRONMENT_ISOLATION_AUDIT.md` — demo/production data isolation.
- `docs/JAM_MASTER_IMPLEMENTATION_REPORT.md` — multi-product/admin/payment implementation summary and remaining work.
- `docs/deployment/STAGING_PREPARATION.md` — Staging target architecture and blockers.
- `docs/deployment/STAGING_OPERATIONS.md` — verified migration constraints, static/admin operations, Redis/S3 checks.

Historical/superseded (read with caution): `README.md`, `docs/SINGLE_SUBSCRIPTION_MODEL.md`, `docs/MANUAL_SUBSCRIPTION_WORKFLOW.md`, `docs/PRODUCTION_READINESS_*.md`, `docs/PRODUCTION_DEPLOYMENT_READINESS.md`, and older phase/audit reports.

API contract source: `backend/config/urls.py` and each app’s `urls.py`. There is no current comprehensive API reference document.

No central decisions log exists. Owner decisions are embedded in the subscription architecture, migration seed, RBAC docs, and this file; ask the owner when a decision is not explicit.

## 12. Definition of done

Before reporting completion:

1. Read the relevant code, tests, docs, and current diff.
2. Keep changes within the authorized scope; preserve unrelated owner changes.
3. Add focused regression tests for behavior changes.
4. Run the smallest relevant check, then the appropriate broader suite.
5. Report exact files changed, commands run, and results.
6. Report skipped tests and reasons, deferred verification, and residual risks.
7. Never claim external connectivity, payment, storage, or deployment success without actual execution.
8. Stop before any protected action in §9.
