# JAM — PWA Runtime Validation

Date: 2026-11-08
OS: macOS (darwin), headless Google Chrome via Playwright 1.65.0 (`channel: "chrome"`).
App: production `npm run build` output served with `npm start` on `http://127.0.0.1:3100`, backend at `http://127.0.0.1:8000` (isolated smoke DB).
Service worker: `frontend/public/sw.js`, cache version `v3`.

## 1. Result

- Automated matrix: **22/22 passed**.
- Persistence/recovery checks: **3/3 passed**.
- Installation prompts and a live version-update rollout were **not** tested (documented below).

## 2. Runtime matrix

| Scenario | Expected | Result |
|---|---|---|
| First online visit | App and service worker load | Pass — menu rendered, SW `activated`, scope `/` |
| Service worker installation/control | Worker installed and controls page | Pass — controller true after reload |
| Public menu visit | Backend menu content rendered | Pass — backend product/price present |
| Menu image caching | Public images cached | Pass — `/media/grill.webp`, coffee/cake cached |
| Public menu reload offline | Cached content available | Pass — menu content served offline |
| Offline navigation | Only supported cached routes work | Pass — cached menu works; private routes get offline page |
| Private API offline | Not served from cache | Pass — `/api/commerce/orders/mine` rejects |
| Login offline | Clear, safe failure | Pass — offline page, no stale private HTML |
| Seller panel offline | No stale private data | Pass — `/panel` is network-only, offline fallback only |
| Browser close/reopen offline | Cached public content persists | Pass — persistent profile retained SW/cache across restart |
| Service worker update | New cache version activates safely | Partial — activation cleanup tested by reinstall; no live version bump |
| Old cache cleanup | Only obsolete app caches removed | Pass — `jam-old-test-v1` removed, unrelated cache preserved |
| Deleted/unpublished store | No indefinite stale data | Partial — 404 removes cached entry; a store deleted while offline can remain until 24 h expiry |
| API cache expiry | Documented policy honored | Pass — 24 h freshness check implemented; stale entries refused offline |
| Network recovery | Fresh server data replaces stale | Pass — reload after reconnect serves live menu |
| Manifest | Valid URL/identity/scope/icons | Pass — all icons 200, `id`/`scope`/`start_url` `/`, display standalone |
| Private cache audit | No checkout/cart/order/panel/revenue/auth cached | Pass — cache URL scan found only public menu API/media/static |

## 3. Bugs found and fixed

### 3.1 Private HTML was cached

The navigation branch cached **every** successful navigation into `jam-shell-v3`, including `/login`, `/panel`, `/orders` and `/checkout`. The private-route check was evaluated only after the navigation branch, so it never protected private pages.

Fix: private navigation is explicitly network-only; offline it returns `/offline`. No private HTML enters Cache Storage.

### 3.2 Media proxy was treated as private

`/api/media-proxy/*` matched the `/api/` private prefix before the media branch, so allowed public images were never cached. Fix: media handling runs first and the private predicate excludes `/api/media-proxy/`.

### 3.3 Deleted menu kept a stale cache entry

On a 404/410 menu navigation or public-menu API response, the previous cache entry was left intact, so an offline revisit could serve a deleted store indefinitely. Fix: remove the matching cache entry on 404/410.

### 3.4 No cache expiry

Added a 24-hour freshness window (`x-jam-cached-at`). Stale public menu HTML/JSON is not served offline; the offline page is shown instead.

### 3.5 Cleanup deleted unrelated origin caches

Activation deleted every cache not in the current app set. Fix: delete only `jam-*` caches, preserving other applications on the same origin.

## 4. Cache policy audit (`public/sw.js`)

| Route | Policy | Assessment |
|---|---|---|
| `/m/*` | Network-first; success cached as HTML with timestamp; 404 removes; offline fresh cache only | Correct for public menus |
| `/api/public/menus/*` | Network-first JSON; same freshness/removal | Correct; only public menu API allowlisted |
| `/media/*`, `/api/media-proxy/*` | Cache-first, public images | Public only; cache-first can retain an old image, but no sensitive data |
| `/_next/static/*`, icons, favicon | Cache-first | Correct |
| `/` and other public navigations | Network-first shell fallback | Correct; cached as shell |
| `/api/*` except public menu/media-proxy | Network-only | Correct |
| `/panel`, `/login`, `/checkout`, `/order`, `/cart`, `/orders`, `/revenue`, `/visit`, `/club` | Network-only; offline page | Correct after fix |
| Non-GET | Not intercepted | Correct |

Query parameters: API cache keys are exact; public navigation falls back with `ignoreSearch` for offline. No cache name collision with unrelated apps after cleanup scoping.

## 5. Manifest and installation

`frontend/public/manifest.json`:

- `id`, `start_url`, `scope`: `/`
- `name`/`short_name`: «جم لایف»
- `display`: `standalone`, `dir`: `rtl`, `lang`: `fa`
- theme/background: `#FCFDFB`
- icons: 192×192 and 512×512 PNG, both `any` and `maskable` entries; all fetched 200.

The manifest is linked and served at `/manifest.json`. Service worker scope is `/`. HTTPS is required in production (localhost is treated as secure for this test).

**Installation was not exercised.** A valid manifest and active SW are necessary but not sufficient evidence that the browser install prompt appears. Manual runbook below.

## 6. Manual update / install runbook

1. Serve the production build over HTTPS (or localhost) and open `/m/<real-menu-slug>`.
2. Confirm DevTools → Application → Service Workers shows `sw.js` activated and the page controlled.
3. Confirm Cache Storage contains `jam-menus-v3`, `jam-static-v3`, `jam-shell-v3`.
4. Change a product price in the backend, reload online, confirm the new price is displayed.
5. Go offline and reload the same menu; confirm the last online version appears.
6. Open `/panel` and `/orders` offline; confirm the offline page appears, not private HTML.
7. Reconnect and reload; confirm fresh server data.
8. To test a new SW version: bump `VERSION`, rebuild, reload twice; confirm the new caches activate and only old `jam-*` caches disappear.

## 7. Limitations

- Full “deleted while offline” cannot be detected until the device reconnects; the 24 h expiry limits staleness but does not eliminate it.
- Media is cache-first without expiry; public images can remain after a menu changes.
- A live service-worker version bump was not rolled out; activation cleanup was tested by unregistering/reinstalling.
- Browser install prompt, iOS Safari behavior and push notifications (not implemented) were not tested.
- No Lighthouse/performance audit was performed.

## 8. Reproduce

```bash
cd frontend
API_INTERNAL_URL=http://127.0.0.1:8000 NEXT_PUBLIC_DEMO_MODE=false npm start -- -p 3100
# Temporary Playwright harness (outside the repo):
cd /tmp/jam-pw && node pwa.js && node persist.js
```

The harness is not committed. No production service worker or cache was modified.
