/* =========================================================
   جم لایف — سرویس‌ورکر (PWA)
   راهبرد:
   - منوی عمومی (/m/*): network-first؛ HTML پاسخ‌داده‌شده شامل
     دادهٔ واقعی API است و در کش «jam-menus» ذخیره می‌شود.
   - API عمومی منو (/api/public/menus/*): network-first با کش
     JSON؛ فقط همین API عمومی کش می‌شود.
   - دارایی‌های ثابت (/_next/static) و تصاویر (/media/*،
     /api/media-proxy/*): cache-first تا منو آفلاین بماند.
   - سایر مسیرهای عمومی: network-first با fallback به کش و سپس
     صفحهٔ /offline.
   - هرگز کش نمی‌شوند: احراز هویت، پنل، سبد، سفارش، پرداخت،
     درآمد، تسویه و هر API خصوصی.
   - تغییر نسخهٔ کش: در فعال‌سازی، کش‌های قدیمی حذف می‌شوند.
   ========================================================= */

const VERSION = "v3";
const MENUS_CACHE = `jam-menus-${VERSION}`;
const STATIC_CACHE = `jam-static-${VERSION}`;
const SHELL_CACHE = `jam-shell-${VERSION}`;
const OFFLINE_URL = "/offline";
const MENU_MAX_AGE_MS = 24 * 60 * 60 * 1000;

const SHELL_ASSETS = [OFFLINE_URL, "/manifest.json", "/icon-192.png", "/icon-512.png", "/favicon.svg"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(SHELL_CACHE)
      .then((cache) => cache.addAll(SHELL_ASSETS))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((k) => k.startsWith("jam-") && ![MENUS_CACHE, STATIC_CACHE, SHELL_CACHE].includes(k))
            .map((k) => caches.delete(k)),
        ),
      )
      .then(() => self.clients.claim()),
  );
});

function withCachedAt(response) {
  const headers = new Headers(response.headers);
  headers.set("x-jam-cached-at", String(Date.now()));
  return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
}

async function putWithTimestamp(cache, request, response) {
  const url = typeof request === "string" ? new URL(request, self.location.origin).href : request.url;
  await cache.put(url, withCachedAt(response.clone()));
}

function cacheIsFresh(response) {
  if (!response) return false;
  const at = Number(response.headers.get("x-jam-cached-at") || 0);
  return at > 0 && Date.now() - at <= MENU_MAX_AGE_MS;
}

async function dropCached(cacheName, request) {
  try {
    const cache = await caches.open(cacheName);
    await cache.delete(request);
  } catch {
    /* best effort */
  }
}

const isStaticAsset = (url) =>
  url.pathname.startsWith("/_next/static/") || url.pathname === "/favicon.svg" || url.pathname.startsWith("/icon-");
const isMedia = (url) => url.pathname.startsWith("/media/") || url.pathname.startsWith("/api/media-proxy/");
const isMenuPage = (url) => url.pathname.startsWith("/m/");
/* فقط منوی عمومی؛ هیچ API خصوصی مجاز به کش نیست */
const isPublicMenuApi = (url) => url.pathname.startsWith("/api/public/menus/");
const isPrivate = (url) =>
  (url.pathname.startsWith("/api/") && !url.pathname.startsWith("/api/media-proxy/")) ||
  url.pathname.startsWith("/panel") ||
  url.pathname.startsWith("/login") ||
  url.pathname.startsWith("/checkout") ||
  url.pathname.startsWith("/order") ||
  url.pathname.startsWith("/cart") ||
  url.pathname.startsWith("/orders") ||
  url.pathname.startsWith("/revenue") ||
  url.pathname.startsWith("/visit") ||
  url.pathname.startsWith("/club");

self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  /* دادهٔ عمومی منو: network-first + کش JSON */
  if (isPublicMenuApi(url)) {
    event.respondWith(
      fetch(request)
        .then(async (res) => {
          if (res.ok) {
            try {
              const cache = await caches.open(MENUS_CACHE);
              await putWithTimestamp(cache, request, res.clone());
            } catch {
              /* خطای کش نباید پاسخ را خراب کند */
            }
          } else if (res.status === 404 || res.status === 410) {
            await dropCached(MENUS_CACHE, request);
          }
          return res;
        })
        .catch(async () => {
          const cache = await caches.open(MENUS_CACHE);
          const hit = await cache.match(request);
          if (cacheIsFresh(hit)) return hit;
          return new Response(JSON.stringify({ detail: "Offline and no fresh cached menu data." }), {
            status: 503,
            headers: { "Content-Type": "application/json; charset=utf-8" },
          });
        }),
    );
    return;
  }

  /* دارایی‌های تصویری عمومی پیش از قاعدهٔ خصوصی بررسی می‌شوند */
  if (isMedia(url)) {
    event.respondWith(
      caches.open(MENUS_CACHE).then(async (cache) => {
        const hit = await cache.match(request);
        const network = fetch(request)
          .then((res) => {
            if (res.ok) cache.put(request.url, res.clone());
            return res;
          })
          .catch(() => hit || new Response("", { status: 503, statusText: "Offline" }));
        return hit || network;
      }),
    );
    return;
  }

  /* درخواست‌های خصوصی/تراکنشی: هیچ‌گاه کش نمی‌شوند. صفحات خصوصی
     آفلاین به صفحهٔ offline می‌رسند، نه به HTML قدیمی. */
  if (isPrivate(url)) {
    if (request.mode === "navigate") {
      event.respondWith(
        fetch(request).catch(
          async () =>
            (await caches.match(OFFLINE_URL)) ||
            new Response("آفلاین", { status: 503, headers: { "Content-Type": "text/plain; charset=utf-8" } }),
        ),
      );
    }
    return;
  }

  if (isStaticAsset(url)) {
    event.respondWith(
      caches.match(request).then(
        (hit) =>
          hit ||
          fetch(request).then((res) => {
            if (res.ok) caches.open(STATIC_CACHE).then((c) => c.put(request, res.clone()));
            return res;
          }),
      ),
    );
    return;
  }

  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request)
        .then(async (res) => {
          if (res.ok) {
            const cacheName = isMenuPage(url) ? MENUS_CACHE : SHELL_CACHE;
            try {
              const cache = await caches.open(cacheName);
              await putWithTimestamp(cache, request, res);
              if (isMenuPage(url)) {
                self.clients.matchAll().then((clients) =>
                  clients.forEach((client) => client.postMessage({ type: "JAM_MENU_CACHED", url: url.pathname })),
                );
              }
            } catch {
              /* خطای کش نباید پاسخ صفحه را خراب کند */
            }
          } else if (isMenuPage(url) && (res.status === 404 || res.status === 410)) {
            await dropCached(MENUS_CACHE, request);
          }
          return res;
        })
        .catch(async () => {
          const cache = await caches.open(isMenuPage(url) ? MENUS_CACHE : SHELL_CACHE);
          const hit = await cache.match(request) || (await cache.match(request, { ignoreSearch: true }));
          if (isMenuPage(url) && !cacheIsFresh(hit)) {
            return (await caches.match(OFFLINE_URL)) || new Response("آفلاین", { status: 503 });
          }
          return (
            hit ||
            (await caches.match(OFFLINE_URL)) ||
            new Response("آفلاین", { status: 503, headers: { "Content-Type": "text/plain; charset=utf-8" } })
          );
        }),
    );
  }
});

self.addEventListener("unhandledrejection", (event) => {
  self.clients.matchAll().then((clients) => clients.forEach((c) => c.postMessage({ type: "JAM_SW_ERROR", error: String(event.reason) })));
});

self.addEventListener("message", (event) => {
  const msg = event.data || {};
  if (msg.type === "JAM_REFRESH_MENU" && typeof msg.url === "string") {
    event.waitUntil(
      (async () => {
        try {
          const res = await fetch(msg.url, { cache: "no-store" });
          if (res.ok) {
            const cache = await caches.open(MENUS_CACHE);
            await putWithTimestamp(cache, msg.url, res.clone());
            const clients = await self.clients.matchAll();
            clients.forEach((client) => client.postMessage({ type: "JAM_MENU_CACHED", url: msg.url }));
          }
        } catch {
          /* همچنان آفلاین */
        }
      })(),
    );
  }
  if (msg.type === "JAM_SKIP_WAITING") self.skipWaiting();
});
