"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Ic from "@/components/icons";
import { ApiError, apiFetch } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import ArenaField from "./ArenaField";
import BaseField from "./BaseField";
import SiegeField from "./SiegeField";
import "./jamplay.css";
import type {
  ArenaSnapshot,
  ArmyItem,
  BattleActionResponse,
  BattleHistoryItem,
  BattlePayload,
  BuildingItem,
  BuildingsPayload,
  Catalog,
  ChestSlot,
  DeckCard,
  FinishResponse,
  Profile,
  RewardSummary,
  SiegeSnapshot,
} from "./types";

const fa = (value: number | string) => Number(value || 0).toLocaleString("fa-IR");
const faDigits = (value: string | number) =>
  String(value).replace(/\d/g, (digit) => "۰۱۲۳۴۵۶۷۸۹"[Number(digit)]);

function clock(seconds: number): string {
  const safe = Math.max(0, Math.ceil(seconds));
  return `${faDigits(Math.floor(safe / 60))}:${faDigits(String(safe % 60).padStart(2, "0"))}`;
}

function clockFromDate(value: string | null, offset = 0): string {
  if (!value) return "—";
  const remaining = (new Date(value).getTime() - Date.now()) / 1000 - offset;
  return clock(remaining);
}

type Screen = "lobby" | "collection" | "deck" | "chests" | "base";

const NAV: { key: Screen; label: string; icon: string }[] = [
  { key: "lobby", label: "آوردگاه", icon: "castle" },
  { key: "collection", label: "کارت‌ها", icon: "layers" },
  { key: "deck", label: "دسته", icon: "grid" },
  { key: "chests", label: "صندوق‌ها", icon: "pkg" },
  { key: "base", label: "پایگاه", icon: "home" },
];

const UNIT_ART: Record<string, string> = {
  guard: "guard",
  sentinel: "guard",
  archer: "archer",
  volley: "archer",
  golem: "golem",
  mage: "mage",
  spark: "mage",
  meteor: "meteor",
  ballista: "ballista",
  scouts: "scouts",
  frost: "frost",
  heal: "frost",
};

function unitArt(key: string): string {
  return `/jamplay/unit-${UNIT_ART[key] || key}.webp`;
}

function chestArt(kind: string): string {
  return kind === "gold" ? "/jamplay/art-chest.webp" : "/jamplay/art-chest.webp";
}

function mergeProfile(base: Profile, patch: Partial<Profile>): Profile {
  return { ...base, ...patch };
}

export default function PlayPage() {
  const { ready, user } = useAuth();

  const [screen, setScreen] = useState<Screen>("lobby");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [catalog, setCatalog] = useState<Catalog | null>(null);
  const [chests, setChests] = useState<ChestSlot[]>([]);
  const [buildings, setBuildings] = useState<BuildingsPayload | null>(null);
  const [history, setHistory] = useState<BattleHistoryItem[]>([]);

  const [battle, setBattle] = useState<BattlePayload | null>(null);
  const [selected, setSelected] = useState<number | null>(null);
  const [result, setResult] = useState<RewardSummary | null>(null);
  const [hint, setHint] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const [toast, setToast] = useState<{ message: string; kind: "ok" | "warn" } | null>(null);

  const [showArenaPrep, setShowArenaPrep] = useState(false);
  const [showSiegePrep, setShowSiegePrep] = useState(false);
  const [chestOpen, setChestOpen] = useState<number | null>(null);
  const [buildingOpen, setBuildingOpen] = useState<string | null>(null);
  const [cardOpen, setCardOpen] = useState<string | null>(null);
  const [deckDraft, setDeckDraft] = useState<string[]>([]);
  const [deckSlot, setDeckSlot] = useState(0);
  const [, setTick] = useState(0);

  const battleRef = useRef<BattlePayload | null>(null);
  const syncRef = useRef({ t: 0, at: 0 });
  const settledRef = useRef(false);
  const toastTimer = useRef<number | null>(null);

  useEffect(() => {
    battleRef.current = battle;
  }, [battle]);

  useEffect(() => {
    const timer = window.setInterval(() => setTick((value) => value + 1), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const showToast = useCallback((message: string, kind: "ok" | "warn" = "ok") => {
    setToast({ message, kind });
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 2800);
  }, []);

  const describeError = useCallback((cause: unknown) => {
    if (cause instanceof ApiError) return cause.message;
    return "درخواست به سرور ناموفق بود.";
  }, []);

  const loadCore = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [profileData, chestData, buildingData, historyData, catalogData] = await Promise.all([
        apiFetch<Profile>("/games/profile/"),
        apiFetch<{ slots: ChestSlot[] }>("/games/chests/"),
        apiFetch<BuildingsPayload>("/games/buildings/"),
        apiFetch<{ battles: BattleHistoryItem[] }>("/games/battles/"),
        apiFetch<Catalog>("/games/catalog/"),
      ]);
      setProfile(profileData);
      setChests(chestData.slots);
      setBuildings(buildingData);
      setHistory(historyData.battles);
      setCatalog(catalogData);
      setDeckDraft(profileData.deck.map((card) => card.key));
    } catch (cause) {
      setError(describeError(cause));
    } finally {
      setLoading(false);
    }
  }, [describeError]);

  useEffect(() => {
    if (!ready) return;
    if (!user) {
      setLoading(false);
      return;
    }
    void loadCore();
  }, [ready, user, loadCore]);

  const refreshProfile = useCallback(async () => {
    try {
      const data = await apiFetch<Profile>("/games/profile/");
      setProfile(data);
      return data;
    } catch (cause) {
      showToast(describeError(cause), "warn");
      return null;
    }
  }, [describeError, showToast]);

  const refreshChests = useCallback(async () => {
    try {
      const data = await apiFetch<{ slots: ChestSlot[] }>("/games/chests/");
      setChests(data.slots);
    } catch {
      /* silent: transient refresh */
    }
  }, []);

  const refreshBuildings = useCallback(async () => {
    try {
      const data = await apiFetch<BuildingsPayload>("/games/buildings/");
      setBuildings(data);
    } catch (cause) {
      showToast(describeError(cause), "warn");
    }
  }, [describeError, showToast]);

  const refreshHistory = useCallback(async () => {
    try {
      const data = await apiFetch<{ battles: BattleHistoryItem[] }>("/games/battles/");
      setHistory(data.battles);
    } catch {
      /* silent */
    }
  }, []);

  const applyBattle = useCallback((next: BattlePayload) => {
    setBattle(next);
    syncRef.current = { t: next.snapshot.t, at: performance.now() };
  }, []);

  const currentElapsed = useCallback(() => {
    const current = battleRef.current;
    if (!current) return 0;
    const pending = (performance.now() - syncRef.current.at) / 1000;
    return Math.min(current.snapshot.limit, syncRef.current.t + pending);
  }, []);

  const settle = useCallback(async () => {
    const current = battleRef.current;
    if (!current) return;
    setBusy("settle");
    try {
      const response = await apiFetch<FinishResponse>(`/games/${current.mode}/finish/`, {
        method: "POST",
        body: { battle_key: current.battle_key },
      });
      setResult(response.rewards);
      setBattle(response.battle);
      setChests(response.chests.slots);
      await refreshProfile();
      void refreshHistory();
    } catch (cause) {
      showToast(describeError(cause), "warn");
      settledRef.current = false;
    } finally {
      setBusy(null);
    }
  }, [describeError, refreshHistory, refreshProfile, showToast]);

  const syncBattle = useCallback(
    async (key: string, mode: "arena" | "siege") => {
      const current = battleRef.current;
      if (!current || current.battle_key !== key || current.snapshot.ended || settledRef.current) return;
      try {
        const response = await apiFetch<BattleActionResponse>(`/games/${mode}/action/`, {
          method: "POST",
          body: { battle_key: key, elapsed: currentElapsed() },
        });
        if (response.deploy_error) setHint(response.deploy_error.detail);
        applyBattle(response.battle);
      } catch (cause) {
        showToast(describeError(cause), "warn");
      }
    },
    [applyBattle, currentElapsed, describeError, showToast],
  );

  useEffect(() => {
    if (!battle) return;
    if (battle.snapshot.ended) {
      if (!settledRef.current) {
        settledRef.current = true;
        void settle();
      }
      return;
    }
    const key = battle.battle_key;
    const mode = battle.mode;
    const interval = window.setInterval(() => {
      void syncBattle(key, mode);
    }, 900);
    return () => window.clearInterval(interval);
  }, [battle?.battle_key, battle?.snapshot.ended, battle?.mode, settle, syncBattle, battle]);

  const startBattle = useCallback(
    async (mode: "arena" | "siege") => {
      setBusy(`start-${mode}`);
      setResult(null);
      setSelected(null);
      settledRef.current = false;
      try {
        const response = await apiFetch<{ battle: BattlePayload }>(`/games/${mode}/start/`, {
          method: "POST",
          body: {},
        });
        applyBattle(response.battle);
        setHint(
          mode === "arena"
            ? "کارت را انتخاب کن، بعد نیمهٔ پایین میدان را لمس کن."
            : "نیرو را انتخاب کن و حاشیهٔ بیرون دیوار را لمس کن.",
        );
        setShowSiegePrep(false);
        setShowArenaPrep(false);
      } catch (cause) {
        showToast(describeError(cause), "warn");
      } finally {
        setBusy(null);
      }
    },
    [applyBattle, describeError, showToast],
  );

  const deploy = useCallback(
    async (x: number, y: number) => {
      const current = battleRef.current;
      if (!current || selected === null) {
        showToast("اول یک کارت را انتخاب کن.", "warn");
        return;
      }
      const mode = current.mode;
      setBusy("deploy");
      try {
        const body =
          mode === "arena"
            ? { battle_key: current.battle_key, elapsed: currentElapsed(), index: selected, x, y }
            : { battle_key: current.battle_key, elapsed: currentElapsed(), index: selected, gx: x, gy: y };
        const response = await apiFetch<BattleActionResponse>(`/games/${mode}/action/`, {
          method: "POST",
          body,
        });
        if (response.deploy_error) {
          showToast(response.deploy_error.detail, "warn");
          return;
        }
        setSelected(null);
        setHint("");
        applyBattle(response.battle);
      } catch (cause) {
        showToast(describeError(cause), "warn");
      } finally {
        setBusy(null);
      }
    },
    [applyBattle, currentElapsed, describeError, selected, showToast],
  );

  const closeBattle = useCallback(async () => {
    const current = battleRef.current;
    if (current && current.status === "active" && !settledRef.current) {
      settledRef.current = true;
      try {
        await apiFetch<FinishResponse>(`/games/${current.mode}/finish/`, {
          method: "POST",
          body: { battle_key: current.battle_key },
        });
        await refreshProfile();
        void refreshChests();
        void refreshHistory();
      } catch {
        /* leaving anyway */
      }
    }
    setBattle(null);
    setResult(null);
    setSelected(null);
    setHint("");
    settledRef.current = false;
    void refreshBuildings();
  }, [refreshBuildings, refreshChests, refreshHistory, refreshProfile]);

  const saveDeck = useCallback(async () => {
    setBusy("deck");
    try {
      const response = await apiFetch<{ deck: DeckCard[] }>("/games/deck/", {
        method: "POST",
        body: { cards: deckDraft },
      });
      setProfile((current) => (current ? mergeProfile(current, { deck: response.deck }) : current));
      showToast("دسته ذخیره شد.", "ok");
    } catch (cause) {
      showToast(describeError(cause), "warn");
    } finally {
      setBusy(null);
    }
  }, [deckDraft, describeError, showToast]);

  const upgradeCard = useCallback(
    async (cardKey: string) => {
      setBusy(`card-${cardKey}`);
      try {
        await apiFetch(`/games/cards/upgrade/`, { method: "POST", body: { card_key: cardKey } });
        await refreshProfile();
        showToast("کارت ارتقا یافت.", "ok");
      } catch (cause) {
        showToast(describeError(cause), "warn");
      } finally {
        setBusy(null);
      }
    },
    [describeError, refreshProfile, showToast],
  );

  const upgradeBuilding = useCallback(
    async (buildingKey: string) => {
      setBusy(`building-${buildingKey}`);
      try {
        await apiFetch(`/games/buildings/upgrade/`, {
          method: "POST",
          body: { building_key: buildingKey },
        });
        await refreshBuildings();
        await refreshProfile();
        showToast("ارتقا شروع شد.", "ok");
      } catch (cause) {
        showToast(describeError(cause), "warn");
      } finally {
        setBusy(null);
      }
    },
    [describeError, refreshBuildings, refreshProfile, showToast],
  );

  const completeBuilding = useCallback(
    async (buildingKey: string) => {
      setBusy(`complete-${buildingKey}`);
      try {
        await apiFetch(`/games/buildings/complete/`, {
          method: "POST",
          body: { building_key: buildingKey },
        });
        await refreshBuildings();
        showToast("ارتقا کامل شد.", "ok");
      } catch (cause) {
        showToast(describeError(cause), "warn");
      } finally {
        setBusy(null);
      }
    },
    [describeError, refreshBuildings, showToast],
  );

  const startChest = useCallback(
    async (index: number) => {
      setBusy(`chest-start-${index}`);
      try {
        const response = await apiFetch<{ chests: { slots: ChestSlot[] } }>(
          `/games/chests/${index}/start/`,
          { method: "POST", body: {} },
        );
        setChests(response.chests.slots);
        showToast("باز کردن صندوق شروع شد.", "ok");
      } catch (cause) {
        showToast(describeError(cause), "warn");
      } finally {
        setBusy(null);
      }
    },
    [describeError, showToast],
  );

  const claimChest = useCallback(
    async (index: number) => {
      setBusy(`chest-claim-${index}`);
      try {
        const response = await apiFetch<{
          rewards: { coins: number; gems: number; cards: string[] };
          chests: { slots: ChestSlot[] };
          profile: Profile;
        }>(`/games/chests/${index}/claim/`, { method: "POST", body: {} });
        setChests(response.chests.slots);
        await refreshProfile();
        setChestOpen(null);
        showToast(
          `+${fa(response.rewards.coins)} سکه${response.rewards.gems ? ` و ${fa(response.rewards.gems)} الماس` : ""}`,
          "ok",
        );
      } catch (cause) {
        showToast(describeError(cause), "warn");
      } finally {
        setBusy(null);
      }
    },
    [describeError, refreshProfile, showToast],
  );

  const cardsByKey = useMemo(() => {
    const map = new Map<string, Profile["cards"][number]>();
    profile?.cards.forEach((card) => map.set(card.key, card));
    return map;
  }, [profile]);

  const arenaSnapshot: ArenaSnapshot | null =
    battle && battle.snapshot.mode === "arena" ? battle.snapshot : null;
  const siegeSnapshot: SiegeSnapshot | null =
    battle && battle.snapshot.mode === "siege" ? battle.snapshot : null;

  const army: ArmyItem[] = useMemo(() => {
    if (siegeSnapshot) return siegeSnapshot.army;
    if (!catalog || !profile) return [];
    const bonus = Math.max(0, Math.floor((profile.town_hall_level - 1) / 2));
    return catalog.army.map((item) => ({ k: item.key, count: item.count + bonus }));
  }, [catalog, profile, siegeSnapshot]);

  const openChest = chestOpen !== null ? chests.find((slot) => slot.index === chestOpen) ?? null : null;
  const openBuilding =
    buildingOpen && buildings ? buildings.buildings.find((item) => item.key === buildingOpen) ?? null : null;
  const openCard = cardOpen ? cardsByKey.get(cardOpen) ?? null : null;

  const builderBuilding = buildings?.builder.busy
    ? buildings.buildings.find((item) => item.key === buildings.builder.building_key) ?? null
    : null;

  if (!ready || loading) {
    return (
      <div className="jg" data-theme="light">
        <div className="wrap" style={{ paddingTop: 80 }}>
          <div className="card center">
            <Ic n="spark" c="lg" />
            <p>جم‌پلی در حال بارگذاری…</p>
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="jg" data-theme="light">
        <div className="wrap" style={{ paddingTop: 60 }}>
          <div className="card center">
            <h1 style={{ fontSize: "1.6rem" }}>جم‌پلی</h1>
            <p className="muted">برای بازی، دسته‌بندی کارت‌ها و نبردهای آنلاین وارد شو.</p>
            <Link href="/login" className="btn btn-primary" style={{ marginTop: 12 }}>
              ورود به جم لایف
            </Link>
          </div>
        </div>
      </div>
    );
  }

  if (error || !profile) {
    return (
      <div className="jg" data-theme="light">
        <div className="wrap" style={{ paddingTop: 60 }}>
          <div className="card center">
            <Ic n="alert" c="lg" />
            <p>{error || "پروفایل بازی پیدا نشد."}</p>
            <button className="btn btn-primary" onClick={() => void loadCore()}>
              تلاش دوباره
            </button>
          </div>
        </div>
      </div>
    );
  }

  const league = profile.league;

  return (
    <div className={`jg ${battle ? "in-battle" : ""}`} data-theme="light">
      <div id="app">
        <header className="hud">
          <div className="hud-me">
            <span className="avatar">
              <img src="/jamplay/art-hero.webp" alt="" />
              <i className="lvl">{fa(profile.level)}</i>
            </span>
            <span className="hud-name">
              <b>{profile.display_name}</b>
              <span className="xpbar">
                <i style={{ width: `${Math.min(100, (profile.xp_in_level / Math.max(1, profile.xp_need)) * 100)}%` }} />
              </span>
            </span>
          </div>
          <div className="hud-res">
            <span className="res">
              <img src="/jamplay/art-vault.webp" alt="" className="ico-img" />
              <span>{fa(profile.coins)}</span>
            </span>
            <span className="res">
              <img src="/jamplay/art-mine.webp" alt="" className="ico-img" />
              <span>{fa(profile.gems)}</span>
            </span>
            <span className="res">
              <img src="/jamplay/art-trophy.webp" alt="" className="ico-img" />
              <span>{fa(profile.trophies)}</span>
            </span>
          </div>
        </header>

        <main className="main">
          <div className="screen">
            <div className="wrap">
              {screen === "lobby" && (
                <Lobby
                  profile={profile}
                  history={history}
                  chests={chests}
                  busy={busy}
                  onOpenArena={() => setShowArenaPrep(true)}
                  onOpenSiege={() => setShowSiegePrep(true)}
                  leagues={catalog?.leagues || []}
                  onChest={(index) => {
                    setScreen("chests");
                    setChestOpen(index);
                  }}
                  onGoDeck={() => setScreen("deck")}
                  onGoCollection={() => setScreen("collection")}
                  onGoBase={() => setScreen("base")}
                />
              )}

              {screen === "collection" && (
                <CollectionScreen
                  profile={profile}
                  cardsByKey={cardsByKey}
                  onOpenCard={setCardOpen}
                />
              )}

              {screen === "deck" && (
                <DeckScreen
                  profile={profile}
                  draft={deckDraft}
                  slot={deckSlot}
                  busy={busy === "deck"}
                  onSlot={setDeckSlot}
                  onPick={(key) => {
                    const existing = deckDraft.indexOf(key);
                    const next = [...deckDraft];
                    if (existing >= 0 && existing !== deckSlot) {
                      showToast("این کارت در دسته هست.", "warn");
                      return;
                    }
                    next[deckSlot] = key;
                    setDeckDraft(next);
                    setDeckSlot((deckSlot + 1) % Math.max(1, next.length));
                  }}
                  onSave={() => void saveDeck()}
                  onReset={() => setDeckDraft(profile.deck.map((card) => card.key))}
                />
              )}

              {screen === "chests" && (
                <ChestsScreen
                  chests={chests}
                  busy={busy}
                  onOpen={setChestOpen}
                  onRefresh={() => void refreshChests()}
                />
              )}

              {screen === "base" && buildings && (
                <BaseScreen
                  buildings={buildings}
                  busy={busy}
                  builderName={builderBuilding?.name || ""}
                  onSelect={(key) => setBuildingOpen(key)}
                  onComplete={() => {
                    if (buildings.builder.building_key) void completeBuilding(buildings.builder.building_key);
                  }}
                  onRefresh={() => void refreshBuildings()}
                />
              )}
            </div>
          </div>
        </main>

        <nav className="nav" aria-label="بخش‌های جم‌پلی">
          <div className="nav-items">
            {NAV.map((item) => (
              <button
                key={item.key}
                className={`tab ${screen === item.key ? "on" : ""}`}
                onClick={() => setScreen(item.key)}
              >
                <span className="tab-ic">
                  <Ic n={item.icon} />
                </span>
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        </nav>
      </div>

      {battle && (
        <section className={`battle ${battle.mode === "arena" ? "is-arena" : "is-siege"}`}>
          <header className="b-top">
            <div className="b-foe">
              <span className="b-av" style={{ ["--c" as string]: league.color }}>
                {(siegeSnapshot || arenaSnapshot)?.opponent.name?.slice(0, 1) || "ح"}
              </span>
              <div>
                <b>{(siegeSnapshot || arenaSnapshot)?.opponent.name || "حریف"}</b>
                <small>
                  {(siegeSnapshot || arenaSnapshot)?.opponent.league_name || league.name} · کارت سطح{" "}
                  {fa((siegeSnapshot || arenaSnapshot)?.opponent.card_level || 1)}
                </small>
              </div>
            </div>
            <div className={`b-clock ${battle.snapshot.limit - battle.snapshot.t < 30 ? "urgent" : ""}`}>
              {clock(battle.snapshot.limit - battle.snapshot.t)}
            </div>
            <button className="b-icon" onClick={() => void closeBattle()} aria-label="خروج از نبرد">
              <Ic n="logout" />
            </button>
          </header>

          <div className="b-score">
            <span className="b-team foe">
              <i />
              <b>
                {battle.snapshot.mode === "arena"
                  ? `${fa(battle.snapshot.crowns.e)} تاج`
                  : `${fa(battle.snapshot.stars)} ستاره`}
              </b>
            </span>
            <span className="b-phase">
              {battle.snapshot.overtime
                ? "اضافه‌وقت · اکسیر دوبرابر"
                : battle.snapshot.mode === "arena"
                  ? `${fa(battle.snapshot.t)} از ${fa(battle.snapshot.limit)} ثانیه`
                  : `تخریب پایگاه حریف`}
            </span>
            <span className="b-team me">
              <b>
                {battle.snapshot.mode === "arena"
                  ? `${fa(battle.snapshot.crowns.p)} تاج`
                  : `${fa(battle.snapshot.destruction)}٪`}
              </b>
              <i />
            </span>
          </div>

          {arenaSnapshot && (
            <ArenaField
              snapshot={arenaSnapshot}
              selected={selected}
              onDeploy={(x, y) => void deploy(x, y)}
              onMessage={(message) => setHint(message)}
            />
          )}
          {siegeSnapshot && (
            <SiegeField
              snapshot={siegeSnapshot}
              selected={selected}
              onDeploy={(x, y) => void deploy(x, y)}
              onMessage={(message) => setHint(message)}
            />
          )}

          <footer className="b-tray">
            <div className="b-hint">{hint || (busy === "deploy" ? "در حال ارسال…" : "")}</div>
            {arenaSnapshot ? (
              <div className="b-hand">
                {arenaSnapshot.hand.map((key, index) => {
                  const card = cardsByKey.get(key);
                  const cost = card?.cost ?? 0;
                  const poor = cost > arenaSnapshot.elixir;
                  return (
                    <button
                      key={`${key}-${index}`}
                      className={`b-card ${selected === index ? "sel" : ""} ${poor ? "poor" : ""}`}
                      onClick={() => setSelected(selected === index ? null : index)}
                    >
                      <span className="cost">{fa(cost)}</span>
                      <img src={unitArt(key)} alt="" />
                      <b>{card?.name || key}</b>
                      <span className="lv">{fa(arenaSnapshot.hand_levels[index] || 1)}</span>
                    </button>
                  );
                })}
              </div>
            ) : (
              <div className="b-hand">
                {army.map((item, index) => {
                  const card = cardsByKey.get(item.k);
                  return (
                    <button
                      key={`${item.k}-${index}`}
                      className={`b-card ${selected === index ? "sel" : ""} ${item.count <= 0 ? "out" : ""}`}
                      disabled={item.count <= 0}
                      onClick={() => setSelected(selected === index ? null : index)}
                    >
                      <span className="cost">{fa(item.count)}</span>
                      <img src={unitArt(item.k)} alt="" />
                      <b>{card?.name || item.k}</b>
                    </button>
                  );
                })}
              </div>
            )}
            <div className="b-meter">
              {arenaSnapshot ? (
                <>
                  <span className="b-next">
                    <img src={unitArt(arenaSnapshot.hand[0] || "guard")} alt="" />
                  </span>
                  <div className="elixir">
                    <i style={{ width: `${Math.min(100, (arenaSnapshot.elixir / 10) * 100)}%` }} />
                    <b>{arenaSnapshot.elixir.toFixed(1)}</b>
                  </div>
                </>
              ) : (
                <div className="destroy">
                  <i style={{ width: `${siegeSnapshot?.destruction || 0}%` }} />
                  <b>{fa(siegeSnapshot?.destruction || 0)}٪ تخریب</b>
                </div>
              )}
            </div>
          </footer>

          {result && (
            <div className="b-modal">
              <div className={`b-dialog result ${result.result || ""}`}>
                <div className="r-badge">
                  {battle.snapshot.mode === "arena" ? (
                    <span className="crowns big">
                      {[0, 1, 2].map((index) => (
                        <i key={index} className={(result.score || 0) > index ? "on" : ""}>
                          <Ic n="star" />
                        </i>
                      ))}
                    </span>
                  ) : (
                    <span className="stars big">
                      {[0, 1, 2].map((index) => (
                        <i key={index} className={(result.score || 0) > index ? "on" : ""}>
                          <Ic n="star" />
                        </i>
                      ))}
                    </span>
                  )}
                </div>
                <h2>
                  {result.result === "win" ? "پیروزی!" : result.result === "draw" ? "مساوی" : "شکست"}
                </h2>
                <p>
                  {battle.snapshot.mode === "arena"
                    ? `${fa(result.score || 0)} تاج در برابر ${fa(battle.snapshot.crowns.e)} تاج`
                    : `${fa(result.destruction || 0)}٪ تخریب · ${fa(result.score || 0)} ستاره`}
                </p>
                <div className="r-rewards">
                  <span>
                    <img src="/jamplay/art-vault.webp" alt="" /> <b>+{fa(result.coins || 0)}</b>
                  </span>
                  <span>
                    <Ic n="spark" /> <b>+{fa(result.xp || 0)}</b>
                  </span>
                  <span>
                    <img src="/jamplay/art-trophy.webp" alt="" />{" "}
                    <b>
                      {(result.trophies || 0) >= 0 ? "+" : "−"}
                      {fa(Math.abs(result.trophies || 0))}
                    </b>
                  </span>
                </div>
                {result.chest && (
                  <div className="r-chest">
                    <img src={chestArt(result.chest.kind)} alt="" />
                    <span>
                      <b>{result.chest.kind === "gold" ? "صندوق طلا" : "صندوق نقره"}</b> به جایگاه صندوق‌ها
                      اضافه شد.
                    </span>
                  </div>
                )}
                {result.promoted && <p className="r-note">به لیگ {result.league_after} ارتقا یافتی!</p>}
                {result.demoted && <p className="r-note">به لیگ {result.league_after} بازگشتی.</p>}
                <div className="b-dialog-row">
                  <button
                    className="btn gold"
                    onClick={() => {
                      const mode = battle.mode;
                      setBattle(null);
                      setResult(null);
                      settledRef.current = false;
                      void startBattle(mode);
                    }}
                  >
                    نبرد دوباره
                  </button>
                  <button className="btn ghost" onClick={() => void closeBattle()}>
                    بازگشت
                  </button>
                </div>
              </div>
            </div>
          )}
        </section>
      )}

      {showArenaPrep && (
        <div className="overlay in">
          <div className="sheet">
            <div className="sheet-h">
              <h2>آماده‌سازی آوردگاه</h2>
              <button className="icon-btn" onClick={() => setShowArenaPrep(false)} aria-label="بستن">
                <Ic n="x" />
              </button>
            </div>
            <div className="sheet-b">
              <div className="ah-league" style={{ marginBottom: 12 }}>
                <img src="/jamplay/art-trophy.webp" alt="" style={{ width: 48 }} />
                <div style={{ flex: 1 }}>
                  <small className="muted">لیگ تو</small>
                  <b style={{ display: "block" }}>{league.name}</b>
                </div>
                <div className="ah-tro" style={{ color: "var(--text)", background: "var(--surface2)" }}>
                  <b>{fa(profile.trophies)}</b>
                  <small>کاپ</small>
                </div>
              </div>
              <p className="muted">
                سه دقیقه وقت داری؛ با سه تاج یا بیشترین تاج در پایان برنده‌ای. اگر تاج‌ها مساوی باشد
                اضافه‌وقت می‌شود و اکسیر دوبرابر می‌شود. استقرار فقط در نیمهٔ خودی و عبور از پل‌ها ممکن است.
              </p>
              <div className="sec-h" style={{ marginTop: 14 }}>
                <div>
                  <h3>دستهٔ نبرد</h3>
                  <p>هشت کارت، انتخاب‌شده روی سرور.</p>
                </div>
                <button
                  className="link"
                  onClick={() => {
                    setShowArenaPrep(false);
                    setScreen("deck");
                  }}
                >
                  ویرایش
                </button>
              </div>
              <div className="deck">
                {profile.deck.map((card) => (
                  <div key={card.slot} className="ccard">
                    <span className="cost">{fa(card.cost)}</span>
                    <img src={unitArt(card.key)} alt="" />
                    <b>{card.name}</b>
                    <span className="lv">سطح {fa(card.level)}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="sheet-f">
              <button
                className="btn gold"
                disabled={busy === "start-arena"}
                onClick={() => void startBattle("arena")}
              >
                {busy === "start-arena" ? "در حال شروع…" : "شروع نبرد"}
              </button>
              <button className="btn ghost" onClick={() => setShowArenaPrep(false)}>
                بستن
              </button>
            </div>
          </div>
        </div>
      )}

      {showSiegePrep && (
        <div className="overlay in">
          <div className="sheet">
            <div className="sheet-h">
              <h2>آماده‌سازی محاصره</h2>
              <button className="icon-btn" onClick={() => setShowSiegePrep(false)} aria-label="بستن">
                <Ic n="x" />
              </button>
            </div>
            <div className="sheet-b">
              <p className="muted">
                ارتش خود را بیرون دیوار پایگاه حریف پیاده کن. هر ساختمان ویران‌شده به درصد تخریب اضافه
                می‌شود؛ ۵۰٪ تخریب، نابودی تالار و ۱۰۰٪ تخریب ستاره می‌دهند.
              </p>
              <div className="record">
                <div>
                  <b>{fa(profile.town_hall_level)}</b>
                  <span>سطح تالار</span>
                </div>
                <div>
                  <b>{fa(army.reduce((sum, item) => sum + item.count, 0))}</b>
                  <span>کل نیرو</span>
                </div>
              </div>
              <div className="b-army" style={{ display: "grid", gap: 8 }}>
                {army.map((item) => (
                  <div key={item.k} className="b-item">
                    <img src={unitArt(item.k)} alt="" />
                    <span>
                      <b>{cardsByKey.get(item.k)?.name || item.k}</b>
                      <small>{fa(item.count)} نیرو</small>
                    </span>
                  </div>
                ))}
              </div>
            </div>
            <div className="sheet-f">
              <button
                className="btn gold"
                disabled={busy === "start-siege"}
                onClick={() => void startBattle("siege")}
              >
                {busy === "start-siege" ? "در حال شروع…" : "شروع محاصره"}
              </button>
            </div>
          </div>
        </div>
      )}

      {openCard && (
        <CardSheet
          card={openCard}
          busy={busy === `card-${openCard.key}`}
          onClose={() => setCardOpen(null)}
          onUpgrade={() => void upgradeCard(openCard.key)}
        />
      )}

      {openChest && (
        <ChestSheet
          slot={openChest}
          busy={busy === `chest-start-${openChest.index}` || busy === `chest-claim-${openChest.index}`}
          onClose={() => setChestOpen(null)}
          onStart={() => void startChest(openChest.index)}
          onClaim={() => void claimChest(openChest.index)}
        />
      )}

      {openBuilding && buildings && (
        <BuildingSheet
          building={openBuilding}
          builder={buildings.builder}
          busy={busy === `building-${openBuilding.key}` || busy === `complete-${openBuilding.key}`}
          onClose={() => setBuildingOpen(null)}
          onUpgrade={() => void upgradeBuilding(openBuilding.key)}
          onComplete={() => void completeBuilding(openBuilding.key)}
        />
      )}

      {toast && (
        <div className="toasts" style={{ pointerEvents: "none" }}>
          <div className={`toast ${toast.kind}`}>
            <Ic n={toast.kind === "warn" ? "alert" : "check"} />
            <span>{toast.message}</span>
          </div>
        </div>
      )}
    </div>
  );
}

/* --------------------------------------------------------------------------- */
/* Screens                                                                      */
/* --------------------------------------------------------------------------- */

function Lobby({
  profile,
  history,
  chests,
  busy,
  leagues,
  onOpenArena,
  onOpenSiege,
  onChest,
  onGoDeck,
  onGoCollection,
  onGoBase,
}: {
  profile: Profile;
  history: BattleHistoryItem[];
  chests: ChestSlot[];
  busy: string | null;
  leagues: { min: number; name: string; color: string }[];
  onOpenArena: () => void;
  onOpenSiege: () => void;
  onChest: (index: number) => void;
  onGoDeck: () => void;
  onGoCollection: () => void;
  onGoBase: () => void;
}) {
  const league = profile.league;
  const remaining = league.next_min ? league.next_min - profile.trophies : 0;
  return (
    <>
      <div className="greet">
        <div>
          <small>
            <Ic n="pin" /> اصفهان · جم‌پلی
          </small>
          <h1>سلام، {profile.display_name}</h1>
        </div>
        <button className="icon-btn soft" onClick={onGoBase} aria-label="پایگاه">
          <Ic n="castle" />
        </button>
      </div>

      <section className="arena-hero">
        <div className="ah-bg" style={{ backgroundImage: "url(/jamplay/unit-arena.webp)" }} />
        <div className="ah-league">
          <img src="/jamplay/art-trophy.webp" alt="" />
          <div>
            <small>لیگ فعلی</small>
            <b>{league.name}</b>
          </div>
          <div className="ah-tro">
            <b>{fa(profile.trophies)}</b>
            <small>کاپ</small>
          </div>
        </div>
        <div className="ah-prog">
          <span className="bar" style={{ display: "block", height: 10, borderRadius: 9, background: "rgba(255,255,255,.18)" }}>
            <i
              style={{
                display: "block",
                height: "100%",
                width: `${Math.round(league.progress * 100)}%`,
                borderRadius: 9,
                background: "var(--gold)",
              }}
            />
          </span>
          <small>
            {league.next_min
              ? `${fa(remaining)} کاپ تا ${league.next_name}`
              : "بالاترین لیگ را داری"}
          </small>
        </div>
        <div className="modes">
          <div className="mode">
            <img src="/jamplay/unit-arena.webp" alt="" />
            <div>
              <h3>آوردگاه</h3>
              <p>نبرد کارتی سه‌دقیقه‌ای؛ سه تاج ببر.</p>
            </div>
            <button className="btn gold" disabled={busy === "start-arena"} onClick={onOpenArena}>
              آماده‌سازی آوردگاه
            </button>
          </div>
          <div className="mode">
            <img src="/jamplay/unit-ballista.webp" alt="" />
            <div>
              <h3>محاصره</h3>
              <p>ارتش را بیرون دیوار پیاده کن و پایگاه را بشکن.</p>
            </div>
            <button className="btn blue" onClick={onOpenSiege}>
              آماده‌سازی محاصره
            </button>
          </div>
        </div>
      </section>

      {leagues.length > 0 && (
        <div className="block">
          <div className="sec-h">
            <div>
              <h2>مسیر لیگ‌ها</h2>
              <p>با کاپ بیشتر به لیگ‌های بالاتر می‌رسی.</p>
            </div>
            <span className="count muted">بهترین: {fa(profile.best_trophies)}</span>
          </div>
          <div className="hscroll">
            {leagues.map((item, index) => (
              <div
                key={item.name}
                className={`ready-it ${index === league.index ? "gold" : ""}`}
                style={{ minWidth: 172 }}
              >
                <span className="ri-ic">
                  <img src="/jamplay/art-trophy.webp" alt="" />
                </span>
                <span>
                  <b>{item.name}</b>
                  <small>
                    {fa(item.min)} کاپ {index === league.index ? "· لیگ تو" : ""}
                  </small>
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="block">
        <div className="sec-h">
          <div>
            <h2>صندوق‌ها</h2>
            <p>از هر پیروزی یک صندوق می‌گیری؛ زمان‌ها روی سرور است.</p>
          </div>
        </div>
        <div className="chests">
          {chests.map((slot) => (
            <button key={slot.index} className={`chest ${chestClass(slot)}`} onClick={() => onChest(slot.index)}>
              {slot.state === "empty" ? (
                <>
                  <Ic n="plus" />
                  <small>خالی</small>
                </>
              ) : (
                <>
                  <img src={chestArt(slot.kind)} alt="" />
                  <b>{slot.kind_name || (slot.kind === "gold" ? "صندوق طلا" : "صندوق نقره")}</b>
                  <small>{chestLabel(slot)}</small>
                </>
              )}
            </button>
          ))}
        </div>
      </div>

      <div className="block">
        <div className="sec-h">
          <div>
            <h2>رکورد</h2>
            <p>آمار نبردهای ثبت‌شده روی سرور.</p>
          </div>
        </div>
        <div className="record">
          <div>
            <b>
              {fa(profile.arena_wins)}<small>/{fa(profile.arena_played)}</small>
            </b>
            <span>برد آوردگاه</span>
          </div>
          <div>
            <b>
              {fa(profile.siege_wins)}<small>/{fa(profile.siege_played)}</small>
            </b>
            <span>برد محاصره</span>
          </div>
          <div>
            <b>{fa(profile.arena_crowns)}</b>
            <span>تاج</span>
          </div>
          <div>
            <b>{fa(profile.best_trophies)}</b>
            <span>بهترین کاپ</span>
          </div>
        </div>
      </div>

      <div className="block">
        <div className="sec-h">
          <div>
            <h2>دستهٔ من</h2>
            <p>پیش از نبرد کارت‌ها را بچین.</p>
          </div>
          <button className="link" onClick={onGoDeck}>
            ویرایش
          </button>
        </div>
        <div className="deck">
          {profile.deck.map((card) => (
            <button key={card.slot} className="ccard" onClick={onGoDeck}>
              <span className="cost">{fa(card.cost)}</span>
              <img src={unitArt(card.key)} alt="" />
              <b>{card.name}</b>
              <span className="lv">سطح {fa(card.level)}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="block">
        <div className="sec-h">
          <div>
            <h2>آخرین نبردها</h2>
          </div>
          <button className="link" onClick={onGoCollection}>
            کارت‌ها
          </button>
        </div>
        {history.length === 0 ? (
          <p className="muted">هنوز نبردی ثبت نشده است.</p>
        ) : (
          <div className="hist">
            {history.map((item) => (
              <div key={item.key} className={`h-row ${item.result === "win" ? "win" : item.result === "loss" ? "loss" : ""}`}>
                <span className="h-res">
                  {item.result === "win" ? "برد" : item.result === "loss" ? "باخت" : "مساوی"}
                </span>
                <b>{item.opponent || "حریف"}</b>
                <small>
                  {item.mode === "arena" ? `${fa(item.score)} تاج` : `${fa(item.destruction)}٪`}
                </small>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
}

function chestClass(slot: ChestSlot): string {
  if (slot.state === "empty") return "empty";
  if (slot.state === "ready") return "ready";
  if (slot.state === "opening") return "open";
  return "";
}

function chestLabel(slot: ChestSlot): string {
  if (slot.state === "empty") return "";
  if (slot.state === "ready") return "آمادهٔ دریافت";
  if (slot.state === "opening") return `باز شدن ${clock(slot.remaining_seconds)}`;
  return "باز نکرده";
}

function CollectionScreen({
  profile,
  cardsByKey,
  onOpenCard,
}: {
  profile: Profile;
  cardsByKey: Map<string, Profile["cards"][number]>;
  onOpenCard: (key: string) => void;
}) {
  return (
    <>
      <div className="sec-h">
        <div>
          <h2>کارت‌لور</h2>
          <p>با نسخه‌های تکراری، کارت‌ها را ارتقا بده.</p>
        </div>
        <span className="count muted">
          {fa(profile.cards.filter((card) => card.owned).length)} کارت
        </span>
      </div>
      <div className="deck">
        {profile.cards.map((meta) => {
          const owned = cardsByKey.get(meta.key);
          return (
            <button
              key={meta.key}
              className={`ccard ${owned?.owned ? "" : "locked"} ${meta.can_upgrade ? "can" : ""}`}
              onClick={() => onOpenCard(meta.key)}
            >
              <span className="cost">{fa(meta.cost)}</span>
              <img src={unitArt(meta.key)} alt="" />
              <b>{meta.name}</b>
              {owned?.owned ? (
                <span className="lv">
                  سطح {fa(owned.level)} · {fa(owned.copies)} نسخه
                </span>
              ) : (
                <small>
                  <Ic n="x" /> قفل
                </small>
              )}
              {meta.can_upgrade && (
                <span className="up-badge">
                  <Ic n="trend" />
                </span>
              )}
            </button>
          );
        })}
      </div>
    </>
  );
}

function DeckScreen({
  profile,
  draft,
  slot,
  busy,
  onSlot,
  onPick,
  onSave,
  onReset,
}: {
  profile: Profile;
  draft: string[];
  slot: number;
  busy: boolean;
  onSlot: (index: number) => void;
  onPick: (key: string) => void;
  onSave: () => void;
  onReset: () => void;
}) {
  const meta = new Map(profile.cards.map((card) => [card.key, card]));
  return (
    <>
      <div className="sec-h">
        <div>
          <h2>دستهٔ نبرد</h2>
          <p>هشت کارت انتخاب کن؛ هر کارت فقط یک بار.</p>
        </div>
        <span className="count muted">{fa(draft.length)}/۸</span>
      </div>
      <div className="deck">
        {draft.map((key, index) => {
          const card = meta.get(key);
          return (
            <button
              key={`${key}-${index}`}
              className="ccard"
              style={slot === index ? { outline: "3px solid var(--gold)" } : undefined}
              onClick={() => onSlot(index)}
            >
              <span className="cost">{fa(card?.cost || 0)}</span>
              <img src={unitArt(key)} alt="" />
              <b>{card?.name || key}</b>
              <span className="lv">سطح {fa(card?.level || 1)}</span>
            </button>
          );
        })}
      </div>
      <div className="block">
        <div className="sec-h">
          <div>
            <h3>انتخاب برای جایگاه {fa(slot + 1)}</h3>
            <p>کارت‌های تحت مالکیت.</p>
          </div>
        </div>
        <div className="deck">
          {profile.cards
            .filter((card) => card.owned)
            .map((card) => {
              const used = draft.includes(card.key) && draft.indexOf(card.key) !== slot;
              return (
                <button
                  key={card.key}
                  className={`ccard ${used ? "locked" : ""}`}
                  onClick={() => onPick(card.key)}
                  disabled={used}
                >
                  <span className="cost">{fa(card.cost)}</span>
                  <img src={unitArt(card.key)} alt="" />
                  <b>{card.name}</b>
                  <span className="lv">سطح {fa(card.level)}</span>
                </button>
              );
            })}
        </div>
      </div>
      <div className="row" style={{ display: "flex", gap: 10, marginTop: 18 }}>
        <button className="btn btn-primary" disabled={busy} onClick={onSave}>
          {busy ? "در حال ذخیره…" : "ذخیرهٔ دسته"}
        </button>
        <button className="btn ghost" onClick={onReset}>
          بازگردانی
        </button>
      </div>
    </>
  );
}

function ChestsScreen({
  chests,
  busy,
  onOpen,
  onRefresh,
}: {
  chests: ChestSlot[];
  busy: string | null;
  onOpen: (index: number) => void;
  onRefresh: () => void;
}) {
  return (
    <>
      <div className="sec-h">
        <div>
          <h2>جایگاه صندوق‌ها</h2>
          <p>باز کردن و دریافت صندوق کاملاً روی سرور کنترل می‌شود.</p>
        </div>
        <button className="icon-btn soft" onClick={onRefresh} aria-label="به‌روزرسانی">
          <Ic n="refresh" />
        </button>
      </div>
      <div className="chests">
        {chests.map((slot) => (
          <button key={slot.index} className={`chest ${chestClass(slot)}`} onClick={() => onOpen(slot.index)}>
            {slot.state === "empty" ? (
              <>
                <Ic n="plus" />
                <small>خالی</small>
              </>
            ) : (
              <>
                <img src={chestArt(slot.kind)} alt="" />
                <b>{slot.kind_name || "صندوق"}</b>
                <small>{chestLabel(slot)}</small>
              </>
            )}
          </button>
        ))}
      </div>
      <div className="card block">
        <h3>چطور صندوق بگیرم؟</h3>
        <p className="muted">
          از هر پیروزی در آوردگاه یا محاصره یک صندوق در اولین جایگاه خالی قرار می‌گیرد. صندوق را باز کن،
          زمانش که تمام شد دریافت کن. هر صندوق فقط یک بار قابل دریافت است.
        </p>
        {busy?.startsWith("chest") && <p className="muted">در حال ارسال درخواست…</p>}
      </div>
    </>
  );
}

function BaseScreen({
  buildings,
  busy,
  builderName,
  onSelect,
  onComplete,
  onRefresh,
}: {
  buildings: BuildingsPayload;
  busy: string | null;
  builderName: string;
  onSelect: (key: string) => void;
  onComplete: () => void;
  onRefresh: () => void;
}) {
  const builder = buildings.builder;
  return (
    <>
      <div className="base-layout">
        <div className="base-view">
          <div className="base-top">
            <span className="chip-stat">
              <Ic n="castle" /> سطح پایگاه {fa(buildings.town_hall_level)}
            </span>
            <span className={`chip-stat ${builder.busy ? "busy" : ""}`}>
              <Ic n="wrench" />
              {builder.busy ? `سازنده: ${builderName || "مشغول"} ${clock(builder.remaining_seconds)}` : "سازنده آزاد"}
            </span>
          </div>
          <BaseField buildings={buildings.buildings} builder={builder} onSelect={onSelect} />
          <div className="base-actions">
            {builder.busy && (
              <button className="btn gold" disabled={busy?.startsWith("complete")} onClick={onComplete}>
                تکمیل ارتقا
              </button>
            )}
            <button className="btn glass" onClick={onRefresh}>
              تازه‌سازی
            </button>
          </div>
        </div>
        <div className="base-panel">
          <div className="bp-h">
            <h2>مدیریت پایگاه</h2>
            <p>ساختمان‌ها را ارتقا بده؛ فقط یک سازنده در دسترس است.</p>
          </div>
          <div className="th-hint ok">
            <Ic n="spark" />
            <div>
              <b>امتیاز کشف: {fa(buildings.discovery_points)}</b>
              <small>ارتقای تالار شهر به کشف شهر نیاز دارد که در فاز ۱ فعال نیست.</small>
            </div>
          </div>
          <div className="b-list">
            {buildings.buildings.map((building: BuildingItem) => {
              const busyHere = builder.busy && builder.building_key === building.key;
              return (
                <button
                  key={building.key}
                  className={`b-item ${busyHere ? "busy" : ""}`}
                  onClick={() => onSelect(building.key)}
                >
                  <img src={`/jamplay/art-${building.art}.webp`} alt="" />
                  <span>
                    <b>
                      {building.name} · سطح {fa(building.level)}
                    </b>
                    <small>{building.next_effect || building.effect}</small>
                  </span>
                  <i className={`st ${busyHere ? "busy" : building.can_upgrade ? "up" : ""}`}>
                    {busyHere ? clock(builder.remaining_seconds) : building.can_upgrade ? "ارتقا" : "بسته"}
                  </i>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
}

/* --------------------------------------------------------------------------- */
/* Sheets                                                                       */
/* --------------------------------------------------------------------------- */

function CardSheet({
  card,
  busy,
  onClose,
  onUpgrade,
}: {
  card: Profile["cards"][number];
  busy: boolean;
  onClose: () => void;
  onUpgrade: () => void;
}) {
  return (
    <div className="overlay in">
      <div className="sheet">
        <div className="sheet-h">
          <h2>{card.name}</h2>
          <button className="icon-btn" onClick={onClose} aria-label="بستن">
            <Ic n="x" />
          </button>
        </div>
        <div className="sheet-b">
          <div className="cs-top">
            <img src={unitArt(card.key)} alt="" />
            <div>
              <p>{card.description}</p>
              <p className="muted">{card.role}</p>
            </div>
          </div>
          <div className="cs-stats">
            <div>
              <small>اکسیر</small>
              <b>{fa(card.cost)}</b>
            </div>
            <div>
              <small>جان</small>
              <b>{fa(card.stats.hp)}</b>
            </div>
            <div>
              <small>آسیب</small>
              <b>{fa(card.stats.dmg)}</b>
            </div>
            <div>
              <small>نیرو</small>
              <b>{fa(card.stats.count)}</b>
            </div>
          </div>
          <div className="cs-up">
            <small>
              سطح {fa(card.level)} از {fa(card.max_level)} · {fa(card.copies)} نسخه
            </small>
            {card.level < card.max_level ? (
              <>
                <small>
                  ارتقا: {fa(card.upgrade_copies)} نسخه و {fa(card.upgrade_cost)} سکه
                </small>
                {!card.can_upgrade && (
                  <small className="why">
                    <Ic n="info" /> نسخه یا سکهٔ کافی نداری.
                  </small>
                )}
              </>
            ) : (
              <small className="muted">به بالاترین سطح رسیده است.</small>
            )}
          </div>
        </div>
        <div className="sheet-f">
          <button className="btn primary" disabled={busy || !card.can_upgrade} onClick={onUpgrade}>
            {busy ? "در حال ارتقا…" : "ارتقا"}
          </button>
          <button className="btn ghost" onClick={onClose}>
            بستن
          </button>
        </div>
      </div>
    </div>
  );
}

function ChestSheet({
  slot,
  busy,
  onClose,
  onStart,
  onClaim,
}: {
  slot: ChestSlot;
  busy: boolean;
  onClose: () => void;
  onStart: () => void;
  onClaim: () => void;
}) {
  return (
    <div className="overlay in">
      <div className="sheet">
        <div className="sheet-h">
          <h2>{slot.kind_name || "صندوق"}</h2>
          <button className="icon-btn" onClick={onClose} aria-label="بستن">
            <Ic n="x" />
          </button>
        </div>
        <div className="sheet-b">
          <div className="chest-info">
            <img
              className={`chest-big ${slot.kind}`}
              src={chestArt(slot.kind)}
              alt=""
            />
            <b>{chestLabel(slot)}</b>
            <small className="muted">
              {slot.minutes ? `زمان باز شدن: ${fa(slot.minutes)} دقیقه` : "جایگاه خالی است"}
            </small>
          </div>
          <div className="record" style={{ marginTop: 12 }}>
            <div>
              <b>{fa(slot.cards)}</b>
              <span>کارت</span>
            </div>
            <div>
              <b>
                {slot.gems_max ? `${fa(slot.gems_min)}–${fa(slot.gems_max)}` : "۰"}
              </b>
              <span>الماس</span>
            </div>
            <div>
              <b>
                {slot.coins_max ? `${fa(slot.coins_min)}–${fa(slot.coins_max)}` : "—"}
              </b>
              <span>سکه</span>
            </div>
            <div>
              <b>{slot.state === "opening" ? clock(slot.remaining_seconds) : "—"}</b>
              <span>باقی‌مانده</span>
            </div>
          </div>
        </div>
        <div className="sheet-f">
          {slot.state === "locked" && (
            <button className="btn gold" disabled={busy} onClick={onStart}>
              {busy ? "…" : "شروع باز کردن"}
            </button>
          )}
          {slot.state === "opening" && (
            <button className="btn ghost" disabled>
              {clock(slot.remaining_seconds)}
            </button>
          )}
          {slot.state === "ready" && (
            <button className="btn gold" disabled={busy} onClick={onClaim}>
              {busy ? "…" : "دریافت پاداش"}
            </button>
          )}
          {slot.state === "empty" && <button className="btn ghost" disabled>جایگاه خالی</button>}
          <button className="btn ghost" onClick={onClose}>
            بستن
          </button>
        </div>
      </div>
    </div>
  );
}

function BuildingSheet({
  building,
  builder,
  busy,
  onClose,
  onUpgrade,
  onComplete,
}: {
  building: BuildingItem;
  builder: BuildingsPayload["builder"];
  busy: boolean;
  onClose: () => void;
  onUpgrade: () => void;
  onComplete: () => void;
}) {
  const busyHere = builder.busy && builder.building_key === building.key;
  return (
    <div className="overlay in">
      <div className="sheet">
        <div className="sheet-h">
          <h2>{building.name}</h2>
          <button className="icon-btn" onClick={onClose} aria-label="بستن">
            <Ic n="x" />
          </button>
        </div>
        <div className="sheet-b">
          <div className="bs-top">
            <img src={`/jamplay/art-${building.art}.webp`} alt="" />
            <div>
              <b>سطح {fa(building.level)}</b>
              <p>{building.effect}</p>
            </div>
          </div>
          <div className="bs-eff">
            <div>
              <small>اثر فعلی</small>
              <b>{building.effect}</b>
            </div>
            <span>←</span>
            <div className="next">
              <small>سطح بعد</small>
              <b>{building.next_effect || "—"}</b>
            </div>
          </div>
          <div className="cost-row">
            <span>
              <img src="/jamplay/art-vault.webp" alt="" className="ico-img" />
              <b>{fa(building.upgrade_cost)}</b>
            </span>
            <span>
              <Ic n="clock" />
              <b>{clock(building.upgrade_seconds)}</b>
            </span>
          </div>
          {busyHere && (
            <p className="muted">سازنده مشغول این ساختمان است: {clock(builder.remaining_seconds)}</p>
          )}
          {!building.can_upgrade && building.blocked_reason && (
            <p className="why">
              <Ic n="info" /> {building.blocked_reason}
            </p>
          )}
          {builder.busy && !busyHere && (
            <p className="muted">سازنده در حال کار روی ساختمان دیگری است.</p>
          )}
        </div>
        <div className="sheet-f">
          {busyHere ? (
            <button className="btn gold" disabled={busy} onClick={onComplete}>
              {busy ? "…" : "تکمیل ارتقا"}
            </button>
          ) : (
            <button className="btn primary" disabled={busy || !building.can_upgrade} onClick={onUpgrade}>
              {busy ? "…" : "ارتقا"}
            </button>
          )}
          <button className="btn ghost" onClick={onClose}>
            بستن
          </button>
        </div>
      </div>
    </div>
  );
}
