/* JamPlay API contracts (mirrors backend/games/services.py payloads). */

export interface LeagueInfo {
  index: number;
  name: string;
  color: string;
  min: number;
  next_min: number | null;
  next_name: string | null;
  progress: number;
}

export interface CardStats {
  cost: number;
  hp: number;
  dmg: number;
  rate: number;
  speed: number;
  range: number;
  count: number;
  splash: number;
  buildings: boolean;
  spell: boolean;
  radius: number;
  heal: number;
  freeze: number;
  art: string;
}

export interface CardItem {
  key: string;
  name: string;
  art: string;
  cost: number;
  role: string;
  description: string;
  owned: boolean;
  level: number;
  copies: number;
  max_level: number;
  upgrade_cost: number;
  upgrade_copies: number;
  can_upgrade: boolean;
  stats: CardStats;
}

export interface DeckCard {
  slot: number;
  key: string;
  name: string;
  art: string;
  cost: number;
  level: number;
  owned: boolean;
}

export interface Profile {
  id: number;
  display_name: string;
  coins: number;
  gems: number;
  xp: number;
  level: number;
  xp_in_level: number;
  xp_need: number;
  trophies: number;
  best_trophies: number;
  league: LeagueInfo;
  arena_played: number;
  arena_wins: number;
  arena_crowns: number;
  siege_played: number;
  siege_wins: number;
  siege_stars: number;
  total_wins: number;
  first_battle_done: boolean;
  town_hall_level: number;
  started_at: string;
  deck: DeckCard[];
  cards: CardItem[];
}

export interface Opponent {
  name?: string;
  league?: number;
  league_name?: string;
  card_level?: number;
}

export interface TowerSnapshot {
  id: string;
  team: number;
  king: boolean;
  x: number;
  y: number;
  hp: number;
  max_hp: number;
  radius: number;
}

export interface UnitSnapshot {
  id: string;
  team: number;
  k: string;
  x: number;
  y: number;
  hp: number;
  max_hp: number;
  freeze: number;
  hit: number;
  target?: string | null;
  path?: number[][];
}

export interface FxSnapshot {
  type: string;
  x: number;
  y: number;
  r: number;
  team: number | null;
  ttl: number;
  max: number;
}

export interface ArenaSnapshot {
  mode: "arena";
  t: number;
  limit: number;
  overtime: boolean;
  ended: boolean;
  result: string;
  reason: string;
  elixir: number;
  hand: string[];
  hand_levels: number[];
  deck: string[];
  towers: TowerSnapshot[];
  units: UnitSnapshot[];
  crowns: { p: number; e: number };
  fx: FxSnapshot[];
  opponent: Opponent;
}

export interface SiegeBuildingSnapshot {
  id: string;
  t: string;
  x: number;
  y: number;
  s: number;
  hp: number;
  max_hp: number;
  hit: number;
}

export interface SiegeWallSnapshot {
  id: string;
  gx: number;
  gy: number;
  hp: number;
  max_hp: number;
}

export interface ArmyItem {
  k: string;
  count: number;
}

export interface SiegeSnapshot {
  mode: "siege";
  t: number;
  limit: number;
  overtime: boolean;
  ended: boolean;
  result: string;
  reason: string;
  buildings: SiegeBuildingSnapshot[];
  walls: SiegeWallSnapshot[];
  units: UnitSnapshot[];
  army: ArmyItem[];
  destruction: number;
  stars: number;
  fx: FxSnapshot[];
  opponent: Opponent;
}

export type Snapshot = ArenaSnapshot | SiegeSnapshot;

export interface ChestAward {
  index: number;
  kind: string;
}

export interface RewardSummary {
  coins?: number;
  xp?: number;
  trophies?: number;
  trophies_before?: number;
  trophies_after?: number;
  league_before?: string;
  league_after?: string;
  promoted?: boolean;
  demoted?: boolean;
  chest?: ChestAward | null;
  score?: number;
  destruction?: number;
  result?: string;
  mode?: string;
}

export interface BattlePayload {
  battle_key: string;
  mode: "arena" | "siege";
  status: string;
  difficulty: string;
  opponent: string;
  snapshot: Snapshot;
  rewards: RewardSummary;
  result: string;
}

export interface BattleActionResponse {
  ok: boolean;
  battle: BattlePayload;
  deploy_error?: { code: string; detail: string };
}

export interface FinishResponse {
  ok: boolean;
  battle: BattlePayload;
  rewards: RewardSummary;
  profile: Omit<Profile, "deck" | "cards">;
  chests: { slots: ChestSlot[] };
  already_settled?: boolean;
}

export interface ChestSlot {
  index: number;
  kind: string;
  kind_name: string;
  state: "empty" | "locked" | "opening" | "ready";
  ready_at: string | null;
  remaining_seconds: number;
  minutes: number;
  cards: number;
  coins_min: number;
  coins_max: number;
  gems_min: number;
  gems_max: number;
}

export interface BuilderInfo {
  busy: boolean;
  building_key: string | null;
  finish_at: string | null;
  remaining_seconds: number;
}

export interface BuildingItem {
  key: string;
  type: string;
  name: string;
  art: string;
  grid_x: number;
  grid_y: number;
  size: number;
  level: number;
  max_level: number;
  effect: string;
  next_effect: string;
  upgrade_cost: number;
  upgrade_seconds: number;
  can_upgrade: boolean;
  blocked_reason: string;
  blocked_code: string;
}

export interface BuildingsPayload {
  town_hall_level: number;
  discovery_points: number;
  buildings: BuildingItem[];
  builder: BuilderInfo;
}

export interface BattleHistoryItem {
  key: string;
  mode: "arena" | "siege";
  status: string;
  result: string;
  score: number;
  destruction: number;
  opponent: string;
  created_at: string;
  rewards: RewardSummary;
}

export interface CatalogCard {
  key: string;
  name: string;
  art: string;
  cost: number;
  hp?: number;
  dmg?: number;
  count?: number;
  spell?: boolean;
  role?: string;
  description?: string;
}

export interface Catalog {
  engine_version: string;
  cards: CatalogCard[];
  starter_cards: string[];
  army: { key: string; count: number }[];
  buildings: { type: string; name: string; size: number; max_level: number; base_cost: number; effect: string; art: string }[];
  base_layout: { key: string; type: string; gx: number; gy: number }[];
  leagues: { min: number; name: string; color: string }[];
  rules: Record<string, number | boolean | number[]>;
}
