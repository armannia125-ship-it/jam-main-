"""JamPlay domain services.

All persistence and business rules for the game live here so views stay thin
and every mutation is transactional, ownership-scoped and auditable.

Invariants:
* Balances only change through ``apply_delta`` (which writes a LedgerEntry in
  the same transaction).
* Battle settlement happens once, guarded by a row lock plus the status field.
* Chest and builder transitions are server-timestamp driven; clients only poll.
"""

from __future__ import annotations

import random
import uuid
from datetime import timedelta
from typing import Any

from django.db import transaction
from django.utils import timezone

from . import combat, rules as R
from .models import (
    Battle,
    Building,
    BuilderJob,
    ChestSlot,
    DeckCard,
    GameProfile,
    LedgerEntry,
    PlayerCard,
)

# Town hall starts at level 3 so buildings can actually be upgraded in Phase 1.
# Town-hall upgrades above this level require discovery points, and City
# Discovery is out of Phase 1 scope, so they stay gated (documented).
STARTING_TOWN_HALL_LEVEL = 3


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _ledger_reason(value: str) -> str:
    return value


def apply_delta(profile: GameProfile, resource: str, delta: int, reason: str,
                reference: str = "", idempotency_key: str | None = None) -> int | None:
    """Apply a signed resource delta and append the audit entry atomically."""
    with transaction.atomic():
        locked = GameProfile.objects.select_for_update().get(pk=profile.pk)
        current = int(getattr(locked, resource))
        if idempotency_key and LedgerEntry.objects.filter(
            profile=locked, idempotency_key=idempotency_key
        ).exists():
            return None
        new_value = max(0, current + int(delta))
        setattr(locked, resource, new_value)
        locked.save(update_fields=[resource])
        LedgerEntry.objects.create(
            profile=locked,
            resource=resource,
            delta=int(delta),
            balance_after=new_value,
            reason=reason,
            reference=reference,
            idempotency_key=idempotency_key,
        )
        profile.__dict__[resource] = new_value
        return new_value


def spend_coins(profile: GameProfile, amount: int, reason: str, reference: str = "",
                idempotency_key: str | None = None) -> bool:
    if amount <= 0:
        return True
    with transaction.atomic():
        locked = GameProfile.objects.select_for_update().get(pk=profile.pk)
        if locked.coins < amount:
            return False
        apply_delta(locked, "coins", -amount, reason, reference, idempotency_key)
        return True


# ---------------------------------------------------------------------------
# Profile bootstrap / payloads
# ---------------------------------------------------------------------------


def get_profile(user) -> GameProfile:
    profile, created = GameProfile.objects.get_or_create(user=user)
    if created:
        _bootstrap(profile)
    else:
        _ensure_collection(profile)
    return profile


def _ensure_collection(profile: GameProfile) -> None:
    existing = {c.card_key for c in profile.cards.all()}
    for key in R.STARTER_CARDS:
        if key not in existing:
            PlayerCard.objects.create(profile=profile, card_key=key, level=1, copies=1)
    if profile.deck.count() == 0:
        for slot, key in enumerate(R.STARTER_CARDS[: R.DECK_SIZE]):
            DeckCard.objects.create(profile=profile, slot=slot, card_key=key)


def _bootstrap(profile: GameProfile) -> None:
    _ensure_collection(profile)
    for item in R.BASE_LAYOUT:
        level = STARTING_TOWN_HALL_LEVEL if item["type"] == "th" else 1
        Building.objects.get_or_create(
            profile=profile,
            key=item["key"],
            defaults={
                "building_type": item["type"],
                "grid_x": item["gx"],
                "grid_y": item["gy"],
                "level": level,
            },
        )
    if not ChestSlot.objects.filter(profile=profile).exists():
        for index in range(R.CHEST_SLOTS):
            if index == 0:
                ChestSlot.objects.create(
                    profile=profile, index=index, kind="silver", state=ChestSlot.State.READY
                )
            else:
                ChestSlot.objects.create(
                    profile=profile, index=index, kind="", state=ChestSlot.State.EMPTY
                )
    # Audit the starting grant (only when it is actually the opening balance).
    if not profile.ledger.exists():
        LedgerEntry.objects.create(
            profile=profile,
            resource=LedgerEntry.Resource.COINS.value,
            delta=profile.coins,
            balance_after=profile.coins,
            reason=LedgerEntry.Reason.STARTING_GRANT.value,
            reference="profile_bootstrap",
        )
        LedgerEntry.objects.create(
            profile=profile,
            resource=LedgerEntry.Resource.GEMS.value,
            delta=profile.gems,
            balance_after=profile.gems,
            reason=LedgerEntry.Reason.STARTING_GRANT.value,
            reference="profile_bootstrap",
        )


def league_payload(trophies: int) -> dict[str, Any]:
    index = R.league_index(trophies)
    current = R.LEAGUES[index]
    nxt = R.LEAGUES[index + 1] if index + 1 < len(R.LEAGUES) else None
    if nxt:
        span = max(1, nxt["min"] - current["min"])
        progress = round(min(1.0, max(0.0, (trophies - current["min"]) / span)), 3)
    else:
        progress = 1.0
    return {
        "index": index,
        "name": current["name"],
        "color": current["color"],
        "min": current["min"],
        "next_min": nxt["min"] if nxt else None,
        "next_name": nxt["name"] if nxt else None,
        "progress": progress,
    }


def profile_payload(profile: GameProfile) -> dict[str, Any]:
    profile = GameProfile.objects.get(pk=profile.pk)
    level = R.level_info(profile.xp)
    return {
        "id": profile.id,
        "display_name": profile.resolved_name(),
        "coins": profile.coins,
        "gems": profile.gems,
        "xp": profile.xp,
        "level": level["level"],
        "xp_in_level": level["xp"],
        "xp_need": level["need"],
        "trophies": profile.trophies,
        "best_trophies": profile.best_trophies,
        "league": league_payload(profile.trophies),
        "arena_played": profile.arena_played,
        "arena_wins": profile.arena_wins,
        "arena_crowns": profile.arena_crowns,
        "siege_played": profile.siege_played,
        "siege_wins": profile.siege_wins,
        "siege_stars": profile.siege_stars,
        "total_wins": profile.total_wins,
        "first_battle_done": profile.first_battle_done,
        "town_hall_level": _town_hall_level(profile),
        "started_at": profile.created_at,
    }


def _town_hall_level(profile: GameProfile) -> int:
    th = profile.buildings.filter(key="th").first()
    return th.level if th else 1


# ---------------------------------------------------------------------------
# Cards & deck
# ---------------------------------------------------------------------------


def cards_payload(profile: GameProfile) -> list[dict[str, Any]]:
    owned = {c.card_key: c for c in profile.cards.all()}
    items: list[dict[str, Any]] = []
    for key, base in R.CARDS.items():
        card = owned.get(key)
        level = card.level if card else 0
        items.append(
            {
                "key": key,
                "name": base["name"],
                "art": base["art"],
                "cost": base["cost"],
                "role": base.get("role", ""),
                "description": base.get("description", ""),
                "owned": bool(card),
                "level": level,
                "copies": card.copies if card else 0,
                "max_level": R.CARD_MAX_LEVEL,
                "upgrade_cost": R.card_upgrade_cost(level) if card else 0,
                "upgrade_copies": R.card_upgrade_copies(level) if card else 0,
                "can_upgrade": bool(
                    card
                    and level < R.CARD_MAX_LEVEL
                    and card.copies >= R.card_upgrade_copies(level)
                    and profile.coins >= R.card_upgrade_cost(level)
                ),
                "stats": combat.unit_stats(key, max(1, level)),
            }
        )
    return items


def deck_payload(profile: GameProfile) -> list[dict[str, Any]]:
    owned = {c.card_key: c for c in profile.cards.all()}
    cards = []
    for slot in profile.deck.all().order_by("slot"):
        card = owned.get(slot.card_key)
        base = R.CARDS.get(slot.card_key, {})
        cards.append(
            {
                "slot": slot.slot,
                "key": slot.card_key,
                "name": base.get("name", slot.card_key),
                "art": base.get("art", slot.card_key),
                "cost": base.get("cost", 0),
                "level": card.level if card else 1,
                "owned": bool(card),
            }
        )
    return cards


def set_deck(profile: GameProfile, keys: list[str]) -> dict[str, Any]:
    if not isinstance(keys, list) or len(keys) != R.DECK_SIZE:
        return {"ok": False, "code": "deck_size", "detail": f"دسته باید دقیقاً {R.DECK_SIZE} کارت داشته باشد."}
    if len(set(keys)) != len(keys):
        return {"ok": False, "code": "deck_duplicate", "detail": "هر کارت فقط یک بار در دسته مجاز است."}
    owned = {c.card_key for c in profile.cards.all()}
    missing = [key for key in keys if key not in owned]
    if missing:
        return {"ok": False, "code": "deck_unowned", "detail": "همهٔ کارت‌های دسته باید در مالکیت تو باشند.", "missing": missing}
    with transaction.atomic():
        profile.deck.all().delete()
        DeckCard.objects.bulk_create(
            [DeckCard(profile=profile, slot=i, card_key=key) for i, key in enumerate(keys)]
        )
    return {"ok": True, "deck": deck_payload(profile)}


def upgrade_card(profile: GameProfile, card_key: str) -> dict[str, Any]:
    card = profile.cards.filter(card_key=card_key).first()
    if card is None:
        return {"ok": False, "code": "card_not_owned", "detail": "این کارت را نداری."}
    if card.level >= R.CARD_MAX_LEVEL:
        return {"ok": False, "code": "max_level", "detail": "این کارت به بالاترین سطح رسیده است."}
    need = R.card_upgrade_copies(card.level)
    cost = R.card_upgrade_cost(card.level)
    if card.copies < need:
        return {"ok": False, "code": "copies", "detail": f"{need - card.copies} نسخهٔ دیگر لازم است."}
    if profile.coins < cost:
        return {"ok": False, "code": "insufficient_coins", "detail": "سکهٔ کافی نداری."}
    with transaction.atomic():
        locked = GameProfile.objects.select_for_update().get(pk=profile.pk)
        if not spend_coins(locked, cost, LedgerEntry.Reason.CARD_UPGRADE.value,
                           reference=f"card:{card_key}", idempotency_key=f"card-upg:{profile.id}:{card_key}:{card.level}"):
            return {"ok": False, "code": "insufficient_coins", "detail": "سکهٔ کافی نداری."}
        card.copies -= need
        card.level += 1
        card.save(update_fields=["copies", "level"])
    return {
        "ok": True,
        "card_key": card_key,
        "level": card.level,
        "copies": card.copies,
        "coins": GameProfile.objects.get(pk=profile.pk).coins,
    }


def grant_card(profile: GameProfile, card_key: str) -> PlayerCard:
    card, created = PlayerCard.objects.get_or_create(profile=profile, card_key=card_key)
    if created:
        card.level = 1
        card.copies = 1
    else:
        card.copies = min(999, card.copies + 1)
    card.save()
    return card


# ---------------------------------------------------------------------------
# Buildings & builder
# ---------------------------------------------------------------------------


def _apply_finished_job(profile: GameProfile) -> None:
    job = BuilderJob.objects.filter(profile=profile).first()
    if not job or job.finish_at > timezone.now():
        return
    building = Building.objects.filter(profile=profile, key=job.building_key).first()
    if building:
        cap = R.max_level_for(building.building_type, _town_hall_level(profile))
        building.level = min(building.level + 1, cap)
        building.save(update_fields=["level"])
    job.delete()


def sync_builder(profile: GameProfile) -> None:
    with transaction.atomic():
        profile_locked = GameProfile.objects.select_for_update().get(pk=profile.pk)
        _apply_finished_job(profile_locked)


def building_can_upgrade(profile: GameProfile, building: Building) -> dict[str, Any]:
    builder = BuilderJob.objects.filter(profile=profile).first()
    if builder and builder.finish_at > timezone.now():
        return {"ok": False, "code": "builder_busy", "detail": "سازنده مشغول است."}
    try:
        meta = R.BUILDING_TYPES[building.building_type]
    except KeyError:
        return {"ok": False, "code": "invalid_building", "detail": "ساختمان نامعتبر است."}
    if building.building_type in ("chest", "hero"):
        return {"ok": False, "code": "not_upgradable", "detail": "این ساختمان ارتقا نمی‌پذیرد."}
    if building.level >= meta["max_level"]:
        return {"ok": False, "code": "max_level", "detail": "به بالاترین سطح رسیده است."}
    th_level = _town_hall_level(profile)
    if building.building_type != "th" and building.level >= th_level:
        return {"ok": False, "code": "town_hall", "detail": "اول تالار شهر را ارتقا بده."}
    if building.building_type == "th":
        need = R.TOWN_HALL_DP[min(building.level + 1, len(R.TOWN_HALL_DP) - 1)]
        if profile.discovery_points < need:
            return {
                "ok": False,
                "code": "discovery_points",
                "detail": f"{need} امتیاز کشف لازم است (کشف شهر در فاز ۱ فعال نیست).",
            }
    cost = R.upgrade_cost(building.building_type, building.level)
    if profile.coins < cost:
        return {"ok": False, "code": "insufficient_coins", "detail": f"{cost - profile.coins} سکهٔ دیگر لازم است.", "cost": cost}
    return {"ok": True, "cost": cost}


def buildings_payload(profile: GameProfile) -> dict[str, Any]:
    sync_builder(profile)
    profile = GameProfile.objects.get(pk=profile.pk)
    th_level = _town_hall_level(profile)
    builder = BuilderJob.objects.filter(profile=profile).first()
    items = []
    for building in profile.buildings.all().order_by("key"):
        meta = R.BUILDING_TYPES.get(building.building_type, {})
        check = building_can_upgrade(profile, building)
        items.append(
            {
                "key": building.key,
                "type": building.building_type,
                "name": meta.get("name", building.building_type),
                "art": meta.get("art", building.building_type),
                "grid_x": building.grid_x,
                "grid_y": building.grid_y,
                "size": meta.get("size", 2),
                "level": building.level,
                "max_level": meta.get("max_level", 1),
                "effect": meta.get("effect", ""),
                "next_effect": _effect_line(building.building_type, building.level + 1),
                "upgrade_cost": R.upgrade_cost(building.building_type, building.level)
                if check.get("code") not in ("max_level", "not_upgradable")
                else 0,
                "upgrade_seconds": R.upgrade_seconds(building.level),
                "can_upgrade": bool(check.get("ok")),
                "blocked_reason": check.get("detail", ""),
                "blocked_code": check.get("code", ""),
            }
        )
    return {
        "town_hall_level": th_level,
        "discovery_points": profile.discovery_points,
        "buildings": items,
        "builder": {
            "busy": bool(builder),
            "building_key": builder.building_key if builder else None,
            "finish_at": builder.finish_at if builder else None,
            "remaining_seconds": max(0, int((builder.finish_at - timezone.now()).total_seconds()))
            if builder
            else 0,
        },
    }


def _effect_line(building_type: str, level: int) -> str:
    return {
        "th": f"سقف سطح ساختمان‌ها: {level}",
        "vault": f"ظرفیت {R.vault_capacity(level)} سکه",
        "camp": f"{R.camp_rate(level)} سکه در ساعت",
        "mine": f"{R.mine_rate(level)} الماس در ساعت",
        "tower": f"جان برج‌های تو در آوردگاه +{round(2.5 * (level - 1))}٪",
        "bazaar": f"پاداش سکهٔ پیشنهادها +{15 * (level - 1)}٪",
        "fountain": f"تجربهٔ همهٔ فعالیت‌ها +{4 * (level - 1)}٪",
    }.get(building_type, "")


def start_building_upgrade(profile: GameProfile, building_key: str) -> dict[str, Any]:
    with transaction.atomic():
        locked = GameProfile.objects.select_for_update().get(pk=profile.pk)
        _apply_finished_job(locked)
        building = Building.objects.filter(profile=locked, key=building_key).first()
        if building is None:
            return {"ok": False, "code": "building_not_found", "detail": "ساختمان پیدا نشد."}
        check = building_can_upgrade(locked, building)
        if not check.get("ok"):
            return check
        cost = check["cost"]
        if not spend_coins(
            locked, cost, LedgerEntry.Reason.BUILDING_UPGRADE.value,
            reference=f"building:{building_key}",
            idempotency_key=f"bupg:{profile.id}:{building_key}:{building.level}",
        ):
            return {"ok": False, "code": "insufficient_coins", "detail": "سکهٔ کافی نداری."}
        finish_at = timezone.now() + timedelta(seconds=R.upgrade_seconds(building.level))
        BuilderJob.objects.update_or_create(
            profile=locked,
            defaults={"building_key": building_key, "started_at": timezone.now(), "finish_at": finish_at},
        )
    return {
        "ok": True,
        "building_key": building_key,
        "cost": cost,
        "finish_at": finish_at,
        "coins": GameProfile.objects.get(pk=profile.pk).coins,
    }


def complete_building_upgrade(profile: GameProfile, building_key: str) -> dict[str, Any]:
    with transaction.atomic():
        locked = GameProfile.objects.select_for_update().get(pk=profile.pk)
        job = BuilderJob.objects.filter(profile=locked, building_key=building_key).first()
        if job is None:
            return {"ok": False, "code": "no_job", "detail": "ساختاری در حال ارتقا نیست."}
        if job.finish_at > timezone.now():
            return {
                "ok": False,
                "code": "not_ready",
                "detail": "زمان ارتقا تمام نشده است.",
                "remaining_seconds": int((job.finish_at - timezone.now()).total_seconds()),
            }
        _apply_finished_job(locked)
    return {"ok": True, "buildings": buildings_payload(profile)}


# ---------------------------------------------------------------------------
# Chests
# ---------------------------------------------------------------------------


def _sync_chest(slot: ChestSlot) -> ChestSlot:
    if slot.state == ChestSlot.State.OPENING and slot.ready_at and slot.ready_at <= timezone.now():
        slot.state = ChestSlot.State.READY
        slot.save(update_fields=["state"])
    return slot


def chests_payload(profile: GameProfile) -> dict[str, Any]:
    ensure_chest_slots(profile)
    slots = []
    now = timezone.now()
    for slot in ChestSlot.objects.filter(profile=profile).order_by("index"):
        slot = _sync_chest(slot)
        remaining = 0
        if slot.state == ChestSlot.State.OPENING and slot.ready_at:
            remaining = max(0, int((slot.ready_at - now).total_seconds()))
        meta = R.CHEST_TYPES.get(slot.kind, {})
        slots.append(
            {
                "index": slot.index,
                "kind": slot.kind,
                "kind_name": meta.get("name", ""),
                "state": slot.state,
                "ready_at": slot.ready_at,
                "remaining_seconds": remaining,
                "minutes": meta.get("minutes", 0),
                "cards": meta.get("cards", 0),
                "coins_min": meta.get("coins", (0, 0))[0],
                "coins_max": meta.get("coins", (0, 0))[1],
                "gems_min": meta.get("gems", (0, 0))[0] if meta.get("gems") else 0,
                "gems_max": meta.get("gems", (0, 0))[1] if meta.get("gems") else 0,
            }
        )
    return {"slots": slots}


def ensure_chest_slots(profile: GameProfile) -> None:
    existing = set(ChestSlot.objects.filter(profile=profile).values_list("index", flat=True))
    for index in range(R.CHEST_SLOTS):
        if index not in existing:
            ChestSlot.objects.create(profile=profile, index=index, kind="", state=ChestSlot.State.EMPTY)


def award_chest(profile: GameProfile, kind: str) -> int | None:
    ensure_chest_slots(profile)
    slot = ChestSlot.objects.filter(profile=profile, state=ChestSlot.State.EMPTY).order_by("index").first()
    if slot is None:
        return None
    slot.kind = kind
    slot.state = ChestSlot.State.LOCKED
    slot.ready_at = None
    slot.save(update_fields=["kind", "state", "ready_at"])
    return slot.index


def start_chest(profile: GameProfile, index: int) -> dict[str, Any]:
    with transaction.atomic():
        slot = ChestSlot.objects.select_for_update().filter(profile=profile, index=index).first()
        if slot is None:
            return {"ok": False, "code": "slot_missing", "detail": "جایگاه صندوق پیدا نشد."}
        _sync_chest(slot)
        if slot.state == ChestSlot.State.EMPTY:
            return {"ok": False, "code": "empty", "detail": "این جایگاه خالی است."}
        if slot.state == ChestSlot.State.OPENING:
            return {"ok": False, "code": "already_opening", "detail": "این صندوق در حال باز شدن است."}
        if slot.state == ChestSlot.State.READY:
            return {"ok": False, "code": "ready", "detail": "این صندوق آمادهٔ دریافت است."}
        meta = R.CHEST_TYPES.get(slot.kind)
        if not meta:
            return {"ok": False, "code": "invalid_kind", "detail": "نوع صندوق نامعتبر است."}
        slot.state = ChestSlot.State.OPENING
        slot.ready_at = timezone.now() + timedelta(minutes=meta["minutes"])
        slot.save(update_fields=["state", "ready_at"])
    return {"ok": True, "chests": chests_payload(profile)}


def claim_chest(profile: GameProfile, index: int) -> dict[str, Any]:
    with transaction.atomic():
        slot = ChestSlot.objects.select_for_update().filter(profile=profile, index=index).first()
        if slot is None:
            return {"ok": False, "code": "slot_missing", "detail": "جایگاه صندوق پیدا نشد."}
        _sync_chest(slot)
        if slot.state != ChestSlot.State.READY:
            return {"ok": False, "code": "not_ready", "detail": "این صندوق آمادهٔ دریافت نیست."}
        meta = R.CHEST_TYPES.get(slot.kind)
        if not meta:
            return {"ok": False, "code": "invalid_kind", "detail": "نوع صندوق نامعتبر است."}
        rng = random.Random(f"{profile.id}:{index}:{slot.kind}:{slot.pk}")
        coin_low, coin_high = meta["coins"]
        coins = rng.randint(coin_low, coin_high)
        gems = 0
        if meta.get("gems"):
            gems = rng.randint(meta["gems"][0], meta["gems"][1])
        card_pool = list(R.STARTER_CARDS)
        cards = [rng.choice(card_pool) for _ in range(3 if slot.kind == "silver" else 5)]
        kind = slot.kind
        claim_ref = uuid.uuid4().hex
        # Consume the chest before granting anything (idempotent claim). The
        # row lock plus the state transition is the real idempotency guard; the
        # per-claim token keeps ledger keys unique across repeated slot reuse.
        slot.state = ChestSlot.State.EMPTY
        slot.kind = ""
        slot.ready_at = None
        slot.save(update_fields=["state", "kind", "ready_at"])

        apply_delta(profile, "coins", coins, LedgerEntry.Reason.CHEST_REWARD.value,
                    reference=f"chest:{index}:{kind}", idempotency_key=f"chest:{slot.pk}:{claim_ref}:coins")
        if gems:
            apply_delta(profile, "gems", gems, LedgerEntry.Reason.CHEST_REWARD.value,
                        reference=f"chest:{index}:{kind}", idempotency_key=f"chest:{slot.pk}:{claim_ref}:gems")
        for card_key in cards:
            if card_key in R.CARDS:
                grant_card(profile, card_key)
    return {
        "ok": True,
        "kind": kind,
        "rewards": {"coins": coins, "gems": gems, "cards": cards},
        "chests": chests_payload(profile),
        "profile": profile_payload(profile),
    }


# ---------------------------------------------------------------------------
# Battles
# ---------------------------------------------------------------------------


def _opponent(profile: GameProfile, seed: int) -> dict[str, Any]:
    rng = random.Random(seed)
    league = R.league_index(profile.trophies)
    return {
        "name": rng.choice(R.OPPONENT_NAMES),
        "league": league,
        "league_name": R.LEAGUES[league]["name"],
        "card_level": R.foe_card_level(profile.trophies),
    }


def _deck_levels(profile: GameProfile) -> tuple[list[str], dict[str, int]]:
    owned = {c.card_key: c.level for c in profile.cards.all()}
    deck = [d.card_key for d in profile.deck.all().order_by("slot")]
    if len(deck) != R.DECK_SIZE:
        deck = list(R.STARTER_CARDS[: R.DECK_SIZE])
    return deck, {key: owned.get(key, 1) for key in deck}


def battle_payload(battle: Battle) -> dict[str, Any]:
    return {
        "battle_key": battle.key,
        "mode": battle.mode,
        "status": battle.status,
        "difficulty": battle.difficulty,
        "opponent": battle.opponent_name,
        "snapshot": combat.snapshot(battle.state or {}),
        "rewards": battle.rewards or {},
        "result": battle.result,
    }


def start_arena(profile: GameProfile) -> dict[str, Any]:
    deck, levels = _deck_levels(profile)
    if not profile.first_battle_done:
        profile.first_battle_done = True
        profile.save(update_fields=["first_battle_done"])
    seed = random.randint(1, 2**31 - 1)
    difficulty = R.battle_difficulty(profile.trophies, not profile.total_wins)
    opponent = _opponent(profile, seed)
    state = combat.arena_new(deck, levels, seed, difficulty, opponent)
    battle = Battle.objects.create(
        profile=profile,
        mode=Battle.Mode.ARENA,
        status=Battle.Status.ACTIVE,
        seed=seed,
        config={"deck": deck, "levels": levels, "difficulty": difficulty},
        state=state,
        last_tick=0,
        opponent_name=opponent["name"],
        difficulty=difficulty,
    )
    return {"ok": True, "battle": battle_payload(battle)}


def start_siege(profile: GameProfile) -> dict[str, Any]:
    _, levels = _deck_levels(profile)
    th_level = _town_hall_level(profile)
    seed = random.randint(1, 2**31 - 1)
    opponent = _opponent(profile, seed)
    state = combat.siege_new(levels, th_level, seed, opponent)
    battle = Battle.objects.create(
        profile=profile,
        mode=Battle.Mode.SIEGE,
        status=Battle.Status.ACTIVE,
        seed=seed,
        config={"levels": levels, "th_level": th_level},
        state=state,
        last_tick=0,
        opponent_name=opponent["name"],
        difficulty="normal",
    )
    return {"ok": True, "battle": battle_payload(battle)}


def _locked_battle(profile: GameProfile, battle_key: str) -> Battle | None:
    return (
        Battle.objects.select_for_update()
        .filter(key=battle_key, profile=profile)
        .first()
    )


def arena_action(profile: GameProfile, battle_key: str, elapsed: float,
                 index: int | None = None, x: float | None = None,
                 y: float | None = None) -> dict[str, Any]:
    with transaction.atomic():
        battle = _locked_battle(profile, battle_key)
        if battle is None:
            return {"ok": False, "code": "battle_not_found", "detail": "نبرد پیدا نشد."}
        if battle.status != Battle.Status.ACTIVE:
            return {"ok": False, "code": "battle_not_active", "detail": "این نبرد فعال نیست.", "battle": battle_payload(battle)}
        if battle.mode != Battle.Mode.ARENA:
            return {"ok": False, "code": "wrong_mode", "detail": "حالت نبرد نامعتبر است."}
        state = battle.state
        target = min(max(0.0, float(elapsed or 0)), float(state.get("limit", R.ARENA_LIMIT)))
        combat.step(state, target)
        deploy_error = None
        if index is not None and x is not None and y is not None and not state.get("ended"):
            result = combat.arena_deploy(state, int(index), float(x), float(y))
            if not result.get("ok"):
                deploy_error = result
        if state.get("ended") and battle.status == Battle.Status.ACTIVE:
            # Settlement is explicit via finish; keep the battle active so the
            # client still receives the finished snapshot and results screen.
            pass
        battle.state = state
        battle.last_tick = int(float(state.get("t", 0)) / combat.DT)
        battle.save(update_fields=["state", "last_tick"])
    payload: dict[str, Any] = {"ok": True, "battle": battle_payload(battle)}
    if deploy_error:
        payload["deploy_error"] = deploy_error
    return payload


def siege_action(profile: GameProfile, battle_key: str, elapsed: float,
                 index: int | None = None, gx: float | None = None,
                 gy: float | None = None) -> dict[str, Any]:
    with transaction.atomic():
        battle = _locked_battle(profile, battle_key)
        if battle is None:
            return {"ok": False, "code": "battle_not_found", "detail": "نبرد پیدا نشد."}
        if battle.status != Battle.Status.ACTIVE:
            return {"ok": False, "code": "battle_not_active", "detail": "این نبرد فعال نیست.", "battle": battle_payload(battle)}
        if battle.mode != Battle.Mode.SIEGE:
            return {"ok": False, "code": "wrong_mode", "detail": "حالت نبرد نامعتبر است."}
        state = battle.state
        target = min(max(0.0, float(elapsed or 0)), float(state.get("limit", R.SIEGE_LIMIT)))
        combat.step(state, target)
        deploy_error = None
        if index is not None and gx is not None and gy is not None and not state.get("ended"):
            result = combat.siege_deploy(state, int(index), float(gx), float(gy))
            if not result.get("ok"):
                deploy_error = result
        battle.state = state
        battle.last_tick = int(float(state.get("t", 0)) / combat.DT)
        battle.save(update_fields=["state", "last_tick"])
    payload: dict[str, Any] = {"ok": True, "battle": battle_payload(battle)}
    if deploy_error:
        payload["deploy_error"] = deploy_error
    return payload


def finish_battle(profile: GameProfile, battle_key: str) -> dict[str, Any]:
    with transaction.atomic():
        battle = _locked_battle(profile, battle_key)
        if battle is None:
            return {"ok": False, "code": "battle_not_found", "detail": "نبرد پیدا نشد."}
        if battle.status == Battle.Status.SETTLED:
            return {
                "ok": True,
                "already_settled": True,
                "battle": battle_payload(battle),
                "rewards": battle.rewards or {},
                "profile": profile_payload(profile),
                "chests": chests_payload(profile),
            }
        if battle.status != Battle.Status.ACTIVE:
            return {"ok": False, "code": "battle_not_active", "detail": "این نبرد فعال نیست."}

        state = battle.state
        combat.finalize(state)
        result = state.get("result") or "loss"
        mode = battle.mode
        score = int(state.get("crowns", {}).get("p", 0)) if mode == Battle.Mode.ARENA else int(state.get("stars", 0))
        destruction = int(state.get("destruction", 0))

        locked = GameProfile.objects.select_for_update().get(pk=profile.pk)
        trophies_before = locked.trophies
        league_before = league_payload(trophies_before)
        difficulty = battle.difficulty or "normal"

        if mode == Battle.Mode.ARENA:
            base = R.arena_rewards(result, score, trophies_before)
        else:
            loot = 450 + (1 + league_before["index"]) * 220
            base = R.siege_rewards(score, destruction, loot, result)
        coins = int(base["coins"])
        xp = int(base["xp"])
        delta = R.trophy_delta(result, "siege" if mode == Battle.Mode.SIEGE else "arena", score)
        new_trophies = max(0, trophies_before + delta)

        apply_delta(locked, "coins", coins, LedgerEntry.Reason.BATTLE_REWARD.value,
                    reference=f"battle:{battle.key}", idempotency_key=f"battle:{battle.key}:coins")
        apply_delta(locked, "xp", xp, LedgerEntry.Reason.BATTLE_REWARD.value,
                    reference=f"battle:{battle.key}", idempotency_key=f"battle:{battle.key}:xp")
        if delta:
            apply_delta(locked, "trophies", delta, LedgerEntry.Reason.BATTLE_TROPHY.value,
                        reference=f"battle:{battle.key}", idempotency_key=f"battle:{battle.key}:trophies")

        locked.best_trophies = max(locked.best_trophies, new_trophies)
        if mode == Battle.Mode.ARENA:
            locked.arena_played += 1
            locked.arena_crowns += score
            if result == "win":
                locked.arena_wins += 1
                locked.total_wins += 1
        else:
            locked.siege_played += 1
            locked.siege_stars += score
            if result == "win":
                locked.siege_wins += 1
                locked.total_wins += 1
        locked.save()

        chest_awarded = None
        chest_kind = None
        if result == "win":
            chest_kind = R.chest_kind_for("siege" if mode == Battle.Mode.SIEGE else "arena", score, locked.total_wins)
            chest_index = award_chest(locked, chest_kind)
            if chest_index is not None:
                chest_awarded = {"index": chest_index, "kind": chest_kind}

        league_after = league_payload(new_trophies)
        rewards = {
            "coins": coins,
            "xp": xp,
            "trophies": delta,
            "trophies_before": trophies_before,
            "trophies_after": new_trophies,
            "league_before": league_before["name"],
            "league_after": league_after["name"],
            "promoted": league_after["index"] > league_before["index"],
            "demoted": league_after["index"] < league_before["index"],
            "chest": chest_awarded,
            "score": score,
            "destruction": destruction,
            "result": result,
            "mode": "siege" if mode == Battle.Mode.SIEGE else "arena",
        }
        battle.state = state
        battle.status = Battle.Status.SETTLED
        battle.result = result
        battle.score = score
        battle.destruction = destruction
        battle.rewards = rewards
        battle.settled_at = timezone.now()
        battle.save()

    return {
        "ok": True,
        "battle": battle_payload(battle),
        "rewards": rewards,
        "profile": profile_payload(profile),
        "chests": chests_payload(profile),
    }


def battles_payload(profile: GameProfile, limit: int = 12) -> list[dict[str, Any]]:
    battles = Battle.objects.filter(profile=profile).order_by("-created_at")[:limit]
    return [
        {
            "key": b.key,
            "mode": b.mode,
            "status": b.status,
            "result": b.result,
            "score": b.score,
            "destruction": b.destruction,
            "opponent": b.opponent_name,
            "created_at": b.created_at,
            "rewards": b.rewards or {},
        }
        for b in battles
    ]
