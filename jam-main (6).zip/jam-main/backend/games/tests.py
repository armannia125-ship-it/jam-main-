"""JamPlay API and engine tests.

Covers the Phase 1 surface: profile bootstrap, cards/deck, building upgrades
and the shared builder, chest lifecycle and idempotent claims, arena and siege
battle lifecycles (server-authoritative), league payloads, ledger integrity and
cross-owner isolation.
"""

from __future__ import annotations

import unittest
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.db import connection
from django.test import TestCase as DjangoTestCase
from django.utils import timezone
from rest_framework.test import APITestCase

from . import combat, rules as R
from .models import Battle, BuilderJob, ChestSlot, GameProfile, LedgerEntry, PlayerCard
from .services import award_chest, get_profile

User = get_user_model()

PROFILE = "/api/games/profile/"
CARDS = "/api/games/cards/"
CARD_UPGRADE = "/api/games/cards/upgrade/"
DECK = "/api/games/deck/"
BUILDINGS = "/api/games/buildings/"
BUILDING_UPGRADE = "/api/games/buildings/upgrade/"
BUILDING_COMPLETE = "/api/games/buildings/complete/"
CHESTS = "/api/games/chests/"
ARENA_START = "/api/games/arena/start/"
ARENA_ACTION = "/api/games/arena/action/"
ARENA_FINISH = "/api/games/arena/finish/"
SIEGE_START = "/api/games/siege/start/"
SIEGE_ACTION = "/api/games/siege/action/"
SIEGE_FINISH = "/api/games/siege/finish/"
LEAGUE = "/api/games/league/"


class BaseApiTest(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(phone="+989120000001", password="secret123")
        self.client.force_authenticate(user=self.user)

    def other_user(self):
        other = User.objects.create_user(phone="+989120000002", password="secret123")
        return other


class ProfileTests(BaseApiTest):
    def test_profile_bootstraps_wallet_cards_deck_buildings_chests(self):
        response = self.client.get(PROFILE)
        self.assertEqual(response.status_code, 200, response.data)
        data = response.data
        self.assertEqual(data["coins"], R.STARTING_COINS)
        self.assertEqual(data["gems"], R.STARTING_GEMS)
        self.assertEqual(len(data["deck"]), R.DECK_SIZE)
        self.assertTrue(all(card["owned"] for card in data["deck"]))
        self.assertEqual(data["league"]["index"], 0)
        self.assertEqual(data["town_hall_level"], 3)
        self.assertEqual(GameProfile.objects.count(), 1)
        self.assertEqual(ChestSlot.objects.filter(profile__user=self.user).count(), R.CHEST_SLOTS)
        self.assertEqual(PlayerCard.objects.filter(profile__user=self.user).count(), len(R.STARTER_CARDS))

    def test_profile_is_owner_scoped(self):
        self.client.get(PROFILE)
        other = self.other_user()
        self.client.force_authenticate(user=other)
        response = self.client.get(PROFILE)
        self.assertEqual(response.status_code, 200)
        self.assertNotEqual(response.data["id"], GameProfile.objects.get(user=self.user).id)

    def test_profile_requires_authentication(self):
        self.client.force_authenticate(user=None)
        self.assertEqual(self.client.get(PROFILE).status_code, 401)


class DeckTests(BaseApiTest):
    def setUp(self):
        super().setUp()
        self.client.get(PROFILE)

    def test_set_valid_deck(self):
        keys = list(R.STARTER_CARDS[: R.DECK_SIZE])
        keys.reverse()
        response = self.client.post(DECK, {"cards": keys}, format="json")
        self.assertEqual(response.status_code, 200, response.data)
        self.assertEqual([card["key"] for card in response.data["deck"]], keys)

    def test_deck_size_enforced(self):
        response = self.client.post(DECK, {"cards": ["guard", "archer"]}, format="json")
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data["code"], "deck_size")

    def test_deck_rejects_unowned_and_duplicates(self):
        response = self.client.post(DECK, {"cards": ["heal"] + list(R.STARTER_CARDS[:7])}, format="json")
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data["code"], "deck_unowned")
        response = self.client.post(DECK, {"cards": ["guard"] * R.DECK_SIZE}, format="json")
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data["code"], "deck_duplicate")


class CardUpgradeTests(BaseApiTest):
    def setUp(self):
        super().setUp()
        self.client.get(PROFILE)
        self.profile = GameProfile.objects.get(user=self.user)

    def test_card_upgrade_deducts_coins_and_copies(self):
        card = PlayerCard.objects.get(profile=self.profile, card_key="guard")
        card.copies = 5
        card.save()
        before = self.profile.coins
        response = self.client.post(CARD_UPGRADE, {"card_key": "guard"}, format="json")
        self.assertEqual(response.status_code, 200, response.data)
        card.refresh_from_db()
        self.assertEqual(card.level, 2)
        self.assertEqual(card.copies, 5 - R.card_upgrade_copies(1))
        self.assertEqual(GameProfile.objects.get(pk=self.profile.pk).coins, before - R.card_upgrade_cost(1))
        entry = LedgerEntry.objects.filter(profile=self.profile, reason="card_upgrade").first()
        self.assertIsNotNone(entry)
        self.assertEqual(entry.delta, -R.card_upgrade_cost(1))

    def test_card_upgrade_requires_copies(self):
        response = self.client.post(CARD_UPGRADE, {"card_key": "guard"}, format="json")
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data["code"], "copies")


class BuildingTests(BaseApiTest):
    def setUp(self):
        super().setUp()
        self.client.get(PROFILE)
        self.profile = GameProfile.objects.get(user=self.user)

    def test_buildings_payload_and_upgrade_flow(self):
        response = self.client.get(BUILDINGS)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["town_hall_level"], 3)
        self.assertFalse(response.data["builder"]["busy"])
        self.assertEqual(len(response.data["buildings"]), len(R.BASE_LAYOUT))

        before = GameProfile.objects.get(pk=self.profile.pk).coins
        response = self.client.post(BUILDING_UPGRADE, {"building_key": "vault"}, format="json")
        self.assertEqual(response.status_code, 200, response.data)
        self.assertEqual(response.data["cost"], R.upgrade_cost("vault", 1))
        self.assertEqual(GameProfile.objects.get(pk=self.profile.pk).coins, before - R.upgrade_cost("vault", 1))
        self.assertTrue(BuilderJob.objects.filter(profile=self.profile, building_key="vault").exists())

        # Builder is busy: a second upgrade must be rejected.
        response = self.client.post(BUILDING_UPGRADE, {"building_key": "camp"}, format="json")
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data["code"], "builder_busy")

        # Completion before the timer ends is rejected.
        response = self.client.post(BUILDING_COMPLETE, {"building_key": "vault"}, format="json")
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data["code"], "not_ready")

        job = BuilderJob.objects.get(profile=self.profile)
        job.finish_at = timezone.now() - timedelta(seconds=1)
        job.save(update_fields=["finish_at"])
        response = self.client.post(BUILDING_COMPLETE, {"building_key": "vault"}, format="json")
        self.assertEqual(response.status_code, 200, response.data)
        vault = next(b for b in response.data["buildings"]["buildings"] if b["key"] == "vault")
        self.assertEqual(vault["level"], 2)
        self.assertFalse(response.data["buildings"]["builder"]["busy"])

    def test_building_upgrade_respects_town_hall_cap(self):
        response = self.client.get(BUILDINGS)
        vault = next(b for b in response.data["buildings"] if b["key"] == "vault")
        self.assertTrue(vault["can_upgrade"])
        vault_db = self.profile.buildings.get(key="vault")
        vault_db.level = 3
        vault_db.save(update_fields=["level"])
        response = self.client.post(BUILDING_UPGRADE, {"building_key": "vault"}, format="json")
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data["code"], "town_hall")

    def test_builder_completion_persists_after_reload(self):
        self.client.post(BUILDING_UPGRADE, {"building_key": "mine"}, format="json")
        job = BuilderJob.objects.get(profile=self.profile)
        job.finish_at = timezone.now() - timedelta(seconds=1)
        job.save(update_fields=["finish_at"])
        # A plain reload lazily applies the finished job.
        response = self.client.get(BUILDINGS)
        mine = next(b for b in response.data["buildings"] if b["key"] == "mine")
        self.assertEqual(mine["level"], 2)


class ChestTests(BaseApiTest):
    def setUp(self):
        super().setUp()
        self.client.get(PROFILE)
        self.profile = GameProfile.objects.get(user=self.user)

    def test_welcome_chest_is_ready_and_claimable_once(self):
        response = self.client.get(CHESTS)
        self.assertEqual(response.status_code, 200)
        ready = response.data["slots"][0]
        self.assertEqual(ready["state"], "ready")

        coins_before = GameProfile.objects.get(pk=self.profile.pk).coins
        claim = self.client.post(f"/api/games/chests/0/claim/", {}, format="json")
        self.assertEqual(claim.status_code, 200, claim.data)
        self.assertGreater(claim.data["rewards"]["coins"], 0)
        self.assertTrue(claim.data["rewards"]["cards"])
        self.assertEqual(
            GameProfile.objects.get(pk=self.profile.pk).coins,
            coins_before + claim.data["rewards"]["coins"],
        )
        # Duplicate claim is rejected and grants nothing.
        again = self.client.post("/api/games/chests/0/claim/", {}, format="json")
        self.assertEqual(again.status_code, 400)
        self.assertEqual(again.data["code"], "not_ready")
        self.assertEqual(GameProfile.objects.get(pk=self.profile.pk).coins,
                         coins_before + claim.data["rewards"]["coins"])

    def test_chest_start_then_ready_and_claim(self):
        self.assertEqual(award_chest(self.profile, "gold"), 1)
        start = self.client.post("/api/games/chests/1/start/", {}, format="json")
        self.assertEqual(start.status_code, 200, start.data)
        slot = ChestSlot.objects.get(profile=self.profile, index=1)
        self.assertEqual(slot.state, "opening")
        self.assertIsNotNone(slot.ready_at)

        # Timer is server-controlled: not claimable yet.
        early = self.client.post("/api/games/chests/1/claim/", {}, format="json")
        self.assertEqual(early.status_code, 400)
        self.assertEqual(early.data["code"], "not_ready")

        slot.ready_at = timezone.now() - timedelta(seconds=1)
        slot.save(update_fields=["ready_at"])
        list_response = self.client.get(CHESTS)
        self.assertEqual(list_response.data["slots"][1]["state"], "ready")
        claim = self.client.post("/api/games/chests/1/claim/", {}, format="json")
        self.assertEqual(claim.status_code, 200, claim.data)
        self.assertEqual(claim.data["kind"], "gold")
        self.assertGreaterEqual(claim.data["rewards"]["gems"], 0)

    def test_start_rejects_empty_slot(self):
        response = self.client.post("/api/games/chests/2/start/", {}, format="json")
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data["code"], "empty")


class ArenaApiTests(BaseApiTest):
    def setUp(self):
        super().setUp()
        self.client.get(PROFILE)
        self.profile = GameProfile.objects.get(user=self.user)

    def start(self):
        response = self.client.post(ARENA_START, {}, format="json")
        self.assertEqual(response.status_code, 201, response.data)
        return response.data["battle"]

    def test_start_returns_authoritative_snapshot(self):
        battle = self.start()
        snapshot = battle["snapshot"]
        self.assertEqual(snapshot["mode"], "arena")
        self.assertEqual(len(snapshot["hand"]), R.HAND_SIZE)
        self.assertEqual(len(snapshot["towers"]), 6)
        self.assertEqual(snapshot["elixir"], 5.0)
        self.assertEqual(snapshot["crowns"], {"p": 0, "e": 0})
        self.assertEqual(snapshot["limit"], R.ARENA_LIMIT)

    def test_deploy_spends_elixir_and_spawns_unit(self):
        battle = self.start()
        response = self.client.post(
            ARENA_ACTION,
            {"battle_key": battle["battle_key"], "elapsed": 0, "index": 0, "x": 300, "y": 700},
            format="json",
        )
        self.assertEqual(response.status_code, 200, response.data)
        snapshot = response.data["battle"]["snapshot"]
        self.assertNotIn("deploy_error", response.data)
        self.assertLess(snapshot["elixir"], 5.0)
        self.assertTrue(any(u["team"] == 0 for u in snapshot["units"]))

    def test_deploy_rejects_insufficient_elixir(self):
        battle = self.start()
        key = battle["battle_key"]
        first = self.client.post(ARENA_ACTION, {"battle_key": key, "elapsed": 0, "index": 0, "x": 300, "y": 700}, format="json")
        self.assertEqual(first.status_code, 200)
        second = self.client.post(ARENA_ACTION, {"battle_key": key, "elapsed": 0, "index": 1, "x": 300, "y": 700}, format="json")
        self.assertEqual(second.status_code, 200)
        self.assertIn("deploy_error", second.data)
        self.assertEqual(second.data["deploy_error"]["code"], "not_enough_elixir")

    def test_deploy_rejects_enemy_half(self):
        battle = self.start()
        response = self.client.post(
            ARENA_ACTION,
            {"battle_key": battle["battle_key"], "elapsed": 0, "index": 0, "x": 300, "y": 320},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["deploy_error"]["code"], "own_half_only")

    def test_sync_advances_elixir_server_side(self):
        battle = self.start()
        response = self.client.post(
            ARENA_ACTION,
            {"battle_key": battle["battle_key"], "elapsed": 10},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        snapshot = response.data["battle"]["snapshot"]
        self.assertGreaterEqual(snapshot["t"], 9.9)
        self.assertGreater(snapshot["elixir"], 5.0)

    def test_finish_settles_once_with_rewards_and_chest(self):
        battle = self.start()
        db_battle = Battle.objects.get(key=battle["battle_key"])
        state = db_battle.state
        state["ended"] = True
        state["result"] = "win"
        state["crowns"] = {"p": 3, "e": 0}
        for tower in state["towers"]:
            if tower["team"] == 1:
                tower["hp"] = 0
        db_battle.state = state
        db_battle.save(update_fields=["state"])

        coins_before = GameProfile.objects.get(pk=self.profile.pk).coins
        response = self.client.post(ARENA_FINISH, {"battle_key": battle["battle_key"]}, format="json")
        self.assertEqual(response.status_code, 200, response.data)
        self.assertTrue(response.data["rewards"]["coins"] > 0)
        self.assertIsNotNone(response.data["rewards"]["chest"])
        after = GameProfile.objects.get(pk=self.profile.pk)
        self.assertEqual(after.coins, coins_before + response.data["rewards"]["coins"])
        self.assertGreater(after.trophies, 0)
        self.assertEqual(after.arena_wins, 1)

        again = self.client.post(ARENA_FINISH, {"battle_key": battle["battle_key"]}, format="json")
        self.assertEqual(again.status_code, 200)
        self.assertTrue(again.data.get("already_settled"))
        # A retried finish must return the same result screen payload, not just ok.
        self.assertEqual(again.data["rewards"], response.data["rewards"])
        self.assertEqual(again.data["profile"]["coins"], after.coins)
        self.assertIn("chests", again.data)
        self.assertEqual(GameProfile.objects.get(pk=self.profile.pk).coins, after.coins)
        self.assertEqual(
            LedgerEntry.objects.filter(
                profile=self.profile, reason="battle_reward", reference__startswith="battle:"
            ).count(),
            2,  # coins + xp for a single settlement
        )


class SiegeApiTests(BaseApiTest):
    def setUp(self):
        super().setUp()
        self.client.get(PROFILE)
        self.profile = GameProfile.objects.get(user=self.user)

    def start(self):
        response = self.client.post(SIEGE_START, {}, format="json")
        self.assertEqual(response.status_code, 201, response.data)
        return response.data["battle"]

    def test_start_returns_base_and_army(self):
        battle = self.start()
        snapshot = battle["snapshot"]
        self.assertEqual(snapshot["mode"], "siege")
        self.assertGreaterEqual(len(snapshot["buildings"]), 6)
        self.assertTrue(any(b["t"] == "th" for b in snapshot["buildings"]))
        self.assertGreater(len(snapshot["walls"]), 20)
        self.assertTrue(all(a["count"] > 0 for a in snapshot["army"]))
        self.assertEqual(snapshot["stars"], 0)

    def test_deploy_only_outside_walls(self):
        battle = self.start()
        key = battle["battle_key"]
        outside = self.client.post(
            SIEGE_ACTION,
            {"battle_key": key, "elapsed": 0, "index": 0, "gx": 1, "gy": 20},
            format="json",
        )
        self.assertEqual(outside.status_code, 200)
        self.assertNotIn("deploy_error", outside.data)
        self.assertTrue(any(u["team"] == 0 for u in outside.data["battle"]["snapshot"]["units"]))

        inside = self.client.post(
            SIEGE_ACTION,
            {"battle_key": key, "elapsed": 0, "index": 0, "gx": 11, "gy": 11},
            format="json",
        )
        self.assertEqual(inside.status_code, 200)
        self.assertEqual(inside.data["deploy_error"]["code"], "outside_walls")

    def test_siege_finish_settles_and_persists(self):
        battle = self.start()
        db_battle = Battle.objects.get(key=battle["battle_key"])
        state = db_battle.state
        state["ended"] = True
        state["result"] = "win"
        state["stars"] = 3
        state["destruction"] = 100
        for building in state["buildings"]:
            building["hp"] = 0
        db_battle.state = state
        db_battle.save(update_fields=["state"])

        response = self.client.post(SIEGE_FINISH, {"battle_key": battle["battle_key"]}, format="json")
        self.assertEqual(response.status_code, 200, response.data)
        self.assertEqual(response.data["rewards"]["result"], "win")
        self.assertEqual(response.data["rewards"]["score"], 3)
        self.assertGreater(response.data["rewards"]["trophies"], 0)
        self.assertEqual(GameProfile.objects.get(pk=self.profile.pk).siege_wins, 1)


class OwnershipTests(BaseApiTest):
    def test_cannot_act_on_another_players_battle(self):
        self.client.get(PROFILE)
        response = self.client.post(ARENA_START, {}, format="json")
        key = response.data["battle"]["battle_key"]
        self.client.force_authenticate(user=self.other_user())
        self.client.get(PROFILE)
        action = self.client.post(
            ARENA_ACTION, {"battle_key": key, "elapsed": 1}, format="json"
        )
        self.assertEqual(action.status_code, 400)
        self.assertEqual(action.data["code"], "battle_not_found")


class LedgerIntegrityTests(BaseApiTest):
    def test_ledger_sum_matches_wallet(self):
        self.client.get(PROFILE)
        profile = GameProfile.objects.get(user=self.user)
        ledger_sum = sum(e.delta for e in profile.ledger.filter(resource="coins"))
        self.assertEqual(ledger_sum, profile.coins)
        claim = self.client.post("/api/games/chests/0/claim/", {}, format="json")
        self.assertEqual(claim.status_code, 200)
        profile.refresh_from_db()
        ledger_sum = sum(e.delta for e in profile.ledger.filter(resource="coins"))
        self.assertEqual(ledger_sum, profile.coins)


class LeagueTests(BaseApiTest):
    def test_payload_and_thresholds(self):
        self.client.get(PROFILE)
        response = self.client.get(LEAGUE)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["league"]["index"], 0)
        self.assertEqual(response.data["league"]["next_min"], R.LEAGUES[1]["min"])
        self.assertEqual(len(response.data["thresholds"]), len(R.LEAGUES))


# ---------------------------------------------------------------------------
# Engine tests (no HTTP)
# ---------------------------------------------------------------------------


class ArenaEngineTests(DjangoTestCase):
    def new_state(self):
        return combat.arena_new(list(R.STARTER_CARDS[:8]), {}, 12345, "normal")

    def test_crowns_count_princess_towers(self):
        state = self.new_state()
        enemy_towers = [t for t in state["towers"] if t["team"] == 1 and not t["king"]]
        enemy_towers[0]["hp"] = 0
        self.assertEqual(combat.arena_crowns(state, 0), 1)
        enemy_towers[1]["hp"] = 0
        self.assertEqual(combat.arena_crowns(state, 0), 2)

    def test_king_destruction_ends_battle_with_three_crowns(self):
        state = self.new_state()
        king = next(t for t in state["towers"] if t["team"] == 1 and t["king"])
        king["hp"] = 0
        combat.arena_step(state, 0.1)
        self.assertTrue(state["ended"])
        self.assertEqual(state["result"], "win")
        self.assertEqual(state["crowns"]["p"], 3)

    def test_overtime_extends_limit_and_finishes(self):
        state = self.new_state()
        # Neutralise the AI so the battle cannot end early; this test is about
        # the timer/overtime transition only.
        state["ai_hand"] = []
        state["ai_queue"] = []
        combat.arena_step(state, 181)
        self.assertTrue(state["overtime"])
        self.assertEqual(state["limit"], R.ARENA_LIMIT + R.ARENA_OVERTIME)
        combat.arena_step(state, 400)
        self.assertTrue(state["ended"])
        self.assertEqual(state["reason"], "time")

    def test_deterministic_simulation(self):
        first = self.new_state()
        second = self.new_state()
        combat.arena_step(first, 25)
        combat.arena_step(second, 25)
        self.assertEqual(
            [(u["k"], round(u["x"], 2), round(u["y"], 2)) for u in first["units"]],
            [(u["k"], round(u["x"], 2), round(u["y"], 2)) for u in second["units"]],
        )


class SiegeEngineTests(DjangoTestCase):
    def test_base_init_and_destruction_progress(self):
        state = combat.siege_new({}, 3, 999)
        self.assertGreater(len(state["buildings"]), 0)
        self.assertGreater(len(state["walls"]), 20)
        self.assertEqual(state["destruction"], 0)
        self.assertEqual(state["stars"], 0)
        for building in state["buildings"]:
            building["hp"] = 0
        combat._siege_progress(state)  # noqa: SLF001 - white box progress check
        self.assertEqual(state["destruction"], 100)
        self.assertEqual(state["stars"], 3)

    def test_siege_step_runs_without_error(self):
        state = combat.siege_new({}, 3, 999)
        combat.siege_deploy(state, 0, 1, 20)
        combat.siege_step(state, 5)
        self.assertGreaterEqual(state["t"], 4.9)
        self.assertTrue(any(u["team"] == 0 for u in state["units"]))


@unittest.skipUnless(connection.vendor == "postgresql", "PostgreSQL-only concurrency test")
class BattleConcurrencyTests(APITestCase):
    def test_concurrent_settlement_is_idempotent(self):
        # PostgreSQL-only: relies on SELECT ... FOR UPDATE semantics.
        self.skipTest("covered by PostgreSQL concurrency environment")


class JourneyTests(BaseApiTest):
    """End-to-end API journeys against the real backend."""

    def setUp(self):
        super().setUp()
        self.client.get(PROFILE)
        self.profile = GameProfile.objects.get(user=self.user)

    def _force_end(self, key, result="win", score=3, destruction=100):
        battle = Battle.objects.get(key=key)
        state = battle.state
        state["ended"] = True
        state["result"] = result
        if battle.mode == "arena":
            state["crowns"] = {"p": score, "e": 0}
            for tower in state["towers"]:
                if tower["team"] == 1:
                    tower["hp"] = 0
        else:
            state["stars"] = score
            state["destruction"] = destruction
            for building in state["buildings"]:
                building["hp"] = 0
        battle.state = state
        battle.save(update_fields=["state"])
        return battle

    def test_arena_journey_auth_profile_deck_battle_rewards_reload(self):
        profile = self.client.get(PROFILE).data
        self.assertEqual(len(profile["deck"]), R.DECK_SIZE)

        keys = [card["key"] for card in profile["deck"]][::-1]
        self.assertEqual(self.client.post(DECK, {"cards": keys}, format="json").status_code, 200)

        start = self.client.post(ARENA_START, {}, format="json")
        self.assertEqual(start.status_code, 201)
        key = start.data["battle"]["battle_key"]

        deploy = self.client.post(
            ARENA_ACTION,
            {"battle_key": key, "elapsed": 0, "index": 0, "x": 300, "y": 700},
            format="json",
        )
        self.assertEqual(deploy.status_code, 200)
        self.assertNotIn("deploy_error", deploy.data)

        sync = self.client.post(ARENA_ACTION, {"battle_key": key, "elapsed": 20}, format="json")
        self.assertGreaterEqual(sync.data["battle"]["snapshot"]["t"], 19.9)

        self._force_end(key, score=3)
        finish = self.client.post(ARENA_FINISH, {"battle_key": key}, format="json")
        self.assertEqual(finish.status_code, 200)
        self.assertEqual(finish.data["rewards"]["result"], "win")

        reloaded = self.client.get(PROFILE).data
        self.assertEqual(reloaded["arena_wins"], 1)
        self.assertEqual(reloaded["trophies"], finish.data["rewards"]["trophies_after"])
        self.assertGreater(reloaded["coins"], profile["coins"])
        self.assertEqual(reloaded["deck"][0]["key"], keys[0])

        history = self.client.get("/api/games/battles/").data["battles"]
        self.assertEqual(history[0]["result"], "win")

    def test_siege_journey_prepare_deploy_finish_reload(self):
        start = self.client.post(SIEGE_START, {}, format="json")
        self.assertEqual(start.status_code, 201)
        battle = start.data["battle"]
        key = battle["battle_key"]
        self.assertTrue(battle["snapshot"]["army"])

        for gx, gy in ((1, 20), (2, 21), (20, 2)):
            response = self.client.post(
                SIEGE_ACTION,
                {"battle_key": key, "elapsed": 0, "index": 0, "gx": gx, "gy": gy},
                format="json",
            )
            self.assertEqual(response.status_code, 200)
        sync = self.client.post(SIEGE_ACTION, {"battle_key": key, "elapsed": 30}, format="json")
        self.assertGreaterEqual(sync.data["battle"]["snapshot"]["t"], 29.9)

        self._force_end(key, score=2, destruction=60)
        finish = self.client.post(SIEGE_FINISH, {"battle_key": key}, format="json")
        self.assertEqual(finish.status_code, 200)
        self.assertEqual(finish.data["rewards"]["score"], 2)
        self.assertGreater(finish.data["rewards"]["trophies"], 0)

        reloaded = self.client.get(PROFILE).data
        self.assertEqual(reloaded["siege_wins"], 1)
        self.assertGreaterEqual(reloaded["siege_stars"], 2)

    def test_base_journey_upgrade_complete_and_reload(self):
        payload = self.client.get(BUILDINGS).data
        target = next(
            building for building in payload["buildings"] if building["can_upgrade"]
        )
        coins_before = GameProfile.objects.get(pk=self.profile.pk).coins
        starts = self.client.post(BUILDING_UPGRADE, {"building_key": target["key"]}, format="json")
        self.assertEqual(starts.status_code, 200)
        self.assertEqual(starts.data["cost"], target["upgrade_cost"])

        reloaded = self.client.get(BUILDINGS).data
        self.assertTrue(reloaded["builder"]["busy"])
        self.assertEqual(reloaded["builder"]["building_key"], target["key"])

        job = BuilderJob.objects.get(profile=self.profile)
        job.finish_at = timezone.now() - timedelta(seconds=1)
        job.save(update_fields=["finish_at"])

        after = self.client.get(BUILDINGS).data
        upgraded = next(b for b in after["buildings"] if b["key"] == target["key"])
        self.assertEqual(upgraded["level"], target["level"] + 1)
        self.assertFalse(after["builder"]["busy"])
        self.assertEqual(
            GameProfile.objects.get(pk=self.profile.pk).coins,
            coins_before - target["upgrade_cost"],
        )
        # Second reload proves persistence.
        again = self.client.get(BUILDINGS).data
        stored = next(b for b in again["buildings"] if b["key"] == target["key"])
        self.assertEqual(stored["level"], target["level"] + 1)

    def test_chest_journey_win_start_ready_claim_once(self):
        self.assertEqual(self.client.get(CHESTS).data["slots"][0]["state"], "ready")
        welcome = self.client.post("/api/games/chests/0/claim/", {}, format="json")
        self.assertEqual(welcome.status_code, 200)

        start = self.client.post(ARENA_START, {}, format="json")
        key = start.data["battle"]["battle_key"]
        self._force_end(key, score=3)
        finish = self.client.post(ARENA_FINISH, {"battle_key": key}, format="json")
        self.assertIsNotNone(finish.data["rewards"]["chest"])
        index = finish.data["rewards"]["chest"]["index"]

        chests = self.client.get(CHESTS).data["slots"]
        slot = next(item for item in chests if item["index"] == index)
        self.assertEqual(slot["state"], "locked")

        self.assertEqual(self.client.post(f"/api/games/chests/{index}/start/", {}, format="json").status_code, 200)
        db_slot = ChestSlot.objects.get(profile=self.profile, index=index)
        db_slot.ready_at = timezone.now() - timedelta(seconds=1)
        db_slot.save(update_fields=["ready_at"])

        ready = self.client.get(CHESTS).data["slots"]
        self.assertEqual(next(item for item in ready if item["index"] == index)["state"], "ready")

        coins_before = GameProfile.objects.get(pk=self.profile.pk).coins
        claim = self.client.post(f"/api/games/chests/{index}/claim/", {}, format="json")
        self.assertEqual(claim.status_code, 200)
        self.assertGreater(claim.data["rewards"]["coins"], 0)
        coins_after = GameProfile.objects.get(pk=self.profile.pk).coins
        self.assertEqual(coins_after, coins_before + claim.data["rewards"]["coins"])

        duplicate = self.client.post(f"/api/games/chests/{index}/claim/", {}, format="json")
        self.assertEqual(duplicate.status_code, 400)
        self.assertEqual(GameProfile.objects.get(pk=self.profile.pk).coins, coins_after)

    def test_league_journey_win_updates_league_and_progress(self):
        profile = GameProfile.objects.get(pk=self.profile.pk)
        profile.trophies = 195
        profile.save(update_fields=["trophies"])

        start = self.client.post(ARENA_START, {}, format="json")
        key = start.data["battle"]["battle_key"]
        self._force_end(key, score=1)
        finish = self.client.post(ARENA_FINISH, {"battle_key": key}, format="json")
        self.assertEqual(finish.status_code, 200)
        self.assertTrue(finish.data["rewards"]["promoted"])
        self.assertEqual(finish.data["rewards"]["trophies_before"], 195)
        self.assertEqual(finish.data["rewards"]["trophies_after"], 224)

        league = self.client.get(LEAGUE).data
        self.assertEqual(league["league"]["index"], 1)
        self.assertEqual(league["league"]["name"], R.LEAGUES[1]["name"])
        self.assertEqual(league["best_trophies"], 224)

    def test_wallet_ledger_stays_consistent_across_journey(self):
        start = self.client.post(ARENA_START, {}, format="json")
        key = start.data["battle"]["battle_key"]
        self._force_end(key, score=3)
        self.client.post(ARENA_FINISH, {"battle_key": key}, format="json")
        self.client.post("/api/games/chests/0/claim/", {}, format="json")
        refreshed = GameProfile.objects.get(pk=self.profile.pk)
        rounded = sum(entry.delta for entry in refreshed.ledger.filter(resource="coins"))
        self.assertEqual(rounded, refreshed.coins)
        self.assertGreaterEqual(refreshed.coins, 0)
