"""JamPlay API URLs.

Included by ``backend/config/urls.py`` under the ``api/games/`` prefix.
Every path is trailing-slash compatible.
"""

from django.urls import path

from . import views

app_name = "games"

urlpatterns = [
    # Profile / catalog / league
    path("profile/", views.ProfileView.as_view(), name="profile"),
    path("catalog/", views.CatalogView.as_view(), name="catalog"),
    path("league/", views.LeagueView.as_view(), name="league"),

    # Cards & deck
    path("cards/", views.CardsView.as_view(), name="cards"),
    path("cards/upgrade/", views.CardUpgradeView.as_view(), name="card-upgrade"),
    path("deck/", views.DeckView.as_view(), name="deck"),

    # Buildings
    path("buildings/", views.BuildingsView.as_view(), name="buildings"),
    path("buildings/upgrade/", views.BuildingUpgradeView.as_view(), name="building-upgrade"),
    path("buildings/complete/", views.BuildingCompleteView.as_view(), name="building-complete"),

    # Chests
    path("chests/", views.ChestsView.as_view(), name="chests"),
    path("chests/<int:index>/start/", views.ChestStartView.as_view(), name="chest-start"),
    path("chests/<int:index>/claim/", views.ChestClaimView.as_view(), name="chest-claim"),

    # Arena
    path("arena/start/", views.ArenaStartView.as_view(), name="arena-start"),
    path("arena/action/", views.ArenaActionView.as_view(), name="arena-action"),
    path("arena/finish/", views.ArenaFinishView.as_view(), name="arena-finish"),

    # Siege
    path("siege/start/", views.SiegeStartView.as_view(), name="siege-start"),
    path("siege/action/", views.SiegeActionView.as_view(), name="siege-action"),
    path("siege/finish/", views.SiegeFinishView.as_view(), name="siege-finish"),

    # Battle history
    path("battles/", views.BattlesView.as_view(), name="battles"),
]
