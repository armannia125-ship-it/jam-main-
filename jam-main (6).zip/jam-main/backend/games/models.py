"""JamPlay persistent game state.

Design boundaries:

* The game wallet belongs to this app, never to JAM commerce. Coins and gems
  have no real-money purchase path and no player-to-player transfer.
* Balances live on ``GameProfile`` but every mutation is written through
  ``games.economy`` which appends an auditable ``LedgerEntry`` in the same
  transaction. Nothing else may update a balance field directly.
* Combat outcomes live on ``Battle`` and are settled exactly once (guarded by
  the unique ``settlement_key`` and a status transition under lock).
"""

from __future__ import annotations

import secrets

from django.conf import settings
from django.db import models
from django.utils import timezone

from . import rules


def new_battle_key() -> str:
    return "gb_" + secrets.token_hex(8)


class GameProfile(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="game_profile"
    )
    display_name = models.CharField(max_length=20, blank=True)
    coins = models.PositiveBigIntegerField(default=rules.STARTING_COINS)
    gems = models.PositiveBigIntegerField(default=rules.STARTING_GEMS)
    discovery_points = models.PositiveBigIntegerField(default=0)
    xp = models.PositiveBigIntegerField(default=0)
    trophies = models.PositiveIntegerField(default=0)
    best_trophies = models.PositiveIntegerField(default=0)

    arena_played = models.PositiveIntegerField(default=0)
    arena_wins = models.PositiveIntegerField(default=0)
    arena_crowns = models.PositiveIntegerField(default=0)
    siege_played = models.PositiveIntegerField(default=0)
    siege_wins = models.PositiveIntegerField(default=0)
    siege_stars = models.PositiveIntegerField(default=0)
    total_wins = models.PositiveIntegerField(default=0)
    first_battle_done = models.BooleanField(default=False)

    daily_gift_date = models.DateField(null=True, blank=True)
    camp_collected_at = models.DateTimeField(default=timezone.now)
    mine_collected_at = models.DateTimeField(default=timezone.now)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        indexes = [
            models.Index(fields=["-trophies"]),
            models.Index(fields=["-discovery_points"]),
        ]

    def __str__(self) -> str:
        return f"JamPlay profile for user {self.user_id}"

    @property
    def level(self) -> int:
        return rules.level_info(self.xp)["level"]

    def resolved_name(self) -> str:
        if self.display_name:
            return self.display_name
        return f"کاشف {self.user_id}"


class LedgerEntry(models.Model):
    """Append-only audit trail for every resource mutation."""

    class Resource(models.TextChoices):
        COINS = "coins", "Coins"
        GEMS = "gems", "Gems"
        XP = "xp", "XP"
        TROPHIES = "trophies", "Trophies"
        DISCOVERY_POINTS = "discovery_points", "Discovery points"

    class Reason(models.TextChoices):
        STARTING_GRANT = "starting_grant", "Starting grant"
        BATTLE_REWARD = "battle_reward", "Battle reward"
        BATTLE_TROPHY = "battle_trophy", "Battle trophy change"
        CHEST_REWARD = "chest_reward", "Chest reward"
        CHEST_SPEEDUP = "chest_speedup", "Chest speed-up"
        CARD_UPGRADE = "card_upgrade", "Card upgrade"
        BUILDING_UPGRADE = "building_upgrade", "Building upgrade"
        BUILDING_SPEEDUP = "building_speedup", "Building speed-up"
        BASE_COLLECTION = "base_collection", "Base collection"
        DAILY_GIFT = "daily_gift", "Daily gift"
        LEVEL_UP = "level_up", "Level up bonus"

    profile = models.ForeignKey(GameProfile, on_delete=models.CASCADE, related_name="ledger")
    resource = models.CharField(max_length=20, choices=Resource.choices)
    delta = models.BigIntegerField()
    balance_after = models.BigIntegerField()
    reason = models.CharField(max_length=32, choices=Reason.choices)
    reference = models.CharField(max_length=80, blank=True)
    idempotency_key = models.CharField(max_length=96, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        constraints = [
            models.UniqueConstraint(
                fields=["profile", "idempotency_key"],
                condition=models.Q(idempotency_key__isnull=False),
                name="uniq_profile_idempotency_key",
            )
        ]
        indexes = [models.Index(fields=["profile", "resource", "-created_at"])]

    def __str__(self) -> str:
        return f"{self.profile_id} {self.resource} {self.delta:+d} ({self.reason})"


class PlayerCard(models.Model):
    profile = models.ForeignKey(GameProfile, on_delete=models.CASCADE, related_name="cards")
    card_key = models.CharField(max_length=32)
    level = models.PositiveSmallIntegerField(default=1)
    copies = models.PositiveIntegerField(default=0)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["profile", "card_key"], name="uniq_profile_card")
        ]

    def __str__(self) -> str:
        return f"{self.card_key} lvl {self.level}"


class DeckCard(models.Model):
    profile = models.ForeignKey(GameProfile, on_delete=models.CASCADE, related_name="deck")
    slot = models.PositiveSmallIntegerField()
    card_key = models.CharField(max_length=32)

    class Meta:
        ordering = ["slot"]
        constraints = [
            models.UniqueConstraint(fields=["profile", "slot"], name="uniq_deck_slot"),
            models.UniqueConstraint(fields=["profile", "card_key"], name="uniq_deck_card"),
        ]

    def __str__(self) -> str:
        return f"slot {self.slot}: {self.card_key}"


class Building(models.Model):
    profile = models.ForeignKey(GameProfile, on_delete=models.CASCADE, related_name="buildings")
    key = models.CharField(max_length=16)
    building_type = models.CharField(max_length=16)
    grid_x = models.PositiveSmallIntegerField()
    grid_y = models.PositiveSmallIntegerField()
    level = models.PositiveSmallIntegerField(default=1)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["profile", "key"], name="uniq_profile_building")
        ]
        ordering = ["key"]

    def __str__(self) -> str:
        return f"{self.key} lvl {self.level}"


class BuilderJob(models.Model):
    """The single builder shared by every building (prototype rule)."""

    profile = models.OneToOneField(
        GameProfile, on_delete=models.CASCADE, related_name="builder_job"
    )
    building_key = models.CharField(max_length=16)
    started_at = models.DateTimeField(default=timezone.now)
    finish_at = models.DateTimeField()

    def __str__(self) -> str:
        return f"builder -> {self.building_key} @ {self.finish_at:%H:%M}"


class ChestSlot(models.Model):
    class State(models.TextChoices):
        EMPTY = "empty", "Empty"
        LOCKED = "locked", "Locked"
        OPENING = "opening", "Opening"
        READY = "ready", "Ready"

    profile = models.ForeignKey(GameProfile, on_delete=models.CASCADE, related_name="chests")
    index = models.PositiveSmallIntegerField()
    kind = models.CharField(max_length=16)
    state = models.CharField(max_length=10, choices=State.choices, default=State.LOCKED)
    ready_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["index"]
        constraints = [
            models.UniqueConstraint(fields=["profile", "index"], name="uniq_chest_slot")
        ]

    def __str__(self) -> str:
        return f"chest {self.index} {self.kind} {self.state}"


class Battle(models.Model):
    class Mode(models.TextChoices):
        ARENA = "arena", "Arena"
        SIEGE = "siege", "Siege"

    class Status(models.TextChoices):
        ACTIVE = "active", "Active"
        SETTLED = "settled", "Settled"
        ABANDONED = "abandoned", "Abandoned"

    class Result(models.TextChoices):
        WIN = "win", "Win"
        LOSS = "loss", "Loss"
        DRAW = "draw", "Draw"

    key = models.CharField(max_length=24, unique=True, default=new_battle_key)
    profile = models.ForeignKey(GameProfile, on_delete=models.CASCADE, related_name="battles")
    mode = models.CharField(max_length=8, choices=Mode.choices)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.ACTIVE)
    engine_version = models.CharField(max_length=32, default=rules.ENGINE_VERSION)
    seed = models.BigIntegerField()
    config = models.JSONField(default=dict)
    actions = models.JSONField(default=list, blank=True)
    # Authoritative engine snapshot; clients only ever render this.
    state = models.JSONField(default=dict, blank=True)
    last_tick = models.IntegerField(default=0)
    opponent_name = models.CharField(max_length=32, blank=True)
    difficulty = models.CharField(max_length=8, blank=True)

    result = models.CharField(max_length=6, choices=Result.choices, blank=True)
    score = models.PositiveSmallIntegerField(default=0)
    destruction = models.PositiveSmallIntegerField(default=0)
    rewards = models.JSONField(default=dict, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    settled_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        indexes = [
            models.Index(fields=["profile", "-created_at"]),
            models.Index(fields=["profile", "status"]),
        ]

    def __str__(self) -> str:
        return f"{self.mode} battle {self.key} ({self.status})"
