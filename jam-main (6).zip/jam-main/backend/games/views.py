"""JamPlay API views.

Thin, ownership-scoped HTTP endpoints over ``games.services``. Every endpoint
requires authentication; the requested profile is always resolved from
``request.user`` so one player can never read or mutate another's game state.
Errors use the JAM structured shape ``{"detail", "code"}`` with Persian copy.
"""

from __future__ import annotations

from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from . import combat, rules as R
from .services import (
    arena_action,
    battles_payload,
    buildings_payload,
    cards_payload,
    chests_payload,
    claim_chest,
    complete_building_upgrade,
    deck_payload,
    finish_battle,
    get_profile,
    league_payload,
    profile_payload,
    set_deck,
    siege_action,
    start_arena,
    start_building_upgrade,
    start_chest,
    start_siege,
    upgrade_card,
)


def _error(detail: str, code: str, http_status=status.HTTP_400_BAD_REQUEST, **extra) -> Response:
    return Response({"detail": detail, "code": code, **extra}, status=http_status)


class BaseGameView(APIView):
    permission_classes = [IsAuthenticated]

    def profile(self, request):
        return get_profile(request.user)


# ---------------------------------------------------------------------------
# Profile / catalog
# ---------------------------------------------------------------------------


class ProfileView(BaseGameView):
    def get(self, request):
        profile = self.profile(request)
        return Response(
            {
                **profile_payload(profile),
                "deck": deck_payload(profile),
                "cards": cards_payload(profile),
            }
        )


class CatalogView(BaseGameView):
    def get(self, request):
        return Response(R.catalog())


class LeagueView(BaseGameView):
    def get(self, request):
        profile = self.profile(request)
        return Response(
            {
                "trophies": profile.trophies,
                "best_trophies": profile.best_trophies,
                "league": league_payload(profile.trophies),
                "thresholds": list(R.LEAGUES),
            }
        )


# ---------------------------------------------------------------------------
# Cards & deck
# ---------------------------------------------------------------------------


class CardsView(BaseGameView):
    def get(self, request):
        return Response({"cards": cards_payload(self.profile(request))})


class CardUpgradeView(BaseGameView):
    def post(self, request):
        card_key = request.data.get("card_key")
        if not card_key:
            return _error("کارت را مشخص کن.", "card_key_required")
        result = upgrade_card(self.profile(request), str(card_key))
        if result.get("ok"):
            return Response(result)
        return _error(result.get("detail", "ارتقای کارت ممکن نشد."), result.get("code", "card_upgrade_failed"))


class DeckView(BaseGameView):
    def get(self, request):
        profile = self.profile(request)
        return Response({"deck": deck_payload(profile)})

    def post(self, request):
        keys = request.data.get("cards") or request.data.get("deck") or []
        result = set_deck(self.profile(request), [str(k) for k in keys])
        if result.get("ok"):
            return Response({"deck": result["deck"]})
        return _error(result.get("detail", "دسته نامعتبر است."), result.get("code", "deck_invalid"), **{
            k: v for k, v in result.items() if k not in ("ok", "detail", "code")
        })


# ---------------------------------------------------------------------------
# Buildings
# ---------------------------------------------------------------------------


class BuildingsView(BaseGameView):
    def get(self, request):
        return Response(buildings_payload(self.profile(request)))


class BuildingUpgradeView(BaseGameView):
    def post(self, request):
        building_key = request.data.get("building_key")
        if not building_key:
            return _error("ساختمان را مشخص کن.", "building_key_required")
        result = start_building_upgrade(self.profile(request), str(building_key))
        if result.get("ok"):
            return Response(result)
        return _error(result.get("detail", "ارتقا ممکن نشد."), result.get("code", "upgrade_failed"), **{
            k: v for k, v in result.items() if k in ("cost", "remaining_seconds")
        })


class BuildingCompleteView(BaseGameView):
    def post(self, request):
        building_key = request.data.get("building_key")
        if not building_key:
            return _error("ساختمان را مشخص کن.", "building_key_required")
        result = complete_building_upgrade(self.profile(request), str(building_key))
        if result.get("ok"):
            return Response(result)
        return _error(result.get("detail", "تکمیل ارتقا ممکن نشد."), result.get("code", "complete_failed"), **{
            k: v for k, v in result.items() if k in ("remaining_seconds",)
        })


# ---------------------------------------------------------------------------
# Chests
# ---------------------------------------------------------------------------


class ChestsView(BaseGameView):
    def get(self, request):
        return Response(chests_payload(self.profile(request)))


class ChestStartView(BaseGameView):
    def post(self, request, index: int):
        result = start_chest(self.profile(request), index)
        if result.get("ok"):
            return Response(result)
        return _error(result.get("detail", "شروع باز کردن صندوق ممکن نشد."), result.get("code", "chest_start_failed"))


class ChestClaimView(BaseGameView):
    def post(self, request, index: int):
        result = claim_chest(self.profile(request), index)
        if result.get("ok"):
            return Response(result)
        return _error(result.get("detail", "دریافت صندوق ممکن نشد."), result.get("code", "chest_claim_failed"))


# ---------------------------------------------------------------------------
# Arena
# ---------------------------------------------------------------------------


class ArenaStartView(BaseGameView):
    def post(self, request):
        result = start_arena(self.profile(request))
        return Response(result, status=status.HTTP_201_CREATED)


class ArenaActionView(BaseGameView):
    def post(self, request):
        battle_key = request.data.get("battle_key")
        if not battle_key:
            return _error("نبرد را مشخص کن.", "battle_key_required")
        try:
            elapsed = float(request.data.get("elapsed", 0))
        except (TypeError, ValueError):
            return _error("زمان نبرد نامعتبر است.", "invalid_elapsed")
        index = request.data.get("index")
        x = request.data.get("x")
        y = request.data.get("y")
        try:
            index = int(index) if index is not None else None
            x = float(x) if x is not None else None
            y = float(y) if y is not None else None
        except (TypeError, ValueError):
            return _error("استقرار نامعتبر است.", "invalid_deploy")
        result = arena_action(self.profile(request), str(battle_key), elapsed, index, x, y)
        if result.get("ok"):
            return Response(result)
        return _error(result.get("detail", "نبرد در دسترس نیست."), result.get("code", "battle_error"), **{
            k: v for k, v in result.items() if k == "battle"
        })


class ArenaFinishView(BaseGameView):
    def post(self, request):
        battle_key = request.data.get("battle_key")
        if not battle_key:
            return _error("نبرد را مشخص کن.", "battle_key_required")
        result = finish_battle(self.profile(request), str(battle_key))
        if result.get("ok"):
            return Response(result)
        return _error(result.get("detail", "ثبت نتیجه ممکن نشد."), result.get("code", "finish_failed"))


# ---------------------------------------------------------------------------
# Siege
# ---------------------------------------------------------------------------


class SiegeStartView(BaseGameView):
    def post(self, request):
        result = start_siege(self.profile(request))
        return Response(result, status=status.HTTP_201_CREATED)


class SiegeActionView(BaseGameView):
    def post(self, request):
        battle_key = request.data.get("battle_key")
        if not battle_key:
            return _error("نبرد را مشخص کن.", "battle_key_required")
        try:
            elapsed = float(request.data.get("elapsed", 0))
        except (TypeError, ValueError):
            return _error("زمان نبرد نامعتبر است.", "invalid_elapsed")
        index = request.data.get("index")
        gx = request.data.get("gx")
        gy = request.data.get("gy")
        try:
            index = int(index) if index is not None else None
            gx = float(gx) if gx is not None else None
            gy = float(gy) if gy is not None else None
        except (TypeError, ValueError):
            return _error("استقرار نامعتبر است.", "invalid_deploy")
        result = siege_action(self.profile(request), str(battle_key), elapsed, index, gx, gy)
        if result.get("ok"):
            return Response(result)
        return _error(result.get("detail", "نبرد در دسترس نیست."), result.get("code", "battle_error"), **{
            k: v for k, v in result.items() if k == "battle"
        })


class SiegeFinishView(BaseGameView):
    def post(self, request):
        battle_key = request.data.get("battle_key")
        if not battle_key:
            return _error("نبرد را مشخص کن.", "battle_key_required")
        result = finish_battle(self.profile(request), str(battle_key))
        if result.get("ok"):
            return Response(result)
        return _error(result.get("detail", "ثبت نتیجه ممکن نشد."), result.get("code", "finish_failed"))


# ---------------------------------------------------------------------------
# Battle history
# ---------------------------------------------------------------------------


class BattlesView(BaseGameView):
    def get(self, request):
        return Response({"battles": battles_payload(self.profile(request))})
